package kaze.module;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import kaze.event.EventListener;
import kaze.event.events.KeyEvent;
import kaze.event.events.MouseButtonEvent;
import kaze.module.modules.client.Kaze;
import kaze.module.setting.BindSetting;
import kaze.utils.EncryptedString;
import net.minecraft.client.gui.screen.ChatScreen;
import kaze.feature.KazeClickGuiScreen;
import kaze.feature.AnchorMacroModule;
import kaze.feature.AutoCrystalModule;
import kaze.feature.AutoInvTotemModule;
import kaze.feature.AutoTotemModule;
import kaze.feature.DoubleAnchorModule;
import kaze.feature.ElytraSwapModule;
import kaze.feature.HitboxModule;
import kaze.feature.HoverTotemModule;
import kaze.feature.MaceSwapModule;
import kaze.feature.StaticHitboxesModule;
import kaze.feature.AntiTrapModule;
import kaze.feature.AntiVanishModule;
import kaze.feature.AuctionSniperModule;
import kaze.feature.AutoRtpModule;
import kaze.feature.AutoSellModule;
import kaze.feature.AutoSpawnerSellModule;
import kaze.feature.SpawnerDropperModule;
import kaze.feature.ChunkFinderModule;
import kaze.feature.ChunkFinderBetterModule;
import kaze.feature.ChunkFinderFastModule;
import kaze.feature.FakeScoreboardModule;
import kaze.feature.LuckyFinderModule;
import kaze.feature.NetheriteFinderModule;
import kaze.feature.OgScoreboardModule;
import kaze.feature.PlayerBypassModule;
import kaze.feature.PrimeChunkFinderModule;
import kaze.feature.RegionMapModule;
import kaze.feature.RtpBaseFinderModule;
import kaze.feature.ShulkerDropperModule;
import kaze.feature.SpawnerOrderModule;
import kaze.feature.StaffListModule;
import kaze.feature.SusChunkFinderModule;
import kaze.feature.SusChunkV2Module;
import kaze.feature.TunnelBaseFinderModule;
import kaze.feature.SpawnerProtectModule;
import kaze.feature.AutoEatModule;
import kaze.feature.AutoFireworkModule;
import kaze.feature.AutoMineModule;
import kaze.feature.AutoTpaModule;
import kaze.feature.AutoToolModule;
import kaze.feature.CordSnapperModule;
import kaze.feature.ElytraGlideModule;
import kaze.feature.FakePayModule;
import kaze.feature.FastPlaceModule;
import kaze.feature.FreecamModule;
import kaze.feature.FreelookModule;
import kaze.feature.NameProtectModule;
import kaze.feature.PlayerDetectionModule;
import kaze.feature.SkinProtectModule;
import kaze.feature.SwingSpeedModule;
import kaze.feature.BedrockEspModule;
import kaze.feature.BlockEspModule;
import kaze.feature.BlockNotifierModule;
import kaze.feature.BlockOverlayModule;
import kaze.feature.CustomSkysModule;
import kaze.feature.CustomToolsModule;
import kaze.feature.CustomTotemModule;
import kaze.feature.HudModule;
import kaze.feature.HalloweenModule;
import kaze.feature.HandAuraModule;
import kaze.feature.ItemOutlineModule;
import kaze.feature.PlayerEspModule;
import kaze.feature.SpawnerNotifyModule;
import kaze.feature.StorageEspModule;
import kaze.feature.TargetHudModule;
import kaze.feature.Character3dModule;

public final class ModuleManager {
   private final List<Module> modules = new ArrayList<>();
   private final Map<Class<?>, Module> modulesByClass = new HashMap<>();
   private final Map<Category, List<Module>> modulesByCategory = new EnumMap<>(Category.class);

   public ModuleManager() {
      this.a();
      this.d();
   }

   public void a() {
      this.a(new ElytraSwapModule());
      this.a(new MaceSwapModule());
      this.a(new HitboxModule());
      this.a(new StaticHitboxesModule());
      this.a(new AutoTotemModule());
      this.a(new HoverTotemModule());
      this.a(new AutoInvTotemModule());
      this.a(new AnchorMacroModule());
      this.a(new AutoCrystalModule());
      this.a(new DoubleAnchorModule());
      this.a(new FastPlaceModule());
      this.a(new FreecamModule());
      this.a(new FreelookModule());
      this.a(new AutoFireworkModule());
      this.a(new ElytraGlideModule());
      this.a(new AutoToolModule());
      this.a(new SwingSpeedModule());
      this.a(new AutoEatModule());
      this.a(new AutoMineModule());
      this.a(new CordSnapperModule());
      this.a(new NameProtectModule());
      this.a(new SkinProtectModule());
      this.a(new PlayerDetectionModule());
      this.a(new FakePayModule());
      this.macro(new AutoTpaModule());
      this.macro(new AutoRtpModule());
      this.macro(new SpawnerProtectModule());
      this.a(new ChunkFinderModule());
      this.a(new SpawnerOrderModule());
      this.a(new RtpBaseFinderModule());
      this.a(new TunnelBaseFinderModule());
      this.a(new NetheriteFinderModule());
      this.macro(new SpawnerDropperModule());
      this.macro(new AutoSellModule());
      this.macro(new ShulkerDropperModule());
      this.a(new AntiTrapModule());

      try {
         this.macro(new AuctionSniperModule());
      } catch (RuntimeException var3) {
         System.err.println("Kaze: Auction Sniper unavailable: " + var3.getMessage());
      }

      this.macro(new AutoSpawnerSellModule());
      this.a(new FakeScoreboardModule());
      this.a(new OgScoreboardModule());
      this.a(new RegionMapModule());
      this.a(new PlayerBypassModule());
      this.a(new SusChunkFinderModule());
      this.a(new SusChunkV2Module());
      this.a(new ChunkFinderBetterModule());
      this.a(new ChunkFinderFastModule());
      this.safe("Prime Chunk Finder", PrimeChunkFinderModule::new);
      this.safe("Anti Vanish", AntiVanishModule::new);
      this.safe("Halloween", HalloweenModule::new);
      this.safe("Custom Totem", CustomTotemModule::new);
      this.safe("Custom Tools", CustomToolsModule::new);
      this.a(new PlayerEspModule());
      this.a(new StorageEspModule());
      this.a(new BlockEspModule());
      this.a(new BlockNotifierModule());
      this.a(new BedrockEspModule());
      this.a(new SpawnerNotifyModule());
      this.a(new TargetHudModule());
      this.safe("3D Character", Character3dModule::new);
      this.safe("Custom Skys", CustomSkysModule::new);
      this.safe("Block Overlay", BlockOverlayModule::new);
      this.safe("Hand Aura", HandAuraModule::new);
      this.a(new Kaze());
      this.a(new HudModule());

      try {
         this.a(new ItemOutlineModule());
      } catch (Throwable var2) {
         System.err.println("Kaze: Item Outline unavailable: " + var2.getClass().getSimpleName());
      }

      this.a(new LuckyFinderModule());
      this.a(new StaffListModule());
   }

   public List<Module> b() {
      return this.modules.stream().filter(Module::isEnabled).toList();
   }

   public List<Module> c() {
      return this.modules;
   }

   public void d() {
      kaze.Kaze.INSTANCE.getEventBus().register(this);

      for (Module var2 : this.modules) {
         var2.addSetting(
            new BindSetting(EncryptedString.of("Keybind"), var2.getKeybind(), true).setDescription(EncryptedString.of("Key to enabled the module"))
         );
      }
   }

   public List<Module> a(Category var1) {
      return this.modulesByCategory.getOrDefault(var1, List.of());
   }

   public Module getModuleByClass(Class<? extends Module> var1) {
      Module var2 = this.modulesByClass.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         for (Module var4 : this.modules) {
            if (var1.isInstance(var4)) {
               return var4;
            }
         }

         return null;
      }
   }

   private void safe(String var1, Supplier<? extends Module> var2) {
      try {
         this.a((Module)var2.get());
      } catch (Throwable var4) {
         System.err.println("Kaze: " + var1 + " unavailable: " + var4);
         var4.printStackTrace(System.err);
      }
   }

   private void macro(Module var1) {
      var1.setCategory(Category.MACROS);
      this.a(var1);
   }

   public void a(Module var1) {
      // Keep only the requested finder modules in the renamed "Base finding" tab.
      // Any other module that previously belonged to Donut is moved to the renamed "Donut" tab.
      if (var1.getCategory() == Category.DONUT && !isBaseFindingModule(var1)) {
         var1.setCategory(Category.MACROS);
      }

      kaze.Kaze.INSTANCE.getEventBus().register(var1);
      this.modules.add(var1);
      this.modulesByClass.put(var1.getClass(), var1);
      this.modulesByCategory.computeIfAbsent(var1.getCategory(), var0 -> new ArrayList<>()).add(var1);
   }

   private static boolean isBaseFindingModule(Module module) {
      String name = module.getName() == null ? "" : module.getName().toString();
      String normalized = name.trim().toLowerCase(java.util.Locale.ROOT).replace('_', ' ').replace('-', ' ');
      return switch (normalized) {
         case "chunk finder", "chunk finder better", "chunk finder fast", "prime chunk finder", "sus chunk finder",
              "sus chunk v2", "lucky finder", "netherite finder", "rtp base finder",
              "tunnel base finder", "player bypass" -> true;
         default -> false;
      };
   }

   @EventListener
   public void a(KeyEvent var1) {
      if (var1.mode == 1 && (kaze.Kaze.mc == null || !(kaze.Kaze.mc.currentScreen instanceof KazeClickGuiScreen var2) || !var2.isTyping())) {
         this.modules
            .forEach(
               var1x -> {
                  boolean var2x;
                  if (var1x.getKeybind() == var1.key
                     && (
                        (var2x = var1x instanceof Kaze)
                           || kaze.Kaze.mc.player != null && kaze.Kaze.mc.options != null && !(kaze.Kaze.mc.currentScreen instanceof ChatScreen)
                     )) {
                     var1x.toggle();
                  }
               }
            );
      }
   }

   @EventListener
   public void onMouseButton(MouseButtonEvent var1) {
      if (var1.actions == 1
         && var1.button >= 0
         && var1.button <= 7
         && !(kaze.Kaze.mc.currentScreen instanceof KazeClickGuiScreen)
         && !(kaze.Kaze.mc.currentScreen instanceof ChatScreen)) {
         this.modules
            .forEach(
               var1x -> {
                  boolean var2;
                  if (var1x.getKeybind() == var1.button
                     && ((var2 = var1x instanceof Kaze) || kaze.Kaze.mc.player != null && kaze.Kaze.mc.options != null)) {
                     var1x.toggle();
                  }
               }
            );
      }
   }
}
