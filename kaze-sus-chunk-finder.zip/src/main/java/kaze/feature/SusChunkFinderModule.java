package kaze.feature;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import kaze.event.EventListener;
import kaze.event.events.Render3DEvent;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.ModeSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.RgbSetting;
import kaze.module.setting.SettingVisibility;
import kaze.utils.EncryptedString;
import kaze.utils.RenderUtils;
import kaze.utils.RenderVisibility;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Sus Chunk Finder (3-in-1).
 *
 *  - Core: "heat" from fully grown plants/amethyst, ignores areas that are currently loaded,
 *    buried rotated deepslate, smart zones.
 *  - From VulxtsSusChunk: weighted score (amethyst bud/cluster, kelp, bamboo, vines) as a second detection channel.
 *  - From WaterSusChunk: chunks with >= 10 chests/trapped chests below Y 0 become "base hits" (blinking).
 *
 * Three scan channels can be toggled: Scan Growth Heat, Scan Weighted Score, Scan Underground Chests.
 * The score channel shares the Kelp/Vines/Amethyst/Bamboo toggles and Sensitivity with the heat channel.
 */
public final class SusChunkFinderModule extends Module {
    // ---- constants from VulxtsSusChunk / WaterSusChunk ----
    private static final int[] THRESHOLDS = {25, 32, 39, 46, 54, 61, 68, 75, 82, 89, 96, 104, 111, 118, 125};
    private static final int CHEST_BASE_MIN = 10;
    private static final int MAX_COLUMN = 32;

    public enum ShapeMode {
        SIDES("Sides"), LINES("Lines"), BOTH("Both");

        private final String label;

        ShapeMode(String label) {
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    private record Opts(boolean kelp, boolean caveVines, boolean vines, boolean amethyst, boolean folia,
                        boolean bamboo, boolean cocoa, boolean beeNest, boolean deepslate,
                        boolean heat, boolean score, boolean chests) {}

    private record ScanResult(int notGrown, boolean hasGrown, Set<BlockPos> deepslate, int score, boolean base) {}

    private record Zone(double centerX, double centerZ, int size, int maxHeat, int level) {}

    // ---- settings: general ----
    private final NumberSetting simulationDistance = new NumberSetting(EncryptedString.of("Simulation Distance"), 0, 10, 4, 1)
        .getValue(EncryptedString.of("Chunk radius around growing plants that is considered 'currently loaded' and ignored. 0 = only the chunk the plants are in, 1 = 3x3 chunks, 2 = 5x5."));
    private final NumberSetting sensitivity = new NumberSetting(EncryptedString.of("Sensitivity"), 1, 20, 5, 1)
        .getValue(EncryptedString.of("Minimum number of unfinished growing things needed to mark a chunk as sus."));
    private final BooleanSetting smartAdjustment = new BooleanSetting(EncryptedString.of("Smart Adjustment"), true)
        .setDescription(EncryptedString.of("Groups nearby sus chunks into zones, drops lone weak chunks, rates each zone (low/medium/high confidence) and draws stronger zones brighter. Only draws chunks inside your render distance. Never changes your sensitivity."));
    private final BooleanSetting noiseFilter = new BooleanSetting(EncryptedString.of("Noise Filter"), true)
        .setDescription(EncryptedString.of("Smart mode: a single sus chunk with nobody else around is only shown if its heat is at least double your sensitivity. Removes most false positives."));
    private final BooleanSetting zoneMarker = new BooleanSetting(EncryptedString.of("Zone Marker"), true)
        .setDescription(EncryptedString.of("Smart mode: draws a tall marker at the center of every zone so you can spot it from far away."));
    private final BooleanSetting notifyZones = new BooleanSetting(EncryptedString.of("Notify Zones"), false)
        .setDescription(EncryptedString.of("Smart mode: prints the coordinates in chat when a new high-confidence zone is found."));

    private final BooleanSetting kelp = new BooleanSetting(EncryptedString.of("Kelp"), false)
        .setDescription(EncryptedString.of("Use kelp growth."));
    private final BooleanSetting caveVines = new BooleanSetting(EncryptedString.of("Cave Vines"), false)
        .setDescription(EncryptedString.of("Use cave vine growth."));
    private final BooleanSetting vines = new BooleanSetting(EncryptedString.of("Vines"), false)
        .setDescription(EncryptedString.of("Use vine growth."));
    private final BooleanSetting amethyst = new BooleanSetting(EncryptedString.of("Amethyst"), true)
        .setDescription(EncryptedString.of("Use amethyst bud and cluster growth."));
    private final BooleanSetting bamboo = new BooleanSetting(EncryptedString.of("Bamboo"), false)
        .setDescription(EncryptedString.of("Use bamboo growth."));
    private final BooleanSetting cocoa = new BooleanSetting(EncryptedString.of("Cocoa"), false)
        .setDescription(EncryptedString.of("Use cocoa pod growth."));
    private final BooleanSetting beeNest = new BooleanSetting(EncryptedString.of("Bee Nest"), false)
        .setDescription(EncryptedString.of("Bee nests with honey mean someone loaded the chunk."));
    private final BooleanSetting rotatedDeepslate = new BooleanSetting(EncryptedString.of("Rotated Deepslate"), false)
        .setDescription(EncryptedString.of("Detect rotated deepslate buried between Y 0 and 60."));

    private final BooleanSetting growthHeat = new BooleanSetting(EncryptedString.of("Scan Growth Heat"), true)
        .setDescription(EncryptedString.of("Channel 1: heat from fully grown plants/amethyst (original Sus Chunk Finder logic)."));
    private final BooleanSetting weightedScore = new BooleanSetting(EncryptedString.of("Scan Weighted Score"), true)
        .setDescription(EncryptedString.of("Channel 2: weighted score of amethyst buds/clusters, tall kelp, bamboo and vines (Vulxts logic). Uses the amethyst/kelp/bamboo/vines toggles above."));
    private final BooleanSetting undergroundChests = new BooleanSetting(EncryptedString.of("Scan Underground Chests"), true)
        .setDescription(EncryptedString.of("Channel 3: chunks with 10+ chests below Y 0 are marked as base hits (Water logic)."));
    private final BooleanSetting debugInfo = new BooleanSetting(EncryptedString.of("Debug Info"), false)
        .setDescription(EncryptedString.of("Every 2 seconds, prints the numbers behind the chunk you are standing in (heat, tracked, loaded neighbors)."));

    // ---- settings: render ----
    private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), 10, 255, 81, 1)
        .getValue(EncryptedString.of("Opacity (10-255) of the chunk fill and the deepslate boxes."));
    private final ModeSetting<ShapeMode> chunkShapeMode = new ModeSetting<>(EncryptedString.of("Chunk Shape Mode"), ShapeMode.SIDES, ShapeMode.class);
    private final RgbSetting chunkSideColor = new RgbSetting(EncryptedString.of("Chunk Fill Color"), argb(110, 255, 0, 0));
    private final RgbSetting chunkLineColor = new RgbSetting(EncryptedString.of("Chunk Outline Color"), argb(200, 255, 0, 0));
    private final NumberSetting chunkY = new NumberSetting(EncryptedString.of("Chunk Y"), -64, 128, 63, 1)
        .getValue(EncryptedString.of("Height the chunk square is drawn at."));
    private final NumberSetting chunkThickness = new NumberSetting(EncryptedString.of("Chunk Thickness"), 0.05, 16.0, 0.1, 0.05)
        .getValue(EncryptedString.of("Thickness of the chunk box in blocks. Small = flat square, larger = tall column."));
    private final NumberSetting chunkInset = new NumberSetting(EncryptedString.of("Chunk Inset"), 0, 7, 2, 1)
        .getValue(EncryptedString.of("Shrinks each chunk square by this many blocks on every side so neighbors don't merge into one big sheet."));
    private final RgbSetting deepslateColor = new RgbSetting(EncryptedString.of("Deepslate Color"), argb(160, 0, 255, 255));
    private final NumberSetting deepslateDistance = new NumberSetting(EncryptedString.of("Deepslate Render Distance"), 16, 256, 64, 1)
        .getValue(EncryptedString.of("Only draw suspicious deepslate within this many blocks."));

    // ---- scan data (written by several threads, so concurrent collections) ----
    private final Map<ChunkPos, Integer> heatmap = new ConcurrentHashMap<>();
    private final Map<ChunkPos, Integer> tracked = new ConcurrentHashMap<>();
    private final Map<ChunkPos, Integer> growthCounts = new ConcurrentHashMap<>();
    private final Map<ChunkPos, Boolean> fullyGrown = new ConcurrentHashMap<>();
    private final Map<ChunkPos, Integer> usedSimDist = new ConcurrentHashMap<>();
    private final Map<ChunkPos, Integer> scoreMap = new ConcurrentHashMap<>();           // Vulxts channel
    private final Set<ChunkPos> baseHits = ConcurrentHashMap.newKeySet();                // Water channel (chests)
    private final Map<ChunkPos, Set<BlockPos>> chunkDeepslate = new ConcurrentHashMap<>();
    private final Set<ChunkPos> loadedChunks = ConcurrentHashMap.newKeySet();
    private final Set<BlockPos> deepslateSet = ConcurrentHashMap.newKeySet();

    private volatile Map<ChunkPos, Integer> susChunks = Map.of();
    private volatile Map<ChunkPos, Integer> susLevel = Map.of();
    private volatile List<Zone> zones = List.of();
    private volatile List<BlockPos> deepslateBlocks = List.of();
    private volatile Set<ChunkPos> baseSnapshot = Set.of();
    private final Set<Long> notifiedZones = new HashSet<>();

    private ExecutorService[] executors;
    private ClientWorld lastWorld;
    private Opts lastOpts;
    private int lastSim = -1;
    private int timer;
    private final Map<ChunkPos, WorldChunk> seenChunks = new HashMap<>();

    private final List<RenderUtils.ColoredBox> renderBoxes = new ArrayList<>();
    private final List<RenderUtils.ColoredLine> renderLines = new ArrayList<>();

    public SusChunkFinderModule() {
        super(
            EncryptedString.of("Sus Chunk Finder"),
            EncryptedString.of("Finds probable base locations using plant/amethyst growth, rotated deepslate and underground chests."),
            -1,
            Category.DONUT
        );

        chunkShapeMode.setDescription(EncryptedString.of("How sus chunks are drawn. Sides = filled flat square, Lines = outline only, Both = filled with outline."));
        chunkSideColor.setDescription(EncryptedString.of("Fill color of sus chunks (opacity comes from the Alpha setting)."));
        chunkLineColor.setDescription(EncryptedString.of("Outline color of sus chunks."));
        deepslateColor.setDescription(EncryptedString.of("Outline color of suspicious rotated deepslate blocks."));

        SettingVisibility.set(noiseFilter, smartAdjustment::getValue);
        SettingVisibility.set(zoneMarker, smartAdjustment::getValue);
        SettingVisibility.set(notifyZones, smartAdjustment::getValue);
        SettingVisibility.set(deepslateColor, rotatedDeepslate::getValue);
        SettingVisibility.set(deepslateDistance, rotatedDeepslate::getValue);

        addSettings(
            simulationDistance, sensitivity, smartAdjustment, noiseFilter, zoneMarker, notifyZones,
            kelp, caveVines, vines, amethyst, bamboo, cocoa, beeNest, rotatedDeepslate,
            growthHeat, weightedScore, undergroundChests, debugInfo,
            alpha, chunkShapeMode, chunkSideColor, chunkLineColor, chunkY, chunkThickness, chunkInset,
            deepslateColor, deepslateDistance
        );
    }

    private static int argb(int a, int r, int g, int b) {
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    // ====================== lifecycle ======================

    @Override
    public void onEnable() {
        restart();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        stopExecutors();
        clearData();
        super.onDisable();
    }

    private void stopExecutors() {
        if (executors != null) {
            for (ExecutorService e : executors) if (e != null) e.shutdownNow();
            executors = null;
        }
    }

    private void restart() {
        stopExecutors();
        clearData();
        int n = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() / 2));
        executors = new ExecutorService[n];
        for (int i = 0; i < n; i++) {
            final int id = i;
            executors[i] = Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "SusChunkFinder-" + id);
                t.setDaemon(true);
                return t;
            });
        }
        lastWorld = mc.world;
        lastOpts = mc.world != null ? opts() : null;
        lastSim = simulationDistance.getIntValue();
    }

    private void clearData() {
        heatmap.clear();
        tracked.clear();
        growthCounts.clear();
        fullyGrown.clear();
        usedSimDist.clear();
        scoreMap.clear();
        baseHits.clear();
        chunkDeepslate.clear();
        loadedChunks.clear();
        deepslateSet.clear();
        seenChunks.clear();
        notifiedZones.clear();
        susChunks = Map.of();
        susLevel = Map.of();
        zones = List.of();
        deepslateBlocks = List.of();
        baseSnapshot = Set.of();
    }

    private boolean isDonutFolia() {
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null) return false;
        String brand = h.getBrand();
        return brand != null && brand.contains("DonutFolia");
    }

    private Opts opts() {
        boolean am = amethyst.getValue();
        return new Opts(kelp.getValue(), caveVines.getValue(), vines.getValue(), am, am && isDonutFolia(),
            bamboo.getValue(), cocoa.getValue(), beeNest.getValue(), rotatedDeepslate.getValue(),
            growthHeat.getValue(), weightedScore.getValue(), undergroundChests.getValue());
    }

    private void info(String message) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("§6[Sus Chunk Finder] §f" + message), false);
    }

    // ====================== chunk scanning ======================

    private void scanNewChunks() {
        ClientWorld w = mc.world;
        if (w == null || mc.player == null) return;
        ChunkPos pc = mc.player.getChunkPos();
        int r = mc.options.getViewDistance().getValue() + (smartAdjustment.getValue() ? 0 : 2);

        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int cx = pc.x + dx, cz = pc.z + dz;
                if (!w.isChunkLoaded(cx, cz)) continue;
                WorldChunk c = w.getChunkManager().getWorldChunk(cx, cz);
                if (c == null) continue;
                ChunkPos p = new ChunkPos(cx, cz);
                if (seenChunks.get(p) == c) continue;
                seenChunks.put(p, c);
                queue(c);
            }
        }
        seenChunks.keySet().removeIf(p -> !w.isChunkLoaded(p.x, p.z));
    }

    private void queue(WorldChunk chunk) {
        ExecutorService[] ex = executors;
        ClientWorld world = mc.world;
        if (ex == null || chunk == null || world == null) return;
        Opts o = opts();
        int sim = simulationDistance.getIntValue();
        ChunkPos p = chunk.getPos();
        int idx = Math.floorMod(p.x * 31 + p.z, ex.length);
        try {
            ex[idx].execute(() -> {
                try {
                    updateChunk(world, chunk, o, sim);
                } catch (Throwable t) {
                    System.err.println("Kaze: Sus Chunk Finder scan failed: " + t);
                }
            });
        } catch (RuntimeException ignored) {
            // executor already shut down
        }
    }

    private static void forEachNeighbor(ChunkPos c, int r, Consumer<ChunkPos> action) {
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++)
                action.accept(new ChunkPos(c.x + dx, c.z + dz));
    }

    private void updateChunk(ClientWorld world, WorldChunk chunk, Opts o, int sim) {
        if (mc.world != world) return;
        ChunkPos pos = chunk.getPos();
        loadedChunks.add(pos);

        int prevSim = usedSimDist.getOrDefault(pos, sim);
        int prevGrowth = growthCounts.getOrDefault(pos, 0);
        boolean wasGrown = Boolean.TRUE.equals(fullyGrown.get(pos));
        Set<BlockPos> prevDeep = chunkDeepslate.remove(pos);

        // remove the old contribution
        if (prevGrowth > 0) {
            forEachNeighbor(pos, prevSim, n -> heatmap.compute(n, (k, v) -> {
                if (v == null) return null;
                int left = v - prevGrowth;
                return left > 0 ? left : null;
            }));
        }
        if (wasGrown) {
            forEachNeighbor(pos, prevSim, n -> tracked.compute(n, (k, v) -> {
                if (v == null) return null;
                return v - 1 > 0 ? v - 1 : null;
            }));
        }
        if (prevDeep != null && !prevDeep.isEmpty()) deepslateSet.removeAll(prevDeep);

        ScanResult r = scanChunk(world, chunk, pos, o);

        growthCounts.put(pos, r.notGrown());
        fullyGrown.put(pos, r.hasGrown());
        usedSimDist.put(pos, sim);

        if (r.hasGrown()) forEachNeighbor(pos, sim, n -> tracked.merge(n, 1, Integer::sum));
        if (r.notGrown() > 0) forEachNeighbor(pos, sim, n -> heatmap.merge(n, r.notGrown(), Integer::sum));

        if (r.score() > 0) scoreMap.put(pos, r.score()); else scoreMap.remove(pos);
        if (r.base()) baseHits.add(pos); else baseHits.remove(pos);

        if (!r.deepslate().isEmpty()) {
            chunkDeepslate.put(pos, r.deepslate());
            deepslateSet.addAll(r.deepslate());
        }
    }

    private static boolean isBud(BlockState s) {
        Block b = s.getBlock();
        return b == Blocks.SMALL_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.LARGE_AMETHYST_BUD;
    }

    private static boolean isCluster(BlockState s) {
        return s.getBlock() == Blocks.AMETHYST_CLUSTER;
    }

    private static boolean isRotatedDeepslate(BlockState s) {
        return s.getBlock() == Blocks.DEEPSLATE && s.contains(Properties.AXIS) && s.get(Properties.AXIS) != Direction.Axis.Y;
    }

    private static boolean isChest(BlockState s) {
        Block b = s.getBlock();
        return b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST;
    }

    private static boolean growthInterest(BlockState s, Opts o, boolean plainAmethyst) {
        Block b = s.getBlock();
        return (o.kelp() && (b == Blocks.KELP || b == Blocks.KELP_PLANT))
            || (o.caveVines() && b == Blocks.CAVE_VINES)
            || (o.vines() && b == Blocks.VINE)
            || (plainAmethyst && (isCluster(s) || isBud(s)))
            || (o.bamboo() && b == Blocks.BAMBOO)
            || (o.cocoa() && b == Blocks.COCOA)
            || (o.beeNest() && b == Blocks.BEE_NEST);
    }

    private static int columnLength(ClientWorld w, BlockPos start, Direction dir, Block... blocks) {
        BlockPos.Mutable p = start.mutableCopy();
        int n = 0;
        for (int i = 0; i < MAX_COLUMN; i++) {
            Block b = w.getBlockState(p).getBlock();
            boolean match = false;
            for (Block x : blocks) {
                if (b == x) { match = true; break; }
            }
            if (!match) break;
            n++;
            p.move(dir);
        }
        return n;
    }

    private ScanResult scanChunk(ClientWorld world, WorldChunk chunk, ChunkPos cp, Opts o) {
        ChunkSection[] sections = chunk.getSectionArray();
        int bottomSection = chunk.getBottomSectionCoord();
        int baseX = cp.getStartX(), baseZ = cp.getStartZ();
        boolean plainAmethyst = o.amethyst() && !o.folia();

        int finished = 0;       // original module's "notGrown": finished / stuck -> creates heat
        int active = 0;         // original module's "hasGrown": still growing -> area is being loaded
        boolean clusterSeen = false, budSeen = false;
        int amHits = 0, kelpHits = 0, bambooHits = 0, vineHits = 0, chests = 0;
        Set<BlockPos> deep = new HashSet<>();
        BlockPos.Mutable m = new BlockPos.Mutable();

        for (int i = 0; i < sections.length; i++) {
            ChunkSection sec = sections[i];
            if (sec == null || sec.isEmpty()) continue;
            int secY = (bottomSection + i) << 4;

            if (o.folia()) {
                if (!clusterSeen && sec.getBlockStateContainer().hasAny(SusChunkFinderModule::isCluster)) clusterSeen = true;
                if (!budSeen && sec.getBlockStateContainer().hasAny(SusChunkFinderModule::isBud)) budSeen = true;
            }

            boolean hasGrowth = (o.heat() || o.score()) && sec.getBlockStateContainer().hasAny(s -> growthInterest(s, o, plainAmethyst));
            boolean hasDeep = o.deepslate() && secY + 15 >= 0 && secY <= 60 && sec.getBlockStateContainer().hasAny(SusChunkFinderModule::isRotatedDeepslate);
            boolean hasChest = o.chests() && secY < 0 && sec.getBlockStateContainer().hasAny(SusChunkFinderModule::isChest);
            if (!hasGrowth && !hasDeep && !hasChest) continue;

            for (int lx = 0; lx < 16; lx++) {
                for (int ly = 0; ly < 16; ly++) {
                    for (int lz = 0; lz < 16; lz++) {
                        BlockState state = sec.getBlockState(lx, ly, lz);
                        Block block = state.getBlock();
                        int x = baseX + lx, y = secY + ly, z = baseZ + lz;

                        if (hasGrowth) {
                            if (!o.heat()) {
                                // heat channel off: skip
                            } else if (o.kelp() && block == Blocks.KELP && state.contains(Properties.AGE_25)) {
                                boolean water = world.getBlockState(m.set(x, y + 1, z)).isOf(Blocks.WATER);
                                if (state.get(Properties.AGE_25) == 25 || !water) finished++; else active++;
                            } else if (o.caveVines() && block == Blocks.CAVE_VINES && state.contains(Properties.AGE_25)) {
                                boolean air = world.getBlockState(m.set(x, y - 1, z)).isAir();
                                if (state.get(Properties.AGE_25) == 25 || !air) finished++; else active++;
                            } else if (o.vines() && block == Blocks.VINE) {
                                BlockState below = world.getBlockState(m.set(x, y - 1, z));
                                if (!below.isOf(Blocks.VINE)) {
                                    if (below.isAir()) {
                                        boolean side = state.get(Properties.NORTH) || state.get(Properties.EAST)
                                            || state.get(Properties.SOUTH) || state.get(Properties.WEST);
                                        if (side) active++; else finished++;
                                    } else finished++;
                                }
                            } else if (plainAmethyst && block == Blocks.AMETHYST_CLUSTER) {
                                finished++;
                            } else if (plainAmethyst && isBud(state) && state.contains(Properties.FACING)) {
                                Direction f = state.get(Properties.FACING);
                                BlockState behind = world.getBlockState(m.set(x, y, z).offset(f.getOpposite()));
                                if (behind.isOf(Blocks.BUDDING_AMETHYST)) active++; else finished++;
                            } else if (o.bamboo() && block == Blocks.BAMBOO && state.contains(Properties.AGE_1)) {
                                BlockState above = world.getBlockState(m.set(x, y + 1, z));
                                if (!above.isOf(Blocks.BAMBOO)) {
                                    if (state.get(Properties.AGE_1) == 1) finished++;
                                    else if (above.isAir()) active++;
                                }
                            } else if (o.cocoa() && block == Blocks.COCOA && state.contains(Properties.AGE_2)) {
                                if (state.get(Properties.AGE_2) == 2) finished++; else active++;
                            } else if (o.beeNest() && block == Blocks.BEE_NEST && state.contains(BeehiveBlock.HONEY_LEVEL)) {
                                if (state.get(BeehiveBlock.HONEY_LEVEL) == 5) finished++; else active++;
                            }

                            // ---- Vulxts-style weighted score (independent of heat) ----
                            if (!o.score()) {
                                // score channel off: skip
                            } else if (plainAmethyst && (block == Blocks.AMETHYST_CLUSTER || isBud(state))) {
                                amHits++;
                            } else if (o.kelp() && (block == Blocks.KELP || block == Blocks.KELP_PLANT)) {
                                Block above = world.getBlockState(m.set(x, y + 1, z)).getBlock();
                                if (above != Blocks.KELP && above != Blocks.KELP_PLANT) {
                                    int len = columnLength(world, new BlockPos(x, y, z), Direction.DOWN, Blocks.KELP, Blocks.KELP_PLANT);
                                    boolean topMax = block == Blocks.KELP && state.contains(Properties.AGE_25) && state.get(Properties.AGE_25) == 25;
                                    if (len >= (topMax ? 8 : 14)) kelpHits++;
                                }
                            } else if (o.bamboo() && block == Blocks.BAMBOO) {
                                if (!world.getBlockState(m.set(x, y - 1, z)).isOf(Blocks.BAMBOO)) {
                                    if (columnLength(world, new BlockPos(x, y, z), Direction.UP, Blocks.BAMBOO) >= 12) bambooHits++;
                                }
                            } else if (o.vines() && block == Blocks.VINE) {
                                if (!world.getBlockState(m.set(x, y + 1, z)).isOf(Blocks.VINE)) {
                                    if (columnLength(world, new BlockPos(x, y, z), Direction.DOWN, Blocks.VINE) >= 7) vineHits++;
                                }
                            }
                        }

                        // ---- fully buried rotated deepslate (Y 0..60) ----
                        if (hasDeep && isRotatedDeepslate(state) && y >= 0 && y <= 60) {
                            boolean buried = true;
                            for (Direction d : Direction.values()) {
                                if (world.getBlockState(m.set(x, y, z).offset(d)).isAir()) { buried = false; break; }
                            }
                            if (buried) deep.add(new BlockPos(x, y, z));
                        }

                        // ---- chests below Y 0 (Water style) ----
                        if (hasChest && y < 0 && isChest(state)) chests++;
                    }
                }
            }
        }

        if (o.folia() && o.heat()) {
            if (clusterSeen) active++;
            else if (budSeen) finished++;
        }

        int score = 2 * (Math.min(amHits, 64) + Math.min(kelpHits, 6) + Math.min(bambooHits, 6) + Math.min(vineHits, 6));
        return new ScanResult(finished, active > 0, deep, score, chests >= CHEST_BASE_MIN);
    }

    // ====================== tick: collect results ======================

    @EventListener
    public void onTick(TickEvent event) {
        if (mc.world == null || mc.player == null || executors == null) return;

        Opts o = opts();
        if (mc.world != lastWorld || !o.equals(lastOpts) || simulationDistance.getIntValue() != lastSim) restart();

        scanNewChunks();

        if (debugInfo.getValue() && mc.player.age % 40 == 0) printDebug();

        if (--timer > 0) return;
        timer = 2;

        ClientWorld world = mc.world;
        int sens = sensitivity.getIntValue();
        int scoreMin = THRESHOLDS[Math.min(15, Math.max(1, sens)) - 1];
        Map<ChunkPos, Integer> raw = new HashMap<>();

        // channel 1: heat (original module)
        if (growthHeat.getValue()) for (Map.Entry<ChunkPos, Integer> e : heatmap.entrySet()) {
            ChunkPos p = e.getKey();
            int heat = e.getValue();
            if (heat < sens) continue;
            if (tracked.containsKey(p)) continue;
            if (!world.isChunkLoaded(p.x, p.z)) continue;
            int n = 0;
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    if ((dx != 0 || dz != 0) && loadedChunks.contains(new ChunkPos(p.x + dx, p.z + dz))) n++;
            if (n >= 3) raw.put(p, heat);
        }

        // channel 2: weighted score (Vulxts)
        if (weightedScore.getValue()) for (Map.Entry<ChunkPos, Integer> e : scoreMap.entrySet()) {
            ChunkPos p = e.getKey();
            if (e.getValue() < scoreMin) continue;
            if (tracked.containsKey(p)) continue;
            if (!world.isChunkLoaded(p.x, p.z)) continue;
            raw.merge(p, sens * 2, Math::max);
        }

        // channel 3: underground chests (Water)
        Set<ChunkPos> bases = new HashSet<>();
        if (undergroundChests.getValue()) {
            for (ChunkPos p : baseHits) {
                if (!world.isChunkLoaded(p.x, p.z)) continue;
                bases.add(p);
                raw.merge(p, sens * 4, Math::max);
            }
        }
        baseSnapshot = bases;

        if (smartAdjustment.getValue()) {
            applySmartMode(raw, sens);
        } else {
            susChunks = raw;
            susLevel = Map.of();
            zones = List.of();
        }

        if (rotatedDeepslate.getValue()) {
            deepslateSet.removeIf(bp -> !world.getBlockState(bp).isOf(Blocks.DEEPSLATE));
            deepslateBlocks = new ArrayList<>(deepslateSet);
        } else {
            deepslateBlocks = List.of();
        }
    }

    private void applySmartMode(Map<ChunkPos, Integer> raw, int sens) {
        Map<ChunkPos, Integer> out = new HashMap<>();
        Map<ChunkPos, Integer> levels = new HashMap<>();
        List<Zone> zl = new ArrayList<>();
        Set<ChunkPos> seen = new HashSet<>();
        boolean filter = noiseFilter.getValue();

        for (ChunkPos start : new ArrayList<>(raw.keySet())) {
            if (!seen.add(start)) continue;

            List<ChunkPos> comp = new ArrayList<>();
            ArrayDeque<ChunkPos> q = new ArrayDeque<>();
            q.add(start);
            while (!q.isEmpty()) {
                ChunkPos c = q.poll();
                comp.add(c);
                for (int dx = -2; dx <= 2; dx++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (dx == 0 && dz == 0) continue;
                        ChunkPos n = new ChunkPos(c.x + dx, c.z + dz);
                        if (raw.containsKey(n) && seen.add(n)) q.add(n);
                    }
                }
            }

            int maxHeat = 0;
            double sx = 0, sz = 0, sw = 0;
            for (ChunkPos c : comp) {
                int h = raw.get(c);
                maxHeat = Math.max(maxHeat, h);
                double w = Math.max(1, h);
                sx += (c.x * 16 + 8) * w;
                sz += (c.z * 16 + 8) * w;
                sw += w;
            }

            if (filter && comp.size() == 1 && maxHeat < sens * 2) continue; // lone weak chunk -> drop

            int level;
            if (comp.size() >= 4 && maxHeat >= sens * 4) level = 2;
            else if (comp.size() >= 2 || maxHeat >= sens * 2) level = 1;
            else level = 0;

            for (ChunkPos c : comp) {
                out.put(c, raw.get(c));
                levels.put(c, level);
            }
            zl.add(new Zone(sx / sw, sz / sw, comp.size(), maxHeat, level));
        }

        susChunks = out;
        susLevel = levels;
        zones = zl;

        if (notifyZones.getValue()) {
            for (Zone z : zl) {
                if (z.level() < 2) continue;
                long key = ChunkPos.toLong((int) Math.floor(z.centerX() / 16.0), (int) Math.floor(z.centerZ() / 16.0));
                if (notifiedZones.add(key)) {
                    info(String.format("High-confidence sus zone at %d, %d (%d chunks)", (int) z.centerX(), (int) z.centerZ(), z.size()));
                }
            }
        }
    }

    private void printDebug() {
        ChunkPos p = mc.player.getChunkPos();
        int neighbors = 0;
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++)
                if ((dx != 0 || dz != 0) && loadedChunks.contains(new ChunkPos(p.x + dx, p.z + dz))) neighbors++;
        info(String.format("Chunk %d, %d | heat=%d tracked=%d score=%d loaded-neighbors=%d",
            p.x, p.z, heatmap.getOrDefault(p, 0), tracked.getOrDefault(p, 0), scoreMap.getOrDefault(p, 0), neighbors));
    }

    // ====================== render ======================

    private static Color withAlpha(int rgb, int a) {
        return new Color((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, Math.max(0, Math.min(255, a)));
    }

    private static double levelFactor(int lvl) {
        return lvl == 0 ? 0.5 : lvl == 1 ? 0.75 : 1.0;
    }

    @EventListener
    public void onRender3D(Render3DEvent event) {
        if (mc.player == null || mc.world == null || event.matrixStack == null) return;

        Map<ChunkPos, Integer> chunks = susChunks;
        Set<ChunkPos> bases = baseSnapshot;
        List<BlockPos> deepslate = deepslateBlocks;
        if (chunks.isEmpty() && bases.isEmpty() && deepslate.isEmpty()) return;

        Camera camera = RenderUtils.getCamera();
        if (camera == null || !camera.isReady()) return;

        boolean smart = smartAdjustment.getValue();
        int view = mc.options.getViewDistance().getValue();
        ChunkPos pc = mc.player.getChunkPos();
        double y = chunkY.getValue();
        double th = chunkThickness.getValue();
        double inset = chunkInset.getValue();
        int a = alpha.getIntValue();
        boolean fill = !chunkShapeMode.isMode(ShapeMode.LINES);
        boolean outline = !chunkShapeMode.isMode(ShapeMode.SIDES);
        int sideRgb = chunkSideColor.getArgb();
        int lineArgb = chunkLineColor.getArgb();
        int lineRgb = lineArgb & 0xFFFFFF;
        int lineAlpha = (lineArgb >>> 24) & 0xFF;

        renderBoxes.clear();
        renderLines.clear();

        Map<ChunkPos, Integer> levels = susLevel;
        for (ChunkPos p : chunks.keySet()) {
            if (smart && Math.max(Math.abs(p.x - pc.x), Math.abs(p.z - pc.z)) > view) continue;

            double f = smart ? levelFactor(levels.getOrDefault(p, 2)) : 1.0;
            double x0 = p.getStartX() + inset, z0 = p.getStartZ() + inset;
            double x1 = p.getStartX() + 16 - inset, z1 = p.getStartZ() + 16 - inset;
            if (!RenderVisibility.box(x0, y, z0, x1, y + th, z1)) continue;

            if (fill) renderBoxes.add(new RenderUtils.ColoredBox(x0, y, z0, x1, y + th, z1, withAlpha(sideRgb, (int) (a * f))));
            if (outline) RenderUtils.addBoxOutline(renderLines, x0, y, z0, x1, y + th, z1, withAlpha(lineRgb, (int) (lineAlpha * f)), 2.0f);
        }

        // tall marker at the center of each zone
        if (smart && zoneMarker.getValue()) {
            for (Zone z : zones) {
                double h = 32.0 * (z.level() + 1);
                double f = levelFactor(z.level());
                double x0 = z.centerX() - 0.5, z0 = z.centerZ() - 0.5;
                double x1 = z.centerX() + 0.5, z1 = z.centerZ() + 0.5;
                renderBoxes.add(new RenderUtils.ColoredBox(x0, y, z0, x1, y + h, z1, withAlpha(sideRgb, (int) (a * f))));
                RenderUtils.addBoxOutline(renderLines, x0, y, z0, x1, y + h, z1, withAlpha(lineRgb, lineAlpha), 2.0f);
            }
        }

        // chest bases (blinking white outline)
        if (!bases.isEmpty() && System.currentTimeMillis() % 400 < 150) {
            Color white = new Color(255, 255, 255, 220);
            for (ChunkPos p : bases) {
                if (smart && Math.max(Math.abs(p.x - pc.x), Math.abs(p.z - pc.z)) > view) continue;
                double x0 = p.getStartX() + inset, z0 = p.getStartZ() + inset;
                double x1 = p.getStartX() + 16 - inset, z1 = p.getStartZ() + 16 - inset;
                RenderUtils.addBoxOutline(renderLines, x0, y + 0.2, z0, x1, y + 0.3, z1, white, 2.5f);
            }
        }

        // rotated deepslate
        if (rotatedDeepslate.getValue() && !deepslate.isEmpty()) {
            double maxD = deepslateDistance.getValue();
            double maxSq = maxD * maxD;
            int dsArgb = deepslateColor.getArgb();
            Color dsSide = withAlpha(dsArgb, a);
            Color dsLine = withAlpha(dsArgb, (dsArgb >>> 24) & 0xFF);
            double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
            for (BlockPos bp : deepslate) {
                double dx = bp.getX() + 0.5 - px, dy = bp.getY() + 0.5 - py, dz = bp.getZ() + 0.5 - pz;
                if (dx * dx + dy * dy + dz * dz > maxSq) continue;
                double bx = bp.getX(), by = bp.getY(), bz = bp.getZ();
                renderBoxes.add(new RenderUtils.ColoredBox(bx, by, bz, bx + 1, by + 1, bz + 1, dsSide));
                RenderUtils.addBoxOutline(renderLines, bx, by, bz, bx + 1, by + 1, bz + 1, dsLine, 2.0f);
            }
        }

        if (renderBoxes.isEmpty() && renderLines.isEmpty()) return;

        MatrixStack stack = event.matrixStack;
        stack.push();
        try {
            RenderUtils.applyCameraTransform(stack, camera);
            if (!renderBoxes.isEmpty()) RenderUtils.renderFilledBoxes(stack, renderBoxes);
            if (!renderLines.isEmpty()) RenderUtils.renderLines(stack, renderLines);
        } finally {
            stack.pop();
        }
    }
}
