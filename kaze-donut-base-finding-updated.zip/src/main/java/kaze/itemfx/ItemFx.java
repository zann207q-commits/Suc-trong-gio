package kaze.itemfx;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Random;
import kaze.halloween.HalloweenParticles;
import kaze.mixin.ItemFxLayerAccessor;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Identifier;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.registry.Registries;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.client.render.item.ItemRenderState.Glint;
import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import kaze.feature.CustomToolsModule;
import kaze.feature.CustomTotemModule;

public final class ItemFx {
   static final int KIND_TOTEM = 1;
   static final int KIND_TOOL = 2;
   private static final Map<Item, Integer> CLASSES = new IdentityHashMap<>();
   private static final Map<Integer, Object> KEYS = new HashMap<>();
   private static final String[] TIERS = new String[]{"wooden_", "stone_", "copper_", "iron_", "golden_", "diamond_", "netherite_"};
   private static final Random RANDOM = new Random();
   private static final long START = System.nanoTime();
   private static long lastFrame;
   private static long frames;
   private static float time;
   private static float floatingAct = -1.0F;
   private static int dripModel;

   private ItemFx() {
   }

   static int kind(int var0) {
      return var0 & 15;
   }

   static int type(int var0) {
      return var0 >> 4 & 15;
   }

   static int tier(int var0) {
      return var0 >> 8 & 15;
   }

   static int style(int var0) {
      return var0 >> 12 & 15;
   }

   static boolean animations(int var0) {
      return (var0 >> 16 & 1) != 0;
   }

   static boolean particles(int var0) {
      return (var0 >> 17 & 1) != 0;
   }

   static boolean popFx(int var0) {
      return (var0 >> 18 & 1) != 0;
   }

   static int design(int var0) {
      int var1 = style(var0);
      if (kind(var0) == 1) {
         return switch (var1) {
            case 1 -> 5;
            case 2 -> 1;
            case 3 -> 2;
            default -> 4;
         };
      } else {
         return var1 == 0 ? 6 : 3;
      }
   }

   static float shaderStyle(int var0) {
      return kind(var0) == 2 && style(var0) == 2 ? 1.0F : 0.0F;
   }

   static float intensity(int var0) {
      return (float)(var0 >> 20 & 127) / 100.0F * 1.3F;
   }

   static boolean spookyLike(int var0) {
      return var0 == 1 || var0 == 4;
   }

   static boolean chromeLike(int var0) {
      return var0 == 2 || var0 == 5;
   }

   static float tint(int var0) {
      int var1 = tier(var0);
      return var1 != 3 && var1 != 5 && var1 != 6 ? 0.0F : 1.0F;
   }

   static int glowCount(int var0, float var1) {
      boolean var2 = var1 >= 0.0F && popFx(var0);
      boolean var3 = particles(var0);
      int var4 = design(var0);
      if (var4 == 6) {
         return var3 ? 10 : 0;
      } else {
         return switch (var4) {
            case 1, 4 -> var2 ? 65 : (var3 ? 32 : 0);
            case 2, 5 -> var2 ? 30 : (var3 ? 8 : 0);
            default -> {
               if (!var3) {
                  yield 0;
               } else if (shaderStyle(var0) == 1.0F) {
                  yield 10;
               } else {
                  yield switch (tier(var0)) {
                     case 2, 3 -> 2;
                     case 4 -> 3;
                     case 5 -> 4;
                     case 6 -> 7;
                     default -> 0;
                  };
               }
            }
         };
      }
   }

   static int smokeCount(int var0, float var1) {
      if (!spookyLike(design(var0))) {
         return 0;
      } else {
         boolean var2 = var1 >= 0.0F && popFx(var0);
         return var2 ? 20 : (particles(var0) ? 8 : 0);
      }
   }

   public static void frame() {
      long var0 = System.nanoTime();
      float var2 = lastFrame == 0L ? 0.016F : Math.min(0.1F, (float)(var0 - lastFrame) / 1.0E9F);
      lastFrame = var0;
      frames++;
      time = (float)((double)(var0 - START) / 1.0E9 % 3600.0);
      if (CustomTotemModule.chromeActive()) {
         int var3 = CustomTotemModule.designIndex() == 1 ? 202 : 2;
         if (var3 != dripModel) {
            float[] var4 = ItemFxRenderer.anchors(var3);
            if (var4 != null) {
               Drips.reset();
               Drips.setAnchors(var4);
               dripModel = var3;
            }
         }

         Drips.update(var2);
      }
   }

   static float time() {
      return time;
   }

   static long frameIndex() {
      return frames;
   }

   public static void floating(float var0) {
      floatingAct = var0;
   }

   private static int classOf(Item var0) {
      Identifier var1 = Registries.ITEM.getId(var0);
      if (!"minecraft".equals(var1.getNamespace())) {
         return 0;
      } else {
         String var2 = var1.getPath();
         if (var2.equals("totem_of_undying")) {
            return 1;
         } else {
            byte var3;
            String var4;
            if (var2.endsWith("_sword")) {
               var3 = 0;
               var4 = var2.substring(0, var2.length() - 5);
            } else if (var2.endsWith("_pickaxe")) {
               var3 = 1;
               var4 = var2.substring(0, var2.length() - 7);
            } else if (var2.endsWith("_axe")) {
               var3 = 2;
               var4 = var2.substring(0, var2.length() - 3);
            } else if (var2.endsWith("_shovel")) {
               var3 = 3;
               var4 = var2.substring(0, var2.length() - 6);
            } else {
               if (!var2.endsWith("_hoe")) {
                  return 0;
               }

               var3 = 4;
               var4 = var2.substring(0, var2.length() - 3);
            }

            for (int var5 = 0; var5 < TIERS.length; var5++) {
               if (var4.equals(TIERS[var5])) {
                  return 2 | var3 << 4 | var5 << 8;
               }
            }

            return 0;
         }
      }
   }

   static int classify(ItemStack var0) {
      Item var1 = var0.getItem();
      Integer var2 = CLASSES.get(var1);
      if (var2 == null) {
         var2 = classOf(var1);
         CLASSES.put(var1, var2);
      }

      if (var2 == 0) {
         return 0;
      } else {
         Identifier var3 = (Identifier)var0.get(DataComponentTypes.ITEM_MODEL);
         return var3 != null && var3.equals(Registries.ITEM.getId(var1)) ? var2 : 0;
      }
   }

   public static void tag(ItemRenderState var0, ItemStack var1, ItemDisplayContext var2) {
      ItemFxState var3 = (ItemFxState)var0;
      var3.kaze$setFx(0);
      if (!var0.isEmpty() && !var1.isEmpty()) {
         int var4 = classify(var1);
         if (var4 != 0) {
            int var5;
            boolean var6;
            if (kind(var4) == 1) {
               if (!CustomTotemModule.active()) {
                  return;
               }

               int var7 = (int)Math.round(CustomTotemModule.glow.getValue());
               var5 = var4
                  | CustomTotemModule.designIndex() << 12
                  | (CustomTotemModule.animations.getValue() ? 65536 : 0)
                  | (CustomTotemModule.particles.getValue() ? 131072 : 0)
                  | (CustomTotemModule.popEffects.getValue() ? 262144 : 0)
                  | Math.max(0, Math.min(100, var7)) << 20;
               var6 = true;
            } else {
               if (!CustomToolsModule.active()) {
                  return;
               }

               int var9 = CustomToolsModule.styleIndex();
               if (var9 == 0 && (type(var4) != 1 || tier(var4) != 5 && tier(var4) != 6)) {
                  return;
               }

               int var8 = (int)Math.round(CustomToolsModule.strength.getValue());
               var5 = var4
                  | var9 << 12
                  | (CustomToolsModule.animations.getValue() ? 65536 : 0)
                  | (CustomToolsModule.effects.getValue() ? 131072 : 0)
                  | Math.max(0, Math.min(100, var8)) << 20;
               var6 = var9 == 0 || CustomToolsModule.animations.getValue() || CustomToolsModule.effects.getValue() || var1.hasGlint();
            }

            var3.kaze$setFx(var5);
            var0.addModelKey(KEYS.computeIfAbsent(var5, var0x -> new Object()));
            int var10 = ItemFxRenderer.meshKey(design(var5), type(var5), tier(var5));
            if (var6 || !ItemFxRenderer.ready(var10)) {
               var0.markAnimated();
            }

            var3.kaze$layer0().setUseLight(true);
         }
      }
   }

   public static boolean render(int var0, ItemDisplayContext var1, LayerRenderState var2, MatrixStack var3, OrderedRenderCommandQueue var4, int var5) {
      int var6 = ItemFxRenderer.meshKey(design(var0), type(var0), tier(var0));
      if (!ItemFxRenderer.prepare(var6)) {
         return false;
      } else {
         ItemFxLayerAccessor var7 = (ItemFxLayerAccessor)var2;
         byte var8;
         if (floatingAct >= 0.0F) {
            var8 = 3;
         } else if (var1 == ItemDisplayContext.GUI) {
            var8 = 2;
         } else if (var1 != ItemDisplayContext.FIRST_PERSON_LEFT_HAND && var1 != ItemDisplayContext.FIRST_PERSON_RIGHT_HAND) {
            var8 = 0;
         } else {
            var8 = 1;
         }

         var3.push();

         try {
            var7.kaze$transform().apply(var1.isLeftHand(), var3.peek());
            var3.translate(0.5F, 0.5F, 0.5F);
            if (var8 == 2 && design(var0) <= 3) {
               if (kind(var0) == 1) {
                  var3.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-20.0F));
                  var3.multiply(RotationAxis.POSITIVE_X.rotationDegrees(7.0F));
               } else {
                  var3.multiply(new Quaternionf().rotationAxis((float)Math.toRadians(26.0), 0.70710677F, 0.70710677F, 0.0F));
               }
            }

            boolean var9 = var7.kaze$glint() != Glint.NONE;
            ItemFxRenderer.submit(var4, var3, var0, var8, var5, var9, var8 == 3 ? floatingAct : -1.0F);
         } finally {
            var3.pop();
         }

         return true;
      }
   }

   static void anim(Matrix4f var0, int var1, int var2, float var3, float var4) {
      var0.identity();
      if (kind(var1) == 1) {
         if (animations(var1)) {
            float var5 = var2 == 2 ? 0.55F : 1.0F;
            var0.translate(0.0F, 0.018F * var5 * (float)Math.sin((double)(var4 * 1.6F)), 0.0F);
            var0.rotateY(0.13F * var5 * (float)Math.sin((double)(var4 * 0.7F)));
            var0.rotateZ(0.025F * var5 * (float)Math.sin((double)(var4 * 1.1F)));
         }

         if (var3 >= 0.0F && popFx(var1)) {
            float var6 = 1.0F + 0.12F * (float)Math.exp((double)(-var3 * 6.0F)) * (float)Math.sin((double)(var3 * 28.0F));
            var0.scale(var6);
         }
      }
   }

   public static boolean totemPop(Entity var0, ParticleEffect var1) {
      if (var1 == ParticleTypes.TOTEM_OF_UNDYING && CustomTotemModule.active() && CustomTotemModule.popEffects.getValue()) {
         double var2 = var0.getX();
         double var4 = var0.getY() + (double)var0.getHeight() * 0.55;
         double var6 = var0.getZ();
         Random var8 = RANDOM;
         int var9 = CustomTotemModule.designIndex();
         if (var9 != 0 && var9 != 2) {
            for (int var15 = 0; var15 < 34; var15++) {
               float[] var21 = dir(var8, 2.6F + var8.nextFloat() * 2.8F);
               HalloweenParticles.spawn(
                  2, var2, var4, var6, var21[0], var21[1] + 1.2F, var21[2], 0.028F, 0.5F, 0.6F + var8.nextFloat() * 0.4F, 0.92F, 0.95F, 1.0F, 1.0F
               );
            }

            for (int var16 = 0; var16 < 20; var16++) {
               float[] var22 = dir(var8, 0.8F + var8.nextFloat() * 1.5F);
               HalloweenParticles.spawn(
                  1,
                  var2,
                  var4,
                  var6,
                  var22[0],
                  var22[1],
                  var22[2],
                  0.08F + var8.nextFloat() * 0.06F,
                  0.4F,
                  1.0F + var8.nextFloat() * 0.6F,
                  0.8F,
                  0.9F,
                  1.0F,
                  0.8F
               );
            }

            for (int var17 = 0; var17 < 18; var17++) {
               float[] var23 = dir(var8, 0.6F + var8.nextFloat());
               HalloweenParticles.spawn(
                  4,
                  var2 + (double)var23[0] * 0.4,
                  var4 + (double)var23[1] * 0.4,
                  var6 + (double)var23[2] * 0.4,
                  var23[0] * 0.3F,
                  var23[1] * 0.3F,
                  var23[2] * 0.3F,
                  0.03F,
                  1.0F,
                  1.6F + var8.nextFloat(),
                  1.0F,
                  1.0F,
                  1.0F,
                  1.0F
               );
            }
         } else {
            for (int var10 = 0; var10 < 40; var10++) {
               float[] var11 = dir(var8, 1.4F + var8.nextFloat() * 2.2F);
               HalloweenParticles.spawn(
                  3,
                  var2 + (double)var11[0] * 0.15,
                  var4 + (double)var11[1] * 0.15,
                  var6 + (double)var11[2] * 0.15,
                  var11[0],
                  var11[1] + 0.8F,
                  var11[2],
                  0.035F + var8.nextFloat() * 0.03F,
                  0.6F,
                  1.1F + var8.nextFloat() * 1.0F,
                  1.0F,
                  0.42F + var8.nextFloat() * 0.25F,
                  0.08F,
                  1.0F
               );
            }

            for (int var12 = 0; var12 < 18; var12++) {
               float[] var18 = dir(var8, 0.8F + var8.nextFloat() * 1.4F);
               HalloweenParticles.spawn(
                  1,
                  var2,
                  var4,
                  var6,
                  var18[0],
                  var18[1],
                  var18[2],
                  0.09F + var8.nextFloat() * 0.06F,
                  0.4F,
                  1.2F + var8.nextFloat() * 0.6F,
                  0.62F,
                  0.25F,
                  1.0F,
                  0.9F
               );
            }

            for (int var13 = 0; var13 < 12; var13++) {
               float[] var19 = dir(var8, 0.5F + var8.nextFloat() * 0.8F);
               HalloweenParticles.spawn(
                  0,
                  var2 + (double)var19[0] * 0.3,
                  var4 - 0.3 + (double)var19[1] * 0.3,
                  var6 + (double)var19[2] * 0.3,
                  var19[0],
                  var19[1] * 0.4F + 0.3F,
                  var19[2],
                  0.3F + var8.nextFloat() * 0.2F,
                  2.6F,
                  2.2F + var8.nextFloat() * 1.0F,
                  0.16F,
                  0.09F,
                  0.18F,
                  0.4F
               );
            }

            for (int var14 = 0; var14 < 14; var14++) {
               float[] var20 = dir(var8, 3.0F + var8.nextFloat() * 2.5F);
               HalloweenParticles.spawn(
                  2, var2, var4, var6, var20[0], var20[1] + 1.0F, var20[2], 0.025F, 0.5F, 0.5F + var8.nextFloat() * 0.3F, 1.0F, 0.6F, 0.15F, 1.0F
               );
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private static float[] dir(Random var0, float var1) {
      double var2 = var0.nextDouble() * Math.PI * 2.0;
      double var4 = var0.nextDouble() * 2.0 - 1.0;
      double var6 = Math.sqrt(1.0 - var4 * var4);
      return new float[]{(float)(Math.cos(var2) * var6) * var1, (float)var4 * var1 * 0.7F, (float)(Math.sin(var2) * var6) * var1};
   }

   public static void moduleOff() {
      if (!CustomTotemModule.active() && !CustomToolsModule.active()) {
         ItemFxRenderer.releaseModels();
         Drips.reset();
      }
   }
}
