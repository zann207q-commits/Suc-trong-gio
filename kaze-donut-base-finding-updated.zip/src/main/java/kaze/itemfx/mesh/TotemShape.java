package kaze.itemfx.mesh;

public final class TotemShape {
   public static final float HEAD_Y = 0.292F;
   public static final float BELT_Y = -0.125F;
   public static final float HEM_Y = -0.455F;
   private static final float[] SLEEVE = new float[]{0.105F, 0.088F, 0.345F, 0.098F, 0.335F, 0.035F, 0.25F, 0.0F, 0.125F, -0.05F};
   private static final float[] SLEEVE_TORN = new float[]{
      0.105F,
      0.088F,
      0.345F,
      0.098F,
      0.335F,
      0.032F,
      0.312F,
      0.004F,
      0.291F,
      0.026F,
      0.262F,
      -0.024F,
      0.236F,
      0.006F,
      0.206F,
      -0.05F,
      0.181F,
      -0.014F,
      0.152F,
      -0.074F,
      0.128F,
      -0.04F,
      0.105F,
      -0.056F
   };
   public final float round;
   public final float blend;
   public final float melt;
   public final float tatter;

   public TotemShape(float var1, float var2, float var3, float var4) {
      this.round = var1;
      this.blend = var2;
      this.melt = var3;
      this.tatter = var4;
   }

   public float head(float var1, float var2, float var3) {
      return Sd.box(var1, var2 - 0.292F, var3, 0.135F, 0.145F, 0.112F, this.round);
   }

   public float torso(float var1, float var2, float var3) {
      float var4 = 1.0F + 0.16F * Sd.clamp((0.14F - var2) / 0.27F, 0.0F, 1.0F);
      return Sd.box(var1 / var4, var2 - 0.005F, var3, 0.098F, 0.135F, 0.082F, Math.min(0.06F, this.round * 0.8F + 0.01F));
   }

   public float arms(float var1, float var2, float var3) {
      float var4 = Math.abs(var1);
      if (var2 < -0.14F) {
         return 1.0F;
      } else {
         float var5 = Sd.roundCone(var4, var2, var3, 0.085F, 0.09F, 0.0F, 0.355F, 0.106F, 0.0F, 0.058F, 0.043F);
         float var6 = Sd.ellipsoid(var4 - 0.392F, var2 - 0.112F, var3, 0.046F, 0.05F, 0.042F);
         return Sd.smin(var5, var6, 0.03F);
      }
   }

   public float sleeves(float var1, float var2, float var3) {
      float var4 = Math.abs(var1);
      if (!(var2 < -0.14F) && !(var4 < 0.08F)) {
         float var5 = Math.max(Sd.polygon(var4, var2, this.tatter > 0.0F ? SLEEVE_TORN : SLEEVE), Math.abs(var3) - 0.03F);
         return Sd.smax(var5, -var2 - 0.1F, 0.01F) - 0.004F;
      } else {
         return 1.0F;
      }
   }

   public float sleeveOutline(float var1, float var2) {
      return Sd.polygon(var1, var2, this.tatter > 0.0F ? SLEEVE_TORN : SLEEVE);
   }

   public float hemY(float var1) {
      if (this.tatter <= 0.0F) {
         return -0.455F;
      } else {
         double var2 = 0.5 + 0.5 * Math.cos((double)(var1 * 9.0F) + 0.8F * Math.sin((double)(var1 * 4.0F)));
         return -0.44300002F - this.tatter * 0.045F * (float)(var2 * var2 * var2);
      }
   }

   public float skirt(float var1, float var2, float var3) {
      if (var2 > -0.05F) {
         return 0.2F;
      } else {
         float var4 = Sd.clamp((-0.12F - var2) / 0.34F, 0.0F, 1.0F);
         float var5 = (float)Math.atan2((double)var3, (double)var1);
         float var6 = var4 * var4 * 0.4F + var4 * 0.6F;
         float var7 = Sd.mix(0.125F, 0.205F, var6) * (1.0F + 0.035F * (float)Math.cos((double)(var5 * 10.0F)) * var4);
         float var8 = Sd.mix(0.095F, 0.15F, var6);
         float var9 = (Sd.len(var1 / var7, var3 / var8) - 1.0F) * Math.min(var7, var8);
         var9 = Sd.smax(var9, this.hemY(var5) - var2, 0.02F);
         return Sd.smax(var9, var2 + 0.08F, 0.02F);
      }
   }

   public float belt(float var1, float var2, float var3) {
      return Sd.torus(var1, var2 - -0.125F, var3 / 0.8F, 0.122F, 0.021F) * 0.8F;
   }

   public float body(float var1, float var2, float var3) {
      float var4 = this.blend;
      float var5 = this.head(var1, var2, var3);
      var5 = Sd.smin(var5, this.torso(var1, var2, var3), 0.04F + var4);
      var5 = Sd.smin(var5, this.arms(var1, var2, var3), 0.03F + var4);
      var5 = Sd.smin(var5, this.sleeves(var1, var2, var3), 0.035F + var4);
      var5 = Sd.smin(var5, this.skirt(var1, var2, var3), 0.03F + var4);
      if (this.melt > 0.0F && var5 < 0.05F) {
         var5 -= this.melt * (Sd.fbm(var1 * 6.0F + 3.1F, var2 * 6.0F, var3 * 6.0F, 2) - 0.5F);
      }

      return var5;
   }
}
