package kaze.itemfx.mesh;

public final class SpookyModel {
   private static final TotemShape SHAPE = new TotemShape(0.042F, 0.0F, 0.0F, 1.0F);
   private static final float FACE_Z = 0.112F;
   private static final float CARVE_DEPTH = 0.046F;
   private static final float[] EYE_L = new float[]{-0.1F, 0.32F, -0.021F, 0.3F, -0.025F, 0.276F, -0.092F, 0.284F};
   private static final float[] EYE_R = new float[]{0.1F, 0.32F, 0.092F, 0.284F, 0.025F, 0.276F, 0.021F, 0.3F};
   private static final float[] MOUTH = new float[]{
      -0.09F,
      0.214F,
      -0.06F,
      0.192F,
      -0.035F,
      0.187F,
      -0.025F,
      0.204F,
      -0.015F,
      0.187F,
      0.015F,
      0.187F,
      0.025F,
      0.204F,
      0.035F,
      0.187F,
      0.06F,
      0.192F,
      0.09F,
      0.214F,
      0.066F,
      0.229F,
      0.056F,
      0.229F,
      0.048F,
      0.207F,
      0.04F,
      0.229F,
      -0.04F,
      0.229F,
      -0.048F,
      0.207F,
      -0.056F,
      0.229F,
      -0.066F,
      0.229F
   };
   private static final float GEM_Z = 0.112F;

   private SpookyModel() {
   }

   public static MeshData build() {
      return SurfaceNets.build(SpookyModel::field, SpookyModel::paint, -0.47F, -0.51F, -0.18F, 0.47F, 0.46F, 0.18F, 0.008333334F, 0.07F);
   }

   static float carve(float var0, float var1, float var2) {
      if (!(var2 < 0.046F) && !(var1 < 0.16F) && !(var1 > 0.36F)) {
         float var3 = Math.min(Math.min(Sd.polygon(var0, var1, EYE_L), Sd.polygon(var0, var1, EYE_R)), Sd.polygon(var0, var1, MOUTH));
         return Math.max(var3, 0.066F - var2);
      } else {
         return 1.0F;
      }
   }

   static float features(float var0, float var1, float var2) {
      if (!(var2 < 0.07F) && !(var1 < 0.22F) && !(var1 > 0.37F)) {
         float var3 = Math.abs(var0);
         float var4 = Sd.roundCone(var3, var1, var2, 0.104F, 0.338F, 0.108F, 0.02F, 0.316F, 0.112F, 0.0115F, 0.0125F);
         float var5 = Sd.box(var0, var1 - 0.258F, var2 - 0.112F, 0.013F, 0.026F, 0.012F, 0.008F);
         return Math.min(var4, var5);
      } else {
         return 1.0F;
      }
   }

   static float plainHead(float var0, float var1, float var2) {
      return Sd.smin(SHAPE.head(var0, var1, var2), features(var0, var1, var2), 0.008F);
   }

   static float head(float var0, float var1, float var2) {
      return Sd.ssub(plainHead(var0, var1, var2), carve(var0, var1, var2), 0.004F);
   }

   static float gem(float var0, float var1, float var2) {
      return !(Math.abs(var0) > 0.08F) && !(Math.abs(var1 - -0.125F) > 0.08F) ? Sd.octahedron(var0, (var1 - -0.125F) / 1.25F, var2 - 0.112F, 0.036F) : 1.0F;
   }

   static float bodyNoHead(float var0, float var1, float var2) {
      float var3 = SHAPE.torso(var0, var1, var2);
      var3 = Sd.smin(var3, SHAPE.arms(var0, var1, var2), 0.03F);
      var3 = Sd.smin(var3, SHAPE.sleeves(var0, var1, var2), 0.035F);
      return Sd.smin(var3, SHAPE.skirt(var0, var1, var2), 0.03F);
   }

   public static float field(float var0, float var1, float var2) {
      float var3 = Sd.smin(head(var0, var1, var2), bodyNoHead(var0, var1, var2), 0.04F);
      var3 = Sd.smin(var3, SHAPE.belt(var0, var1, var2), 0.008F);
      return Math.min(var3, gem(var0, var1, var2));
   }

   public static void paint(float var0, float var1, float var2, float var3, float var4, float var5, SurfaceNets.Surface var6) {
      float var7 = Math.abs(gem(var0, var1, var2));
      float var8 = Math.abs(SHAPE.belt(var0, var1, var2));
      float var9 = Math.abs(head(var0, var1, var2));
      float var10 = Math.abs(bodyNoHead(var0, var1, var2));
      var6.u = (float)(Math.atan2((double)var2, (double)var0) / (Math.PI * 2) + 0.5);
      var6.v = var1;
      if (var7 <= var8 && var7 < 0.006F) {
         var6.mat = 4;
         var6.rgb = Mat.rgb(0.62F, 0.16F, 1.0F);
         var6.p1 = 1.0F;
      } else if (var8 < var10 && var8 < var9 && var8 < 0.006F) {
         var6.mat = 1;
         var6.rgb = Mat.rgb(0.36F, 0.13F, 0.48F);
         var6.p1 = 0.3F;
      } else {
         boolean var11 = var9 <= var10 && var1 > 0.12F;
         float var12 = Math.abs(var0);
         var6.mat = 5;
         float var13 = var11 ? Sd.smoothstep(0.06F, 0.1F, var2) : 0.0F;
         var6.rgb = Mat.rgb(0.062F + 0.045F * var13, 0.052F + 0.034F * var13, 0.06F + 0.036F * var13);
         var6.p2 = var11 ? Sd.clamp(-plainHead(var0, var1, var2) / 0.046F, 0.0F, 1.0F) : 0.0F;
         float var14 = (float)Math.atan2((double)var2, (double)var0);
         float var15 = var1 < -0.36F ? 1.0F - Sd.smoothstep(0.0F, 0.032F, var1 - SHAPE.hemY(var14)) : 0.0F;
         float var16 = 0.0F;
         if (!var11 && var12 > 0.11F && var12 < 0.35F && var1 < 0.05F && var1 > -0.11F && Math.abs(SHAPE.sleeves(var0, var1, var2)) < 0.012F) {
            var16 = (1.0F - Sd.smoothstep(0.0F, 0.022F, Math.abs(SHAPE.sleeveOutline(var12, var1)))) * Sd.smoothstep(0.05F, 0.025F, var1);
         }

         var6.p1 = Math.max(var15, var16);
         if (var11) {
            var6.region = 4;
         } else if (var1 < -0.3F) {
            var6.region = 3;
         } else if (var12 > 0.11F && var1 < 0.075F) {
            var6.region = var0 < 0.0F ? 1 : 2;
         } else {
            var6.region = 0;
         }
      }
   }
}
