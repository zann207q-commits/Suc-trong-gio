package kaze.itemfx.mesh;

public final class Sd {
   private Sd() {
   }

   public static float len(float var0, float var1) {
      return (float)Math.sqrt((double)(var0 * var0 + var1 * var1));
   }

   public static float len(float var0, float var1, float var2) {
      return (float)Math.sqrt((double)(var0 * var0 + var1 * var1 + var2 * var2));
   }

   public static float clamp(float var0, float var1, float var2) {
      return var0 < var1 ? var1 : (var0 > var2 ? var2 : var0);
   }

   public static float mix(float var0, float var1, float var2) {
      return var0 + (var1 - var0) * var2;
   }

   public static float smoothstep(float var0, float var1, float var2) {
      float var3 = clamp((var2 - var0) / (var1 - var0), 0.0F, 1.0F);
      return var3 * var3 * (3.0F - 2.0F * var3);
   }

   public static float smin(float var0, float var1, float var2) {
      if (var2 <= 0.0F) {
         return Math.min(var0, var1);
      } else {
         float var3 = Math.max(var2 - Math.abs(var0 - var1), 0.0F) / var2;
         return Math.min(var0, var1) - var3 * var3 * var2 * 0.25F;
      }
   }

   public static float smax(float var0, float var1, float var2) {
      return -smin(-var0, -var1, var2);
   }

   public static float ssub(float var0, float var1, float var2) {
      return smax(var0, -var1, var2);
   }

   public static float sphere(float var0, float var1, float var2, float var3) {
      return len(var0, var1, var2) - var3;
   }

   public static float ellipsoid(float var0, float var1, float var2, float var3, float var4, float var5) {
      float var6 = len(var0 / var3, var1 / var4, var2 / var5);
      float var7 = len(var0 / (var3 * var3), var1 / (var4 * var4), var2 / (var5 * var5));
      return var7 < 1.0E-6F ? -Math.min(var3, Math.min(var4, var5)) : var6 * (var6 - 1.0F) / var7;
   }

   public static float box(float var0, float var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = Math.abs(var0) - var3 + var6;
      float var8 = Math.abs(var1) - var4 + var6;
      float var9 = Math.abs(var2) - var5 + var6;
      float var10 = len(Math.max(var7, 0.0F), Math.max(var8, 0.0F), Math.max(var9, 0.0F));
      return var10 + Math.min(Math.max(var7, Math.max(var8, var9)), 0.0F) - var6;
   }

   public static float capsule(float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9) {
      float var10 = var0 - var3;
      float var11 = var1 - var4;
      float var12 = var2 - var5;
      float var13 = var6 - var3;
      float var14 = var7 - var4;
      float var15 = var8 - var5;
      float var16 = clamp((var10 * var13 + var11 * var14 + var12 * var15) / (var13 * var13 + var14 * var14 + var15 * var15), 0.0F, 1.0F);
      return len(var10 - var13 * var16, var11 - var14 * var16, var12 - var15 * var16) - var9;
   }

   public static float roundCone(
      float var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10
   ) {
      float var11 = var6 - var3;
      float var12 = var7 - var4;
      float var13 = var8 - var5;
      float var14 = var11 * var11 + var12 * var12 + var13 * var13;
      float var15 = var9 - var10;
      float var16 = var14 - var15 * var15;
      float var17 = 1.0F / var14;
      float var18 = var0 - var3;
      float var19 = var1 - var4;
      float var20 = var2 - var5;
      float var21 = var18 * var11 + var19 * var12 + var20 * var13;
      float var22 = var21 - var14;
      float var23 = var18 * var14 - var11 * var21;
      float var24 = var19 * var14 - var12 * var21;
      float var25 = var20 * var14 - var13 * var21;
      float var26 = var23 * var23 + var24 * var24 + var25 * var25;
      float var27 = var21 * var21 * var14;
      float var28 = var22 * var22 * var14;
      float var29 = Math.signum(var15) * var15 * var15 * var26;
      if (Math.signum(var22) * var16 * var28 > var29) {
         return (float)Math.sqrt((double)(var26 + var28)) * var17 - var10;
      } else {
         return Math.signum(var21) * var16 * var27 < var29
            ? (float)Math.sqrt((double)(var26 + var27)) * var17 - var9
            : ((float)Math.sqrt((double)(var26 * var16 * var17)) + var21 * var15) * var17 - var9;
      }
   }

   public static float torus(float var0, float var1, float var2, float var3, float var4) {
      return len(len(var0, var2) - var3, var1) - var4;
   }

   public static float octahedron(float var0, float var1, float var2, float var3) {
      return (Math.abs(var0) + Math.abs(var1) + Math.abs(var2) - var3) * 0.57735026F;
   }

   public static float segment(float var0, float var1, float var2, float var3, float var4, float var5) {
      float var6 = var0 - var2;
      float var7 = var1 - var3;
      float var8 = var4 - var2;
      float var9 = var5 - var3;
      float var10 = clamp((var6 * var8 + var7 * var9) / (var8 * var8 + var9 * var9), 0.0F, 1.0F);
      return len(var6 - var8 * var10, var7 - var9 * var10);
   }

   public static float polygon(float var0, float var1, float[] var2) {
      int var3 = var2.length / 2;
      float var4 = (var0 - var2[0]) * (var0 - var2[0]) + (var1 - var2[1]) * (var1 - var2[1]);
      float var5 = 1.0F;
      int var6 = var3 - 1;

      for (int var7 = 0; var7 < var3; var6 = var7++) {
         float var8 = var2[var7 * 2];
         float var9 = var2[var7 * 2 + 1];
         float var10 = var2[var6 * 2];
         float var11 = var2[var6 * 2 + 1];
         float var12 = var10 - var8;
         float var13 = var11 - var9;
         float var14 = var0 - var8;
         float var15 = var1 - var9;
         float var16 = clamp((var14 * var12 + var15 * var13) / (var12 * var12 + var13 * var13), 0.0F, 1.0F);
         float var17 = var14 - var12 * var16;
         float var18 = var15 - var13 * var16;
         var4 = Math.min(var4, var17 * var17 + var18 * var18);
         boolean var19 = var1 >= var9;
         boolean var20 = var1 < var11;
         boolean var21 = var12 * var15 > var13 * var14;
         if (var19 && var20 && var21 || !var19 && !var20 && !var21) {
            var5 = -var5;
         }
      }

      return var5 * (float)Math.sqrt((double)var4);
   }

   private static float hash(int var0, int var1, int var2) {
      int var3 = var0 * 374761393 + var1 * 668265263 + var2 * 1274126177;
      var3 = (var3 ^ var3 >>> 13) * 1274126177;
      return (float)((var3 ^ var3 >>> 16) & 16777215) / 1.6777215E7F;
   }

   public static float noise(float var0, float var1, float var2) {
      int var3 = (int)Math.floor((double)var0);
      int var4 = (int)Math.floor((double)var1);
      int var5 = (int)Math.floor((double)var2);
      float var6 = var0 - (float)var3;
      float var7 = var1 - (float)var4;
      float var8 = var2 - (float)var5;
      var6 = var6 * var6 * (3.0F - 2.0F * var6);
      var7 = var7 * var7 * (3.0F - 2.0F * var7);
      var8 = var8 * var8 * (3.0F - 2.0F * var8);
      float var9 = mix(hash(var3, var4, var5), hash(var3 + 1, var4, var5), var6);
      float var10 = mix(hash(var3, var4 + 1, var5), hash(var3 + 1, var4 + 1, var5), var6);
      float var11 = mix(hash(var3, var4, var5 + 1), hash(var3 + 1, var4, var5 + 1), var6);
      float var12 = mix(hash(var3, var4 + 1, var5 + 1), hash(var3 + 1, var4 + 1, var5 + 1), var6);
      return mix(mix(var9, var10, var7), mix(var11, var12, var7), var8);
   }

   public static float fbm(float var0, float var1, float var2, int var3) {
      float var4 = 0.0F;
      float var5 = 0.5F;
      float var6 = 0.0F;

      for (int var7 = 0; var7 < var3; var7++) {
         var4 += noise(var0, var1, var2) * var5;
         var6 += var5;
         var0 = var0 * 2.03F + 17.1F;
         var1 = var1 * 2.03F + 3.7F;
         var2 = var2 * 2.03F + 9.3F;
         var5 *= 0.5F;
      }

      return var4 / var6;
   }
}
