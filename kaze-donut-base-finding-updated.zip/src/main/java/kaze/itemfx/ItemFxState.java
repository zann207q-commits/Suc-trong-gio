package kaze.itemfx;

import net.minecraft.client.render.item.ItemRenderState.LayerRenderState;

public interface ItemFxState {
   int kaze$fx();

   void kaze$setFx(int var1);

   LayerRenderState kaze$layer0();
}
