package kaze.feature;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class Character3dHelper {
   private static final List<CharacterDefinition> BUILT_IN = List.of(
      new SakuraDesign(),
      new LunaDesign(),
      new MikaDesign(),
      new AoiDesign(),
      new MikuDesign(),
      BakedCharacterAsset.builtIn("cj", "CJ", "/assets/kaze/characters/cj.anc"),
      BakedCharacterAsset.builtIn("neighbor", "Neighbor", "/assets/kaze/characters/neighbor.anc"),
      new TungTungSahurDesign(),
      new TralaleroDesign()
   );
   private static volatile List<CharacterDefinition> designs = BUILT_IN;

   private Character3dHelper() {
   }

   public static List<CharacterDefinition> all() {
      return designs;
   }

   static boolean refresh() {
      List<CharacterDefinition> updated = new ArrayList<>(BUILT_IN);
      List<String> knownNames = new ArrayList<>(names(BUILT_IN));
      for (BakedCharacterAsset asset : LocalCharacterAssetLibrary.scan()) {
         if (!knownNames.contains(asset.name())) {
            knownNames.add(asset.name());
            updated.add(asset);
         }
      }

      List<CharacterDefinition> previous = designs;
      designs = List.copyOf(updated);
      if (previous.size() != updated.size()) {
         return true;
      }
      for (int index = 0; index < updated.size(); index++) {
         if (!previous.get(index).id().equals(updated.get(index).id())) {
            return true;
         }
      }
      return false;
   }

   static List<String> names() {
      return names(designs);
   }

   private static List<String> names(List<CharacterDefinition> definitions) {
      List<String> result = new ArrayList<>(definitions.size());
      for (CharacterDefinition definition : definitions) {
         result.add(definition.name());
      }
      return result;
   }

   static CharacterDefinition byName(String name) {
      for (CharacterDefinition definition : designs) {
         if (definition.name().equals(name)) {
            return definition;
         }
      }
      return designs.get(0);
   }
}
