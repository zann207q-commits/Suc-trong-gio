package kaze.feature;

import java.awt.Color;
import kaze.module.modules.client.Kaze;

public enum UiPalette {
   Black(15527409, 16777215, 1.0F, 1316121, 1579293, 131587, 16777215, 9343126),
   White(16777215, 16777215, 1.9F, 3355964, 3816516, 657932, 16777215, 14277860),
   Purple(12166143, 10585343, 1.45F, 1578026, 2825546, 328459, 16777215, 10255359),
   Ocean(8571135, 5941503, 1.4F, 1120806, 1388623, 132620, 16777215, 6140671),
   Rose(16753606, 16742572, 1.35F, 2233372, 4528175, 656134, 16777215, 16745137),
   Mint(9302732, 5234092, 1.3F, 1122075, 1391923, 133640, 16777215, 5956276),
   Amber(16763786, 16754002, 1.3F, 2169361, 4599834, 656898, 16777215, 16756318),
   Crimson(16747146, 16734810, 1.3F, 2233108, 4659483, 656131, 16777215, 16737380),
   Halloween(15964750, 9725680, 1.25F, 1708568, 2757680, 656389, 16761470, 10706687);

   private static final int SIZE = 23;
   private static final long BLEND_NS = 700000000L;
   private static UiPalette target;
   private static float[] from;
   private static long changedAt;
   private static float[] cached;
   private static long cachedAt = -1L;
   final int accent;
   final int light;
   final float lightAmount;
   final int glass;
   final int bgTop;
   final int bgBottom;
   final int logoTop;
   final int logoBottom;

   private UiPalette(int nullxx, int nullxxx, float nullxxxx, int nullxxxxx, int nullxxxxxx, int nullxxxxxxx, int nullxxxxxxxx, int nullxxxxxxxxx) {
      this.accent = nullxx;
      this.light = nullxxx;
      this.lightAmount = nullxxxx;
      this.glass = nullxxxxx;
      this.bgTop = nullxxxxxx;
      this.bgBottom = nullxxxxxxx;
      this.logoTop = nullxxxxxxxx;
      this.logoBottom = nullxxxxxxxxx;
   }

   private float[] vector() {
      float[] var1 = new float[23];
      put(var1, 0, this.accent);
      put(var1, 3, this.light);
      put(var1, 6, this.glass);
      put(var1, 9, this.bgTop);
      put(var1, 12, this.bgBottom);
      put(var1, 15, this.logoTop);
      put(var1, 18, this.logoBottom);
      var1[21] = this.lightAmount;
      var1[22] = this == Halloween ? 1.0F : 0.0F;
      return var1;
   }

   private static void put(float[] var0, int var1, int var2) {
      var0[var1] = (float)(var2 >> 16 & 0xFF);
      var0[var1 + 1] = (float)(var2 >> 8 & 0xFF);
      var0[var1 + 2] = (float)(var2 & 0xFF);
   }

   public static UiPalette selected() {
      try {
         return Kaze.theme.getValue() instanceof UiPalette var1 ? var1 : Black;
      } catch (Throwable var2) {
         return Black;
      }
   }

   private static float[] now() {
      long var0 = System.nanoTime();
      if (var0 == cachedAt && cached != null) {
         return cached;
      } else {
         UiPalette var2 = selected();
         if (target == null) {
            target = var2;
            from = var2.vector();
            changedAt = var0 - 700000000L;
         } else if (var2 != target) {
            from = cached != null ? (float[])cached.clone() : target.vector();
            target = var2;
            changedAt = var0;
         }

         float var3 = Math.min(1.0F, (float)(var0 - changedAt) / 7.0E8F);
         float var4 = var3 * var3 * (3.0F - 2.0F * var3);
         float[] var5 = target.vector();
         float[] var6 = new float[23];

         for (int var7 = 0; var7 < 23; var7++) {
            var6[var7] = from[var7] + (var5[var7] - from[var7]) * var4;
         }

         cached = var6;
         cachedAt = var0;
         return var6;
      }
   }

   private static int rgb(float[] var0, int var1, float var2) {
      int var3 = Math.round(Math.max(0.0F, Math.min(1.0F, var2)) * 255.0F);
      return var3 << 24 | Math.round(var0[var1]) << 16 | Math.round(var0[var1 + 1]) << 8 | Math.round(var0[var1 + 2]);
   }

   public static int accent(float var0) {
      return rgb(now(), 0, var0);
   }

   public static int light(float var0) {
      return rgb(now(), 3, var0);
   }

   public static int glass(float var0) {
      return rgb(now(), 6, var0);
   }

   public static int bgTop(float var0) {
      return rgb(now(), 9, var0);
   }

   public static int bgBottom(float var0) {
      return rgb(now(), 12, var0);
   }

   public static int logoTop(float var0) {
      return rgb(now(), 15, var0);
   }

   public static int logoBottom(float var0) {
      return rgb(now(), 18, var0);
   }

   public static float halloween() {
      return now()[22];
   }

   public static float lightAmount() {
      return now()[21];
   }

   public static Color accentColor(int var0) {
      float[] var1 = now();
      return new Color(Math.round(var1[0]), Math.round(var1[1]), Math.round(var1[2]), Math.max(0, Math.min(255, var0)));
   }

   public int previewAccent() {
      return 0xFF000000 | this.accent;
   }

   public int previewLight() {
      return 0xFF000000 | this.light;
   }

   public int previewTop() {
      return 0xFF000000 | this.bgTop;
   }

   public int previewLogo() {
      return 0xFF000000 | this.logoBottom;
   }
}
