package kaze.feature;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import kaze.event.EventListener;
import kaze.event.events.Render3DEvent;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.Setting;
import kaze.module.setting.StringSetting;
import kaze.utils.BytecodeException;
import kaze.utils.EnchantmentUtil;
import kaze.utils.EncryptedString;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.ClientConnection;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

public final class SpawnerProtectModule extends Module {
   private static final double REACH = 4.3;
   private static final int TARGET_TIMEOUT_TICKS = 400;
   private static final int STUCK_CHECK_TICKS = 60;
   private static final int NO_TARGET_GRACE_TICKS = 30;
   private static final int OFFHAND_SLOT = 40;
   private final NumberSetting detectRange;
   private final NumberSetting emergencyDistance;
   private final NumberSetting mineRadius;
   private final BooleanSetting useEnderChest;
   private final NumberSetting stashStacks;
   private final StringSetting whitelist;
   private final BooleanSetting chatAlerts;
   private final Random random;
   private final Set<BlockPos> skipped;
   private SpawnerProtectModule.ProtectionState state;
   private BlockPos origin;
   private BlockPos target;
   private BlockPos chestPos;
   private int targetTicks;
   private int stateTicks;
   private int actionDelay;
   private int noTargetTicks;
   private int nextOpenAttempt;
   private Vec3d stuckCheckPos;
   private int stuckTicks;
   private boolean chestFull;
   private boolean stashFailed;
   private boolean warnedNoPickaxe;
   private boolean warnedNoChest;
   private int aimTicks;
   private int stashCooldown;
   private int stashFailures;
   private BlockPos jitterFor;
   private double jitterA;
   private double jitterB;
   private boolean aimActive;
   private boolean aimOvershoot;
   private long aimStart;
   private long aimDuration;
   private float aimStartYaw;
   private float aimStartPitch;
   private float aimEndYaw;
   private float aimEndPitch;
   private float aimFinalYaw;
   private float aimFinalPitch;
   private float aimCurve;
   private float tremorYaw;
   private float tremorPitch;
   private float tremorTargetYaw;
   private float tremorTargetPitch;
   private long nextTremorChange;
   private long lastAimUpdate;
   private int lastMineAge;

   public SpawnerProtectModule() {
      super(EncryptedString.of("Spawner Protect"),
         EncryptedString.of("Mines and stashes your spawners when a player shows up, and logs out if they get too close"),
         -1, Category.MACROS);
      this.detectRange = new NumberSetting(EncryptedString.of("Detect Range"), 8.0, 128.0, 48.0, 1.0)
         .getValue(EncryptedString.of("Starts protecting when another player comes within this many blocks"));
      this.emergencyDistance = new NumberSetting(EncryptedString.of("Emergency Distance"), 0.0, 32.0, 5.0, 1.0)
         .getValue(EncryptedString.of("Logs out if a player gets this close (0 = off)"));
      this.mineRadius = new NumberSetting(EncryptedString.of("Mine Radius"), 4.0, 32.0, 12.0, 1.0)
         .getValue(EncryptedString.of("Spawners within this many blocks of where you stood get collected"));
      this.useEnderChest = new BooleanSetting(EncryptedString.of("Use Ender Chest"), true)
         .setDescription(EncryptedString.of("Stores the spawners in the ender chest placed next to them"));
      this.stashStacks = new NumberSetting(EncryptedString.of("Stash After Stacks"), 1.0, 27.0, 4.0, 1.0)
         .getValue(EncryptedString.of("Stores spawners in the ender chest once you carry this many stacks"));
      this.whitelist = new StringSetting(EncryptedString.of("Whitelist"), "")
         .setDescription(EncryptedString.of("Player names that won't trigger it, separated by commas"));
      this.chatAlerts = new BooleanSetting(EncryptedString.of("Chat Alerts"), true);
      this.random = new Random();
      this.skipped = new HashSet<>();
      this.state = ProtectionState.IDLE;
      this.lastMineAge = Integer.MIN_VALUE;
      this.addSettings(new Setting[]{this.detectRange, this.emergencyDistance, this.mineRadius,
         this.useEnderChest, this.stashStacks, this.whitelist, this.chatAlerts});
   }

   public void onEnable() {
      this.reset();
      if (this.mc.player != null && this.findSilkPickaxe() == (-1)) {
         this.warnNoPickaxe();
      }

      super.onEnable();
   }

   public void onDisable() {
      this.reset();
      super.onDisable();
   }

   private void reset() {
      this.releaseKeys();
      if (this.mc.interactionManager != null) {
         this.mc.interactionManager.cancelBlockBreaking();
      }

      this.state = SpawnerProtectModule.ProtectionState.IDLE;
      this.skipped.clear();
      this.origin = null;
      this.target = null;
      this.chestPos = null;
      this.targetTicks = 0;
      this.stateTicks = 0;
      this.actionDelay = 0;
      this.noTargetTicks = 0;
      this.nextOpenAttempt = 0;
      this.stuckCheckPos = null;
      this.stuckTicks = 0;
      this.chestFull = false;
      this.stashFailed = false;
      this.warnedNoPickaxe = false;
      this.warnedNoChest = false;
      this.aimTicks = 0;
      this.stashCooldown = 0;
      this.stashFailures = 0;
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.player != null && this.mc.world != null && this.mc.interactionManager != null) {
         AbstractClientPlayerEntity var2 = this.nearestThreat();
         double var3 = var2 == null ? 1.7976931348623157e+308 : Math.sqrt(this.mc.player.squaredDistanceTo(var2));
         if (var2 != null
            && this.emergencyDistance.getValue() > 0.0
            && var3 <= this.emergencyDistance.getValue()) {
            this.emergencyLogout(var2, var3);
         } else {
            int var5 = var2 != null && var3 <= this.detectRange.getValue() ? 1 : 0;
            switch (this.state) {
               case IDLE:
                  if (var5 == 0) {
                     this.warnedNoPickaxe = false;
                  } else if (this.findSilkPickaxe() == (-1)) {
                     if (!this.warnedNoPickaxe) {
                        this.warnNoPickaxe();
                     }
                  } else {
                     this.start(var2);
                  }

                  return;
               case DONE:
                  this.releaseKeys();
                  if (var5 == 0) {
                     this.state = SpawnerProtectModule.ProtectionState.IDLE;
                     this.warnedNoPickaxe = false;
                  }

                  return;
               default:
                  this.stateTicks += 1;
                  if (this.actionDelay > 0) {
                     this.actionDelay -= 1;
                  } else {
                     switch (this.state) {
                        case MINING:
                           this.tickMining();
                           break;
                        case STASH_WALK:
                           this.tickStashWalk();
                           break;
                        case STASH_OPEN:
                           this.tickStashOpen();
                           break;
                        case STASH_DEPOSIT:
                           this.tickStashDeposit();
                     }
                  }
            }
         }
      }
   }

   private void start(AbstractClientPlayerEntity var1) {
      this.origin = this.mc.player.getBlockPos();
      this.skipped.clear();
      this.chestFull = false;
      this.stashFailed = false;
      this.stashFailures = 0;
      this.stashCooldown = 0;
      this.warnedNoChest = false;
      this.target = null;
      this.setState(SpawnerProtectModule.ProtectionState.MINING);
      this.alert("§e" + var1.getName().getString() + " §fdetected - mining your spawners");
      if (this.useEnderChest.getValue() && this.findPlacedChest() == null) {
         this.warnNoChest();
      }
   }

   private void tickMining() {
      this.mc.options.sneakKey.setPressed(true);
      if (this.stashCooldown > 0) {
         this.stashCooldown -= 1;
      }

      if (this.shouldStash(false)) {
         this.beginStash();
      } else {
         if (this.target == null || !this.isSpawner(this.target)) {
            this.target = this.nextTarget();
            this.targetTicks = 0;
            this.aimTicks = 0;
            this.stuckCheckPos = null;
            this.stuckTicks = 0;
            if (this.target == null) {
               this.stopWalking();
               if ((this.noTargetTicks += 1) < (30)) {
                  return;
               }

               if (this.shouldStash(true)) {
                  this.beginStash();
                  return;
               }

               if (this.stashCooldown > 0 && this.canStash() && this.countItem(Items.SPAWNER) > 0) {
                  return;
               }

               this.finish();
               return;
            }
         }

         this.noTargetTicks = 0;
         int var1 = this.findSilkPickaxe();
         if (var1 == (-1)) {
            this.warnNoPickaxe();
            this.finish();
         } else {
            this.mc.player.getInventory().setSelectedSlot(var1);
            if ((this.targetTicks += 1) > (400)) {
               this.skipTarget("took too long");
            } else {
               Vec3d var2 = Vec3d.ofCenter(this.target);
               if (this.mc.player.getEyePos().squaredDistanceTo(var2) <= 18.49) {
                  this.stopWalking();
                  boolean var3 = this.lookAt(this.faceCenter(this.target));
                  BlockHitResult var4 = this.crosshairBlock();
                  if (var4 != null && !var4.getBlockPos().equals(this.target) && this.isCollectable(var4.getBlockPos())) {
                     this.target = var4.getBlockPos().toImmutable();
                  }

                  if (var4 != null && var4.getBlockPos().equals(this.target)) {
                     this.aimTicks = 0;
                     this.mineBlock(this.target, var4.getSide());
                  } else if (var3 && (this.aimTicks += 1) > (40)) {
                     this.skipTarget("blocked from view");
                  }
               } else if (!this.walkTowards(var2)) {
                  this.skipTarget("can't walk there");
               }
            }
         }
      }
   }

   private boolean isCollectable(BlockPos var1) {
      double var2 = this.mineRadius.getValue();
      return ((this.isSpawner(var1)
            && !this.skipped.contains(var1)
            && var1.getSquaredDistance(this.origin) <= var2 * var2));
   }

   private Vec3d faceCenter(BlockPos pos) {
      if (!pos.equals(this.jitterFor)) {
         this.jitterFor = pos;
         this.jitterA = (this.random.nextDouble() - 0.5) * 0.5;
         this.jitterB = (this.random.nextDouble() - 0.5) * 0.5;
      }

      Vec3d eye = this.mc.player.getEyePos();
      Vec3d center = Vec3d.ofCenter(pos);
      Direction facing = Direction.getFacing((float)(eye.x - center.x), (float)(eye.y - center.y), (float)(eye.z - center.z));
      Vec3d point = center.add(facing.getOffsetX() * 0.45, facing.getOffsetY() * 0.45, facing.getOffsetZ() * 0.45);
      if (facing.getOffsetX() != 0) {
         return point.add(0.0, this.jitterA, this.jitterB);
      } else {
         return facing.getOffsetY() != 0 ? point.add(this.jitterA, 0.0, this.jitterB) : point.add(this.jitterA, this.jitterB, 0.0);
      }
   }

   private BlockHitResult crosshairBlock() {
      if (this.mc.crosshairTarget instanceof BlockHitResult var1 && var1.getType() == Type.BLOCK) {
         return var1;
      }

      return null;
   }

   private BlockPos nextTarget() {
      double var1 = this.mineRadius.getValue() * this.mineRadius.getValue();
      int var3 = (int)Math.ceil(this.mineRadius.getValue() / 16.0)
         + (1);
      ChunkPos var4 = new ChunkPos(this.origin);
      BlockPos var5 = null;
      double var6 = 1.7976931348623157e+308;

      for (int var8 = var4.x - var3; var8 <= var4.x + var3; var8++) {
         for (int var9 = var4.z - var3; var9 <= var4.z + var3; var9++) {
            if (this.mc.world.isChunkLoaded(var8, var9)) {
               WorldChunk var10 = this.mc.world.getChunk(var8, var9);

               for (BlockEntity var12 : var10.getBlockEntities().values()) {
                  if (var12 instanceof MobSpawnerBlockEntity) {
                     BlockPos var13 = var12.getPos();
                     if (!this.skipped.contains(var13)
                        && var13.getSquaredDistance(this.origin) <= var1
                        && this.isSpawner(var13)) {
                        double var14 = this.mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(var13));
                        if (var14 < var6) {
                           var6 = var14;
                           var5 = var13.toImmutable();
                        }
                     }
                  }
               }
            }
         }
      }

      return var5;
   }

   private boolean isSpawner(BlockPos var1) {
      return this.mc.world.getBlockState(var1).isOf(Blocks.SPAWNER);
   }

   private void skipTarget(String var1) {
      this.alert("§cSkipped spawner at " + this.target.toShortString() + " (" + var1 + ")");
      this.skipped.add(this.target);
      this.target = null;
      this.mc.interactionManager.cancelBlockBreaking();
   }

   private void finish() {
      this.releaseKeys();
      this.mc.interactionManager.cancelBlockBreaking();
      String var1 = this.skipped.isEmpty()
         ? "All spawners mined"
         : "Done - " + this.skipped.size() + " spawner(s) could not be reached";
      int var2 = this.countItem(Items.SPAWNER);
      String var3 = var2 > 0
         ? "[Spawner Protect] " + var1 + " - logged out holding " + var2 + " spawners"
         : "[Spawner Protect] " + var1 + " and stored in the ender chest - logged out";
      if (this.isEnabled()) {
         this.toggle();
      }

      if (this.mc.getNetworkHandler() != null) {
         this.mc.getNetworkHandler().getConnection().disconnect(Text.literal(var3));
      }
   }

   private void mineBlock(BlockPos var1, Direction var2) {
      if (this.mc.player.age != this.lastMineAge) {
         this.lastMineAge = this.mc.player.age;
         if (this.mc.interactionManager.updateBlockBreakingProgress(var1, var2)) {
            this.mc.player.swingHand(Hand.MAIN_HAND);
         }
      }
   }

   private boolean walkTowards(Vec3d var1) {
      this.lookAt(var1);
      this.mc.options.forwardKey.setPressed(true);
      this.mc
         .options
         .jumpKey
         .setPressed(((this.mc.player.horizontalCollision && this.mc.player.isOnGround())));
      if (this.stuckCheckPos == null) {
         this.stuckCheckPos = this.mc.player.getEntityPos();
         this.stuckTicks = 0;
      } else if ((this.stuckTicks += 1) >= (60)) {
         int var2 = this.mc.player.getEntityPos().squaredDistanceTo(this.stuckCheckPos)
               > 0.09
            ? 1
            : 0;
         this.stuckCheckPos = this.mc.player.getEntityPos();
         this.stuckTicks = 0;
         if (var2 == 0) {
            this.stopWalking();
            return false;
         }
      }

      return true;
   }

   private void stopWalking() {
      this.mc.options.forwardKey.setPressed(false);
      this.mc.options.jumpKey.setPressed(false);
   }

   private void releaseKeys() {
      if (this.mc.options != null) {
         this.mc.options.forwardKey.setPressed(false);
         this.mc.options.jumpKey.setPressed(false);
         this.mc.options.sneakKey.setPressed(false);
      }
   }

   @EventListener
   public void onRender3D(Render3DEvent var1) {
      if (this.mc.player != null
         && this.state != SpawnerProtectModule.ProtectionState.IDLE
         && this.state != SpawnerProtectModule.ProtectionState.DONE) {
         this.updateAim(System.nanoTime());
      }
   }

   private boolean lookAt(Vec3d var1) {
      long var2 = System.nanoTime();
      float[] var4 = this.rotationTo(var1);
      float var5 = this.aimActive ? this.aimFinalYaw : this.mc.player.getYaw();
      float var6 = this.aimActive ? this.aimFinalPitch : this.mc.player.getPitch();
      float var7 = angleBetween(var5, var6, var4[0], var4[1]);
      if (var7 > 6.0F) {
         this.startAim(
            var4[0],
            var4[1],
            var2 + (long)((60) + this.random.nextInt(100)) * (1000000L),
            true
         );
      } else if (var7 > 0.4000000059604645F) {
         if (this.aimActive) {
            this.aimFinalYaw = this.aimStartYaw
               + MathHelper.wrapDegrees(var4[0] - this.aimStartYaw);
            this.aimFinalPitch = var4[1];
            if (!this.aimOvershoot) {
               this.aimEndYaw = this.aimFinalYaw;
               this.aimEndPitch = this.aimFinalPitch;
            }
         } else {
            this.startAim(var4[0], var4[1], var2, false);
         }
      }

      this.updateAim(var2);
      return ((!this.aimActive
            && angleBetween(
                  this.mc.player.getYaw(), this.mc.player.getPitch(), var4[0], var4[1]
               )
               < 3.0F));
   }

   private void startAim(float var1, float var2, long var3, boolean var5) {
      float var6 = this.mc.player.getYaw();
      float var7 = this.mc.player.getPitch();
      float var8 = MathHelper.wrapDegrees(var1 - var6);
      float var9 = var2 - var7;
      float var10 = (float)Math.sqrt((double)(var8 * var8 + var9 * var9));
      this.aimFinalYaw = var6 + var8;
      this.aimFinalPitch = var2;
      this.aimOvershoot = ((var5
            && var10 > 20.0F
            && this.random.nextFloat() < 0.3499999940395355F));
      float var11 = this.aimOvershoot
         ? 1.0399999618530273F + this.random.nextFloat() * 0.05999999865889549F
         : 1.0F;
      this.aimStartYaw = var6;
      this.aimStartPitch = var7;
      this.aimEndYaw = var6 + var8 * var11;
      this.aimEndPitch = MathHelper.clamp(
         var7 + var9 * var11, -90.0F, 90.0F
      );
      double var12 = (
            90.0
               + 110.0
                  * (
                     Math.log(
                           1.0
                              + (double)var10 / 4.0
                        )
                        / Math.log(2.0)
                  )
         )
         * (
            0.85
               + this.random.nextDouble() * 0.35
         );
      this.aimDuration = (long)(var12 * 1000000.0);
      this.aimCurve = (this.random.nextFloat() - 0.5F)
         * 0.23999999463558197F;
      this.aimStart = var3;
      this.aimActive = true;
   }

   private void updateAim(long var1) {
      if (this.mc.player != null && this.mc.currentScreen == null) {
         double var3 = this.lastAimUpdate == (0L)
            ? 0.0
            : Math.min(
               0.1,
               (double)(var1 - this.lastAimUpdate) / 1000000000.0
            );
         this.lastAimUpdate = var1;
         if (this.aimActive) {
            if (var1 < this.aimStart) {
               return;
            }

            if (var1 - this.aimStart > this.aimDuration + (500000000L)) {
               this.aimActive = false;
               return;
            }

            double var5 = Math.min(
               1.0,
               (double)(var1 - this.aimStart) / (double)this.aimDuration
            );
            double var7 = var5
               * var5
               * var5
               * (
                  10.0
                     - 15.0 * var5
                     + 6.0 * var5 * var5
               );
            float var9 = this.aimEndYaw - this.aimStartYaw;
            float var10 = this.aimEndPitch - this.aimStartPitch;
            double var11 = Math.sqrt((double)(var9 * var9 + var10 * var10));
            double var13 = Math.sin(3.141592653589793 * var7)
               * (double)this.aimCurve
               * var11;
            double var15 = var11 > 0.001
               ? (double)(-var10) / var11
               : 0.0;
            double var17 = var11 > 0.001
               ? (double)var9 / var11
               : 0.0;
            this.moveLook(
               (float)((double)this.aimStartYaw + (double)var9 * var7 + var15 * var13),
               (float)((double)this.aimStartPitch + (double)var10 * var7 + var17 * var13)
            );
            if (var5 >= 1.0) {
               if (this.aimOvershoot) {
                  this.aimOvershoot = false;
                  this.aimStartYaw = this.mc.player.getYaw();
                  this.aimStartPitch = this.mc.player.getPitch();
                  this.aimEndYaw = this.aimFinalYaw;
                  this.aimEndPitch = this.aimFinalPitch;
                  float var19 = angleBetween(
                     this.aimStartYaw, this.aimStartPitch, this.aimEndYaw, this.aimEndPitch
                  );
                  this.aimDuration = (long)(
                     (
                           60.0
                              + (double)this.random.nextInt(60)
                              + (double)var19 * 4.0
                        )
                        * 1000000.0
                  );
                  this.aimCurve = 0.0F;
                  this.aimStart = var1
                     + (long)((20) + this.random.nextInt(40)) * (1000000L);
               } else {
                  this.aimActive = false;
               }
            }
         } else if (var3 > 0.0) {
            if (var1 >= this.nextTremorChange) {
               this.tremorTargetYaw = (this.random.nextFloat() - 0.5F)
                  * 0.6000000238418579F;
               this.tremorTargetPitch = (this.random.nextFloat() - 0.5F)
                  * 0.4000000059604645F;
               this.nextTremorChange = var1
                  + (long)((180) + this.random.nextInt(260)) * (1000000L);
            }

            float var20 = (float)(
               1.0
                  - Math.exp(-var3 / 0.25)
            );
            float var6 = (this.tremorTargetYaw - this.tremorYaw) * var20;
            float var21 = (this.tremorTargetPitch - this.tremorPitch) * var20;
            this.tremorYaw += var6;
            this.tremorPitch += var21;
            this.moveLook(this.mc.player.getYaw() + var6, this.mc.player.getPitch() + var21);
         }
      } else {
         this.lastAimUpdate = var1;
      }
   }

   private void moveLook(float var1, float var2) {
      double var3 = (double)(var1 - this.mc.player.getYaw());
      double var5 = (double)(var2 - this.mc.player.getPitch());
      if (Math.abs(var3) > 0.0001
         || Math.abs(var5) > 0.0001) {
         this.mc
            .player
            .changeLookDirection(
               var3 / 0.15,
               var5 / 0.15
            );
      }
   }

   private float[] rotationTo(Vec3d var1) {
      Vec3d var2 = this.mc.player.getEyePos();
      double var3 = var1.x - var2.x;
      double var5 = var1.y - var2.y;
      double var7 = var1.z - var2.z;
      float var9 = (float)Math.toDegrees(Math.atan2(var7, var3)) - 90.0F;
      float var10 = (float)(-Math.toDegrees(Math.atan2(var5, Math.sqrt(var3 * var3 + var7 * var7))));
      float[] var10000 = new float[2];
      var10000[0] = var9;
      var10000[1] = MathHelper.clamp(
         var10, -90.0F, 90.0F
      );
      return var10000;
   }

   private static float angleBetween(float var0, float var1, float var2, float var3) {
      float var4 = MathHelper.wrapDegrees(var2 - var0);
      float var5 = var3 - var1;
      return (float)Math.sqrt((double)(var4 * var4 + var5 * var5));
   }

   private boolean canStash() {
      return ((this.useEnderChest.getValue()
            && !this.chestFull
            && !this.stashFailed
            && this.findPlacedChest() != null));
   }

   private boolean shouldStash(boolean var1) {
      if (this.useEnderChest.getValue() && !this.chestFull && !this.stashFailed && this.stashCooldown <= 0) {
         int var2 = this.countItem(Items.SPAWNER);
         if (var2 == 0) {
            return false;
         } else {
            int var3 = !var1
                  && var2 < this.stashStacks.getIntValue() * (64)
                  && this.mc.player.getInventory().getEmptySlot() != (-1)
               ? 0
               : 1;
            if (var3 == 0) {
               return false;
            } else if (this.findPlacedChest() == null) {
               if (!this.warnedNoChest) {
                  this.warnNoChest();
               }

               return false;
            } else {
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private BlockPos findPlacedChest() {
      double var1 = Math.max(8.0, this.mineRadius.getValue());
      double var3 = var1 * var1;
      int var5 = (int)Math.ceil(var1 / 16.0) + (1);
      BlockPos var6 = this.origin != null ? this.origin : this.mc.player.getBlockPos();
      ChunkPos var7 = new ChunkPos(var6);
      BlockPos var8 = null;
      double var9 = 1.7976931348623157e+308;

      for (int var11 = var7.x - var5; var11 <= var7.x + var5; var11++) {
         for (int var12 = var7.z - var5; var12 <= var7.z + var5; var12++) {
            if (this.mc.world.isChunkLoaded(var11, var12)) {
               for (BlockEntity var14 : this.mc.world.getChunk(var11, var12).getBlockEntities().values()) {
                  if (var14 instanceof EnderChestBlockEntity) {
                     BlockPos var15 = var14.getPos();
                     if (var15.getSquaredDistance(var6) <= var3 && this.mc.world.getBlockState(var15).isOf(Blocks.ENDER_CHEST)) {
                        double var16 = this.mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(var15));
                        if (var16 < var9) {
                           var9 = var16;
                           var8 = var15.toImmutable();
                        }
                     }
                  }
               }
            }
         }
      }

      return var8;
   }

   private void beginStash() {
      this.stopWalking();
      this.mc.interactionManager.cancelBlockBreaking();
      this.chestPos = this.findPlacedChest();
      this.stuckCheckPos = null;
      this.stuckTicks = 0;
      this.setState(SpawnerProtectModule.ProtectionState.STASH_WALK);
   }

   private void stashFailed(String var1) {
      if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
         this.mc.player.closeHandledScreen();
      }

      if ((this.stashFailures += 1) >= (3)) {
         this.alert("§cEnder chest stash failed (" + var1 + ") - keeping spawners in your inventory");
         this.stashFailed = true;
      } else {
         this.alert("§cEnder chest stash failed (" + var1 + ") - trying again in a few seconds");
         this.stashCooldown = 100;
      }

      this.chestPos = null;
      this.stopWalking();
      this.setState(SpawnerProtectModule.ProtectionState.MINING);
   }

   private void tickStashWalk() {
      this.mc.options.sneakKey.setPressed(true);
      if (this.chestPos != null && this.mc.world.getBlockState(this.chestPos).isOf(Blocks.ENDER_CHEST)) {
         Vec3d var1 = Vec3d.ofCenter(this.chestPos);
         if (this.mc.player.getEyePos().squaredDistanceTo(var1) <= 18.49) {
            this.stopWalking();
            this.setState(SpawnerProtectModule.ProtectionState.STASH_OPEN);
         } else if (this.stateTicks > (400) || !this.walkTowards(var1)) {
            this.stashFailed("could not walk to the ender chest");
         }
      } else {
         this.stashFailed("the ender chest is gone");
      }
   }

   private void tickStashOpen() {
      this.mc.options.sneakKey.setPressed(false);
      if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
         this.setState(SpawnerProtectModule.ProtectionState.STASH_DEPOSIT);
         this.actionDelay = 3;
      } else if (this.chestPos == null || !this.mc.world.getBlockState(this.chestPos).isOf(Blocks.ENDER_CHEST)) {
         this.stashFailed("the ender chest is gone");
      } else if (!this.mc.player.isSneaking()) {
         if (this.stateTicks > (60)) {
            this.stashFailed("could not open the ender chest");
         } else {
            boolean var1 = this.lookAt(Vec3d.ofCenter(this.chestPos));
            BlockHitResult var2 = this.crosshairBlock();
            if (var1
               && var2 != null
               && var2.getBlockPos().equals(this.chestPos)
               && this.stateTicks >= this.nextOpenAttempt) {
               this.mc.interactionManager.interactBlock(this.mc.player, Hand.MAIN_HAND, var2);
               this.mc.player.swingHand(Hand.MAIN_HAND);
               this.nextOpenAttempt = this.stateTicks + (20);
            }
         }
      }
   }

   private void tickStashDeposit() {
      if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler var1) {
         int var5 = var1.getRows() * (9);

         for (int var3 = var5; var3 < var1.slots.size(); var3++) {
            ItemStack var4 = var1.getSlot(var3).getStack();
            if (var4.isOf(Items.SPAWNER)) {
               if (this.hasRoomFor(var1, var5, var4)) {
                  this.mc.interactionManager.clickSlot(var1.syncId, var3, 0, SlotActionType.QUICK_MOVE, this.mc.player);
                  this.actionDelay = (2) + this.random.nextInt(2);
                  return;
               }

               this.chestFull = true;
               this.alert(
                  "§eEnder chest is full, keeping the rest in your inventory"
               );
               break;
            }
         }

         this.mc.player.closeHandledScreen();
         this.alert("§aStored spawners in the ender chest");
         this.chestPos = null;
         this.setState(SpawnerProtectModule.ProtectionState.MINING);
         this.actionDelay = 2;
      } else {
         this.setState(SpawnerProtectModule.ProtectionState.MINING);
      }
   }

   private boolean hasRoomFor(GenericContainerScreenHandler var1, int var2, ItemStack var3) {
      for (int var4 = 0; var4 < var2; var4++) {
         ItemStack var5 = var1.getSlot(var4).getStack();
         if (var5.isEmpty() || ItemStack.areItemsAndComponentsEqual(var5, var3) && var5.getCount() < var5.getMaxCount()) {
            return true;
         }
      }

      return false;
   }

   private AbstractClientPlayerEntity nearestThreat() {
      HashSet var1 = new HashSet();
      String[] var2 = this.whitelist.getValue().split(",");
      int var3 = var2.length;

      for (int var4 = 0; var4 < var3; var4++) {
         String var5 = var2[var4];
         if (!var5.isBlank()) {
            var1.add(var5.trim().toLowerCase(Locale.ROOT));
         }
      }

      AbstractClientPlayerEntity var9 = null;
      double var10 = 1.7976931348623157e+308;

      for (AbstractClientPlayerEntity var6 : this.mc.world.getPlayers()) {
         if (var6 != this.mc.player
            && !var6.isSpectator()
            && isRealPlayer(var6.getUuid())
            && !var1.contains(var6.getName().getString().toLowerCase(Locale.ROOT))) {
            double var7 = this.mc.player.squaredDistanceTo(var6);
            if (var7 < var10) {
               var10 = var7;
               var9 = var6;
            }
         }
      }

      return var9;
   }

   private static boolean isRealPlayer(UUID var0) {
      return ((var0.version() == (4)));
   }

   private void emergencyLogout(AbstractClientPlayerEntity var1, double var2) {
      String var4 = var1.getName().getString();
      this.reset();
      if (this.mc.getNetworkHandler() != null) {
         this.mc
            .getNetworkHandler()
            .getConnection()
            .disconnect(Text.literal("[Spawner Protect] Logged out - " + var4 + " came within " + Math.round(var2) + " blocks"));
      }
   }

   private int findSilkPickaxe() {
      PlayerInventory var1 = this.mc.player.getInventory();

      for (int var2 = 0; var2 < (9); var2++) {
         ItemStack var3 = var1.getStack(var2);
         if (var3.isIn(ItemTags.PICKAXES) && EnchantmentUtil.hasEnchantment(var3, Enchantments.SILK_TOUCH)) {
            return var2;
         }
      }

      return -1;
   }

   private int countItem(Item var1) {
      int var2 = 0;
      PlayerInventory var3 = this.mc.player.getInventory();

      for (int var4 = 0; var4 < (36); var4++) {
         ItemStack var5 = var3.getStack(var4);
         if (var5.isOf(var1)) {
            var2 += var5.getCount();
         }
      }

      return var2;
   }

   private void warnNoPickaxe() {
      this.warnedNoPickaxe = true;
      this.mc
         .player
         .playSound(
            (SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), 1.0F, 0.5F
         );
      this.mc
         .player
         .sendMessage(
            Text.literal(
               "§c[Spawner Protect] §fNot holding a silk touch pickaxe"
            ),
            false
         );
      this.mc
         .player
         .sendMessage(
            Text.literal("§cNot holding a silk touch pickaxe"),
            true
         );
   }

   private void warnNoChest() {
      this.warnedNoChest = true;
      this.mc
         .player
         .playSound((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), 1.0F, 0.5F);
      this.mc
         .player
         .sendMessage(
            Text.literal(
               "§c[Spawner Protect] §fNo ender chest placed nearby - will mine everything and log out when done"
            ),
            false
         );
      this.mc
         .player
         .sendMessage(
            Text.literal("§cNo ender chest placed nearby"),
            true
         );
   }

   private void alert(String var1) {
      if (this.chatAlerts.getValue() && this.mc.player != null) {
         this.mc.player.sendMessage(Text.literal("§6[Spawner Protect] §f" + var1), false);
      }
   }

   private void setState(SpawnerProtectModule.ProtectionState var1) {
      this.state = var1;
      this.stateTicks = 0;
      this.nextOpenAttempt = 0;
   }

   private static enum ProtectionState {
      IDLE,
      MINING,
      STASH_WALK,
      STASH_OPEN,
      STASH_DEPOSIT,
      DONE;
   }
}

