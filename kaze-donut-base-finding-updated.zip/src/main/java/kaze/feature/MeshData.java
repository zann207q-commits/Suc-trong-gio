package kaze.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class MeshData {
   final float[] pos;
   final int vertexCount;
   final int[] tris;
   final int triCount;

   MeshData(float[] positions, int vertexCount, int[] triangles, int triangleCount) {
      this.pos = positions;
      this.vertexCount = vertexCount;
      this.tris = triangles;
      this.triCount = triangleCount;
   }



}
