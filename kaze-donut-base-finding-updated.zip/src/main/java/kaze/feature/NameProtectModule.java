package kaze.feature;

import kaze.Kaze;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.ModuleManager;
import kaze.module.setting.StringSetting;
import kaze.utils.EncryptedString;

public class NameProtectModule extends Module {
   private final StringSetting fakeName;

   public NameProtectModule() {
      super(
         EncryptedString.of("Name Protect"),
         EncryptedString.of("Replaces your name with given one."),
         -1,
         Category.MISC
      );
      this.fakeName = new StringSetting("Fake Name", "Player");
      this.addSettings(this.fakeName);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   public String getFakeName() {
      String value = this.fakeName.getValue();
      return value != null && !value.isBlank() ? value.trim() : "Player";
   }

   public static String displayName(String original) {
      if (original == null || original.isEmpty()) {
         return "";
      }
      Kaze client = Kaze.INSTANCE;
      if (client == null) {
         return original;
      }
      ModuleManager modules = client.getModuleManager();
      if (modules == null) {
         return original;
      }
      NameProtectModule nameProtect = (NameProtectModule)modules.getModuleByClass(NameProtectModule.class);
      return nameProtect != null && nameProtect.isEnabled() ? nameProtect.getFakeName() : original;
   }
}
