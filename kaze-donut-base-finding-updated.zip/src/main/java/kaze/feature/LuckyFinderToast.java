package kaze.feature;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.toast.Toast.Visibility;

public final class LuckyFinderToast implements Toast {
   private static final Identifier TEXTURE = Identifier.ofVanilla("toast/advancement");
   private static final ItemStack ICON = new ItemStack(Items.EMERALD);
   private static final Text TITLE = Text.literal("Lucky Finder");
   private final Text coordinates;
   private Visibility visibility = Visibility.SHOW;

   public LuckyFinderToast(int var1, int var2) {
      this.coordinates = Text.literal("X: " + var1 + " Z: " + var2);
   }

   public Visibility getVisibility() {
      return this.visibility;
   }

   public void update(ToastManager var1, long var2) {
      this.visibility = (double)var2 >= 5000.0 * var1.getNotificationDisplayTimeMultiplier() ? Visibility.HIDE : Visibility.SHOW;
   }

   public void draw(DrawContext var1, TextRenderer var2, long var3) {
      var1.drawGuiTexture(RenderPipelines.GUI_TEXTURED, TEXTURE, 0, 0, this.getWidth(), this.getHeight());
      var1.drawText(var2, TITLE, 30, 7, -43521, false);
      var1.drawText(var2, this.coordinates, 30, 18, -1, false);
      var1.drawItemWithoutEntity(ICON, 8, 8);
   }
}
