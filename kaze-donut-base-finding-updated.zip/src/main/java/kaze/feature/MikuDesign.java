package kaze.feature;

import java.util.ArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class MikuDesign extends CharacterDefinition {
   private static final int SKIN = -8241;
   private static final int SKIN_SHADE = -1198942;
   private static final int SKIN_LINE = -5740452;
   private static final int HAIR_ROOT = -14705514;
   private static final int HAIR = -12793152;
   private static final int HAIR_TIP = -7936291;
   private static final int HAIR_SHADE = -15368325;
   private static final int HAIR_LINE = -15903662;
   private static final int SHINE = -857866245;
   private static final int SHIRT = -2499360;
   private static final int SHIRT_SHADE = -5525063;
   private static final int SHIRT_LINE = -10788500;
   private static final int BLACK = -13618373;
   private static final int BLACK_SHADE = -14934492;
   private static final int BLACK_IN = -15592681;
   private static final int BLACK_LINE = -16119026;
   private static final int TEAL = -13645638;
   private static final int TEAL_DARK = -14971002;
   private static final int MAGENTA = -1882484;
   private static final int TATTOO = -2608065;
   private static final float SKIRT_TOP = 17.9F;
   private static final float SKIRT_HEM = 13.3F;
   private static final int PLEATS = 18;
   private static final float HS = 1.12F;
   private static final float DROP = 0.4F;
   private static final float HX = 0.0F;
   private static final float HY = 28.9F;
   private static final float HZ = -0.3F;
   private static final float PPU = 56.88889F;
   private static final float FACE_TOP = 29.95F;
   private static final float[][] LOCKS;

   public MikuDesign() {
      super("miku", "Miku");
   }

   protected void define(CharacterRig var1) {
      var1.scale(1.0F)
         .outline(-14011336, 0.11999999731779099F)
         .occlusion(0.30000001192092896F)
         .flatLight(0.550000011920929F);
      float[][] var2 = lockPaths();
      SurfacePaint var3 = hairPaint();
      head(var1, var2);
      hair(var1, var3);
      fringe(var1, var2);
      twinTails(var1);
      headset(var1);
      body(var1);
      skirt(var1);
      arms(var1);
      legs(var1);
   }

   private static Sdf3D up(Sdf3D var0) {
      return var0.scale(
            1.1200000047683716F,
            0.0F,
            24.600000381469727F,
            -0.20000000298023224F
         )
         .move(0.0F, -0.4000000059604645F, 0.0F);
   }

   private static float tx(float var0) {
      return var0 * 1.1200000047683716F;
   }

   private static float ty(float var0) {
      return 24.600000381469727F
         + (var0 - 24.600000381469727F) * 1.1200000047683716F
         - 0.4000000059604645F;
   }

   private static float tz(float var0) {
      return -0.20000000298023224F
         + (var0 + 0.20000000298023224F) * 1.1200000047683716F;
   }

   private static Sdf3D headBase() {
      float var10000 = 0.8500000238418579F;
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = SdfShapes.ellipsoid(
         0.0F,
         28.719999313354492F,
         -0.15000000596046448F,
         2.2799999713897705F,
         2.4000000953674316F,
         2.3499999046325684F
      );
      var10001[1] = SdfShapes.ellipsoid(
         0.0F,
         27.75F,
         0.550000011920929F,
         2.049999952316284F,
         1.2999999523162842F,
         1.75F
      );
      var10001[2] = SdfShapes.cone(
         0.0F,
         27.299999237060547F,
         0.6200000047683716F,
         1.350000023841858F,
         0.0F,
         26.049999237060547F,
         1.2000000476837158F,
         0.30000001192092896F
      );
      return SdfShapes.blend(var10000, var10001);
   }

   private static void head(CharacterRig var0, float[][] var1) {
      Sdf3D var2 = SdfShapes.capsule(
         0.0F,
         23.299999237060547F,
         -0.44999998807907104F,
         0.0F,
         25.899999618530273F,
         -0.30000001192092896F,
         0.5799999833106995F
      );
      float var3 = ty(25.81999969482422F);
      float var4 = tz(1.2000000476837158F);
      SurfacePaint var5 = SurfacePaint.field(
         (var2x, var3x, var4x) -> {
            float var5x = var3 + Math.max(0.0F, var4 - var4x) * 0.6200000047683716F;
            float var6x = smooth(var5x + 0.05000000074505806F, var5x - 0.20000000298023224F, var3x)
               * (
                  0.6000000238418579F
                     + 0.4000000059604645F
                        * smooth(23.399999618530273F, 24.799999237060547F, var3x)
               );
            return ArgbColors.mix(-8241, -1198942, var6x);
         }
      );
      Sdf3D var6 = up(
         headBase().intersect(SdfShapes.below(30.200000762939453F))
      );
      CharacterPartBuilder var10000 = var0.part(CharacterBone.HEAD)
         .pivot(0.0F, 24.600000381469727F, -0.20000000298023224F);
      float var10001 = 0.44999998807907104F;
      Sdf3D[] var10002 = new Sdf3D[2];
      var10002[0] = var6;
      var10002[1] = var2;
      var10000.shape(SdfShapes.blend(var10001, var10002).paint(var5))
         .detail(2.0F)
         .flatLight(1.0F)
         .occlusion(0.2199999988079071F)
         .outline(-5740452, 0.10000000149011612F)
         .decal(face(var1));
   }

   private static float[][] lockPaths() {
      Sdf3D var0 = headBase();
      float[][] var1 = new float[LOCKS.length][];

      for (int var2 = 0; var2 < LOCKS.length; var2++) {
         float[] var3 = LOCKS[var2];
         float[] var4 = onHead(
            36.0F, var3[2], -0.15000000596046448F
         );
         float[] var5 = onHead(
            58.0F, var3[2], 0.05000000074505806F
         );
         float var6 = var5[0]
            + (var3[0] - var5[0]) * 0.75F;
         float var7 = var3[1] + 0.6800000071525574F;
         float var8 = var3[0] - Math.signum(var3[0]) * var3[4];
         float[] var10002 = new float[13];
         var10002[0] = var4[0];
         var10002[1] = var4[1];
         var10002[2] = var4[2];
         var10002[3] = var5[0];
         var10002[4] = var5[1];
         var10002[5] = var5[2];
         var10002[6] = var6;
         var10002[7] = var7;
         var10002[8] = frontZ(var0, var6, var7) + var3[5];
         var10002[9] = var8;
         var10002[10] = var3[1];
         var10002[11] = frontZ(var0, var8, var3[1])
            + 0.2199999988079071F;
         var10002[12] = var3[3];
         var1[var2] = var10002;
      }

      return var1;
   }

   private static float frontZ(Sdf3D var0, float var1, float var2) {
      float var3 = 3.5F;

      while (var3 > -1.0F && var0.distance(var1, var2, var3) > 0.0F) {
         var3 -= 0.019999999552965164F;
      }

      return var3;
   }

   private static void fringe(CharacterRig var0, float[][] var1) {
      Sdf3D[] var2 = new Sdf3D[var1.length];
      Sdf3D[] var3 = new Sdf3D[var1.length];

      for (int var4 = 0; var4 < var1.length; var4++) {
         float[] var5 = var1[var4];
         float var6 = var5[12];
         float[] var10000 = new float[16];
         var10000[0] = var5[0];
         var10000[1] = var5[1];
         var10000[2] = var5[2];
         var10000[3] = 0.8999999761581421F * var6;
         var10000[4] = var5[3];
         var10000[5] = var5[4];
         var10000[6] = var5[5];
         var10000[7] = 1.149999976158142F * var6;
         var10000[8] = var5[6];
         var10000[9] = var5[7];
         var10000[10] = var5[8];
         var10000[11] = 0.949999988079071F * var6;
         var10000[12] = var5[9];
         var10000[13] = var5[10];
         var10000[14] = var5[11];
         var10000[15] = 0.11999999731779099F;
         TaperedTubeSdf3D var7 = SdfShapes.tube(var10000)
            .flattenFrom(
               3.0F,
               0.0F,
               28.700000762939453F,
               -0.15000000596046448F
            );
         var3[var4] = SdfShapes.extrude(
            Sdf2D.polygon(blade(var5)),
            5.0F,
            0.0F
         );
         var2[var4] = SdfShapes.intersect(var7, var3[var4]);
      }

      Sdf3D var8 = SdfShapes.intersect(
         SdfShapes.blend(0.15000000596046448F, var2), SdfShapes.union(var3)
      );
      Sdf3D var9 = headBase();
      SurfacePaint var10 = SurfacePaint.field(
         (var1x, var2x, var3x) -> {
            int var4x = ArgbColors.mix(
               ArgbColors.mix(-14705514, -12793152, 0.44999998807907104F),
               -12793152,
               smooth(30.899999618530273F, 29.700000762939453F, var2x)
            );
            var4x = ArgbColors.mix(
               var4x,
               -7936291,
               0.44999998807907104F
                  * smooth(29.5F, 28.5F, var2x)
            );
            return ArgbColors.mix(
               var4x,
               -15368325,
               0.6000000238418579F
                  * (
                     1.0F
                        - smooth(0.11999999731779099F, 0.41999998688697815F, var9.distance(var1x, var2x, var3x))
                  )
            );
         }
      );
      var0.extra("fringe", CharacterBone.HEAD)
         .shape(up(var8.paint(var10)))
         .resolution(0.44999998807907104F)
         .detail(1.0499999523162842F)
         .flatLight(0.699999988079071F)
         .occlusion(0.10000000149011612F)
         .outline(-15903662, 0.09000000357627869F)
         .decal(shine());
   }

   private static float[] blade(float[] var0) {
      float var1 = var0[12];
      int var2 = var0[9] < 0.0F ? 1 : 0;
      float var3 = var0[3];
      float var4 = 31.600000381469727F;
      float var5 = var0[6];
      float var6 = var0[7];
      float var7 = var0[9];
      float var8 = var0[10];
      int var9 = 12;
      float[] var10 = new float[((2) * var9 + (1)) * (2)];

      for (int var11 = 0; var11 <= var9; var11++) {
         float var12 = (float)var11 / (float)var9;
         float var13 = 1.0F - var12;
         float var14 = var13 * var13 * var3 + 2.0F * var13 * var12 * var5 + var12 * var12 * var7;
         float var15 = var13 * var13 * var4 + 2.0F * var13 * var12 * var6 + var12 * var12 * var8;
         float var16 = var13 * (var5 - var3) + var12 * (var7 - var5);
         float var17 = var13 * (var6 - var4) + var12 * (var8 - var6);
         float var18 = (float)Math.sqrt((double)(var16 * var16 + var17 * var17));
         float var19 = -var17 / var18;
         float var20 = var16 / var18;
         if ((var19 > 0.0F ? 1 : 0) != var2) {
            var19 = -var19;
            var20 = -var20;
         }

         float var21 = var1
            * (
               1.0F
                  - smooth(0.6000000238418579F, 1.0F, var12)
            );
         float var22 = var1
            * (
               1.0F
                  - (float)Math.pow(
                     (double)smooth(0.30000001192092896F, 1.0F, var12),
                     0.75
                  )
            );
         var10[var11 * (2)] = var14 + var19 * var21;
         var10[var11 * (2) + (1)] = var15 + var20 * var21;
         if (var11 < var9) {
            var10[((2) * var9 - var11) * (2)] = var14 - var19 * var22;
            var10[((2) * var9 - var11) * (2) + (1)] = var15 - var20 * var22;
         }
      }

      return var10;
   }

   private static SurfaceDecal shine() {
      PixelCanvas var0 = new PixelCanvas(280, 22);
      float[][] var10000 = new float[5][];
      int var10002 = 0;
      float[] var10003 = new float[2];
      var10003[0] = -68.0F;
      var10003[1] = -54.0F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[2];
      var10003[0] = -45.0F;
      var10003[1] = -25.0F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[2];
      var10003[0] = -13.0F;
      var10003[1] = 9.0F;
      var10000[var10002] = var10003;
      var10002 = 3;
      var10003 = new float[2];
      var10003[0] = 20.0F;
      var10003[1] = 38.0F;
      var10000[var10002] = var10003;
      var10002 = 4;
      var10003 = new float[2];
      var10003[0] = 48.0F;
      var10003[1] = 64.0F;
      var10000[var10002] = var10003;
      float[][] var1 = var10000;
      float[][] var2 = var1;
      int var3 = var1.length;

      for (int var4 = 0; var4 < var3; var4++) {
         float[] var5 = var2[var4];
         float var6 = var5[0];
         float var7 = var5[1];
         float var8 = (var6 + var7) * 0.5F;
         float var9 = 6.5F - Math.abs(var8) * 0.02500000037252903F;
         var0.fill(
            Sdf2D.curve(
               140.0F + var6 * 2.0F,
               ringY(var6),
               140.0F + var6 + var8,
               ringY((var6 + var8) * 0.5F),
               140.0F + var8 * 2.0F,
               ringY(var8),
               1.0F,
               var9
            ),
            -857866245
         );
         var0.fill(
            Sdf2D.curve(
               140.0F + var8 * 2.0F,
               ringY(var8),
               140.0F + var8 + var7,
               ringY((var8 + var7) * 0.5F),
               140.0F + var7 * 2.0F,
               ringY(var7),
               var9,
               1.0F
            ),
            -857866245
         );
      }

      return SurfaceDecal.wrap(
            var0,
            0.0F,
            ty(30.15999984741211F),
            tz(-0.30000001192092896F),
            0.0F,
            1.0F,
            0.0F,
            0.0F,
            0.0F,
            1.0F,
            140.0F,
            0.6272000074386597F
         )
         .radius(1.2000000476837158F, 3.799999952316284F)
         .offset(0.029999999329447746F);
   }

   private static float ringY(float var0) {
      float var1 = 30.399999618530273F
         - 0.36000001430511475F * (1.0F - (float)Math.cos(Math.toRadians((double)var0)));
      return (30.440000534057617F - var1) * 40.0F;
   }

   private static void hair(CharacterRig var0, SurfacePaint var1) {
      ArrayList var2 = new ArrayList();
      var2.add(
         SdfShapes.ellipsoid(
            0.0F,
            28.899999618530273F,
            -0.30000001192092896F,
            2.5799999237060547F,
            2.619999885559082F,
            2.700000047683716F
         )
      );
      float[] var10000 = new float[4];
      var10000[0] = 64.0F;
      var10000[1] = 88.0F;
      var10000[2] = 272.0F;
      var10000[3] = 296.0F;
      float[] var3 = var10000;
      int var4 = var3.length;

      for (int var5 = 0; var5 < var4; var5++) {
         float var6 = var3[var5];
         var2.add(
            capLock(
               var6,
               5.0F,
               98.0F,
               0.800000011920929F,
               0.6200000047683716F
            )
         );
      }

      for (float var11 = 130.0F;
         var11 <= 230.0F;
         var11 += 25.0F
      ) {
         var2.add(
            capLock(
               var11,
               20.0F,
               118.0F,
               0.8500000238418579F,
               0.5F
            )
         );
      }

      Sdf3D var12 = SdfShapes.box(
         0.0F,
         26.299999237060547F,
         2.299999952316284F,
         2.950000047683716F,
         3.299999952316284F,
         2.799999952316284F,
         0.8999999761581421F
      );
      float var16 = 0.30000001192092896F;
      Sdf3D[] var10001 = new Sdf3D[2];
      int var10003 = 0;
      float var10004 = 0.6200000047683716F;
      float var10005 = 0.4399999976158142F;
      float[] var10006 = new float[9];
      var10006[0] = -2.299999952316284F;
      var10006[1] = 29.600000381469727F;
      var10006[2] = -0.05000000074505806F;
      var10006[3] = -2.4800000190734863F;
      var10006[4] = 28.100000381469727F;
      var10006[5] = -0.11999999731779099F;
      var10006[6] = -2.450000047683716F;
      var10006[7] = 26.5F;
      var10006[8] = -0.2199999988079071F;
      var10001[var10003] = SdfShapes.strand(var10004, var10005, var10006)
         .flatten(
            1.600000023841858F,
            1.0F,
            0.0F,
            0.0F
         );
      var10003 = 1;
      var10004 = 0.6800000071525574F;
      var10005 = 0.4399999976158142F;
      var10006 = new float[9];
      var10006[0] = -2.25F;
      var10006[1] = 29.5F;
      var10006[2] = -0.949999988079071F;
      var10006[3] = -2.4600000381469727F;
      var10006[4] = 27.899999618530273F;
      var10006[5] = -1.0499999523162842F;
      var10006[6] = -2.450000047683716F;
      var10006[7] = 26.299999237060547F;
      var10006[8] = -1.1200000047683716F;
      var10001[var10003] = SdfShapes.strand(var10004, var10005, var10006)
         .flatten(
            1.600000023841858F,
            1.0F,
            0.0F,
            0.0F
         );
      Sdf3D var13 = SdfShapes.blend(var16, var10001).mirrorX();
      float var17 = 0.8999999761581421F;
      float var22 = 0.30000001192092896F;
      float[] var10002 = new float[9];
      var10002[0] = 0.0F;
      var10002[1] = 28.0F;
      var10002[2] = -2.3499999046325684F;
      var10002[3] = 0.0F;
      var10002[4] = 26.600000381469727F;
      var10002[5] = -2.200000047683716F;
      var10002[6] = 0.0F;
      var10002[7] = 25.600000381469727F;
      var10002[8] = -1.9500000476837158F;
      TaperedTubeSdf3D var14 = SdfShapes.strand(var17, var22, var10002)
         .flatten(
            2.200000047683716F,
            0.0F,
            0.0F,
            1.0F
         );
      float var18 = 0.25F;
      var10001 = new Sdf3D[3];
      var10001[0] = SdfShapes.subtract(
            SdfShapes.blend(0.30000001192092896F, ((Sdf3D[]) var2.toArray(new Sdf3D[0]))),
            var12
         )
         .paint(var1);
      var10001[1] = var13.paint(var1.occlusion(0.3499999940395355F));
      var10001[2] = var14.paint(var1);
      Sdf3D var15 = SdfShapes.blend(var18, var10001);
      var0.extra("hair", CharacterBone.HEAD)
         .shape(up(var15))
         .detail(1.100000023841858F)
         .flatLight(0.550000011920929F)
         .occlusion(0.2199999988079071F)
         .outline(-15903662, 0.09000000357627869F)
         .decal(shine());
      var10000 = new float[24];
      var10000[0] = -1.9500000476837158F;
      var10000[1] = 30.399999618530273F;
      var10000[2] = 0.9200000166893005F;
      var10000[3] = 0.550000011920929F;
      var10000[4] = -2.299999952316284F;
      var10000[5] = 29.299999237060547F;
      var10000[6] = 1.1200000047683716F;
      var10000[7] = 0.6000000238418579F;
      var10000[8] = -2.4200000762939453F;
      var10000[9] = 27.799999237060547F;
      var10000[10] = 1.0F;
      var10000[11] = 0.550000011920929F;
      var10000[12] = -2.4000000953674316F;
      var10000[13] = 25.899999618530273F;
      var10000[14] = 0.800000011920929F;
      var10000[15] = 0.46000000834465027F;
      var10000[16] = -2.299999952316284F;
      var10000[17] = 24.0F;
      var10000[18] = 0.7799999713897705F;
      var10000[19] = 0.36000001430511475F;
      var10000[20] = -2.1500000953674316F;
      var10000[21] = 22.600000381469727F;
      var10000[22] = 0.8199999928474426F;
      var10000[23] = 0.05000000074505806F;
      TaperedTubeSdf3D var7 = SdfShapes.tube(var10000)
         .flatten(
            1.7999999523162842F,
            1.0F,
            0.0F,
            0.30000001192092896F
         );
      var10000 = new float[24];
      var10000[0] = -2.200000047683716F;
      var10000[1] = 30.200000762939453F;
      var10000[2] = 0.10000000149011612F;
      var10000[3] = 0.5799999833106995F;
      var10000[4] = -2.5199999809265137F;
      var10000[5] = 28.899999618530273F;
      var10000[6] = 0.23999999463558197F;
      var10000[7] = 0.6200000047683716F;
      var10000[8] = -2.5799999237060547F;
      var10000[9] = 27.299999237060547F;
      var10000[10] = 0.3199999928474426F;
      var10000[11] = 0.550000011920929F;
      var10000[12] = -2.450000047683716F;
      var10000[13] = 25.600000381469727F;
      var10000[14] = 0.5F;
      var10000[15] = 0.41999998688697815F;
      var10000[16] = -2.359999895095825F;
      var10000[17] = 23.799999237060547F;
      var10000[18] = 0.5199999809265137F;
      var10000[19] = 0.25F;
      var10000[20] = -2.299999952316284F;
      var10000[21] = 23.0F;
      var10000[22] = 0.550000011920929F;
      var10000[23] = 0.03999999910593033F;
      TaperedTubeSdf3D var8 = SdfShapes.tube(var10000)
         .flatten(
            1.7999999523162842F,
            1.0F,
            0.0F,
            0.15000000596046448F
         );
      BoneMotionProfile var9 = new BoneMotionProfile()
         .idle(
            1.5F,
            0.0F,
            0.6000000238418579F,
            0.3499999940395355F
         )
         .walk(
            3.0F,
            0.0F,
            1.0F,
            2.0F
         )
         .drag(8.0F)
         .hang(0.6000000238418579F)
         .spring(60.0F, 8.0F)
         .bend(1.399999976158142F);
      CharacterPartBuilder var21 = var0.extra(
            "sidelock_r", CharacterBone.HEAD
         )
         .pivot(
            tx(-2.299999952316284F),
            ty(30.0F),
            tz(0.6000000238418579F)
         );
      float var24 = 0.25F;
      Sdf3D[] var25 = new Sdf3D[2];
      var25[0] = var7;
      var25[1] = var8;
      CharacterPartBuilder var10 = var21.shape(up(SdfShapes.blend(var24, var25).paint(var1)))
         .motion(var9)
         .resolution(0.699999988079071F)
         .detail(0.6000000238418579F)
         .flatLight(0.5F)
         .occlusion(0.3499999940395355F)
         .outline(-15903662, 0.09000000357627869F);
      var0.extra("sidelock_l", CharacterBone.HEAD).mirrorOf(var10);
   }

   private static void twinTails(CharacterRig var0) {
      float var1 = tx(-2.619999885559082F);
      float var2 = ty(30.200000762939453F);
      float var3 = tz(-1.350000023841858F);
      float[][] var10000 = new float[3][];
      int var10002 = 0;
      float[] var10003 = new float[24];
      var10003[0] = 0.0F;
      var10003[1] = 0.0F;
      var10003[2] = 1.0F;
      var10003[3] = -0.8999999761581421F;
      var10003[4] = -0.5F;
      var10003[5] = 1.350000023841858F;
      var10003[6] = -1.5F;
      var10003[7] = -2.5999999046325684F;
      var10003[8] = 1.5F;
      var10003[9] = -1.75F;
      var10003[10] = -6.5F;
      var10003[11] = 1.4500000476837158F;
      var10003[12] = -1.75F;
      var10003[13] = -11.5F;
      var10003[14] = 1.2999999523162842F;
      var10003[15] = -1.600000023841858F;
      var10003[16] = -16.5F;
      var10003[17] = 1.0499999523162842F;
      var10003[18] = -1.4500000476837158F;
      var10003[19] = -20.5F;
      var10003[20] = 0.699999988079071F;
      var10003[21] = -1.350000023841858F;
      var10003[22] = -23.399999618530273F;
      var10003[23] = 0.05999999865889549F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[24];
      var10003[0] = 0.0F;
      var10003[1] = 0.10000000149011612F;
      var10003[2] = 0.800000011920929F;
      var10003[3] = -1.0F;
      var10003[4] = -0.4000000059604645F;
      var10003[5] = 1.0F;
      var10003[6] = -1.899999976158142F;
      var10003[7] = -2.799999952316284F;
      var10003[8] = 1.100000023841858F;
      var10003[9] = -2.200000047683716F;
      var10003[10] = -7.0F;
      var10003[11] = 1.0F;
      var10003[12] = -2.25F;
      var10003[13] = -12.0F;
      var10003[14] = 0.8999999761581421F;
      var10003[15] = -2.049999952316284F;
      var10003[16] = -17.0F;
      var10003[17] = 0.699999988079071F;
      var10003[18] = -1.850000023841858F;
      var10003[19] = -20.799999237060547F;
      var10003[20] = 0.44999998807907104F;
      var10003[21] = -1.9500000476837158F;
      var10003[22] = -22.799999237060547F;
      var10003[23] = 0.03999999910593033F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[24];
      var10003[0] = 0.0F;
      var10003[1] = 0.10000000149011612F;
      var10003[2] = 0.800000011920929F;
      var10003[3] = -0.699999988079071F;
      var10003[4] = -0.6000000238418579F;
      var10003[5] = 1.0F;
      var10003[6] = -1.0F;
      var10003[7] = -2.9000000953674316F;
      var10003[8] = 1.0499999523162842F;
      var10003[9] = -1.149999976158142F;
      var10003[10] = -7.199999809265137F;
      var10003[11] = 1.0F;
      var10003[12] = -1.100000023841858F;
      var10003[13] = -12.199999809265137F;
      var10003[14] = 0.8999999761581421F;
      var10003[15] = -0.949999988079071F;
      var10003[16] = -16.799999237060547F;
      var10003[17] = 0.699999988079071F;
      var10003[18] = -0.8999999761581421F;
      var10003[19] = -20.200000762939453F;
      var10003[20] = 0.44999998807907104F;
      var10003[21] = -0.75F;
      var10003[22] = -22.200000762939453F;
      var10003[23] = 0.03999999910593033F;
      var10000[var10002] = var10003;
      float[][] var4 = var10000;
      float[] var17 = new float[3];
      var17[0] = 0.0F;
      var17[1] = -0.25F;
      var17[2] = 0.20000000298023224F;
      float[] var5 = var17;
      Sdf3D[] var6 = new Sdf3D[var4.length];

      for (int var7 = 0; var7 < var4.length; var7++) {
         float[] var8 = var4[var7];
         float[] var9 = new float[var8.length / (3) * (4)];

         for (int var10 = 0; var10 < var8.length / (3); var10++) {
            float var11 = (float)var10 / ((float)var8.length / 3.0F - 1.0F);
            var9[var10 * (4)] = var1 + var8[var10 * (3)];
            var9[var10 * (4) + (1)] = var2
               + var8[var10 * (3) + (1)] * 1.1200000047683716F;
            var9[var10 * (4) + (2)] = var3
               - 1.149999976158142F
                  * (float)Math.sin(
                     (double)Math.min(1.0F, var11 * 3.0F)
                        * 3.141592653589793
                        * 0.5
                  )
               + var5[var7] * var11;
            var9[var10 * (4) + (3)] = var8[var10 * (3) + (2)];
         }

         var6[var7] = SdfShapes.tube(var9)
            .flatten(
               1.7000000476837158F,
               0.25F,
               0.0F,
               1.0F
            );
      }

      float var12 = var2 - 26.20800018310547F;
      SurfacePaint var13 = SurfacePaint.field(
         (var3x, var4x, var5x) -> {
            float var6x = clamp01((var2 - var4x) / (var2 - var12));
            int var7x = ArgbColors.mix(
               -14705514,
               -12793152,
               smooth(0.0F, 0.18000000715255737F, var6x)
            );
            var7x = ArgbColors.mix(
               var7x,
               -7936291,
               0.6000000238418579F
                  * smooth(0.550000011920929F, 1.0F, var6x)
            );
            float var8x = smooth(
                  0.4000000059604645F,
                  -0.6000000238418579F,
                  var3x - var1 + 1.600000023841858F
               )
               * 0.3499999940395355F;
            return ArgbColors.mix(var7x, -15368325, var8x);
         }
      );
      Sdf3D[] var18 = new Sdf3D[3];
      var18[0] = SdfShapes.box(
            var1 - 0.30000001192092896F,
            var2,
            var3,
            0.3400000035762787F,
            1.0F,
            0.75F,
            0.14000000059604645F
         )
         .color(-13618373);
      var18[1] = SdfShapes.box(
            var1 - 0.6200000047683716F,
            var2,
            var3 + 0.3799999952316284F,
            0.05999999865889549F,
            0.8600000143051147F,
            0.09000000357627869F,
            0.029999999329447746F
         )
         .color(-1882484);
      var18[2] = SdfShapes.box(
            var1 - 0.6200000047683716F,
            var2,
            var3 - 0.3799999952316284F,
            0.05999999865889549F,
            0.8600000143051147F,
            0.09000000357627869F,
            0.029999999329447746F
         )
         .color(-1882484);
      Sdf3D var14 = SdfShapes.union(var18)
         .rotate(
            0.0F,
            0.0F,
            -12.0F,
            var1,
            var2,
            var3
         );
      BoneMotionProfile var15 = BoneMotionProfile.hair()
         .hang(0.25F)
         .follow(CharacterBone.BODY, 0.800000011920929F)
         .drag(12.0F)
         .turn(6.0F, 0.0F)
         .spring(40.0F, 6.0F)
         .bend(1.600000023841858F)
         .limit(35.0F);
      CharacterPartBuilder var19 = var0.extra("tail_r", CharacterBone.HEAD)
         .pivot(var1, var2, var3);
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.blend(0.3499999940395355F, var6).paint(var13);
      var10001[1] = var14;
      CharacterPartBuilder var16 = var19.shape(SdfShapes.union(var10001))
         .motion(var15)
         .resolution(1.0F)
         .detail(0.8999999761581421F)
         .flatLight(0.5F)
         .occlusion(0.30000001192092896F)
         .outline(-15903662, 0.10000000149011612F);
      var0.extra("tail_l", CharacterBone.HEAD).mirrorOf(var16);
   }

   private static void headset(CharacterRig var0) {
      Sdf3D[] var10000 = new Sdf3D[2];
      var10000[0] = SdfShapes.cylinder(
            -2.450000047683716F,
            28.0F,
            0.05000000074505806F,
            -2.8499999046325684F,
            28.0F,
            0.05000000074505806F,
            0.6200000047683716F,
            0.11999999731779099F
         )
         .color(-13618373);
      var10000[1] = SdfShapes.cylinder(
            -2.799999952316284F,
            28.0F,
            0.05000000074505806F,
            -2.950000047683716F,
            28.0F,
            0.05000000074505806F,
            0.3799999952316284F,
            0.05999999865889549F
         )
         .color(-13645638);
      Sdf3D var1 = SdfShapes.union(var10000);
      var10000 = new Sdf3D[2];
      int var10002 = 0;
      float[] var10003 = new float[16];
      var10003[0] = -2.700000047683716F;
      var10003[1] = 27.700000762939453F;
      var10003[2] = 0.44999998807907104F;
      var10003[3] = 0.07999999821186066F;
      var10003[4] = -2.450000047683716F;
      var10003[5] = 26.799999237060547F;
      var10003[6] = 1.2999999523162842F;
      var10003[7] = 0.07999999821186066F;
      var10003[8] = -1.7000000476837158F;
      var10003[9] = 26.25F;
      var10003[10] = 2.049999952316284F;
      var10003[11] = 0.07999999821186066F;
      var10003[12] = -0.949999988079071F;
      var10003[13] = 26.149999618530273F;
      var10003[14] = 2.25F;
      var10003[15] = 0.07999999821186066F;
      var10000[var10002] = SdfShapes.tube(var10003).color(-13618373);
      var10000[1] = SdfShapes.ellipsoid(
            -0.8500000238418579F,
            26.149999618530273F,
            2.2799999713897705F,
            0.2199999988079071F,
            0.1599999964237213F,
            0.1599999964237213F
         )
         .color(-14934492);
      Sdf3D var2 = SdfShapes.union(var10000);
      CharacterPartBuilder var4 = var0.extra("headset", CharacterBone.HEAD);
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = var1;
      var10001[1] = var1.mirrored();
      var10001[2] = var2;
      var4.shape(up(SdfShapes.union(var10001)))
         .resolution(0.4000000059604645F)
         .detail(0.6000000238418579F)
         .flatLight(0.4000000059604645F)
         .outline(-16119026, 0.07999999821186066F);
   }

   private static Sdf3D capLock(float var0, float var1, float var2, float var3, float var4) {
      float[] var5 = new float[15];

      for (int var6 = 0; var6 < (5); var6++) {
         float[] var7 = onHead(
            var1 + (var2 - var1) * (float)var6 / 4.0F, var0, 0.019999999552965164F
         );
         System.arraycopy(var7, 0, var5, var6 * (3), 3);
      }

      return SdfShapes.strand(var3, var4, var5)
         .flattenFrom(
            2.799999952316284F,
            0.0F,
            28.899999618530273F,
            -0.30000001192092896F
         );
   }

   private static float[] onHead(float var0, float var1, float var2) {
      double var3 = Math.toRadians((double)var0);
      double var5 = Math.toRadians((double)var1);
      float var7 = (float)Math.cos(var3);
      float var8 = (float)Math.sin(var3);
      float var9 = (float)Math.cos(var5);
      float var10 = (float)Math.sin(var5);
      float var11 = var10 * var8;
      float var12 = 0.9700000286102295F * var7 + 0.23999999463558197F * var9 * var8;
      float var13 = -0.23999999463558197F * var7 + 0.9700000286102295F * var9 * var8;
      float var14 = 1.0F
            / (float)Math.sqrt(
               (double)(
                  var11 * var11 / 7.39840030670166F
                     + var12 * var12 / 7.39840030670166F
                     + var13 * var13 / 8.06559944152832F
               )
            )
         + var2;
      float[] var10000 = new float[3];
      var10000[0] = 0.0F + var11 * var14;
      var10000[1] = 28.899999618530273F + var12 * var14;
      var10000[2] = -0.30000001192092896F + var13 * var14;
      return var10000;
   }

   private static SurfacePaint hairPaint() {
      return SurfacePaint.field(
         (var0, var1, var2) -> {
            float var3 = var1 - 31.200000762939453F;
            float var4 = var2 + 0.699999988079071F;
            float var5 = (float)Math.sqrt((double)(var0 * var0 + var3 * var3 + var4 * var4));
            int var6 = ArgbColors.mix(
               -14705514,
               -12793152,
               smooth(0.800000011920929F, 2.9000000953674316F, var5)
            );
            return ArgbColors.mix(
               var6,
               -7936291,
               smooth(5.5F, 17.5F, var5)
                  * 0.8999999761581421F
            );
         }
      );
   }

   private static void body(CharacterRig var0) {
      Sdf3D[] var10000 = new Sdf3D[2];
      var10000[0] = SdfShapes.capsule(
         0.0F,
         23.950000762939453F,
         -0.15000000596046448F,
         -2.450000047683716F,
         23.299999237060547F,
         -0.15000000596046448F,
         0.8999999761581421F
      );
      var10000[1] = SdfShapes.capsule(
         0.0F,
         23.950000762939453F,
         -0.15000000596046448F,
         2.450000047683716F,
         23.299999237060547F,
         -0.15000000596046448F,
         0.8999999761581421F
      );
      Sdf3D var1 = SdfShapes.union(var10000);
      Sdf3D var2 = SdfShapes.ellipsoid(
         0.0F,
         21.700000762939453F,
         0.05000000074505806F,
         2.450000047683716F,
         2.0999999046325684F,
         1.649999976158142F
      );
      Sdf3D var3 = SdfShapes.ellipsoid(
            0.8399999737739563F,
            21.600000381469727F,
            0.6000000238418579F,
            0.8999999761581421F,
            0.800000011920929F,
            0.949999988079071F
         )
         .mirrorX();
      Sdf3D var4 = SdfShapes.ellipsoid(
         0.0F,
         19.600000381469727F,
         0.0F,
         2.0F,
         1.7000000476837158F,
         1.4500000476837158F
      );
      Sdf3D var5 = SdfShapes.ellipsoid(
         0.0F,
         17.799999237060547F,
         0.0F,
         2.1500000953674316F,
         1.600000023841858F,
         1.5F
      );
      float var18 = 1.0F;
      Sdf3D[] var10001 = new Sdf3D[4];
      var10001[0] = var1;
      int var10003 = 1;
      float var10004 = 0.800000011920929F;
      Sdf3D[] var10005 = new Sdf3D[2];
      var10005[0] = var2;
      var10005[1] = var3;
      var10001[var10003] = SdfShapes.blend(var10004, var10005);
      var10001[2] = var4;
      var10001[3] = var5;
      Sdf3D var6 = SdfShapes.blend(var18, var10001)
         .intersect(SdfShapes.above(17.200000762939453F));
      SurfacePaint var7 = SurfacePaint.field(
         (var0x, var1x, var2x) -> {
            float var3x = smooth(0.5F, 1.2999999523162842F, var2x)
               * smooth(19.899999618530273F, 20.5F, var1x)
               * (
                  1.0F
                     - smooth(20.600000381469727F, 21.100000381469727F, var1x)
               );
            float var4x = smooth(1.600000023841858F, 2.299999952316284F, Math.abs(var0x))
               * 0.3499999940395355F;
            return ArgbColors.mix(
               -2499360, -5525063, Math.max(var3x * 0.550000011920929F, var4x)
            );
         }
      );
      var0.part(CharacterBone.BODY)
         .shape(var6.paint(var7))
         .outline(-10788500, 0.10000000149011612F)
         .detail(0.8500000238418579F)
         .occlusion(0.20000000298023224F);
      float[] var19 = new float[10];
      var19[0] = 0.05000000074505806F;
      var19[1] = 24.5F;
      var19[2] = 1.149999976158142F;
      var19[3] = 24.549999237060547F;
      var19[4] = 1.350000023841858F;
      var19[5] = 23.700000762939453F;
      var19[6] = 0.6000000238418579F;
      var19[7] = 23.149999618530273F;
      var19[8] = 0.07999999821186066F;
      var19[9] = 23.549999237060547F;
      Sdf2D var8 = Sdf2D.polygon(var19);
      Sdf3D var9 = SdfShapes.extrude(
            var8, 0.14000000059604645F, 0.07000000029802322F
         )
         .rotate(
            -25.0F,
            -20.0F,
            0.0F,
            0.5F,
            23.899999618530273F,
            0.0F
         )
         .move(
            0.0F,
            0.0F,
            frontZ(var6, 0.6000000238418579F, 23.799999237060547F)
               + 0.019999999552965164F
         );
      var10000 = new Sdf3D[2];
      var10000[0] = var9;
      var10000[1] = var9.mirrored();
      Sdf3D var10 = SdfShapes.union(var10000).color(-2499360);
      var0.extra("collar", CharacterBone.BODY)
         .shape(var10)
         .resolution(0.3499999940395355F)
         .detail(0.800000011920929F)
         .flatLight(0.30000001192092896F)
         .outline(-13645638, 0.10000000149011612F);
      float[] var21 = new float[5];
      var21[0] = 23.350000381469727F;
      var21[1] = 22.399999618530273F;
      var21[2] = 21.299999237060547F;
      var21[3] = 20.200000762939453F;
      var21[4] = 19.299999237060547F;
      float[] var11 = var21;
      float[] var22 = new float[5];
      var22[0] = 0.25999999046325684F;
      var22[1] = 0.3199999928474426F;
      var22[2] = 0.3799999952316284F;
      var22[3] = 0.41999998688697815F;
      var22[4] = 0.4399999976158142F;
      float[] var12 = var22;
      float[] var13 = new float[var11.length * (4)];

      for (int var14 = 0; var14 < var11.length; var14++) {
         var13[var14 * (4) + (1)] = var11[var14];
         var13[var14 * (4) + (2)] = frontZ(
               var6, 0.0F, var11[var14]
            )
            + 0.10000000149011612F;
         var13[var14 * (4) + (3)] = var12[var14];
      }

      float[] var23 = new float[10];
      var23[0] = -1.0F;
      var23[1] = 24.0F;
      var23[2] = 1.0F;
      var23[3] = 24.0F;
      var23[4] = 1.0F;
      var23[5] = 19.700000762939453F;
      var23[6] = 0.0F;
      var23[7] = 19.100000381469727F;
      var23[8] = -1.0F;
      var23[9] = 19.700000762939453F;
      Sdf2D var17 = Sdf2D.polygon(var23);
      Sdf3D var15 = SdfShapes.intersect(
         SdfShapes.tube(var13)
            .flatten(
               3.5F,
               0.0F,
               0.0F,
               1.0F
            ),
         SdfShapes.extrude(var17, 4.0F, 0.0F)
      );
      Sdf3D var16 = SdfShapes.ellipsoid(
         0.0F,
         23.450000762939453F,
         frontZ(var6, 0.0F, 23.450000762939453F)
            + 0.11999999731779099F,
         0.36000001430511475F,
         0.30000001192092896F,
         0.2199999988079071F
      );
      CharacterPartBuilder var24 = var0.extra("tie", CharacterBone.BODY)
         .pivot(0.0F, 23.450000762939453F, 1.600000023841858F);
      var10001 = new Sdf3D[2];
      var10001[0] = var15;
      var10001[1] = var16;
      var24.shape(
            SdfShapes.union(var10001)
               .paint(
                  SurfacePaint.vertical(
                     -14971002,
                     19.299999237060547F,
                     -13645638,
                     22.5F
                  )
               )
         )
         .motion(
            BoneMotionProfile.none()
               .walk(
                  3.0F,
                  0.0F,
                  2.0F,
                  2.0F
               )
               .drag(4.0F)
               .spring(80.0F, 8.0F)
         )
         .resolution(0.4000000059604645F)
         .detail(0.5F)
         .flatLight(0.4000000059604645F)
         .outline(-15835560, 0.07999999821186066F);
   }

   private static void skirt(CharacterRig var0) {
      Sdf3D var1 = SdfShapes.field(
            MikuDesign::skirtDistance,
            -3.4000000953674316F,
            13.100000381469727F,
            -3.0F,
            3.4000000953674316F,
            18.100000381469727F,
            3.0F
         )
         .paint(SurfacePaint.field(MikuDesign::skirtColor));
      var0.extra("skirt", CharacterBone.BODY)
         .pivot(0.0F, 17.899999618530273F, 0.0F)
         .shape(var1)
         .resolution(0.8999999761581421F)
         .detail(0.800000011920929F)
         .occlusion(0.3499999940395355F)
         .outline(-16119026, 0.11999999731779099F)
         .decal(stripe(13.65000057220459F, 0.25999999046325684F))
         .motion(
            BoneMotionProfile.none()
               .walk(
                  0.0F,
                  8.0F,
                  0.0F,
                  1.0F
               )
               .walkPhase(-90.0F)
               .drag(2.0F)
               .spring(80.0F, 10.0F)
         );
   }

   private static float flare(float var0) {
      float var1 = clamp01((17.600000381469727F - var0) / 4.299999237060547F);
      return var1 * (2.0F - var1) * 0.800000011920929F
         + var1 * 0.20000000298023224F;
   }

   private static float pleat(float var0, float var1, float var2) {
      float var3 = 2.25F + 0.949999988079071F * var2;
      float var4 = 1.6200000047683716F + 0.949999988079071F * var2;
      double var5 = Math.atan2((double)(var0 / var3), (double)(var1 / var4))
         * 18.0
         / 6.283185307179586;
      var5 -= Math.floor(var5);
      return (float)Math.abs(
         2.0 * var5 - 1.0
      );
   }

   private static float skirtDistance(float var0, float var1, float var2) {
      float var3 = flare(var1);
      float var4 = 2.25F + 0.949999988079071F * var3;
      float var5 = 1.6200000047683716F + 0.949999988079071F * var3;
      float var6 = var0 / var4;
      float var7 = var2 / var5;
      float var8 = (float)Math.sqrt((double)(var6 * var6 + var7 * var7));
      float var9 = (var8 - 1.0F) * Math.min(var4, var5) * 0.7200000286102295F
         - 0.20000000298023224F
            * var3
            * (pleat(var0, var2, var3) - 0.5F);
      return Math.max(var9, Math.max(var1 - 17.899999618530273F, 13.300000190734863F - var1));
   }

   private static int skirtColor(float var0, float var1, float var2) {
      float var3 = flare(var1);
      return ArgbColors.mix(
         -14934492,
         -13618373,
         0.3499999940395355F
            + 0.6499999761581421F
               * (1.0F - var3 + var3 * pleat(var0, var2, var3))
      );
   }

   private static SurfaceDecal stripe(float var0, float var1) {
      PixelCanvas var2 = new PixelCanvas(512, 24);
      var2.fill(
         Sdf2D.box(
            256.0F,
            12.0F,
            256.0F,
            8.0F,
            0.0F
         ),
         -13645638
      );
      return SurfaceDecal.wrap(
            var2,
            0.0F,
            var0,
            0.0F,
            0.0F,
            1.0F,
            0.0F,
            0.0F,
            0.0F,
            1.0F,
            360.0F,
            var1
         )
         .radius(1.7999999523162842F, 3.4000000953674316F);
   }

   private static void arms(CharacterRig var0) {
      float var1 = -3.5F;
      float var2 = 23.100000381469727F;
      float var3 = -0.11999999731779099F;
      float var4 = -3.950000047683716F;
      float var5 = 19.5F;
      float var6 = -0.30000001192092896F;
      float var7 = -4.199999809265137F;
      float var8 = 16.0F;
      float var9 = 0.4000000059604645F;
      float var10000 = 0.3499999940395355F;
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = SdfShapes.sphere(
         var1 + 0.10000000149011612F, var2, var3, 0.6600000262260437F
      );
      var10001[1] = SdfShapes.cone(
         var1, var2, var3, 0.6200000047683716F, var4, var5, var6, 0.5199999809265137F
      );
      var10001[2] = SdfShapes.cone(
         var4, var5, var6, 0.5199999809265137F, var7, var8, var9, 0.4399999976158142F
      );
      Sdf3D var10 = SdfShapes.blend(var10000, var10001)
         .paint(
            SurfacePaint.field(
               (var0x, var1x, var2x) -> {
                  float var3x = smooth(23.399999618530273F, 21.799999237060547F, var1x);
                  return ArgbColors.mix(
                     -1198942,
                     -8241,
                     0.4000000059604645F + 0.6000000238418579F * var3x
                  );
               }
            )
         );
      CharacterPartBuilder var11 = var0.part(CharacterBone.RIGHT_ARM)
         .pivot(-3.5F, 23.25F, -0.10000000149011612F)
         .grip(-4.320000171661377F, 15.050000190734863F, 0.7200000286102295F)
         .shape(var10)
         .resolution(0.699999988079071F)
         .detail(0.800000011920929F)
         .flatLight(0.800000011920929F)
         .outline(-5740452, 0.10000000149011612F)
         .swing(0.550000011920929F)
         .joint(var4, var5, var6, 0.550000011920929F);
      var0.part(CharacterBone.LEFT_ARM).mirrorOf(var11).decal(tattoo(-var1, var2, var3, -var4, var5, var6));
      float var12 = (float)Math.sqrt((double)((var7 - var4) * (var7 - var4) + (var8 - var5) * (var8 - var5) + (var9 - var6) * (var9 - var6)));
      float var13 = (var7 - var4) / var12;
      float var14 = (var8 - var5) / var12;
      float var15 = (var9 - var6) / var12;
      float var16 = var4 + 0.3499999940395355F * (var7 - var4);
      float var17 = var5 + 0.3499999940395355F * (var8 - var5) + 0.8999999761581421F;
      float var18 = var6 + 0.3499999940395355F * (var9 - var6);
      float var19 = var7 + 1.100000023841858F * var13;
      float var20 = var8 + 1.100000023841858F * var14;
      float var21 = var9 + 1.100000023841858F * var15;
      Sdf3D var22 = SdfShapes.cone(
         var16,
         var17 + 0.30000001192092896F,
         var18,
         0.6200000047683716F,
         var19,
         var20,
         var21,
         1.149999976158142F
      );
      Sdf3D var23 = SdfShapes.sphere(
         var19 + 0.25F * var13,
         var20 + 0.25F * var14,
         var21 + 0.25F * var15,
         0.949999988079071F
      );
      float var25 = var17 + 0.30000001192092896F;
      float var27 = (float)Math.sqrt((double)((var19 - var16) * (var19 - var16) + (var20 - var25) * (var20 - var25) + (var21 - var18) * (var21 - var18)));
      Sdf3D var28 = SdfShapes.subtract(0.10000000149011612F, var22, var23)
         .paint(
            SurfacePaint.field(
               (var7x, var8x, var9x) -> {
                  float var10x = ((var7x - var16) * (var19 - var16) + (var8x - var25) * (var20 - var25) + (var9x - var18) * (var21 - var18)) / (var27 * var27);
                  return ArgbColors.mix(
                     -13618373,
                     -14934492,
                     smooth(0.20000000298023224F, 1.0F, var10x)
                        * 0.5F
                  );
               }
            )
         );
      PixelCanvas var29 = new PixelCanvas(256, 16);
      var29.fill(
         Sdf2D.box(
            128.0F,
            8.0F,
            128.0F,
            6.0F,
            0.0F
         ),
         -13645638
      );
      float var30 = var19 - var16;
      float var31 = var20 - var25;
      float var32 = var21 - var18;
      SurfaceDecal var33 = SurfaceDecal.wrap(
            var29,
            var16 + var30 * 0.9300000071525574F,
            var25 + var31 * 0.9300000071525574F,
            var18 + var32 * 0.9300000071525574F,
            var30,
            var31,
            var32,
            0.0F,
            0.0F,
            1.0F,
            360.0F,
            var27 * 0.10000000149011612F
         )
         .radius(0.699999988079071F, 1.399999976158142F);
      SurfaceDecal var34 = SurfaceDecal.wrap(
            var29,
            var16 + var30 * 0.05000000074505806F,
            var25 + var31 * 0.05000000074505806F,
            var18 + var32 * 0.05000000074505806F,
            var30,
            var31,
            var32,
            0.0F,
            0.0F,
            1.0F,
            360.0F,
            var27 * 0.07999999821186066F
         )
         .radius(0.4000000059604645F, 1.0F);
      CharacterPartBuilder var35 = var0.extra(
            "sleeve_r", CharacterBone.RIGHT_ARM
         )
         .shape(var28)
         .resolution(1.100000023841858F)
         .detail(0.800000011920929F)
         .flatLight(0.30000001192092896F)
         .occlusion(0.4000000059604645F)
         .outline(-16119026, 0.10000000149011612F)
         .decal(var33)
         .decal(var34);
      var0.extra("sleeve_l", CharacterBone.LEFT_ARM).mirrorOf(var35);
      hands(var0, var7, var8, var9);
   }

   private static SurfaceDecal tattoo(float var0, float var1, float var2, float var3, float var4, float var5) {
      PixelCanvas var6 = new PixelCanvas(64, 40);
      var6.fill(
         Sdf2D.ellipse(
               44.0F,
               20.0F,
               9.0F,
               14.0F
            )
            .outline(4.5F),
         -2608065
      );
      var6.fill(
         Sdf2D.line(
            20.0F,
            7.0F,
            20.0F,
            34.0F,
            4.5F
         ),
         -2608065
      );
      var6.fill(
         Sdf2D.line(
            20.0F,
            7.0F,
            14.0F,
            13.0F,
            4.0F
         ),
         -2608065
      );
      float var7 = 0.2199999988079071F;
      float var8 = var0 + (var3 - var0) * var7;
      float var9 = var1 + (var4 - var1) * var7;
      float var10 = var2 + (var5 - var2) * var7;
      return SurfaceDecal.left(
            var6,
            var8 + 0.550000011920929F,
            var9,
            var10 + 0.05000000074505806F,
            1.0F,
            0.6200000047683716F
         )
         .depth(0.6000000238418579F, 0.6000000238418579F)
         .maxAngle(70.0F)
         .flatLight(0.800000011920929F);
   }

   private static void hands(CharacterRig var0, float var1, float var2, float var3) {
      float var4 = 4.300000190734863F;
      float var5 = 15.25F;
      float var6 = 0.6000000238418579F;
      ArrayList var7 = new ArrayList();
      var7.add(
         SdfShapes.ellipsoid(
            var4,
            var5,
            var6,
            0.33000001311302185F,
            0.6000000238418579F,
            0.5199999809265137F
         )
      );
      var7.add(
         SdfShapes.capsule(
            var4 - 0.019999999552965164F,
            var5 + 0.44999998807907104F,
            var6 - 0.11999999731779099F,
            -var1,
            var2 + 0.10000000149011612F,
            var3,
            0.3199999928474426F
         )
      );
      float var10001 = 0.15000000596046448F;
      float var10002 = 0.12999999523162842F;
      float[] var10003 = new float[9];
      var10003[0] = var4 + 0.019999999552965164F;
      var10003[1] = var5 - 0.4000000059604645F;
      var10003[2] = var6 + 0.36000001430511475F;
      var10003[3] = var4 - 0.019999999552965164F;
      var10003[4] = var5 - 0.8600000143051147F;
      var10003[5] = var6 + 0.4399999976158142F;
      var10003[6] = var4 - 0.20000000298023224F;
      var10003[7] = var5 - 1.100000023841858F;
      var10003[8] = var6 + 0.4000000059604645F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      var10001 = 0.15000000596046448F;
      var10002 = 0.12999999523162842F;
      var10003 = new float[9];
      var10003[0] = var4 + 0.029999999329447746F;
      var10003[1] = var5 - 0.4399999976158142F;
      var10003[2] = var6 + 0.11999999731779099F;
      var10003[3] = var4;
      var10003[4] = var5 - 0.9800000190734863F;
      var10003[5] = var6 + 0.14000000059604645F;
      var10003[6] = var4 - 0.2199999988079071F;
      var10003[7] = var5 - 1.2599999904632568F;
      var10003[8] = var6 + 0.10999999940395355F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      var10001 = 0.14000000059604645F;
      var10002 = 0.11999999731779099F;
      var10003 = new float[9];
      var10003[0] = var4 + 0.029999999329447746F;
      var10003[1] = var5 - 0.41999998688697815F;
      var10003[2] = var6 - 0.11999999731779099F;
      var10003[3] = var4;
      var10003[4] = var5 - 0.8999999761581421F;
      var10003[5] = var6 - 0.12999999523162842F;
      var10003[6] = var4 - 0.20000000298023224F;
      var10003[7] = var5 - 1.159999966621399F;
      var10003[8] = var6 - 0.14000000059604645F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      var10001 = 0.12999999523162842F;
      var10002 = 0.10999999940395355F;
      var10003 = new float[9];
      var10003[0] = var4 + 0.019999999552965164F;
      var10003[1] = var5 - 0.36000001430511475F;
      var10003[2] = var6 - 0.3400000035762787F;
      var10003[3] = var4;
      var10003[4] = var5 - 0.7400000095367432F;
      var10003[5] = var6 - 0.36000001430511475F;
      var10003[6] = var4 - 0.1599999964237213F;
      var10003[7] = var5 - 0.949999988079071F;
      var10003[8] = var6 - 0.3499999940395355F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      var10001 = 0.17000000178813934F;
      var10002 = 0.14000000059604645F;
      var10003 = new float[9];
      var10003[0] = var4 - 0.18000000715255737F;
      var10003[1] = var5 + 0.10000000149011612F;
      var10003[2] = var6 + 0.41999998688697815F;
      var10003[3] = var4 - 0.30000001192092896F;
      var10003[4] = var5 - 0.30000001192092896F;
      var10003[5] = var6 + 0.5799999833106995F;
      var10003[6] = var4 - 0.3199999928474426F;
      var10003[7] = var5 - 0.5400000214576721F;
      var10003[8] = var6 + 0.5F;
      var7.add(SdfShapes.strand(var10001, var10002, var10003));
      CharacterPartBuilder var8 = var0.extra(
            "hand_l", CharacterBone.LEFT_ARM
         )
         .shape(
            SdfShapes.blend(0.11999999731779099F, ((Sdf3D[]) var7.toArray(new Sdf3D[0])))
               .color(-8241)
         )
         .resolution(0.44999998807907104F)
         .detail(0.3499999940395355F)
         .flatLight(1.0F)
         .occlusion(0.25F)
         .outline(-5740452, 0.10000000149011612F);
      var0.extra("hand_r", CharacterBone.RIGHT_ARM).mirrorOf(var8);
   }

   private static void legs(CharacterRig var0) {
      float var1 = -1.100000023841858F;
      Sdf3D var2 = SdfShapes.sphere(
         var1, 14.600000381469727F, -0.05000000074505806F, 1.0199999809265137F
      );
      Sdf3D var3 = SdfShapes.cone(
         var1 - 0.05000000074505806F,
         14.300000190734863F,
         0.0F,
         1.0199999809265137F,
         var1,
         8.399999618530273F,
         0.07999999821186066F,
         0.7599999904632568F
      );
      Sdf3D var4 = SdfShapes.sphere(
         var1, 7.900000095367432F, 0.10000000149011612F, 0.7200000286102295F
      );
      float[] var10000 = new float[16];
      var10000[0] = var1;
      var10000[1] = 7.599999904632568F;
      var10000[2] = 0.07999999821186066F;
      var10000[3] = 0.7200000286102295F;
      var10000[4] = var1 - 0.019999999552965164F;
      var10000[5] = 5.800000190734863F;
      var10000[6] = -0.11999999731779099F;
      var10000[7] = 0.800000011920929F;
      var10000[8] = var1 - 0.03999999910593033F;
      var10000[9] = 3.5999999046325684F;
      var10000[10] = -0.019999999552965164F;
      var10000[11] = 0.5600000023841858F;
      var10000[12] = var1 - 0.05000000074505806F;
      var10000[13] = 2.0F;
      var10000[14] = 0.0F;
      var10000[15] = 0.47999998927116394F;
      TaperedTubeSdf3D var5 = SdfShapes.tube(var10000);
      float var13 = 0.44999998807907104F;
      Sdf3D[] var10001 = new Sdf3D[4];
      var10001[0] = var2;
      var10001[1] = var3;
      var10001[2] = var4;
      var10001[3] = var5;
      Sdf3D var6 = SdfShapes.blend(var13, var10001);
      Sdf3D var7 = var6.intersect(SdfShapes.above(10.600000381469727F))
         .paint(
            SurfacePaint.vertical(
               -1198942, 10.800000190734863F, -8241, 12.5F
            )
         );
      Sdf3D var8 = SdfShapes.cylinder(
            var1,
            11.050000190734863F,
            0.029999999329447746F,
            var1,
            10.350000381469727F,
            0.05000000074505806F,
            0.8999999761581421F,
            0.11999999731779099F
         )
         .color(-13645638);
      float var14 = 0.30000001192092896F;
      var10001 = new Sdf3D[2];
      var10001[0] = var6.intersect(SdfShapes.below(10.399999618530273F))
         .inflate(0.09000000357627869F);
      var10001[1] = shoe(var1);
      Sdf3D var9 = SdfShapes.blend(var14, var10001)
         .paint(
            SurfacePaint.field(
               (var0x, var1x, var2x) -> ArgbColors.mix(
                     -13618373,
                     -14934492,
                     smooth(-0.20000000298023224F, -0.800000011920929F, var2x)
                        * 0.6000000238418579F
                  )
            )
         );
      CharacterPartBuilder var10 = var0.part(CharacterBone.RIGHT_LEG)
         .pivot(var1, 14.199999809265137F, 0.0F)
         .shape(var7)
         .detail(0.6000000238418579F)
         .resolution(1.0F)
         .flatLight(0.800000011920929F)
         .outline(-5740452, 0.10000000149011612F)
         .occlusion(0.30000001192092896F)
         .swing(0.550000011920929F, 30.0F)
         .joint(var1, 7.900000095367432F, 0.10000000149011612F, 0.800000011920929F);
      var0.part(CharacterBone.LEFT_LEG).mirrorOf(var10);
      CharacterPartBuilder var11 = var0.extra(
            "boot_r", CharacterBone.RIGHT_LEG
         )
         .shape(var9)
         .detail(0.800000011920929F)
         .resolution(1.0F)
         .outline(-16119026, 0.10999999940395355F)
         .occlusion(0.30000001192092896F);
      var0.extra("boot_l", CharacterBone.LEFT_LEG).mirrorOf(var11);
      CharacterPartBuilder var15 = var0.extra(
         "boot_trim_r", CharacterBone.RIGHT_LEG
      );
      var10001 = new Sdf3D[2];
      var10001[0] = var8;
      var10001[1] = sole(var1);
      CharacterPartBuilder var12 = var15.shape(SdfShapes.union(var10001))
         .detail(0.4000000059604645F)
         .resolution(0.6000000238418579F)
         .flatLight(0.30000001192092896F)
         .outline(-15835560, 0.09000000357627869F);
      var0.extra("boot_trim_l", CharacterBone.LEFT_LEG).mirrorOf(var12);
   }

   private static Sdf3D shoe(float var0) {
      float var10000 = 0.4000000059604645F;
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = SdfShapes.ellipsoid(
         var0,
         1.100000023841858F,
         0.949999988079071F,
         0.6200000047683716F,
         0.6000000238418579F,
         1.149999976158142F
      );
      var10001[1] = SdfShapes.ellipsoid(
         var0,
         1.399999976158142F,
         -0.3499999940395355F,
         0.6200000047683716F,
         0.8999999761581421F,
         0.7200000286102295F
      );
      var10001[2] = SdfShapes.cone(
         var0,
         2.299999952316284F,
         -0.05000000074505806F,
         0.5F,
         var0,
         1.2000000476837158F,
         0.0F,
         0.6000000238418579F
      );
      return SdfShapes.blend(var10000, var10001);
   }

   private static Sdf3D sole(float var0) {
      Sdf3D var1 = SdfShapes.box(
         var0,
         0.6200000047683716F,
         0.8500000238418579F,
         0.6399999856948853F,
         0.14000000059604645F,
         1.2999999523162842F,
         0.11999999731779099F
      );
      Sdf3D var2 = SdfShapes.box(
         var0,
         0.30000001192092896F,
         -0.550000011920929F,
         0.46000000834465027F,
         0.30000001192092896F,
         0.4000000059604645F,
         0.10000000149011612F
      );
      float var10000 = 0.11999999731779099F;
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = var1;
      var10001[1] = var2;
      return SdfShapes.blend(var10000, var10001)
         .intersect(SdfShapes.above(0.0F))
         .paint(
            SurfacePaint.vertical(
               -14971002, 0.0F, -13645638, 0.699999988079071F
            )
         );
   }

   private static float px(float var0) {
      return 128.0F + var0 * 56.88888931274414F;
   }

   private static float py(float var0) {
      return (29.950000762939453F - var0) * 56.88888931274414F;
   }

   private static SurfaceDecal face(float[][] var0) {
      PixelCanvas var1 = new PixelCanvas(88, 136);
      float var2 = 40.0F;
      float var3 = 70.0F;
      Sdf2D var4 = Sdf2D.ellipse(
         var2, var3, 27.5F, 33.0F
      );
      float var10003 = var3 - 33.0F;
      float var10005 = var3 + 10.0F;
      int[] var10006 = new int[2];
      var10006[0] = -1904912;
      var10006[1] = -1;
      var1.fill(var4, ColorField2D.linear(var2, var10003, var2, var10005, var10006));
      var1.fill(
         Sdf2D.ellipse(
               var2,
               var3 - 34.0F,
               34.0F,
               22.0F
            )
            .intersect(var4),
         -1715153190,
         2.0F
      );
      Sdf2D var5 = Sdf2D.ellipse(
         var2, var3 + 3.5F, 20.5F, 27.5F
      );
      Sdf2D var6 = var5.intersect(var4);
      var10003 = var3 - 24.0F;
      var10005 = var3 + 30.0F;
      var10006 = new int[3];
      var10006[0] = -16106432;
      var10006[1] = -14504024;
      var10006[2] = -6491416;
      var1.fill(var6, ColorField2D.linear(var2, var10003, var2, var10005, var10006));
      var1.fill(var5.outline(2.5999999046325684F).intersect(var4), -1341506496);
      var1.fill(
         Sdf2D.ellipse(
            var2,
            var3 + 1.5F,
            9.0F,
            12.5F
         ),
         -16439768
      );
      var1.fill(
         Sdf2D.ellipse(
               var2,
               var3 + 17.0F,
               12.0F,
               6.5F
            )
            .intersect(var6),
         -2133655560,
         3.0F
      );
      var1.fill(
         Sdf2D.curve(
            var2 + 26.5F,
            var3 - 13.0F,
            var2 + 2.0F,
            var3 - 46.0F,
            var2 - 30.0F,
            var3 - 6.0F,
            4.199999809265137F,
            8.399999618530273F
         ),
         -14800336
      );
      var1.fill(
         Sdf2D.taper(
            var2 - 25.0F,
            var3 - 9.0F,
            6.0F,
            var2 - 35.0F,
            var3 - 6.0F,
            1.399999976158142F
         ),
         -14800336
      );
      var1.fill(
         Sdf2D.curve(
            var2 - 5.0F,
            var3 + 32.0F,
            var2 - 20.0F,
            var3 + 31.0F,
            var2 - 26.5F,
            var3 + 16.0F,
            1.600000023841858F,
            2.799999952316284F
         ),
         -868591010
      );
      var1.fill(
         Sdf2D.curve(
            var2 + 15.0F,
            var3 - 38.0F,
            var2,
            var3 - 48.0F,
            var2 - 23.0F,
            var3 - 33.0F,
            1.5F,
            1.5F
         ),
         2005965984
      );
      var1.fill(
         Sdf2D.curve(
            var2 + 20.0F,
            var3 - 48.0F,
            var2 + 2.0F,
            var3 - 57.0F,
            var2 - 22.0F,
            var3 - 51.0F,
            4.0F,
            2.5999999046325684F
         ),
         -13989243
      );
      var1.fill(
         Sdf2D.ellipse(
            var2 - 4.0F,
            var3 + 46.0F,
            21.0F,
            9.0F
         ),
         1442810524,
         10.0F
      );
      PixelCanvas var7 = new PixelCanvas(256, 220);
      int var8 = Math.round(py(28.0F)) - (70);
      ArrayList var9 = new ArrayList();
      float[][] var10 = var0;
      int var11 = var0.length;

      for (int var12 = 0; var12 < var11; var12++) {
         float[] var13 = var10[var12];
         float[] var14 = blade(var13);

         for (int var15 = 0; var15 < var14.length; var15 += 2) {
            var14[var15] = px(var14[var15]);
            var14[var15 + (1)] = py(var14[var15 + (1)])
               + 14.0F;
         }

         var9.add(Sdf2D.polygon(var14));
      }

      var9.add(
         Sdf2D.box(
            128.0F,
            py(29.75F),
            130.0F,
            14.222222328186035F,
            0.0F
         )
      );
      var7.fill(
         Sdf2D.union(((Sdf2D[]) var9.toArray(new Sdf2D[0]))),
         -1931434602,
         3.0F
      );
      var7.draw(var1, 28, var8);
      var7.draw(var1.mirrored(), 140, var8);

      for (int var16 = -1; var16 <= (1); var16 += 2) {
         float var17 = 128.0F + (float)var16 * 60.0F;
         var7.fill(
            Sdf2D.ellipse(
               var17 - 7.5F,
               (float)var8 + 60.0F,
               7.0F,
               8.800000190734863F
            ),
            -1
         );
         var7.fill(
            Sdf2D.circle(
               var17 + 8.0F,
               (float)var8 + 83.0F,
               3.0F
            ),
            -570425345
         );
         var7.fill(
            Sdf2D.circle(
               var17 - 12.0F,
               (float)var8 + 76.0F,
               1.600000023841858F
            ),
            -1426063361
         );
      }

      var7.fill(
         Sdf2D.line(
            130.0F,
            (float)var8 + 119.0F,
            127.0F,
            (float)var8 + 124.5F,
            2.4000000953674316F
         ),
         -1713795968
      );
      float var10001 = 3.0F;
      float var10002 = 3.0F;
      float[] var19 = new float[10];
      var19[0] = 118.0F;
      var19[1] = (float)var8 + 156.0F;
      var19[2] = 123.0F;
      var19[3] = (float)var8 + 161.0F;
      var19[4] = 128.0F;
      var19[5] = (float)var8 + 157.5F;
      var19[6] = 133.0F;
      var19[7] = (float)var8 + 161.0F;
      var19[8] = 138.0F;
      var19[9] = (float)var8 + 156.0F;
      var7.fill(Sdf2D.path(var10001, var10002, var19), -6668728);
      return SurfaceDecal.front(
            var7,
            0.0F,
            ty(28.016407012939453F),
            tz(2.0999999046325684F),
            5.039999961853027F,
            4.331250190734863F
         )
         .depth(2.0F, 1.7999999523162842F)
         .maxAngle(72.0F)
         .flatLight(1.0F)
         .occlusion(0.30000001192092896F);
   }

   private static float smooth(float var0, float var1, float var2) {
      float var3 = clamp01((var2 - var0) / (var1 - var0));
      return var3 * var3 * (3.0F - 2.0F * var3);
   }

   private static float clamp01(float var0) {
      return var0 < 0.0F
         ? 0.0F
         : Math.min(var0, 1.0F);
   }











































   static {
      float[][] var5 = new float[9][];
      float[] var14;
      (var14 = new float[6])[0] = -0.1F;
      var14[1] = 28.3F;
      var14[2] = -2.0F;
      var14[3] = 0.95F;
      var14[4] = 0.12F;
      var14[5] = 0.34F;
      var5[0] = var14;
      float[] var16;
      (var16 = new float[6])[0] = -1.0F;
      var16[1] = 28.75F;
      var16[2] = -25.0F;
      var16[3] = 0.95F;
      var16[4] = 0.28F;
      var16[5] = 0.3F;
      var5[1] = var16;
      float[] var18;
      (var18 = new float[6])[0] = -1.92F;
      var18[1] = 28.4F;
      var18[2] = -47.0F;
      var18[3] = 0.92F;
      var18[4] = 0.26F;
      var18[5] = 0.3F;
      var5[2] = var18;
      float[] var5x;
      (var5x = new float[6])[0] = 0.9F;
      var5x[1] = 28.85F;
      var5x[2] = 24.0F;
      var5x[3] = 0.95F;
      var5x[4] = 0.28F;
      var5x[5] = 0.3F;
      var5[3] = var5x;
      float[] var22;
      (var22 = new float[6])[0] = 1.9F;
      var22[1] = 28.5F;
      var22[2] = 46.0F;
      var22[3] = 0.92F;
      var22[4] = 0.25F;
      var22[5] = 0.3F;
      var5[4] = var22;
      float[] var24;
      (var24 = new float[6])[0] = -0.55F;
      var24[1] = 28.5F;
      var24[2] = -13.0F;
      var24[3] = 0.45F;
      var24[4] = 0.16F;
      var24[5] = 0.44F;
      var5[5] = var24;
      float[] var26;
      (var26 = new float[6])[0] = 0.46F;
      var26[1] = 28.62F;
      var26[2] = 11.0F;
      var26[3] = 0.45F;
      var26[4] = 0.18F;
      var26[5] = 0.44F;
      var5[6] = var26;
      float[] var28;
      (var28 = new float[6])[0] = -1.46F;
      var28[1] = 28.65F;
      var28[2] = -36.0F;
      var28[3] = 0.42F;
      var28[4] = 0.2F;
      var28[5] = 0.42F;
      var5[7] = var28;
      float[] var30;
      (var30 = new float[6])[0] = 1.42F;
      var30[1] = 28.7F;
      var30[2] = 35.0F;
      var30[3] = 0.42F;
      var30[4] = 0.2F;
      var30[5] = 0.42F;
      var5[8] = var30;
      LOCKS = var5;
   }
}
