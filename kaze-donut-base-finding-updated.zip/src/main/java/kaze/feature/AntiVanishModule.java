package kaze.feature;

import com.mojang.brigadier.suggestion.Suggestion;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Deque;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentHashMap.KeySetView;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;
import java.util.stream.Stream;
import kaze.module.ext.ClientModule;
import kaze.module.ext.EventHandler;
import kaze.module.ext.ModuleCategory;
import kaze.module.ext.ModuleRegistry;
import kaze.module.ext.event.PacketReceiveNettyEvent;
import kaze.module.ext.event.PacketSendEvent;
import kaze.module.ext.event.TickEvent;
import kaze.utils.BytecodeException;
import kaze.utils.ext.DonutRegionTracker;
import kaze.utils.ext.ModuleChat;
import kaze.utils.ext.NameFilter;
import kaze.utils.ext.ModuleChat.Body;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.Item;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.RequestCommandCompletionsC2SPacket;
import net.minecraft.network.packet.s2c.play.CommandSuggestionsS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityTrackerUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.ParticleS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundFromEntityS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRemoveS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket.Action;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket.Entry;
import net.minecraft.particle.ParticleType;
import net.minecraft.registry.DefaultedRegistry;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.text.TextContent;
import net.minecraft.text.TranslatableTextContent;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;

@Environment(EnvType.CLIENT)
public final class AntiVanishModule extends ClientModule {
   private static final MinecraftClient MC = MinecraftClient.getInstance();
   private static final String PROBE_COMMAND = "minecraft:msg";
   private static final int SENSOR_RANGE = 64;
   private static final long SIGNAL_WINDOW_MS = 15000L;
   private static final long DETECTION_TTL_MS = 20000L;
   private static final long CRITICAL_COOLDOWN_MS = 12000L;
   private static final long ANNOUNCE_COOLDOWN_MS = 1500L;
   private static final long ANNOUNCE_WINDOW_MS = 4000L;
   private static final int MAX_ANNOUNCE_PER_WINDOW = 6;
   private static final int MAX_OBSERVATIONS_PER_TICK = 512;
   private static final int CRITICAL_SCORE = 35;
   private static final long SELF_PLACE_TTL_MS = 6000L;
   private static final long CONTAINER_SELF_GRACE_MS = 2500L;
   private static final long SPELL_SETTLE_MS = 1000L;
   private final ConcurrentLinkedQueue<AntiVanishModule.VanishSignal> observations;
   private final Map<UUID, AntiVanishModule.StaffProfile> knownPlayers;
   private final Map<String, AntiVanishModule.AlertCandidate> detections;
   private final Map<String, Long> signalCooldowns;
   private final Map<String, Long> announceCooldowns;
   private final Deque<Long> announceTimes;
   private final Map<Long, Long> selfPlacedBlocks;
   private final Map<UUID, Long> confirmedDepartures;
   private final Map<Long, Long> automatedMechanisms;
   private final Map<String, Deque<Long>> weakParticleBursts;
   private final Deque<AntiVanishModule.VanishFinding> signals;
   private final Deque<AntiVanishModule.SpatialSignal> recentExplosions;
   private final Deque<AntiVanishModule.PendingTabRemoval> pendingVanishes;
   private final Map<String, AntiVanishModule.VanishObservation> hiddenSpells;
   private final Deque<AntiVanishModule.AntiVanishHelper> recentMessages;
   private boolean serverSendsLeaveMessages;
   private final Set<Integer> completionRequestIds;
   private volatile List<String> pendingCompletionNames;
   private int nextCompletionId;
   private static final long RECENT_MESSAGE_TTL_MS = 8000L;
   private static final long TRUSTED_LISTED_MS = 1500L;
   private final Map<UUID, Long> listedSinceMs;
   private final DonutRegionTracker shard;
   private int tickCounter;
   private volatile long lastLocalActionMs;
   private long lastContainerActivityMs;
   private long lastCriticalMs;
   private long criticalUntilMs;
   private String criticalWatcher;
   private final Set<UUID> pendingChimes;
   private UUID ghostId;
   private String ghostName;

   public AntiVanishModule() {
      super("anti-vanish", "Anti Vanish", "Detects vanished players.", ModuleCategory.DONUT);
      this.observations = new ConcurrentLinkedQueue<>();
      this.knownPlayers = new HashMap<>();
      this.detections = new LinkedHashMap<>();
      this.signalCooldowns = new HashMap<>();
      this.announceCooldowns = new HashMap<>();
      this.announceTimes = new ArrayDeque<>();
      this.selfPlacedBlocks = new ConcurrentHashMap<>();
      this.confirmedDepartures = new HashMap<>();
      this.automatedMechanisms = new HashMap<>();
      this.weakParticleBursts = new HashMap<>();
      this.signals = new ArrayDeque<>();
      this.recentExplosions = new ArrayDeque<>();
      this.pendingVanishes = new ArrayDeque<>();
      this.hiddenSpells = new LinkedHashMap<>();
      this.recentMessages = new ArrayDeque<>();
      this.completionRequestIds = ConcurrentHashMap.newKeySet();
      this.nextCompletionId = 30000;
      this.listedSinceMs = new HashMap<>();
      this.shard = new DonutRegionTracker();
      this.criticalWatcher = "";
      this.pendingChimes = new HashSet<>();
      this.usesNotifications();
   }

   public void onEnable() {
      this.resetRuntime();
      if (MC.player != null && MC.world != null) this.trackListedPlayers();
   }

   public void onDisable() {
      this.resetRuntime();
   }

   @EventHandler
   public void onTick(TickEvent event) {
      if (MC.player == null || MC.world == null || MC.getNetworkHandler() == null) {
         this.resetRuntime();
         return;
      }
      if (this.shard.moved(MC)) this.resetRuntime();
      this.playPendingChime();
      this.tickCounter++;
      if (MC.player.currentScreenHandler != MC.player.playerScreenHandler) {
         this.lastContainerActivityMs = System.currentTimeMillis();
      }
      this.drainObservations();
      this.processPendingVanishes();
      this.processCompletionProbe();
      if (this.tickCounter % 100 == 0) this.sendCompletionProbe();
      if (this.tickCounter % 10 == 0) {
         this.trackListedPlayers();
         this.reviewSpells();
      }
      if (this.tickCounter % 5 == 0) this.scanInvisiblePlayers();
      this.pruneState();
   }

   @EventHandler
   public void onPacketSend(PacketSendEvent event) {
      this.handleOutbound(event.packet);
   }

   private void handleOutbound(Packet<?> packet) {
      if (packet instanceof PlayerInteractBlockC2SPacket place) {
         this.lastLocalActionMs = System.currentTimeMillis();
         if (place.getBlockHitResult() == null || place.getBlockHitResult().getBlockPos() == null) return;
         long expiresAt = System.currentTimeMillis() + SELF_PLACE_TTL_MS;
         BlockPos target = place.getBlockHitResult().getBlockPos();
         BlockPos adjacent = target.offset(place.getBlockHitResult().getSide());
         this.selfPlacedBlocks.put(target.asLong(), expiresAt);
         this.selfPlacedBlocks.put(adjacent.asLong(), expiresAt);
         String itemPath = "";
         if (MC.player != null && place.getHand() != null) {
            Identifier id = Registries.ITEM.getId(MC.player.getStackInHand(place.getHand()).getItem());
            itemPath = VanishSignalClassifier.path(id == null ? "" : id.toString());
         }
         markSelfMultiBlockFootprint(target, itemPath, this.selfPlacedBlocks, expiresAt);
         markSelfMultiBlockFootprint(adjacent, itemPath, this.selfPlacedBlocks, expiresAt);
      } else if (packet instanceof PlayerActionC2SPacket
            || packet instanceof PlayerInteractItemC2SPacket
            || packet instanceof PlayerInteractEntityC2SPacket
            || packet instanceof HandSwingC2SPacket) {
         this.lastLocalActionMs = System.currentTimeMillis();
      }
   }

   static void markSelfMultiBlockFootprint(BlockPos position, String itemPath, Map<Long, Long> placements, long expiresAt) {
      if (position == null || placements == null) return;
      placements.put(position.asLong(), expiresAt);
      String path = itemPath == null ? "" : itemPath;
      boolean isTall = (path.endsWith("_door") && !path.endsWith("trapdoor"))
         || path.contains("sunflower") || path.contains("lilac") || path.contains("rose_bush")
         || path.contains("peony") || path.contains("tall_grass")
         || path.contains("large_fern") || path.contains("pitcher_plant");
      if (isTall) {
         placements.put(position.up().asLong(), expiresAt);
         placements.put(position.down().asLong(), expiresAt);
      }
      if (path.endsWith("_bed")) {
         placements.put(position.add(1, 0, 0).asLong(), expiresAt);
         placements.put(position.add(-1, 0, 0).asLong(), expiresAt);
         placements.put(position.add(0, 0, 1).asLong(), expiresAt);
         placements.put(position.add(0, 0, -1).asLong(), expiresAt);
      }
   }

   @EventHandler
   public void onPacketReceiveNetty(PacketReceiveNettyEvent var1) {
      Packet var6 = var1.packet;
      if ((byte)(this.handleInbound(var6) ? 1 : 0) != 0) {
         var1.setCancelled(true);
      }
   }

   private boolean handleInbound(Packet<?> packet) {
      if (packet instanceof PlayerRemoveS2CPacket removed) {
         if (removed.profileIds().size() < 4) {
            for (UUID id : removed.profileIds()) {
               this.observations.offer(AntiVanishModule.VanishSignal.tabRemove(id));
            }
         }
         return false;
      }

      if (packet instanceof PlayerListS2CPacket listed
         && listed.getActions().contains(PlayerListS2CPacket.Action.UPDATE_LISTED)) {
         int hiddenCount = 0;
         for (PlayerListS2CPacket.Entry entry : listed.getEntries()) {
            if (entry != null && !entry.listed()) {
               hiddenCount++;
            }
         }
         if (hiddenCount > 0 && hiddenCount < 4) {
            for (PlayerListS2CPacket.Entry entry : listed.getEntries()) {
               if (entry != null && !entry.listed()) {
                  this.observations.offer(AntiVanishModule.VanishSignal.tabHide(entry.profileId()));
               }
            }
         }
         return false;
      }

      if (packet instanceof PlayerListS2CPacket gameMode
         && gameMode.getActions().contains(PlayerListS2CPacket.Action.UPDATE_GAME_MODE)) {
         this.queueGamemodeUpdates(gameMode);
         return false;
      }

      if (packet instanceof GameMessageS2CPacket message) {
         String text = message.content() == null ? "" : message.content().getString();
         if (!text.isBlank()) {
            this.observations.offer(AntiVanishModule.VanishSignal.systemChat(text));
         }
         String departed = departedPlayerName(message.content());
         if (!departed.isBlank()) {
            this.observations.offer(AntiVanishModule.VanishSignal.playerLeft(departed));
         }
         return false;
      }

      if (packet instanceof CommandSuggestionsS2CPacket suggestions
         && this.completionRequestIds.remove(suggestions.id())) {
         ArrayList<String> names = new ArrayList<>();
         for (Suggestion suggestion : suggestions.getSuggestions().getList()) {
            String name = suggestion.getText();
            if (name != null && !name.isBlank()) {
               names.add(name.trim());
            }
         }
         this.pendingCompletionNames = names;
         return true;
      }

      if (packet instanceof EntityTrackerUpdateS2CPacket metadata) {
         this.observations.offer(AntiVanishModule.VanishSignal.entityMetadata(metadata.id()));
      } else if (packet instanceof ExplosionS2CPacket explosion) {
         this.observations.offer(AntiVanishModule.VanishSignal.explosion(explosion.center(), explosion.radius()));
      } else if (packet instanceof PlaySoundFromEntityS2CPacket sound) {
         this.observations.offer(AntiVanishModule.VanishSignal.entitySound(
            sound.getEntityId(), soundId(((SoundEvent) sound.getSound().value()).id())
         ));
      } else if (packet instanceof ParticleS2CPacket particle) {
         Identifier id = Registries.PARTICLE_TYPE.getId(particle.getParameters().getType());
         this.observations.offer(AntiVanishModule.VanishSignal.position(
            AntiVanishModule.VanishSignalType.PARTICLE,
            particle.getX(), particle.getY(), particle.getZ(), id == null ? "" : id.toString()
         ));
      } else if (packet instanceof PlaySoundS2CPacket sound) {
         this.onSoundPacket(sound);
      }
      return false;
   }

   private void onSoundPacket(PlaySoundS2CPacket var1) {
      if (var1 != null && var1.getSound() != null && var1.getSound().value() != null) {
         String var2 = soundId(((SoundEvent)var1.getSound().value()).id());
         this.observations
            .offer(
               VanishSignal.position(VanishSignalType.POSITIONAL_SOUND, var1.getX(), var1.getY(), var1.getZ(), var2)
            );
      }
   }

   public static boolean shouldShowHud() {
      AntiVanishModule var0 = instance();
      return ((var0 != null && var0.isEnabled() && var0.hasHudContent()));
   }

   private boolean hasHudContent() {
      long var1 = System.currentTimeMillis();
      if (var1 < this.criticalUntilMs) {
         return true;
      } else {
         for (AlertCandidate var4 : this.detections.values()) {
            if (var4.expiresAt > var1 && detectionWorthShowing(var4)) {
               return true;
            }
         }

         return false;
      }
   }

   private static boolean detectionWorthShowing(AlertCandidate var0) {
      if (var0 == null) {
         return false;
      } else {
         String var1 = var0.name == null ? "" : var0.name.trim();
         return ((!var1.isBlank()
               && !"Unknown".equalsIgnoreCase(var1)
               && !"You".equalsIgnoreCase(var1)
               && !"CRITICAL".equalsIgnoreCase(var1)
            ? 1
            : 0) != 0);
      }
   }

   public static String hudTag(VanishHudEntry var0) {
      if (var0 == null) {
         return "WATCH";
      } else if ("CRITICAL".equalsIgnoreCase(var0.name())) {
         return "ALERT";
      } else {
         String var1 = var0.reason() == null ? "" : var0.reason().toLowerCase(Locale.ROOT);
         if (var1.startsWith("vanish event")) {
            return "VANISH";
         } else if (var1.startsWith("invisible entity")) {
            return "INVIS";
         } else if (var1.startsWith("suspicious sound")) {
            return "SOUND";
         } else {
            return var1.startsWith("ghost particle")
               ? "PARTICLE"
               : "WATCH";
         }
      }
   }

   public static String hudValue(VanishHudEntry var0) {
      if (var0 == null) {
         return "Staff";
      } else if ("CRITICAL".equalsIgnoreCase(var0.name())) {
         return shortName(var0.reason());
      } else {
         String var1 = var0.name() == null ? "" : var0.name().trim();
         return !var1.isBlank()
               && !"Unknown".equalsIgnoreCase(var1)
               && !"You".equalsIgnoreCase(var1)
            ? shortName(var1)
            : "Staff";
      }
   }

   private static String shortName(String var0) {
      String var1 = var0 == null ? "" : NameFilter.apply(var0.trim());
      return var1.length() <= (16) ? var1 : var1.substring(0, 16);
   }

   public static List<VanishHudEntry> hudEntries() {
      AntiVanishModule var0 = instance();
      return var0 != null && shouldShowHud() ? var0.hudSnapshot() : List.of();
   }

   private static AntiVanishModule instance() {
      return ModuleRegistry.get(AntiVanishModule.class);
   }

   private void drainObservations() {
      for (int var1 = 0; var1 < (512); var1++) {
         VanishSignal var2 = this.observations.poll();
         if (var2 == null) {
            break;
         }

         this.processObservation(var2);
      }

      while (this.observations.size() > (4096)) {
         this.observations.poll();
      }
   }

   private void processObservation(VanishSignal var1) {
      switch (var1.type()) {
         case TAB_REMOVE:
            this.handleTabRemoval(var1.profileId());
            break;
         case TAB_HIDE:
            this.handleTabHidden(var1.profileId());
            break;
         case PLAYER_LEFT:
            this.serverSendsLeaveMessages = true;
            this.confirmDeparture(var1.detail());
            break;
         case SYSTEM_CHAT:
            this.cacheRecentMessage(var1.detail());
            break;
         case ENTITY_METADATA:
            this.inspectInvisibleEntity(var1.entityId());
            break;
         case POSITIONAL_SOUND:
            this.inspectPositionalSound(var1);
            break;
         case ENTITY_SOUND:
            this.inspectEntitySound(var1);
            break;
         case PARTICLE:
            this.inspectParticle(var1);
            break;
         case EXPLOSION:
            this.rememberExplosion(var1);
            break;
         case GAMEMODE:
            this.announceGamemode(var1.profileId(), var1.detail());
      }
   }

   private void trackListedPlayers() {
      if (MC.getNetworkHandler() != null) {
         long var1 = System.currentTimeMillis();

         for (PlayerListEntry var4 : MC.getNetworkHandler().getListedPlayerListEntries()) {
            if (var4 != null && var4.getProfile() != null && var4.getProfile().id() != null) {
               UUID var5 = var4.getProfile().id();
               if (MC.player == null || !MC.player.getUuid().equals(var5)) {
                  this.listedSinceMs.putIfAbsent(var5, var1);
                  String var6 = var4.getProfile().name();
                  if (var6 != null && !this.knownPlayers.containsKey(var5)) {
                     this.knownPlayers.put(var5, new StaffProfile(var5, var6));
                  }

                  if (var6 != null && !this.hiddenSpells.isEmpty()) {
                     this.endSpell(var6, false, 1000L);
                  }
               }
            }
         }

         if (this.listedSinceMs.size() > (1024) || this.knownPlayers.size() > (1024)) {
            HashSet var7 = new HashSet();

            for (PlayerListEntry var9 : MC.getNetworkHandler().getPlayerList()) {
               if (var9 != null && var9.getProfile() != null) {
                  var7.add(var9.getProfile().id());
               }
            }

            this.listedSinceMs.keySet().retainAll(var7);
            this.knownPlayers.keySet().retainAll(var7);
         }
      }
   }

   private boolean trustedListed(UUID var1) {
      Long var2 = var1 == null ? null : this.listedSinceMs.get(var1);
      return ((var2 != null && System.currentTimeMillis() - var2 >= (1500L)));
   }

   private boolean credibleSubject(UUID var1, String var2) {
      return ((var1 != null
            && VanishChatParser.isUsername(var2)
            && VanishAlertRules.isStaffName(var2)
            && this.trustedListed(var1)));
   }

   private void handleTabRemoval(UUID var1) {
      if (var1 != null && !MC.player.getUuid().equals(var1)) {
         String var2 = this.knownName(var1);
         if (this.credibleSubject(var1, var2) && VanishChatParser.isPlausiblePlayerName(var2)) {
            this.pendingVanishes.removeIf(var1x -> var1x.uuid().equals(var1));
            this.pendingVanishes.addLast(new PendingTabRemoval(var1, var2, this.tickCounter + (20)));
         }
      }
   }

   private void handleTabHidden(UUID var1) {
      if (var1 != null && !MC.player.getUuid().equals(var1)) {
         StaffProfile var2 = this.knownPlayers.get(var1);
         String var3 = var2 != null && var2.name() != null ? var2.name() : this.knownName(var1);
         if (this.credibleSubject(var1, var3) && VanishChatParser.isPlausiblePlayerName(var3) && !this.recentMessageNames(var3)) {
            this.reportHidden(
               var1,
               var3,
               false,
               "Vanish Event: hidden from TAB",
               "hidden from TAB",
               100
            );
         }
      }
   }

   private String knownName(UUID var1) {
      StaffProfile var2 = this.knownPlayers.get(var1);
      if (var2 != null && var2.name() != null && !var2.name().isBlank()) {
         return var2.name();
      } else {
         if (MC.getNetworkHandler() != null) {
            PlayerListEntry var3 = MC.getNetworkHandler().getPlayerListEntry(var1);
            if (var3 != null && var3.getProfile() != null) {
               return var3.getProfile().name();
            }
         }

         return null;
      }
   }

   private UUID knownUuid(String var1) {
      for (StaffProfile var3 : this.knownPlayers.values()) {
         if (var3.name().equalsIgnoreCase(var1)) {
            return var3.uuid();
         }
      }

      return null;
   }

   private void confirmDeparture(String var1) {
      long var2 = System.currentTimeMillis();

      for (StaffProfile var5 : this.knownPlayers.values()) {
         if (VanishChatParser.containsPlayerName(var1, var5.name())) {
            this.confirmedDepartures.put(var5.uuid(), var2 + (5000L));
            this.pendingVanishes.removeIf(var1x -> var1x.uuid().equals(var5.uuid()));
            this.hiddenSpells.remove(spellKey(var5.name()));
            AlertCandidate var6 = this.detections.get(var5.uuid().toString());
            if (var6 != null && tabDepartureReason(var6.reason)) {
               this.detections.remove(var5.uuid().toString());
            }

            this.signals
               .removeIf(
                  var1x -> ((var1x.type() == VanishEvidenceType.VANISH
                           && var1x.subject().equalsIgnoreCase(var5.name())
                           && tabDepartureReason(var1x.reason())))
               );
         }
      }
   }

   private void processPendingVanishes() {
      while (!this.pendingVanishes.isEmpty() && this.pendingVanishes.peekFirst().dueTick() <= this.tickCounter) {
         PendingTabRemoval var1 = this.pendingVanishes.removeFirst();
         if (MC.getNetworkHandler().getPlayerListEntry(var1.uuid()) == null) {
            long var2 = System.currentTimeMillis();
            if (this.confirmedDepartures.getOrDefault(var1.uuid(), 0L) <= var2) {
               if (this.recentMessageNames(var1.name())) {
                  this.serverSendsLeaveMessages = true;
               } else {
                  PlayerEntity var4 = MC.world.getPlayerByUuid(var1.uuid());
                  if (var4 != null && !var4.isRemoved()) {
                     this.reportHidden(
                        var1.uuid(),
                        var1.name(),
                        false,
                        "Vanish Event: entity remained",
                        "off TAB, still nearby",
                        100
                     );
                  } else {
                     String var5 = "Vanish Event: silent TAB disappearance";
                     int var6 = silentTabRemovalScore(this.serverSendsLeaveMessages);
                     if (this.serverSendsLeaveMessages) {
                        this.reportHidden(
                           var1.uuid(),
                           var1.name(),
                           false,
                           var5,
                           "left TAB silently",
                           var6
                        );
                     } else {
                        NearbyStaffProof var7 = this.regionProof(var1.uuid());
                        if (var7 != null) {
                           this.signals
                              .addLast(new VanishFinding(VanishEvidenceType.VANISH, var1.name(), var7, var5, var6, var2));
                           this.evaluateCritical();
                        }
                     }
                  }
               }
            }
         }
      }
   }

   static int silentTabRemovalScore(boolean serverSendsLeaveMessages) {
      return serverSendsLeaveMessages ? 100 : 30;
   }

   static boolean tabDepartureReason(String reason) {
      if (reason == null) return false;
      String lower = reason.toLowerCase(Locale.ROOT);
      return lower.startsWith("vanish event:")
         && (lower.contains("tab") || lower.contains("entity remained") || lower.contains("no leave packet"));
   }

   private void cacheRecentMessage(String var1) {
      if (var1 != null && !var1.isBlank()) {
         long var2 = System.currentTimeMillis();
         this.recentMessages.addLast(new AntiVanishHelper(var1, var2));

         while (
            !this.recentMessages.isEmpty()
               && (
                  var2 - this.recentMessages.peekFirst().atMs() > (8000L)
                     || this.recentMessages.size() > (64)
               )
         ) {
            this.recentMessages.removeFirst();
         }
      }
   }

   private boolean recentMessageNames(String var1) {
      if (var1 != null && !var1.isBlank()) {
         long var2 = System.currentTimeMillis();

         for (AntiVanishHelper var5 : this.recentMessages) {
            if (var2 - var5.atMs() <= (8000L) && VanishChatParser.looksLikeLeaveMessage(var5.text(), var1)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private void sendCompletionProbe() {
      if (MC.getNetworkHandler() != null) {
         String var1 = "minecraft:msg";
         int var10000 = this.nextCompletionId;
         this.nextCompletionId += 1;
         int var2 = var10000;
         if (this.nextCompletionId > (40000)) {
            this.nextCompletionId = 30000;
         }

         this.completionRequestIds.add(var2);

         while (this.completionRequestIds.size() > (8)) {
            this.completionRequestIds.remove(this.completionRequestIds.iterator().next());
         }

         try {
            MC.getNetworkHandler().sendPacket(new RequestCommandCompletionsC2SPacket(var2, var1.trim() + " "));
         } catch (Throwable var4) {
         }
      }
   }

   private void processCompletionProbe() {
      List var1 = this.pendingCompletionNames;
      if (var1 != null) {
         this.pendingCompletionNames = null;
         if (MC.getNetworkHandler() != null && MC.player != null) {
            HashSet var2 = new HashSet();

            for (PlayerListEntry var4 : MC.getNetworkHandler().getPlayerList()) {
               if (var4 != null && var4.getProfile() != null && var4.getProfile().name() != null) {
                  var2.add(var4.getProfile().name().toLowerCase(Locale.ROOT));
               }
            }

            String var7 = MC.player.getName().getString();
            ArrayList var8 = new ArrayList();

            for (Object var6Object : var1) { String var6 = (String)var6Object;
               if (VanishAlertRules.isStaffName(var6)
                  && VanishChatParser.isPlausiblePlayerName(var6)
                  && !var6.equalsIgnoreCase(var7)
                  && !var2.contains(var6.toLowerCase(Locale.ROOT))
                  && !this.recentMessageNames(var6)) {
                  var8.add(var6);
               }
            }

            if (!var8.isEmpty() && var8.size() <= (3)) {
               for (Object var10Object : var8) { String var10 = (String)var10Object;
                  this.reportHidden(
                     this.knownUuid(var10),
                     var10,
                     false,
                     "Vanish Event: hidden but targetable",
                     "off TAB, still targetable",
                     90
                  );
               }
            }
         }
      }
   }

   private static String departedPlayerName(Text var0) {
      if (var0 != null
         && var0.getContent() instanceof TranslatableTextContent var1
         && "multiplayer.player.left".equals(var1.getKey())) {
         Object[] var5 = var1.getArgs();
         if (var5.length != 0 && var5[0] != null) {
            return var5[0] instanceof Text var3 ? var3.getString() : String.valueOf(var5[0]);
         } else {
            return "";
         }
      } else {
         return "";
      }
   }

   private void reportHidden(UUID var1, String var2, boolean var3, String var4, String var5, int var6) {
      this.upsertDetection(
         detectionKey(var1, var2), var2, var4, var6, System.currentTimeMillis() + (20000L)
      );
      VanishObservation var7 = this.hiddenSpells.get(spellKey(var2));
      if (var7 == null || var7.spectator != var3) {
         this.hiddenSpells
            .put(
               spellKey(var2),
               new VanishObservation(var1, var2, var3, var5, this.regionProof(var1), this.tickCounter)
            );
      }
   }

   private void reviewSpells() {
      Iterator var1 = this.hiddenSpells.values().iterator();

      while (var1.hasNext()) {
         VanishObservation var2 = (VanishObservation)var1.next();
         if (var2.spectator && MC.getNetworkHandler().getPlayerListEntry(var2.uuid) == null) {
            var1.remove();
         } else if (!var2.watched && var2.sinceTick < this.tickCounter) {
            NearbyStaffProof var3 = this.regionProof(var2.uuid);
            if (var3 == null && !var2.told) {
               var3 = var2.proof;
            }

            if (var3 != null) {
               var2.told = true;
               var2.watched = true;
               this.watchingYou(var2.name, var3);
            } else if (!var2.told) {
               var2.told = true;
               this.news(var2.name, var2.how(), var2.detail);
            }
         }
      }
   }

   private boolean endSpell(String var1, boolean var2, long var3) {
      VanishObservation var5 = this.hiddenSpells.get(spellKey(var1));
      if (var5 != null && var5.spectator == var2 && System.currentTimeMillis() - var5.sinceMs >= var3) {
         this.hiddenSpells.remove(spellKey(var1));
         this.detections.remove(detectionKey(var5.uuid, var5.name));
         if (var5.told) {
            this.news(
               var5.name,
               ModuleChat.body()
                  .text("is ")
                  .good("visible again")
                  .build(),
               ""
            );
         }

         return true;
      } else {
         return false;
      }
   }

   private NearbyStaffProof regionProof(UUID var1) {
      if (var1 == null) {
         return null;
      } else {
         PlayerEntity var2 = MC.world.getPlayerByUuid(var1);
         if (var2 != null && var2 != MC.player) {
            return new NearbyStaffProof(var1, Math.round(var2.distanceTo(MC.player)));
         } else {
            return VanishAlertRules.isInYourRegion(var1) ? new NearbyStaffProof(var1, -1) : null;
         }
      }
   }

   private static String spellKey(String var0) {
      return var0.toLowerCase(Locale.ROOT);
   }

   private static String detectionKey(UUID var0, String var1) {
      return var0 != null ? var0.toString() : var1;
   }

   private void scanInvisiblePlayers() {
      double var1 = this.sensorRangeSq();

      for (PlayerEntity var4 : MC.world.getPlayers()) {
         if (var4 != null
            && var4 != MC.player
            && var4.isInvisible()
            && !(var4.squaredDistanceTo(MC.player) > var1)
            && this.realPlayer(var4)) {
            this.triggerSensor(
               VanishEvidenceType.INVISIBLE,
               var4,
               "Invisible Entity: metadata flag",
               35,
               5000L
            );
         }
      }
   }

   private void inspectInvisibleEntity(int var1) {
      if (MC.world.getEntityById(var1) instanceof PlayerEntity var2
         && var2 != MC.player
         && var2.isInvisible()
         && !(var2.squaredDistanceTo(MC.player) > this.sensorRangeSq())
         && this.realPlayer(var2)) {
         this.triggerSensor(
            VanishEvidenceType.INVISIBLE,
            var2,
            "Invisible Entity: metadata flag",
            35,
            5000L
         );
      }
   }

   private boolean realPlayer(PlayerEntity var1) {
      return this.credibleSubject(var1.getUuid(), profileName(var1));
   }

   private static String profileName(PlayerEntity var0) {
      return var0.getGameProfile() == null ? var0.getName().getString() : var0.getGameProfile().name();
   }

   private void inspectPositionalSound(VanishSignal var1) {
      if (VanishSignalClassifier.suspiciousSound(var1.detail())) {
         Vec3d var2 = var1.position();
         long var3 = System.currentTimeMillis();
         if (this.nearPlayer(var2)
            && !this.hasVisibleCause(var2)
            && !this.isExplosionRelated(var2)
            && !this.isPoweredMechanism(var2, var1.detail())
            && var3 - this.lastLocalActionMs >= (1000L)
            && !this.recentlySelfPlaced(var2)
            && !this.villagerToggledDoor(var1.detail(), var2)
            && (!this.selfContainerActive() || !isContainerSignal(var1.detail()))) {
            this.triggerSensor(
               VanishEvidenceType.SOUND,
               this.locatedSubject(var2),
               "Suspicious Sound: " + shortId(var1.detail()),
               14,
               3000L
            );
         }
      }
   }

   private void inspectEntitySound(VanishSignal var1) {
      if (VanishSignalClassifier.suspiciousSound(var1.detail())
         && MC.world.getEntityById(var1.entityId()) instanceof PlayerEntity var2
         && var2 != MC.player
         && var2.isInvisible()
         && var2.squaredDistanceTo(MC.player) <= this.sensorRangeSq()
         && this.realPlayer(var2)) {
         this.triggerSensor(
            VanishEvidenceType.SOUND,
            var2,
            "Suspicious Sound: invisible source",
            16,
            3000L
         );
      }
   }

   private void inspectParticle(VanishSignal var1) {
      if (VanishSignalClassifier.suspiciousParticle(var1.detail())) {
         Vec3d var2 = var1.position();
         long var3 = System.currentTimeMillis();
         if (this.nearPlayer(var2)
            && !this.hasVisibleCause(var2)
            && !this.isExplosionRelated(var2)
            && var3 - this.lastLocalActionMs >= (900L)
            && !this.hasAmbientParticleSource(var2, var1.detail())) {
            String var5 = shortId(var1.detail());
            if ((
                  !var5.equals("block")
                        && !var5.contains("smoke")
                     || !this.nearSelf(var2, 6.25)
               )
               && (
                  !var5.equals("block")
                        && !var5.contains("smoke")
                     || this.particleBurstReady(var5, var3)
               )) {
               this.triggerSensor(
                  VanishEvidenceType.PARTICLE,
                  this.locatedSubject(var2),
                  "Ghost Particle: " + shortId(var1.detail()),
                  16,
                  3000L
               );
            }
         }
      }
   }

   private boolean villagerToggledDoor(String var1, Vec3d var2) {
      String var3 = VanishSignalClassifier.path(var1);
      int var4 = (
               !var3.contains("door")
                  || var3.contains("trapdoor")
            )
            && !var3.contains("fence_gate")
         ? 0
         : 1;
      if (var4 != 0 && var2 != null && MC.world != null) {
         for (Entity var6 : MC.world.getEntities()) {
            if (var6.getType() == EntityType.VILLAGER
               && var6.getEntityPos().squaredDistanceTo(var2) <= 9.0) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean recentlySelfPlaced(Vec3d var1) {
      if (var1 == null) {
         return false;
      } else {
         Long var2 = this.selfPlacedBlocks.get(BlockPos.ofFloored(var1).asLong());
         return ((var2 != null && var2 > System.currentTimeMillis()));
      }
   }

   private void rememberExplosion(VanishSignal var1) {
      long var2 = System.currentTimeMillis();
      this.recentExplosions
         .addLast(
            new SpatialSignal(
               var1.position(),
               Math.max(
                  2.0,
                  parseDouble(var1.detail(), 4.0)
                     + 4.0
               ),
               var2
            )
         );

      while (this.recentExplosions.size() > (8)) {
         this.recentExplosions.removeFirst();
      }
   }

   private boolean particleBurstReady(String var1, long var2) {
       Deque<Long> var4 = (Deque<Long>)this.weakParticleBursts.computeIfAbsent(var1, var0 -> new ArrayDeque<Long>());
      var4.addLast(var2);

      while (!var4.isEmpty() && var2 - var4.peekFirst() > (2000L)) {
         var4.removeFirst();
      }

      if (var4.size() < (2)) {
         return false;
      } else {
         var4.clear();
         return true;
      }
   }

   private void triggerSensor(AntiVanishModule.VanishEvidenceType var1, String var2, String var3, int var4, long var5) {
      this.addSignal(var1, var2, null, var3, var4, var5);
   }

   private void triggerSensor(AntiVanishModule.VanishEvidenceType var1, PlayerEntity var2, String var3, int var4, long var5) {
      String var15 = profileName(var2);
      UUID var17 = var2.getUuid();
      AntiVanishModule.NearbyStaffProof var16 = this.regionProof(var17);
      this.addSignal(var1, var15, var16, var3, var4, var5);
   }

   private void addSignal(VanishEvidenceType var1, String var2, NearbyStaffProof var3, String var4, int var5, long var6) {
      long var8 = System.currentTimeMillis();
      String var10 = var1.name() + "|" + var2.toLowerCase(Locale.ROOT);
      long var11 = this.signalCooldowns.getOrDefault(var10, 0L);
      if (var8 - var11 >= var6) {
         this.signalCooldowns.put(var10, var8);
         this.signals.addLast(new VanishFinding(var1, var2, var3, var4, var5, var8));
         this.upsertDetection("signal:" + var10, var2, var4, var5, var8 + (20000L));
         this.announceTrigger(var10, var2, ((var3 != null)), var4);
         this.evaluateCritical();
      }
   }

   private void evaluateCritical() {
      long var1 = System.currentTimeMillis();
      this.pruneSignals(var1);
       EnumMap<VanishEvidenceType, Integer> var3 = new EnumMap<>(VanishEvidenceType.class);
      VanishFinding var4 = null;

      for (VanishFinding var6 : this.signals) {
         var3.merge(var6.type(), Integer.valueOf(var6.weight()), Math::max);
         if (var6.proof() != null) {
            var4 = var6;
         }
      }

      int var7 = var3.values().stream().mapToInt(Integer::intValue).sum();
      if (var4 != null
         && var3.size() >= (2)
         && var7 >= (35)
         && var1 - this.lastCriticalMs >= (12000L)) {
         this.watchingYou(var4.subject(), var4.proof());
      }
   }

   private void watchingYou(String var1, NearbyStaffProof var2) {
      long var3 = System.currentTimeMillis();
      this.lastCriticalMs = var3;
      this.criticalUntilMs = var3 + (7000L);
      this.criticalWatcher = var1;
      this.pendingChimes.add(var2.id());
      this.ghostId = var2.id();
      this.ghostName = var1;
   }

   private void playPendingChime() {
      if (!this.pendingChimes.isEmpty()) {
         boolean var1 = this.pendingChimes.stream().allMatch(VanishAlertRules::alarmedRecently);
         this.pendingChimes.clear();
         if (!var1) {
            if (MC.getSoundManager() != null) {
               MC.getSoundManager()
                  .play(
                     PositionedSoundInstance.ui(
                        SoundEvents.ENTITY_ELDER_GUARDIAN_CURSE, 1.0F, 1.0F
                     )
                  );
            }

            PlayerWatchHud.watching(this.ghostId, this.ghostName, 0);
         }
      }
   }

   private void news(String var1, Text var2, String var3) {
      Body var4 = ModuleChat.body()
         .name(NameFilter.apply(var1))
         .text(" ")
         .append(var2);
      if (!var3.isEmpty()) {
         var4.text(" (" + var3 + ")");
      }

      ModuleChat.send(this, var4);
   }

   private void queueGamemodeUpdates(PlayerListS2CPacket var1) {
      if (!var1.getActions().contains(Action.ADD_PLAYER)) {
         for (Entry var3 : var1.getEntries()) {
            if (var3 != null && var3.gameMode() != null && var3.profileId() != null) {
               this.observations.offer(VanishSignal.gamemode(var3.profileId(), var3.gameMode().getId()));
            }
         }
      }
   }

   private void announceGamemode(UUID var1, String var2) {
      if (var1 != null && (MC.player == null || !MC.player.getUuid().equals(var1))) {
         StaffProfile var3 = this.knownPlayers.get(var1);
         if (var3 != null && VanishAlertRules.isStaffName(var3.name())) {
            if (GameMode.SPECTATOR.getId().equals(var2)) {
               if (this.credibleSubject(var1, var3.name())) {
                  this.reportHidden(
                     var1,
                     var3.name(),
                     true,
                     "Vanish Event: switched to spectator",
                     "",
                     100
                  );
                  return;
               }
            } else if (this.endSpell(var3.name(), true, 0L)) {
               return;
            }

            ModuleChat.send(
               this,
               VanishAlertRules.switchedTo(
                  ModuleChat.body()
                     .name(NameFilter.apply(var3.name()))
                     .text(" "),
                  var2
               )
            );
         }
      }
   }

   private void announceTrigger(String var1, String var2, boolean var3, String var4) {
      long var5 = System.currentTimeMillis();
      Long var7 = this.announceCooldowns.get(var1);
      if (var7 == null || var5 - var7 >= (1500L)) {
         while (!this.announceTimes.isEmpty() && var5 - this.announceTimes.peekFirst() > (4000L)) {
            this.announceTimes.removeFirst();
         }

         if (this.announceTimes.size() < (6)) {
            this.announceCooldowns.put(var1, var5);
            this.announceTimes.addLast(var5);
            int var8 = var4.indexOf(": ");
            Body var9 = var8 < 0
               ? ModuleChat.body().warn(var4)
               : ModuleChat.body().warn(var4.substring(0, var8)).text(var4.substring(var8));
            int var10 = var2 != null
                  && !var2.isBlank()
                  && !"Unknown".equalsIgnoreCase(var2)
                  && !"CRITICAL".equalsIgnoreCase(var2)
               ? 1
               : 0;
            if (var10 != 0) {
               var9.text(" (");
               if (var3) {
                  var9.name(NameFilter.apply(var2));
               } else {
                  var9.value(var2);
               }

               var9.text(")");
            }

            ModuleChat.send(this, var9);
         }
      }
   }

   private void upsertDetection(String var1, String var2, String var3, int var4, long var5) {
      AlertCandidate var7 = this.detections.get(var1);
      if (var7 == null) {
         this.detections.put(var1, new AlertCandidate(var2, var3, var4, var5));
      } else {
         var7.name = var2;
         var7.expiresAt = Math.max(var7.expiresAt, var5);
         if (var4 >= var7.score) {
            var7.reason = var3;
            var7.score = var4;
         }
      }
   }

   private List<VanishHudEntry> hudSnapshot() {
      long var1 = System.currentTimeMillis();
      ArrayList var3 = new ArrayList();
      if (var1 < this.criticalUntilMs) {
         var3.add(new VanishHudEntry("CRITICAL", this.criticalWatcher));
      }

      HashSet var4 = new HashSet();
      this.detections
         .values()
         .stream()
         .filter(var2 -> ((var2.expiresAt > var1)))
         .filter(AntiVanishModule::detectionWorthShowing)
         .sorted(
            Comparator.<AlertCandidate>comparingInt(var0 -> var0.score).reversed().thenComparing(var0 -> var0.name, String.CASE_INSENSITIVE_ORDER)
         )
         .map(var0 -> new VanishHudEntry(var0.name, var0.reason))
         .filter(var1x -> var4.add(hudTag(var1x) + "\u0000" + hudValue(var1x)))
         .limit(4L)
         .forEach(var3::add);
      return List.copyOf(var3);
   }

   private void pruneState() {
      long var1 = System.currentTimeMillis();
      this.detections.entrySet().removeIf(var2 -> ((var2.getValue().expiresAt <= var1)));
      this.signalCooldowns
         .entrySet()
         .removeIf(
            var2 -> ((var1 - var2.getValue() > (60000L)))
         );
      this.announceCooldowns
         .entrySet()
         .removeIf(
            var2 -> ((var1 - var2.getValue() > (60000L)))
         );
      this.selfPlacedBlocks.entrySet().removeIf(var2 -> ((var2.getValue() <= var1)));
      this.confirmedDepartures.entrySet().removeIf(var2 -> ((var2.getValue() <= var1)));
      this.automatedMechanisms.entrySet().removeIf(var2 -> ((var2.getValue() <= var1)));
      this.weakParticleBursts.values().removeIf(var2 -> {
         while (!var2.isEmpty() && var1 - var2.peekFirst() > (2000L)) {
            var2.removeFirst();
         }

         return var2.isEmpty();
      });

      while (
         !this.recentExplosions.isEmpty() && var1 - this.recentExplosions.peekFirst().timeMs() > (3000L)
      ) {
         this.recentExplosions.removeFirst();
      }

      this.pruneSignals(var1);
   }

   private void pruneSignals(long var1) {
      while (
         !this.signals.isEmpty() && var1 - this.signals.peekFirst().timeMs() > (15000L)
      ) {
         this.signals.removeFirst();
      }
   }

   private boolean nearPlayer(Vec3d var1) {
      return ((var1 != null && var1.squaredDistanceTo(MC.player.getEntityPos()) <= this.sensorRangeSq()));
   }

   private boolean nearSelf(Vec3d var1, double var2) {
      return ((var1 != null
            && MC.player != null
            && var1.squaredDistanceTo(MC.player.getEntityPos()) < var2));
   }

   private boolean selfContainerActive() {
      return ((System.currentTimeMillis() - this.lastContainerActivityMs < (2500L)));
   }

   private static boolean isContainerSignal(String var0) {
      String var1 = VanishSignalClassifier.path(var0);
      return ((!var1.contains("chest")
            && !var1.contains("barrel")
            && !var1.contains("shulker")
         ? 0
         : 1) != 0);
   }

   private String locatedSubject(Vec3d var1) {
      if (var1 != null && MC.player != null) {
         Vec3d var2 = MC.player.getEntityPos();
         double var3 = var1.x - var2.x;
         double var5 = var1.y - var2.y;
         double var7 = var1.z - var2.z;
         long var9 = Math.round(Math.sqrt(var3 * var3 + var5 * var5 + var7 * var7));
         String var11 = compass(var3, var7);
         return var11.isEmpty() ? var9 + "m" : var9 + "m " + var11;
      } else {
         return "nearby";
      }
   }

   private static String compass(double var0, double var2) {
      String var4 = var2 < -1.0
         ? "N"
         : (
            var2 > 1.0
               ? "S"
               : ""
         );
      String var5 = var0 > 1.0
         ? "E"
         : (
            var0 < -1.0
               ? "W"
               : ""
         );
      return var4 + var5;
   }

   private boolean hasVisibleCause(Vec3d var1) {
      if (var1 == null) {
         return true;
      } else {
         for (Entity var3 : MC.world.getEntities()) {
            if (var3 != MC.player) {
               if (var3 instanceof PlayerEntity var4) {
                  if (!var4.isInvisible() && var3.getEntityPos().squaredDistanceTo(var1) <= 16.0) {
                     return true;
                  }
               } else if (var3 instanceof ProjectileEntity
                  && var3.getEntityPos().squaredDistanceTo(var1) <= 16.0) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private boolean isExplosionRelated(Vec3d var1) {
      if (var1 == null) {
         return false;
      } else {
         long var2 = System.currentTimeMillis();

         while (
            !this.recentExplosions.isEmpty() && var2 - this.recentExplosions.peekFirst().timeMs() > (3000L)
         ) {
            this.recentExplosions.removeFirst();
         }

         for (SpatialSignal var5 : this.recentExplosions) {
            if (var5.center().squaredDistanceTo(var1) <= var5.radius() * var5.radius()) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean hasAmbientParticleSource(Vec3d var1, String var2) {
      if (var1 != null && shortId(var2).contains("smoke")) {
         BlockPos var3 = BlockPos.ofFloored(var1);

         for (int var4 = -2; var4 <= (2); var4++) {
            for (int var5 = -2; var5 <= (2); var5++) {
               for (int var6 = -2; var6 <= (2); var6++) {
                  BlockPos var7 = var3.add(var4, var5, var6);
                  Identifier var8 = Registries.BLOCK.getId(MC.world.getBlockState(var7).getBlock());
                  String var9 = shortId(
                     var8 == null ? "" : var8.toString()
                  );
                  if (var9.contains("campfire")
                     || var9.contains("furnace")
                     || var9.contains("smoker")
                     || var9.contains("torch")
                     || var9.contains("fire")
                     || var9.contains("candle")
                     || var9.contains("respawn_anchor")) {
                     return true;
                  }
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean isPoweredMechanism(Vec3d var1, String var2) {
      String var3 = shortId(var2);
      if (!var3.contains("door")
         && !var3.contains("trapdoor")) {
         return false;
      } else {
         BlockPos var4 = BlockPos.ofFloored(var1);
         long var5 = System.currentTimeMillis();

         for (int var7 = -1; var7 <= (1); var7++) {
            BlockPos var8 = var4.add(0, var7, 0);
            BlockState var9 = MC.world.getBlockState(var8);
            long var10 = var8.asLong();
            int var12 = var9.contains(Properties.POWERED) && var9.get(Properties.POWERED)
               ? 1
               : 0;
            if (var12 != 0 || MC.world.isReceivingRedstonePower(var8)) {
               this.automatedMechanisms.put(var10, var5 + (5000L));
               return true;
            }

            if (this.automatedMechanisms.getOrDefault(var10, 0L) > var5) {
               return true;
            }
         }

         return false;
      }
   }

   private double sensorRangeSq() {
      double var1 = 64.0;
      return var1 * var1;
   }

   private static double parseDouble(String var0, double var1) {
      try {
         return Double.parseDouble(var0);
      } catch (Exception var4) {
         return var1;
      }
   }

   private static String soundId(Identifier var0) {
      return var0 == null ? "" : var0.toString();
   }

   private static String shortId(String var0) {
      return VanishSignalClassifier.path(var0);
   }

   private void resetRuntime() {
      this.observations.clear();
      this.knownPlayers.clear();
      this.detections.clear();
      this.signalCooldowns.clear();
      this.announceCooldowns.clear();
      this.announceTimes.clear();
      this.selfPlacedBlocks.clear();
      this.confirmedDepartures.clear();
      this.automatedMechanisms.clear();
      this.weakParticleBursts.clear();
      this.signals.clear();
      this.recentExplosions.clear();
      this.pendingVanishes.clear();
      this.hiddenSpells.clear();
      this.shard.clear();
      this.tickCounter = 0;
      this.lastLocalActionMs = 0L;
      this.lastContainerActivityMs = 0L;
      this.lastCriticalMs = 0L;
      this.criticalUntilMs = 0L;
      this.criticalWatcher = "";
      this.pendingChimes.clear();
      this.ghostId = null;
      this.ghostName = null;
      this.recentMessages.clear();
      this.listedSinceMs.clear();
      this.serverSendsLeaveMessages = false;
      this.completionRequestIds.clear();
      this.pendingCompletionNames = null;
      this.nextCompletionId = 30000;
   }

   @Environment(EnvType.CLIENT)
   private static final class AlertCandidate {
      String name;
      String reason;
      int score;
      long expiresAt;

      AlertCandidate(String name, String reason, int score, long expiresAt) {
         this.name = name;
         this.reason = reason;
         this.score = score;
         this.expiresAt = expiresAt;
      }
   }

   @Environment(EnvType.CLIENT)
   private record SpatialSignal(Vec3d center, double radius, long timeMs) {
   }

   @Environment(EnvType.CLIENT)
   private static final class VanishObservation {
      final UUID uuid;
      final String name;
      final boolean spectator;
      final String detail;
      final NearbyStaffProof proof;
      final int sinceTick;
      final long sinceMs = System.currentTimeMillis();
      boolean told;
      boolean watched;

      VanishObservation(UUID uuid, String name, boolean spectator, String detail, NearbyStaffProof proof, int sinceTick) {
         this.uuid = uuid;
         this.name = name;
         this.spectator = spectator;
         this.detail = detail;
         this.proof = proof;
         this.sinceTick = sinceTick;
      }

      Text how() {
         return this.spectator
            ? VanishAlertRules.switchedTo(ModuleChat.body(), GameMode.SPECTATOR.getId()).build()
            : ModuleChat.body().danger("vanished").build();
      }
   }

   @Environment(EnvType.CLIENT)
   public record VanishHudEntry(String name, String reason) {
   }

   @Environment(EnvType.CLIENT)
   private record StaffProfile(UUID uuid, String name) {
   }

   @Environment(EnvType.CLIENT)
   private record VanishSignal(AntiVanishModule.VanishSignalType type, UUID profileId, int entityId, double x, double y, double z, String detail) {
      static AntiVanishModule.VanishSignal tabRemove(UUID var0) {
         return new AntiVanishModule.VanishSignal(AntiVanishModule.VanishSignalType.TAB_REMOVE, var0, -1, 0.0, 0.0, 0.0, "");
      }

      static AntiVanishModule.VanishSignal tabHide(UUID var0) {
         return new AntiVanishModule.VanishSignal(AntiVanishModule.VanishSignalType.TAB_HIDE, var0, -1, 0.0, 0.0, 0.0, "");
      }

      static AntiVanishModule.VanishSignal gamemode(UUID var0, String var1) {
         return new AntiVanishModule.VanishSignal(AntiVanishModule.VanishSignalType.GAMEMODE, var0, -1, 0.0, 0.0, 0.0, var1);
      }

      static AntiVanishModule.VanishSignal playerLeft(String var0) {
         return new AntiVanishModule.VanishSignal(AntiVanishModule.VanishSignalType.PLAYER_LEFT, null, -1, 0.0, 0.0, 0.0, var0);
      }

      static AntiVanishModule.VanishSignal systemChat(String var0) {
         return new AntiVanishModule.VanishSignal(AntiVanishModule.VanishSignalType.SYSTEM_CHAT, null, -1, 0.0, 0.0, 0.0, var0);
      }

      static AntiVanishModule.VanishSignal entityMetadata(int var0) {
         return new AntiVanishModule.VanishSignal(AntiVanishModule.VanishSignalType.ENTITY_METADATA, null, var0, 0.0, 0.0, 0.0, "");
      }

      static AntiVanishModule.VanishSignal explosion(Vec3d var0, float var1) {
         return new AntiVanishModule.VanishSignal(AntiVanishModule.VanishSignalType.EXPLOSION, null, -1, var0.x, var0.y, var0.z, Float.toString(var1));
      }

      static AntiVanishModule.VanishSignal entitySound(int var0, String var1) {
         return new AntiVanishModule.VanishSignal(AntiVanishModule.VanishSignalType.ENTITY_SOUND, null, var0, 0.0, 0.0, 0.0, var1);
      }

      static AntiVanishModule.VanishSignal position(AntiVanishModule.VanishSignalType var0, double var1, double var3, double var5, String var7) {
         return new AntiVanishModule.VanishSignal(var0, null, -1, var1, var3, var5, var7);
      }

      Vec3d position() {
         return new Vec3d(this.x, this.y, this.z);
      }
   }

   @Environment(EnvType.CLIENT)
   private static enum VanishSignalType {
      TAB_REMOVE,
      TAB_HIDE,
      PLAYER_LEFT,
      SYSTEM_CHAT,
      ENTITY_METADATA,
      POSITIONAL_SOUND,
      ENTITY_SOUND,
      PARTICLE,
      EXPLOSION,
      GAMEMODE;
   }

   @Environment(EnvType.CLIENT)
   private record PendingTabRemoval(UUID uuid, String name, int dueTick) {
   }

   @Environment(EnvType.CLIENT)
   private record AntiVanishHelper(String text, long atMs) {
   }

   @Environment(EnvType.CLIENT)
   private record NearbyStaffProof(UUID id, int distance) {
   }

   @Environment(EnvType.CLIENT)
   private record VanishFinding(
      AntiVanishModule.VanishEvidenceType type, String subject, AntiVanishModule.NearbyStaffProof proof, String reason, int weight, long timeMs
   ) {
   }

   @Environment(EnvType.CLIENT)
   private static enum VanishEvidenceType {
      VANISH,
      INVISIBLE,
      PARTICLE,
      SOUND;
   }
}


