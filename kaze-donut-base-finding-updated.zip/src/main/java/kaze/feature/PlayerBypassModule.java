package kaze.feature;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import kaze.Kaze;
import kaze.event.EventListener;
import kaze.event.events.TickEvent;
import kaze.event.events.Render3DEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.Setting;
import kaze.module.setting.BooleanSetting;
import kaze.utils.EncryptedString;
import kaze.utils.RenderUtils.ColoredBox;
import kaze.utils.ChunkLightTracker;
import kaze.utils.RenderUtils.ColoredLine;
import kaze.utils.RenderUtils;
import kaze.utils.RenderVisibility;
import kaze.utils.FlagAlarm;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.MutableText;

public final class PlayerBypassModule extends Module {
   private static final int RENDER_DISTANCE_CHUNKS = 16;
   private final NumberSetting plateSize = new NumberSetting(
      EncryptedString.of("Plate Size"),
      8.0,
      64.0,
      15.0,
      1.0
   );
   private final NumberSetting alpha = new NumberSetting(
      EncryptedString.of("Alpha"),
      10.0,
      255.0,
      180.0,
      1.0
   );
   private final BooleanSetting tracers = new BooleanSetting(
      EncryptedString.of("Tracers"), false
   );
   private final BooleanSetting kickOnFlag = new BooleanSetting(
         EncryptedString.of("Kick On Flag"),
         false
      )
      .setDescription(
         EncryptedString.of(
            "Disconnects once, then automatically turns itself off"
         )
      );
   private final BooleanSetting flagSound = new BooleanSetting(
         EncryptedString.of("Flag Sound"), true
      )
      .setDescription(
         EncryptedString.of(
            "Plays an alarm that continues on the disconnect and menu screens"
         )
      );
   private final Set<Long> handledFlags = new HashSet<>();
   private final List<ColoredBox> renderBoxes = new ArrayList<>();
   private final List<ColoredLine> renderLines = new ArrayList<>();
   private Object trackedWorld;

   public PlayerBypassModule() {
      super(
         EncryptedString.of("Player Bypass"),
         EncryptedString.of(
            "Highlights suspicious light-signal chunks with a yellow through-wall plate"
         ),
         -1,
         Category.DONUT
      );
      Setting[] var10001 = new Setting[5];
      var10001[0] = this.plateSize;
      var10001[1] = this.alpha;
      var10001[2] = this.tracers;
      var10001[3] = this.kickOnFlag;
      var10001[4] = this.flagSound;
      this.addSettings(var10001);
   }

   @Override
   public void onEnable() {
      this.handledFlags.clear();
      this.trackedWorld = this.mc.world;
      super.onEnable();
   }

   @Override
   public void onDisable() {
      this.handledFlags.clear();
      this.trackedWorld = null;
      this.renderBoxes.clear();
      this.renderLines.clear();
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         if (this.trackedWorld != this.mc.world) {
            this.handledFlags.clear();
            this.trackedWorld = this.mc.world;
         }

         int var2 = this.mc.player.getBlockPos().getX() >> (4);
         int var3 = this.mc.player.getBlockPos().getZ() >> (4);

         for (long var5 : ChunkLightTracker.getFlaggedChunks()) {
            int var7 = ChunkPos.getPackedX(var5);
            int var8 = ChunkPos.getPackedZ(var5);
            if (Math.abs(var7 - var2) <= (16)
               && Math.abs(var8 - var3) <= (16)
               && this.handledFlags.add(var5)) {
               this.onFlag(var7, var8);
            }
         }
      }
   }

   private void onFlag(int var1, int var2) {
      int var3 = (var1 << (4)) + (8);
      int var4 = (var2 << (4)) + (8);
      if (this.flagSound.getValue()) {
         FlagAlarm.trigger(this.mc);
      }

      this.mc
         .player
         .sendMessage(Text.literal("§e[Player Bypass] §fFlagged chunk at X: " + var3 + " Z: " + var4), false);
      AutoRtpModule var5 = (AutoRtpModule)Kaze.INSTANCE
         .getModuleManager()
         .getModuleByClass(AutoRtpModule.class);
      if (var5 != null) {
         var5.onBypassFlag();
      }

      if (this.kickOnFlag.getValue() && this.mc.getNetworkHandler() != null) {
         this.kickOnFlag.setValue(false);
         MutableText var6 = Text.literal("Kicked - Player Bypass flagged X: " + var3 + " Z: " + var4 + "\nKick On Flag was automatically turned OFF.");
         this.mc.getNetworkHandler().getConnection().disconnect(var6);
      }
   }

   @EventListener
   public void onRender3D(Render3DEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         Camera var2 = RenderUtils.getCamera();
         if (var2 != null && var2.isReady()) {
            int var3 = this.mc.player.getBlockPos().getX() >> (4);
            int var4 = this.mc.player.getBlockPos().getZ() >> (4);
            long var5 = System.currentTimeMillis();
            double var7 = 0.72
               + Math.sin((double)var5 / 260.0)
                  * 0.18;
            int var9 = Math.max(
               1,
               Math.min(
                  255,
                  (int)((double)this.alpha.getIntValue() * 0.42 * var7)
               )
            );
            Color var10 = new Color(255, 210, 25, var9);
            Color var11 = new Color(255, 225, 55, this.alpha.getIntValue());
            this.renderBoxes.clear();
            this.renderLines.clear();
            Vec3d var12 = RenderUtils.getTracerStart(var2);
            double var13 = this.plateSize.getValue() * 0.5;

            for (long var16 : ChunkLightTracker.getFlaggedChunks()) {
               int var18 = ChunkPos.getPackedX(var16);
               int var19 = ChunkPos.getPackedZ(var16);
               if (Math.abs(var18 - var3) <= (16) && Math.abs(var19 - var4) <= (16)) {
                  double var20 = (double)(var18 << (4)) + 8.0;
                  double var22 = (double)(var19 << (4)) + 8.0;
                  double var24 = 64.25
                     + Math.sin((double)(var5 + var16) / 420.0)
                        * 0.12;
                  double var26 = var24 + 0.16;
                  if (!this.tracers.getValue() && !RenderVisibility.box(
                     var20 - var13, var24, var22 - var13,
                     var20 + var13, var26, var22 + var13)) {
                     continue;
                  }
                  this.renderBoxes
                     .add(new ColoredBox(var20 - var13, var24, var22 - var13, var20 + var13, var26, var22 + var13, var10));
                  RenderUtils.addBoxOutline(
                     this.renderLines,
                     var20 - var13,
                     var24,
                     var22 - var13,
                     var20 + var13,
                     var26,
                     var22 + var13,
                     var11,
                     2.5F
                  );
                  if (this.tracers.getValue()) {
                     this.renderLines
                        .add(new ColoredLine(var12, new Vec3d(var20, var26, var22), var11, 2.0F));
                  }
               }
            }

            if (!this.renderBoxes.isEmpty()) {
               MatrixStack var28 = var1.matrixStack;
               var28.push();
               RenderUtils.applyCameraTransform(var28, var2);
               RenderUtils.renderFilledBoxes(var28, this.renderBoxes);
               RenderUtils.renderLines(var28, this.renderLines);
               var28.pop();
            }
         }
      }
   }
}
