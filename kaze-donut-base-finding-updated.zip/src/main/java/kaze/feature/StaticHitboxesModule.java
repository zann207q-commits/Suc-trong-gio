package kaze.feature;

import kaze.event.EventListener;
import kaze.event.events.TargetPoseEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.utils.EncryptedString;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;

public final class StaticHitboxesModule extends Module {
   public StaticHitboxesModule() {
      super(EncryptedString.of("Static HitBoxes"), EncryptedString.of("Expands a Player's Hitbox"), -1, Category.COMBAT);
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTargetPose(TargetPoseEvent event) {
      if (this.isEnabled() && event.entity instanceof PlayerEntity player && !player.isMainPlayer()) {
         event.cir.setReturnValue(EntityPose.STANDING);
      }
   }
}
