package kaze.feature;

import kaze.Kaze;
import kaze.event.EventListener;
import kaze.event.events.PostItemUseEvent;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BindSetting;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.NumberSetting;
import kaze.utils.EncryptedString;
import kaze.utils.InventoryUtil;
import kaze.utils.KeyUtils;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public final class AutoFireworkModule extends Module {
   private final BindSetting activateKey;
   private final NumberSetting delay;
   private final BooleanSetting switchBack;
   private final NumberSetting switchDelay;
   private boolean isFireworkActive;
   private boolean hasUsedFirework;
   private int useDelayCounter;
   private int previousSelectedSlot;
   private int switchDelayCounter;
   private int cooldownCounter;

   public AutoFireworkModule() {
      super(
         EncryptedString.of("Auto Firework"),
         EncryptedString.of("Switches to a firework and uses it when you press a bind."),
         -1,
         Category.MISC
      );
      activateKey = new BindSetting(EncryptedString.of("Activate Key"), -1, false);
      delay = new NumberSetting(EncryptedString.of("Delay"), 0.0, 20.0, 0.0, 1.0);
      switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
      switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0, 20.0, 0.0, 1.0)
         .getValue(EncryptedString.of("Delay after using firework before switching back."));
      addSettings(activateKey, delay, switchBack, switchDelay);
   }

   @Override
   public void onEnable() {
      resetState();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (mc.currentScreen != null) {
         return;
      }
      if (cooldownCounter > 0) {
         cooldownCounter--;
         return;
      }
      if (mc.player != null && KeyUtils.isKeyPressed(activateKey.getValue())) {
         ElytraGlideModule glide = (ElytraGlideModule)Kaze.INSTANCE.MODULE_MANAGER.getModuleByClass(ElytraGlideModule.class);
         if ((glide.isEnabled() || mc.player.isGliding())
            && mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)
            && !mc.player.getInventory().getSelectedStack().isOf(Items.FIREWORK_ROCKET)) {
            var components = mc.player.getMainHandStack().getItem().getComponents();
            if (!components.contains(DataComponentTypes.FOOD)
               && !components.contains(DataComponentTypes.EQUIPPABLE)) {
               isFireworkActive = true;
            }
         }
      }
      if (!isFireworkActive) {
         return;
      }
      if (previousSelectedSlot == -1) {
         previousSelectedSlot = mc.player.getInventory().getSelectedSlot();
      }
      if (!InventoryUtil.swap(Items.FIREWORK_ROCKET)) {
         resetState();
         return;
      }
      if (useDelayCounter < delay.getIntValue()) {
         useDelayCounter++;
         return;
      }
      if (!hasUsedFirework) {
         mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
         hasUsedFirework = true;
      }
      if (switchBack.getValue()) {
         handleSwitchBack();
      } else {
         resetState();
      }
   }

   private void handleSwitchBack() {
      if (switchDelayCounter < switchDelay.getIntValue()) {
         switchDelayCounter++;
      } else {
         InventoryUtil.swap(previousSelectedSlot);
         resetState();
      }
   }

   private void resetState() {
      previousSelectedSlot = -1;
      useDelayCounter = 0;
      switchDelayCounter = 0;
      cooldownCounter = 4;
      isFireworkActive = false;
      hasUsedFirework = false;
   }

   @EventListener
   public void onPostItemUse(PostItemUseEvent event) {
      if (mc.player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)) {
         hasUsedFirework = true;
      }
      if (cooldownCounter > 0) {
         event.cancel();
      }
   }
}
