package kaze.feature;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import kaze.event.EventListener;
import kaze.event.events.PreItemUseEvent;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BindSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.Setting;
import kaze.utils.BlockUtil;
import kaze.utils.EncryptedString;
import kaze.utils.KeyUtils;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.mob.SlimeEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;


public final class AutoCrystalModule extends Module {
   private final BindSetting activateKey = new BindSetting(
         EncryptedString.of("Activate Key"),
         1,
         false
      )
      .setDescription(EncryptedString.of("Key that does the crystalling"));
   private final NumberSetting placeDelay = new NumberSetting(
      EncryptedString.of("Place Delay"),
      0.0,
      20.0,
      0.0,
      1.0
   );
   private final NumberSetting breakDelay = new NumberSetting(
      EncryptedString.of("Break Delay"),
      0.0,
      20.0,
      0.0,
      1.0
   );
   private int placeDelayCounter;
   private int breakDelayCounter;
   public boolean isActive;

   public AutoCrystalModule() {
      super(
         EncryptedString.of("Auto Crystal"),
         EncryptedString.of("Automatically crystals fast for you"),
         -1,
         Category.COMBAT
      );
      Setting[] var10001 = new Setting[3];
      var10001[0] = this.activateKey;
      var10001[1] = this.placeDelay;
      var10001[2] = this.breakDelay;
      this.addSettings(var10001);
   }

   @Override
   public void onEnable() {
      this.resetCounters();
      this.isActive = false;
      super.onEnable();
   }

   private void resetCounters() {
      this.placeDelayCounter = 0;
      this.breakDelayCounter = 0;
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.currentScreen == null) {
         this.updateCounters();
         if (!this.mc.player.isUsingItem() && this.isKeyActive() && this.mc.player.getMainHandStack().getItem() == Items.END_CRYSTAL) {
            this.handleInteraction();
         }
      }
   }

   private void updateCounters() {
      if (this.placeDelayCounter > 0) {
         this.placeDelayCounter -= 1;
      }

      if (this.breakDelayCounter > 0) {
         this.breakDelayCounter -= 1;
      }
   }

   private boolean isKeyActive() {
      int var1 = this.activateKey.getValue();
      if (var1 != (-1) && !KeyUtils.isKeyPressed(var1)) {
         this.resetCounters();
         return this.isActive = false;
      } else {
         return this.isActive = true;
      }
   }

   private void handleInteraction() {
      HitResult var1 = this.mc.crosshairTarget;
      if (this.mc.crosshairTarget instanceof BlockHitResult) {
         this.handleBlockInteraction((BlockHitResult)var1);
      } else if (this.mc.crosshairTarget instanceof EntityHitResult var2) {
         this.handleEntityInteraction(var2);
      }
   }

   private void handleBlockInteraction(BlockHitResult var1) {
      if (var1.getType() == Type.BLOCK && this.placeDelayCounter <= 0) {
         BlockPos var2 = var1.getBlockPos();
         if ((
               BlockUtil.isBlockAtPosition(var2, Blocks.OBSIDIAN)
                  || BlockUtil.isBlockAtPosition(var2, Blocks.BEDROCK)
            )
            && this.isValidCrystalPlacement(var2)) {
            BlockUtil.interactWithBlock(var1, true);
            this.placeDelayCounter = this.placeDelay.getIntValue();
         }
      }
   }

   private void handleEntityInteraction(EntityHitResult var1) {
      if (this.breakDelayCounter <= 0) {
         Entity var2 = var1.getEntity();
         if (var2 instanceof EndCrystalEntity || var2 instanceof SlimeEntity) {
            this.mc.interactionManager.attackEntity(this.mc.player, var2);
            this.mc.player.swingHand(Hand.MAIN_HAND);
            this.breakDelayCounter = this.breakDelay.getIntValue();
         }
      }
   }

   @EventListener
   public void onPreItemUse(PreItemUseEvent var1) {
      if (this.mc.player.getMainHandStack().getItem() == Items.END_CRYSTAL
         && this.mc.crosshairTarget instanceof BlockHitResult var2
         && this.mc.crosshairTarget.getType() == Type.BLOCK) {
         BlockPos var4 = var2.getBlockPos();
         if (BlockUtil.isBlockAtPosition(var4, Blocks.OBSIDIAN)
            || BlockUtil.isBlockAtPosition(var4, Blocks.BEDROCK)) {
            var1.cancel();
         }
      }
   }

   private boolean isValidCrystalPlacement(BlockPos var1) {
      BlockPos var2 = var1.up();
      if (!this.mc.world.isAir(var2)) {
         return false;
      } else {
         int var3 = var2.getX();
         int var4 = var2.getY();
         int var5 = var2.getZ();
         return this.mc
            .world
            .getOtherEntities(
               null,
               new Box(
                  (double)var3,
                  (double)var4,
                  (double)var5,
                  (double)var3 + 1.0,
                  (double)var4 + 2.0,
                  (double)var5 + 1.0
               )
            )
            .isEmpty();
      }
   }
}
