package kaze.feature;

import java.util.function.Predicate;
import kaze.event.EventListener;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BindSetting;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.NumberSetting;
import kaze.utils.EncryptedString;
import kaze.utils.InventoryUtil;
import kaze.utils.KeyUtils;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

public final class ElytraSwapModule extends Module {
   private final BindSetting activateKey;
   private final NumberSetting swapDelay;
   private final BooleanSetting switchBack;
   private final NumberSetting switchDelay;
   private final BooleanSetting moveToSlot;
   private final NumberSetting elytraSlot;
   private boolean isSwapping;
   private boolean isSwinging;
   private boolean isItemSwapped;
   private int swapCounter;
   private int switchCounter;
   private int activationCooldown;
   private int originalSlot;

   public ElytraSwapModule() {
      super(
         EncryptedString.of("Elytra Swap"),
         EncryptedString.of("Seamlessly swap between an Elytra and a Chestplate with a configurable keybinding"),
         -1,
         Category.COMBAT
      );
      activateKey = new BindSetting(EncryptedString.of("Activate Key"), 71, false);
      swapDelay = new NumberSetting(EncryptedString.of("Delay"), 0.0, 20.0, 0.0, 1.0);
      switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true);
      switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0.0, 20.0, 0.0, 1.0);
      moveToSlot = new BooleanSetting(EncryptedString.of("Move to slot"), true)
         .setDescription("If elytra is not in hotbar it will move it from inventory to preferred slot");
      elytraSlot = new NumberSetting(EncryptedString.of("Elytra Slot"), 1.0, 9.0, 9.0, 1.0)
         .getValue(EncryptedString.of("Your preferred elytra slot"));
      addSettings(activateKey, swapDelay, switchBack, switchDelay, moveToSlot, elytraSlot);
   }

   @Override
   public void onEnable() {
      resetState();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (mc.currentScreen != null || mc.player == null) {
         return;
      }

      if (activationCooldown > 0) {
         activationCooldown--;
      } else if (KeyUtils.isKeyPressed(activateKey.getValue())) {
         isSwapping = true;
         activationCooldown = 4;
      }
      if (!isSwapping) {
         return;
      }
      if (originalSlot == -1) {
         originalSlot = mc.player.getInventory().getSelectedSlot();
      }
      if (swapCounter < swapDelay.getIntValue()) {
         swapCounter++;
         return;
      }

      boolean wearingElytra = mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
      Predicate<Item> targetItem = wearingElytra
         ? item -> item != Items.ELYTRA && item.getComponents().contains(DataComponentTypes.EQUIPPABLE)
         : item -> item.equals(Items.ELYTRA);
      if (!isItemSwapped) {
         if (!InventoryUtil.swapItem(targetItem)) {
            if (!moveToSlot.getValue()) {
               resetState();
               return;
            }
            mc.interactionManager.clickSlot(
               mc.player.currentScreenHandler.syncId,
               9,
               elytraSlot.getIntValue() - 1,
               SlotActionType.SWAP,
               mc.player
            );
            swapCounter = 0;
            return;
         }
         isItemSwapped = true;
      }

      if (!isSwinging) {
         mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
         mc.player.swingHand(Hand.MAIN_HAND);
         isSwinging = true;
      }
      if (switchBack.getValue()) {
         handleSwitchBack();
      } else {
         resetState();
      }
   }

   private void handleSwitchBack() {
      if (switchCounter < switchDelay.getIntValue()) {
         switchCounter++;
      } else {
         InventoryUtil.swap(originalSlot);
         resetState();
      }
   }

   private void resetState() {
      originalSlot = -1;
      switchCounter = 0;
      swapCounter = 0;
      isSwapping = false;
      isSwinging = false;
      isItemSwapped = false;
   }
}
