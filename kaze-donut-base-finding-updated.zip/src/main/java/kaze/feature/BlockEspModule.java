package kaze.feature;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import kaze.event.EventListener;
import kaze.event.events.ChunkDataEvent;
import kaze.event.events.Render3DEvent;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.Setting;
import kaze.module.setting.StorageBlocksSetting;
import kaze.module.setting.StorageBlocksSetting.Entry;
import kaze.utils.BlockUtil;
import kaze.utils.EncryptedString;
import kaze.utils.RenderUtils;
import kaze.utils.RenderVisibility;
import kaze.utils.RenderUtils.ColoredBox;
import kaze.utils.RenderUtils.ColoredLine;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.registry.DefaultedRegistry;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry.Reference;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.PalettedContainer;
import net.minecraft.world.chunk.WorldChunk;

public final class BlockEspModule extends Module {
   private static final int MAX_RENDERED_BLOCKS = 4096;
   private final NumberSetting alpha;
   private final BooleanSetting tracers;
   private final StorageBlocksSetting blocks;
   private final Map<Long, List<BlockEspModule.BlockEntry>> results;
   private final Queue<Long> scanQueue;
   private final Set<Long> queued;
   private final Set<Long> scanned;
   private final Map<Block, Entry> selected;
   private final List<ColoredBox> renderBoxes;
   private final List<ColoredLine> renderLines;
   private Object trackedWorld;
   private int selectionSignature;
   private int ticks;

   public BlockEspModule() {
      super(EncryptedString.of("Block ESP"),
            EncryptedString.of("Searches and highlights any selected Minecraft block"),
            -1, Category.RENDER);
      alpha = new NumberSetting(EncryptedString.of("Alpha"), 0.0, 255.0, 53.0, 1.0);
      tracers = new BooleanSetting(EncryptedString.of("Tracers"), false);
      blocks = createBlockPalette();
      results = new HashMap<>();
      scanQueue = new ArrayDeque<>();
      queued = new HashSet<>();
      scanned = new HashSet<>();
      selected = new HashMap<>();
      renderBoxes = new ArrayList<>();
      renderLines = new ArrayList<>();
      addSettings(new Setting[]{alpha, tracers, blocks});
   }

   private static StorageBlocksSetting createBlockPalette() {
      StorageBlocksSetting palette = new StorageBlocksSetting(EncryptedString.of("Blocks"));
      for (Block block : Registries.BLOCK) {
         if (block == Blocks.AIR || block == Blocks.CAVE_AIR || block == Blocks.VOID_AIR) {
            continue;
         }
         Identifier id = Registries.BLOCK.getId(block);
         Color color = Color.getHSBColor((id.toString().hashCode() & 65535) / 65535.0F, 0.58F, 1.0F);
         palette.add(id.toString(), block.getName().getString(), block.asItem(), false, color);
      }
      return palette;
   }

   public void onEnable() {
      reset();
      trackedWorld = mc.world;
      refreshSelection();
      enqueueLoadedChunks();
      super.onEnable();
   }

   public void onDisable() {
      reset();
      super.onDisable();
   }

   private void reset() {
      results.clear();
      scanQueue.clear();
      queued.clear();
      scanned.clear();
      selected.clear();
      renderBoxes.clear();
      renderLines.clear();
      trackedWorld = null;
      selectionSignature = 0;
      ticks = 0;
   }

   @EventListener
   public void onChunkData(ChunkDataEvent event) {
      enqueue(event.packet.getChunkX(), event.packet.getChunkZ());
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (mc.world == null || mc.player == null) {
         reset();
         return;
      }
      if (trackedWorld != mc.world) {
         reset();
         trackedWorld = mc.world;
      }
      if (computeSelectionSignature() != selectionSignature) {
         results.clear();
         scanQueue.clear();
         queued.clear();
         scanned.clear();
         refreshSelection();
         enqueueLoadedChunks();
      }
      if (selected.isEmpty()) {
         return;
      }
      ticks++;
      if (ticks % 100 == 1) {
         enqueueLoadedChunks();
      }
      if (ticks % 400 == 0) {
         scanned.clear();
      }
      scanNextChunk();
      if (ticks % 20 == 0) {
         pruneUnloaded();
      }
   }

   private int computeSelectionSignature() {
      int signature = 1;
      for (Entry entry : blocks.entries()) {
         if (entry.enabled()) {
            signature = signature * 31 + entry.id().hashCode();
         }
      }
      return signature;
   }

   private void refreshSelection() {
      selected.clear();
      for (Entry entry : blocks.entries()) {
         if (entry.enabled()) {
            Registries.BLOCK.getEntry(Identifier.of(entry.id()))
                  .ifPresent(block -> selected.put(block.value(), entry));
         }
      }
      selectionSignature = computeSelectionSignature();
   }

   private void enqueueLoadedChunks() {
      if (mc.world == null || mc.player == null || selected.isEmpty()) {
         return;
      }
      ChunkPos playerChunk = mc.player.getChunkPos();
      List<WorldChunk> chunks = BlockUtil.getLoadedChunksList();
      chunks.sort(Comparator.comparingInt(chunk -> {
         ChunkPos pos = chunk.getPos();
         return Math.max(Math.abs(pos.x - playerChunk.x), Math.abs(pos.z - playerChunk.z));
      }));
      for (WorldChunk chunk : chunks) {
         enqueue(chunk.getPos().x, chunk.getPos().z);
      }
   }

   private void enqueue(int chunkX, int chunkZ) {
      long key = ChunkPos.toLong(chunkX, chunkZ);
      if (!selected.isEmpty() && !scanned.contains(key) && queued.add(key)) {
         scanQueue.offer(key);
      }
   }

   private void scanNextChunk() {
      Long key = scanQueue.poll();
      if (key == null) {
         return;
      }
      queued.remove(key);
      scanned.add(key);
      int chunkX = ChunkPos.getPackedX(key);
      int chunkZ = ChunkPos.getPackedZ(key);
      if (!mc.world.isChunkLoaded(chunkX, chunkZ)) {
         results.remove(key);
         return;
      }

      WorldChunk chunk = mc.world.getChunk(chunkX, chunkZ);
      ChunkSection[] sections = chunk.getSectionArray();
      int bottomSection = chunk.getBottomSectionCoord();
      int startX = chunk.getPos().getStartX();
      int startZ = chunk.getPos().getStartZ();
      List<BlockEntry> found = new ArrayList<>();
      for (int sectionIndex = 0; sectionIndex < sections.length && found.size() < MAX_RENDERED_BLOCKS; sectionIndex++) {
         ChunkSection section = sections[sectionIndex];
         if (section == null || !section.getBlockStateContainer().hasAny(state -> selected.containsKey(state.getBlock()))) {
            continue;
         }
         int startY = (bottomSection + sectionIndex) << 4;
         for (int y = 0; y < 16 && found.size() < MAX_RENDERED_BLOCKS; y++) {
            for (int z = 0; z < 16 && found.size() < MAX_RENDERED_BLOCKS; z++) {
               for (int x = 0; x < 16 && found.size() < MAX_RENDERED_BLOCKS; x++) {
                  Block block = section.getBlockState(x, y, z).getBlock();
                  if (selected.containsKey(block)) {
                     found.add(new BlockEntry(new BlockPos(startX + x, startY + y, startZ + z), block));
                  }
               }
            }
         }
      }
      if (found.isEmpty()) {
         results.remove(key);
      } else {
         results.put(key, List.copyOf(found));
      }
   }

   private void pruneUnloaded() {
      results.keySet().removeIf(key ->
            !mc.world.isChunkLoaded(ChunkPos.getPackedX(key), ChunkPos.getPackedZ(key)));
   }

   @EventListener
   public void onRender3D(Render3DEvent event) {
      if (mc.world == null || results.isEmpty()) {
         return;
      }
      Camera camera = RenderUtils.getCamera();
      if (camera == null || !camera.isReady()) {
         return;
      }
      renderBoxes.clear();
      renderLines.clear();
      Vec3d tracerStart = RenderUtils.getTracerStart(camera);
      int opacity = alpha.getIntValue();
      int rendered = 0;
      boolean drawTracers = tracers.getValue();
      outer:
      for (List<BlockEntry> chunkEntries : results.values()) {
         for (BlockEntry blockEntry : chunkEntries) {
            BlockPos pos = blockEntry.pos();
            if (!drawTracers && !RenderVisibility.box(pos.getX(), pos.getY(), pos.getZ(),
                  pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1)) {
               continue;
            }
            Entry entry = selected.get(blockEntry.block());
            if (entry == null) {
               continue;
            }
            Color rgb = entry.color();
            Color color = new Color(rgb.getRed(), rgb.getGreen(), rgb.getBlue(), opacity);
            renderBoxes.add(new ColoredBox(pos.getX() + 0.08, pos.getY() + 0.08, pos.getZ() + 0.08,
                  pos.getX() + 0.92, pos.getY() + 0.92, pos.getZ() + 0.92, color));
            if (drawTracers) {
               renderLines.add(new ColoredLine(tracerStart,
                     new Vec3d(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5), color, 1.5F));
            }
            if (++rendered >= MAX_RENDERED_BLOCKS) {
               break outer;
            }
         }
      }
      MatrixStack matrices = event.matrixStack;
      matrices.push();
      RenderUtils.applyCameraTransform(matrices, camera);
      RenderUtils.renderFilledBoxes(matrices, renderBoxes);
      RenderUtils.renderLines(matrices, renderLines);
      matrices.pop();
   }

   private record BlockEntry(BlockPos pos, Block block) {
   }
}
