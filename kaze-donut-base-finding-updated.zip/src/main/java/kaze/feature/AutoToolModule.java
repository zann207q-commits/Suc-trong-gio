package kaze.feature;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;
import kaze.event.EventListener;
import kaze.event.events.AttackBlockEvent;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.Setting;
import kaze.utils.EncryptedString;
import kaze.utils.InventoryUtil;
import net.minecraft.block.BambooBlock;
import net.minecraft.block.BambooShootBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShearsItem;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntry.Reference;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.math.BlockPos;

public final class AutoToolModule extends Module {
   private static final int MANUAL_GRACE_MS = 450;
   private static final int MAX_SWITCHES = 10;
   private static final int SWITCH_WINDOW_MS = 4000;
   private final BooleanSetting legit;
   private final BooleanSetting antiBreak;
   private final NumberSetting antiBreakPercentage;
   private final Deque<Long> switchTimes;
   private int pendingSlot;
   private BlockPos pendingBlock;
   private long switchAt;
   private long nextSwitchAllowedAt;
   private long lastManualChangeAt;
   private int lastObservedSlot;
   private int lastAutomaticSlot;

   public AutoToolModule() {
      super(EncryptedString.of("Auto Tool"), EncryptedString.of("Automatically switches to the best tool"), -1, Category.MISC);
      legit = new BooleanSetting(EncryptedString.of("Legit"), false)
            .setDescription(EncryptedString.of("Adds human-like delay, hold time, variation and switch limits"));
      antiBreak = new BooleanSetting(EncryptedString.of("Anti Break"), true);
      antiBreakPercentage = new NumberSetting(EncryptedString.of("Anti Break Percentage"), 1.0, 100.0, 5.0, 1.0);
      switchTimes = new ArrayDeque<>();
      pendingSlot = -1;
      lastObservedSlot = -1;
      lastAutomaticSlot = -1;
      addSettings(new Setting[]{legit, antiBreak, antiBreakPercentage});
   }

   public void onEnable() {
      this.resetState();
      if (this.mc.player != null) {
         this.lastObservedSlot = this.mc.player.getInventory().getSelectedSlot();
      }

      super.onEnable();
   }

   public void onDisable() {
      this.resetState();
      super.onDisable();
   }

   private void resetState() {
      this.pendingSlot = -1;
      this.pendingBlock = null;
      this.switchAt = 0L;
      this.nextSwitchAllowedAt = 0L;
      this.lastManualChangeAt = 0L;
      this.lastObservedSlot = -1;
      this.lastAutomaticSlot = -1;
      this.switchTimes.clear();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.player != null && this.mc.world != null) {
         long var2 = System.currentTimeMillis();
         int var4 = this.mc.player.getInventory().getSelectedSlot();
         if (this.lastObservedSlot == (-1)) {
            this.lastObservedSlot = var4;
         }

         if (var4 != this.lastObservedSlot) {
            if (var4 != this.lastAutomaticSlot) {
               this.lastManualChangeAt = var2;
               this.pendingSlot = -1;
               this.pendingBlock = null;
            }

            this.lastObservedSlot = var4;
            this.lastAutomaticSlot = -1;
         }

         while (!this.switchTimes.isEmpty() && var2 - this.switchTimes.peekFirst() > (4000L)) {
            this.switchTimes.removeFirst();
         }

         if (this.legit.getValue() && this.pendingSlot >= 0) {
            if (this.mc.currentScreen == null && this.mc.options.attackKey.isPressed() && this.pendingBlock != null) {
               if (var2 >= this.switchAt
                  && var2 >= this.nextSwitchAllowedAt
                  && var2 - this.lastManualChangeAt >= (450L)) {
                  if (this.switchTimes.size() < (10)
                     && !this.mc.world.getBlockState(this.pendingBlock).isAir()) {
                     this.performSwitch(this.pendingSlot, var2);
                     this.pendingSlot = -1;
                     this.pendingBlock = null;
                  } else {
                     this.pendingSlot = -1;
                     this.pendingBlock = null;
                  }
               }
            } else {
               this.pendingSlot = -1;
               this.pendingBlock = null;
            }
         }
      } else {
         this.pendingSlot = -1;
         this.pendingBlock = null;
      }
   }

   @EventListener
   public void handleAttackBlockEvent(AttackBlockEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         BlockState var2 = this.mc.world.getBlockState(var1.pos);
         ItemStack var3 = this.mc.player.getMainHandStack();
         if (this.isToolBreakingSoon(var3) && isToolItemStack(var3)) {
            this.mc.options.attackKey.setPressed(false);
            this.pendingSlot = -1;
            this.pendingBlock = null;
            var1.cancel();
         } else {
            AutoToolModule.SlotScore var4 = this.findBestChoice(var2, this.legit.getValue());
            if (var4.slot() >= 0) {
               double var5 = calculateToolEfficiency(
                  var3, var2, var1x -> ((!this.isToolBreakingSoon(var1x)))
               );
               if (var4.slot() != this.mc.player.getInventory().getSelectedSlot() && this.isWorthSwitching(var5, var4.score())) {
                  if (!this.legit.getValue()) {
                     this.performSwitch(var4.slot(), System.currentTimeMillis());
                  } else {
                     long var7 = System.currentTimeMillis();
                     if (var7 - this.lastManualChangeAt >= (450L) && var7 >= this.nextSwitchAllowedAt) {
                        if (!(ThreadLocalRandom.current().nextDouble() < 0.03)) {
                           this.pendingSlot = var4.slot();
                           this.pendingBlock = var1.pos.toImmutable();
                           int var9 = ThreadLocalRandom.current().nextInt(30, 76);
                           int var10 = ThreadLocalRandom.current().nextInt(55, 126);
                           this.switchAt = var7 + (long)var9 + (long)var10;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private AutoToolModule.SlotScore findBestChoice(BlockState var1, boolean var2) {
      int[] var10000 = new int[9];
      var10000[0] = 0;
      var10000[1] = 1;
      var10000[2] = 2;
      var10000[3] = 3;
      var10000[4] = 4;
      var10000[5] = 5;
      var10000[6] = 6;
      var10000[7] = 7;
      var10000[8] = 8;
      int[] var3 = var10000;
      if (var2) {
         ThreadLocalRandom var4 = ThreadLocalRandom.current();

         for (int var5 = var3.length - (1); var5 > 0; var5--) {
            int var6 = var4.nextInt(var5 + (1));
            int var7 = var3[var5];
            var3[var5] = var3[var6];
            var3[var6] = var7;
         }
      }

      int var16 = -1;
      int var17 = -1;
      double var18 = -1.0;
      double var8 = -1.0;
      int[] var10 = var3;
      int var11 = var3.length;

      for (int var12 = 0; var12 < var11; var12++) {
         int var13 = var10[var12];
         double var14 = calculateToolEfficiency(
            this.mc.player.getInventory().getStack(var13),
            var1,
            var1x -> ((!this.isToolBreakingSoon(var1x)))
         );
         if (var14 > var18) {
            var17 = var16;
            var8 = var18;
            var16 = var13;
            var18 = var14;
         } else if (var14 > var8) {
            var17 = var13;
            var8 = var14;
         }
      }

      return var2
            && var17 >= 0
            && var18 > 0.0
            && var8 / var18 >= 0.92
            && ThreadLocalRandom.current().nextDouble() < 0.12
         ? new AutoToolModule.SlotScore(var17, var8)
         : new AutoToolModule.SlotScore(var16, var18);
   }

   private boolean isWorthSwitching(double var1, double var3) {
      if (var3 < 0.0) {
         return false;
      } else if (var1 < 0.0) {
         return true;
      } else if (!this.legit.getValue()) {
         return ((var3 > var1));
      } else if (var3 <= 0.0) {
         return false;
      } else if (var1 / var3 >= 0.96) {
         return false;
      } else {
         return ((var3 >= var1 * 1.08));
      }
   }

   private void performSwitch(int var1, long var2) {
      if (var1 >= 0 && var1 <= (8) && this.mc.player != null) {
         InventoryUtil.swap(var1);
         this.lastAutomaticSlot = var1;
         this.lastObservedSlot = var1;
         this.switchTimes.addLast(var2);
         this.nextSwitchAllowedAt = var2 + (long)ThreadLocalRandom.current().nextInt(95, 221);
      }
   }

   public static double calculateToolEfficiency(ItemStack var0, BlockState var1, Predicate<ItemStack> var2) {
      if (var2.test(var0) && isToolItemStack(var0)) {
         int var3 = !var0.getRegistryEntry().isIn(ItemTags.SWORDS)
               || !(var1.getBlock() instanceof BambooBlock) && !(var1.getBlock() instanceof BambooShootBlock)
            ? 0
            : 1;
         int var4 = var0.getItem() instanceof ShearsItem && var1.getBlock() instanceof LeavesBlock ? 1 : 0;
         int var5 = !var0.isSuitableFor(var1) && var3 == 0 && var4 == 0 && !var1.isIn(BlockTags.WOOL)
            ? 0
            : 1;
         return var5 != 0
            ? (double)(var0.getMiningSpeedMultiplier(var1) * 1000.0F)
            : -1.0;
      } else {
         return -1.0;
      }
   }

   public static boolean isToolItemStack(ItemStack var0) {
      return isToolItem(var0.getItem());
   }

   public static boolean isToolItem(Item var0) {
      return ((!(!var0.getRegistryEntry().isIn(ItemTags.AXES)
            && !var0.getRegistryEntry().isIn(ItemTags.HOES)
            && !var0.getRegistryEntry().isIn(ItemTags.PICKAXES)
            && !var0.getRegistryEntry().isIn(ItemTags.SHOVELS)
            && !(var0 instanceof ShearsItem))));
   }

   private boolean isToolBreakingSoon(ItemStack var1) {
      return ((this.antiBreak.getValue()
            && var1.isDamageable()
            && var1.getMaxDamage() - var1.getDamage() < var1.getMaxDamage() * this.antiBreakPercentage.getIntValue() / (100)));
   }

   private record SlotScore(int slot, double score) {
   }
}
