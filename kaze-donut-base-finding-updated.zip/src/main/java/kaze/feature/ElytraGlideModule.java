package kaze.feature;

import kaze.event.EventListener;
import kaze.event.events.PreItemUseEvent;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.utils.EncryptedString;
import kaze.utils.InventoryUtil;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;

public final class ElytraGlideModule extends Module {
   private boolean isFlyingTriggered;
   private boolean isFireworkUsed;
   private boolean isJumpKeyPressed;

   public ElytraGlideModule() {
      super(
         EncryptedString.of("Elytra Glide"),
         EncryptedString.of("Starts flying when attempting to use a firework"),
         -1,
         Category.MISC
      );
   }

   @Override
   public void onEnable() {
      super.onEnable();
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.currentScreen != null) {
         return;
      }
      if (this.isJumpKeyPressed) {
         this.isJumpKeyPressed = false;
         KeyBinding.setKeyPressed(this.mc.options.jumpKey.getDefaultKey(), false);
         return;
      }
      if (!this.isFlyingTriggered) {
         return;
      }
      if (!this.isFireworkUsed) {
         KeyBinding.setKeyPressed(this.mc.options.jumpKey.getDefaultKey(), true);
         this.isJumpKeyPressed = true;
         if (!this.mc.player.isOnGround()) {
            this.isFireworkUsed = true;
         }
         return;
      }

      int selectedSlot = this.mc.player.getInventory().getSelectedSlot();
      if (!this.mc.player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)
         && !InventoryUtil.swap(Items.FIREWORK_ROCKET)) {
         return;
      }
      this.mc.interactionManager.interactItem(this.mc.player, this.mc.player.getActiveHand());
      this.mc.player.getInventory().setSelectedSlot(selectedSlot);
      this.isFireworkUsed = false;
      this.isFlyingTriggered = false;
   }

   @EventListener
   public void onPreItemUse(PreItemUseEvent event) {
      if (this.mc.player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)
         && this.mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)
         && this.mc.player.isGliding()) {
         this.isFlyingTriggered = true;
      }
   }
}
