package kaze.feature;

import java.util.List;
import kaze.event.EventListener;
import kaze.event.events.MouseButtonEvent;
import kaze.event.events.Render2DEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.Setting;
import kaze.module.setting.StringSetting;
import kaze.utils.EncryptedString;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.util.Window;
import net.minecraft.world.World;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;

public final class HudModule extends Module {
   public static final BooleanSetting HIDE_POTION_HUD = new BooleanSetting(EncryptedString.of("Hide Potion HUD"), true)
      .setDescription(EncryptedString.of("Hides the full vanilla status-effect overlay"));
   private final BooleanSetting showWatermark = new BooleanSetting(EncryptedString.of("Watermark"), true)
      .setDescription(EncryptedString.of("Kaze logo in the corner"));
   private final BooleanSetting showTime = new BooleanSetting(EncryptedString.of("Time"), true).setDescription(EncryptedString.of("Clock next to the logo"));
   private final BooleanSetting showInfo = new BooleanSetting(EncryptedString.of("Info"), true).setDescription(EncryptedString.of("FPS, ping and server"));
   private final BooleanSetting showPlayer = new BooleanSetting(EncryptedString.of("Player"), false)
      .setDescription(EncryptedString.of("Your head, name and health"));
   private final BooleanSetting showCoordinates = new BooleanSetting(EncryptedString.of("Show Coordinates"), true)
      .setDescription(EncryptedString.of("Position with a mini compass"));
   private final BooleanSetting showDirection = new BooleanSetting(EncryptedString.of("Direction"), true)
      .setDescription(EncryptedString.of("Facing direction next to the coordinates"));
   private final BooleanSetting showNether = new BooleanSetting(EncryptedString.of("Nether Coords"), false)
      .setDescription(EncryptedString.of("Matching overworld / nether position"));
   private final BooleanSetting showModules = new BooleanSetting(EncryptedString.of("Modules"), true)
      .setDescription(EncryptedString.of("Enabled modules, longest name first"));
   private final BooleanSetting rainbow = new BooleanSetting(EncryptedString.of("Rainbow HUD"), false)
      .setDescription(EncryptedString.of("Soft flowing rainbow on the module list and accents"));
   private final NumberSetting rainbowSpeed = new NumberSetting(EncryptedString.of("Rainbow Speed"), 0.1, 5.0, 1.0, 0.1)
      .getValue(EncryptedString.of("How fast the rainbow flows"));
   private final NumberSetting hudScale = new NumberSetting(EncryptedString.of("HUD Scale"), 60.0, 160.0, 100.0, 5.0)
      .getValue(EncryptedString.of("Size of the HUD in percent"));
   private final NumberSetting opacity = new NumberSetting(EncryptedString.of("Opacity"), 0.0, 1.0, 0.62, 0.05)
      .getValue(EncryptedString.of("Strength of the glass behind HUD elements"));
   private final StringSetting customIp = new StringSetting(EncryptedString.of("Custom IP"), "")
      .setDescription(EncryptedString.of("Server name shown in the HUD; blank uses the connected server"));
   private final BooleanSetting spoofPing = new BooleanSetting(EncryptedString.of("Ping Spoof"), false)
      .setDescription(EncryptedString.of("Display a custom ping value in this HUD only"));
   private final NumberSetting spoofedPing = new NumberSetting(EncryptedString.of("Spoofed Ping"), 0.0, 9999.0, 50.0, 1.0)
      .getValue(EncryptedString.of("Ping value shown in the HUD while Ping Spoof is enabled"));
   private final HudLayoutEditor hud = new HudLayoutEditor();
   private final HudLayoutEditor.adhvjlahyjurfh options = new HudLayoutEditor.adhvjlahyjurfh();
   private final HudModule.HudDataSourceAdapter data = new HudModule.HudDataSourceAdapter();
   private float shown;
   private long last;

   public HudModule() {
      super(EncryptedString.of("HUD"), EncryptedString.of("Clean glass HUD; open chat to drag elements"), -1, Category.CLIENT);
      this.addSettings(
         new Setting[]{
            this.showWatermark,
            this.showTime,
            this.showInfo,
            this.showPlayer,
            this.showCoordinates,
            this.showDirection,
            this.showNether,
            this.showModules,
            this.rainbow,
            this.rainbowSpeed,
            this.hudScale,
            this.opacity,
            HIDE_POTION_HUD,
            this.customIp,
            this.spoofPing,
            this.spoofedPing
         }
      );

      try {
         this.hud.setFile(FabricLoader.getInstance().getConfigDir().resolve("kaze-hud-layout.txt"));
      } catch (Throwable var2) {
      }
   }

   @EventListener
   public void onRender2D(Render2DEvent var1) {
      if (!this.mc.options.hudHidden && this.mc.getWindow() != null) {
         long var2 = System.nanoTime();
         float var4 = this.last == 0L ? 0.016F : Math.min(0.1F, (float)(var2 - this.last) / 1.0E9F);
         this.last = var2;
         boolean var5 = this.mc.currentScreen instanceof kaze.feature.KazeClickGuiScreen;
         float var6 = var5 ? 0.0F : 1.0F;
         this.shown = this.shown + (var6 - this.shown) * (1.0F - (float)Math.exp((double)(-(var5 ? 14.0F : 7.0F) * var4)));
         if (!(this.shown < 0.01F)) {
            this.options.watermark = this.showWatermark.getValue();
            this.options.time = this.showTime.getValue();
            this.options.info = this.showInfo.getValue();
            this.options.player = this.showPlayer.getValue();
            this.options.coords = this.showCoordinates.getValue();
            this.options.direction = this.showDirection.getValue();
            this.options.netherCoords = this.showNether.getValue();
            this.options.modules = this.showModules.getValue();
            this.options.scale = (float)(this.hudScale.getValue() / 100.0);
            this.options.opacity = (float)this.opacity.getValue();
            this.options.rainbow = this.rainbow.getValue();
            this.options.rainbowSpeed = (float)this.rainbowSpeed.getValue();
            Window var7 = this.mc.getWindow();
            int var8 = var7.getFramebufferWidth();
            int var9 = var7.getFramebufferHeight();
            float var10 = (float)var7.getScaleFactor();
            double var11 = this.mc.mouse.getX() * (double)var8 / (double)Math.max(1, var7.getWidth());
            double var13 = this.mc.mouse.getY() * (double)var9 / (double)Math.max(1, var7.getHeight());
            boolean var15 = this.mc.currentScreen instanceof ChatScreen;
            var1.context.getMatrices().pushMatrix();
            var1.context.getMatrices().scale(1.0F / var10, 1.0F / var10);

            try {
               this.hud.render(new MinecraftUiRenderer(var1.context, var10), var8, var9, this.data, this.options, this.shown, var15, var11, var13);
            } finally {
               var1.context.getMatrices().popMatrix();
            }
         }
      }
   }

   @EventListener
   public void onMouseButton(MouseButtonEvent var1) {
      if (var1.button == 0) {
         if (var1.actions == 1 && this.mc.currentScreen instanceof ChatScreen) {
            Window var2 = this.mc.getWindow();
            double var3 = this.mc.mouse.getX() * (double)var2.getFramebufferWidth() / (double)Math.max(1, var2.getWidth());
            double var5 = this.mc.mouse.getY() * (double)var2.getFramebufferHeight() / (double)Math.max(1, var2.getHeight());
            this.hud.mousePressed(var3, var5);
         } else if (var1.actions == 0) {
            this.hud.mouseReleased();
         }
      }
   }

   private final class HudDataSourceAdapter implements HudLayoutEditor.HudDataSource {
      @Override
      public int fps() {
         return HudModule.this.mc.getCurrentFps();
      }

      @Override
      public String ping() {
         if (HudModule.this.spoofPing.getValue()) {
            return String.valueOf(HudModule.this.spoofedPing.getIntValue());
         } else if (HudModule.this.mc.player != null && HudModule.this.mc.getNetworkHandler() != null) {
            PlayerListEntry var1 = HudModule.this.mc.getNetworkHandler().getPlayerListEntry(HudModule.this.mc.player.getUuid());
            return var1 == null ? "0" : String.valueOf(var1.getLatency());
         } else {
            return "0";
         }
      }

      @Override
      public String server() {
         String var1 = HudModule.this.customIp.getValue();
         if (var1 != null && !var1.isBlank()) {
            return var1.trim();
         } else if (HudModule.this.mc.getCurrentServerEntry() != null) {
            return HudModule.this.mc.getCurrentServerEntry().address;
         } else {
            return HudModule.this.mc.isInSingleplayer() ? "Singleplayer" : "";
         }
      }

      @Override
      public boolean inWorld() {
         return HudModule.this.mc.player != null && HudModule.this.mc.world != null;
      }

      @Override
      public double x() {
         return HudModule.this.mc.player.getX();
      }

      @Override
      public double y() {
         return HudModule.this.mc.player.getY();
      }

      @Override
      public double z() {
         return HudModule.this.mc.player.getZ();
      }

      @Override
      public float yaw() {
         return HudModule.this.mc.player.getYaw();
      }

      @Override
      public boolean nether() {
         return HudModule.this.mc.world != null && HudModule.this.mc.world.getRegistryKey() == World.NETHER;
      }

      @Override
      public String playerName() {
         return NameProtectModule.displayName(HudModule.this.mc.player == null ? "" : HudModule.this.mc.player.getName().getString());
      }

      @Override
      public float health() {
         return HudModule.this.mc.player == null ? 0.0F : HudModule.this.mc.player.getHealth();
      }

      @Override
      public List<String> modules() {
         return ModuleCatalog.enabled(HudModule.this);
      }
   }
}
