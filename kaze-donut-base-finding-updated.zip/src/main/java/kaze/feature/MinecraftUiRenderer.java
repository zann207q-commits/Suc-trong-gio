package kaze.feature;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.gui.render.state.GuiRenderState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.entity.player.SkinTextures;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix3x2fc;

public final class MinecraftUiRenderer extends UiRenderer {
   private static final Map<Item, ItemStack> STACKS = new HashMap<>();
   private static Supplier<SkinTextures> profileSkin;
   private final DrawContext ctx;
   private final float guiScale;
   private int pushed;
   private static final Field STATE = stateField();
   private static final Field SCISSORS = scissorField();
   private static final Method PEEK = scissorPeek();
   private final GuiRenderState state;
   private final Deque<ScreenRect> clips = new ArrayDeque<>();
   private final ScreenRect inheritedClip;
   private MinecraftUiRenderer.lIIllI batch;
   private UiTextureData batchTexture;
   private ScreenRect clip;

   private static Field stateField() {
      for (Field var3 : DrawContext.class.getDeclaredFields()) {
         if (var3.getType() == GuiRenderState.class) {
            var3.setAccessible(true);
            return var3;
         }
      }

      throw new IllegalStateException("Missing GUI render state");
   }

   private static Field scissorField() {
      for (Field var3 : DrawContext.class.getDeclaredFields()) {
         if (var3.getType().getEnclosingClass() == DrawContext.class) {
            for (Method var7 : var3.getType().getDeclaredMethods()) {
               if (var7.getParameterCount() == 0 && var7.getReturnType() == ScreenRect.class) {
                  var3.setAccessible(true);
                  return var3;
               }
            }
         }
      }

      throw new IllegalStateException("Missing GUI clipping state");
   }

   private static Method scissorPeek() {
      for (Method var3 : SCISSORS.getType().getDeclaredMethods()) {
         if (var3.getParameterCount() == 0
            && var3.getReturnType() == ScreenRect.class
            && (var3.getName().equals("peekLast") || var3.getName().equals("method_70863"))) {
            var3.setAccessible(true);
            return var3;
         }
      }

      throw new IllegalStateException("Missing GUI clip accessor");
   }

   public MinecraftUiRenderer(DrawContext var1, float var2) {
      this.ctx = var1;
      this.guiScale = var2 <= 0.0F ? 1.0F : var2;

      try {
         this.state = (GuiRenderState)STATE.get(var1);
         this.inheritedClip = (ScreenRect)PEEK.invoke(SCISSORS.get(var1));
         this.clip = this.inheritedClip;
      } catch (ReflectiveOperationException var4) {
         throw new IllegalStateException("Cannot access GUI drawing state", var4);
      }
   }

   @Override
   protected void fillRaw(int var1, int var2, int var3, int var4, int var5) {
      if (var3 > var1 && var4 > var2) {
         this.quad(null, var1, var2, var3, var4, 0.0F, 0.0F, 0.0F, 0.0F, var5, var5);
      }
   }

   @Override
   protected void gradientRaw(int var1, int var2, int var3, int var4, int var5, int var6) {
      if (var3 > var1 && var4 > var2) {
         this.quad(null, var1, var2, var3, var4, 0.0F, 0.0F, 0.0F, 0.0F, var5, var6);
      }
   }

   @Override
   protected void blitRaw(UiTextureData var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10) {
      if (var4 > 0 && var5 > 0) {
         Identifier var11 = upload(var1);
         if (var11 != null) {
            this.quad(
               var1,
               var2,
               var3,
               var2 + var4,
               var3 + var5,
               (float)var6 / (float)var1.w,
               (float)var7 / (float)var1.h,
               (float)(var6 + var8) / (float)var1.w,
               (float)(var7 + var9) / (float)var1.h,
               var10,
               var10
            );
         }
      }
   }

   private void quad(UiTextureData var1, int var2, int var3, int var4, int var5, float var6, float var7, float var8, float var9, int var10, int var11) {
      Matrix3x2fStack var12 = this.ctx.getMatrices();
      if (this.batch != null && this.batchTexture == var1) {
         this.batch.append(var12, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
      } else {
         TextureSetup var13 = TextureSetup.empty();
         if (var1 != null) {
            Identifier var14 = (Identifier)var1.handle;
            AbstractTexture var15 = MinecraftClient.getInstance().getTextureManager().getTexture(var14);
            var13 = TextureSetup.of(var15.getGlTextureView(), var15.getSampler());
         }

         MinecraftUiRenderer.lIIllI var16 = new MinecraftUiRenderer.lIIllI(var1 == null ? RenderPipelines.GUI : RenderPipelines.GUI_TEXTURED, var13, this.clip);
         if (!var16.append(var12, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11)) {
            return;
         }

         this.state.createNewRootLayer();
         this.state.addSimpleElement(var16);
         this.batch = var16;
         this.batchTexture = var1;
      }
   }

   private void barrier() {
      this.batch = null;
      this.batchTexture = null;
   }

   @Override
   public void pushTransform(float var1, float var2, float var3) {
      Matrix3x2fStack var4 = this.ctx.getMatrices();
      var4.pushMatrix();
      var4.translate(var1, var2);
      var4.scale(var3, var3);
      this.pushed++;
   }

   @Override
   public void popTransform() {
      if (this.pushed > 0) {
         this.pushed--;
         this.ctx.getMatrices().popMatrix();
      }
   }

   @Override
   public float scale() {
      Matrix3x2fStack var1 = this.ctx.getMatrices();
      float var2 = (float)Math.sqrt((double)(var1.m00() * var1.m00() + var1.m01() * var1.m01()));
      return var2 * this.guiScale;
   }

   @Override
   public void pushClip(float var1, float var2, float var3, float var4) {
      this.ctx.enableScissor(Math.round(var1), Math.round(var2), Math.round(var1 + var3), Math.round(var2 + var4));
      ScreenRect var5 = new ScreenRect(
            Math.round(var1), Math.round(var2), Math.round(var1 + var3) - Math.round(var1), Math.round(var2 + var4) - Math.round(var2)
         )
         .transform(this.ctx.getMatrices());
      ScreenRect var6 = this.clips.isEmpty() ? this.inheritedClip : this.clips.peek();
      if (var6 != null) {
         var5 = var6.intersection(var5);
      }

      if (var5 == null) {
         var5 = ScreenRect.empty();
      }

      this.clips.push(var5);
      this.clip = var5;
      this.barrier();
   }

   @Override
   public void popClip() {
      this.ctx.disableScissor();
      if (!this.clips.isEmpty()) {
         this.clips.pop();
      }

      this.clip = this.clips.isEmpty() ? this.inheritedClip : this.clips.peek();
      this.barrier();
   }

   @Override
   public void head(float var1, float var2, float var3) {
      this.barrier();
      this.state.createNewRootLayer();

      try {
         MinecraftClient var4 = MinecraftClient.getInstance();
         SkinTextures var5;
         if (var4.player != null) {
            var5 = var4.player.getSkin();
         } else {
            if (profileSkin == null) {
               profileSkin = var4.getSkinProvider().supplySkinTextures(var4.getGameProfile(), false);
            }

            var5 = profileSkin.get();
         }

         if (var5 != null) {
            this.ctx.getMatrices().pushMatrix();
            this.ctx.getMatrices().translate((float)Math.round(var1), (float)Math.round(var2));
            PlayerSkinDrawer.draw(this.ctx, var5, 0, 0, Math.round(var3));
            this.ctx.getMatrices().popMatrix();
         }
      } catch (Throwable var6) {
      }
   }

   @Override
   public void item(Object var1, float var2, float var3, float var4) {
      this.barrier();
      this.state.createNewRootLayer();
      if (var1 instanceof Item var5) {
         ItemStack var6 = STACKS.computeIfAbsent(var5, ItemStack::new);
         Matrix3x2fStack var7 = this.ctx.getMatrices();
         var7.pushMatrix();
         var7.translate(var2, var3);
         var7.scale(var4 / 16.0F, var4 / 16.0F);
         this.ctx.drawItem(var6, 0, 0);
         var7.popMatrix();
      }
   }

   static Identifier upload(UiTextureData var0) {
      if (var0.handle instanceof Identifier var2) {
         return var2;
      } else if (var0.handle != null) {
         return null;
      } else {
         try {
            NativeImage image = new NativeImage(var0.w, var0.h, false);

            for (int var3 = 0; var3 < var0.h; var3++) {
               for (int var4 = 0; var4 < var0.w; var4++) {
                  image.setColorArgb(var4, var3, var0.argb[var3 * var0.w + var4]);
               }
            }

            String var7 = "kui/" + var0.key.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9/._-]", "_");
            Identifier var8 = Identifier.of("kaze", var7);
            MinecraftClient.getInstance().getTextureManager().registerTexture(var8, new MinecraftUiRenderer.UiTexture(var0.key, image));
            var0.handle = var8;
            return var8;
         } catch (Throwable var5) {
            System.err.println("Kaze: texture upload failed for " + var0.key + ": " + var5);
            var0.handle = Boolean.FALSE;
            return null;
         }
      }
   }

   private static final class UiTexture extends NativeImageBackedTexture {
      private UiTexture(String var1, NativeImage var2) {
         super(() -> "Kaze " + var1, var2);
         this.sampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
      }
   }

   static final class lIIllI implements SimpleGuiElementRenderState {
      private final RenderPipeline pipeline;
      private final TextureSetup texture;
      private final ScreenRect clip;
      private float[] xyuv = new float[256];
      private int[] colors = new int[64];
      private int vertices;
      private int left = Integer.MAX_VALUE;
      private int top = Integer.MAX_VALUE;
      private int right = Integer.MIN_VALUE;
      private int bottom = Integer.MIN_VALUE;

      lIIllI(RenderPipeline var1, TextureSetup var2, ScreenRect var3) {
         this.pipeline = var1;
         this.texture = var2;
         this.clip = var3;
      }

      boolean append(Matrix3x2fc var1, int var2, int var3, int var4, int var5, float var6, float var7, float var8, float var9, int var10, int var11) {
         float var12 = var1.m00() * (float)var2 + var1.m10() * (float)var3 + var1.m20();
         float var13 = var1.m01() * (float)var2 + var1.m11() * (float)var3 + var1.m21();
         float var14 = var1.m00() * (float)var2 + var1.m10() * (float)var5 + var1.m20();
         float var15 = var1.m01() * (float)var2 + var1.m11() * (float)var5 + var1.m21();
         float var16 = var1.m00() * (float)var4 + var1.m10() * (float)var5 + var1.m20();
         float var17 = var1.m01() * (float)var4 + var1.m11() * (float)var5 + var1.m21();
         float var18 = var1.m00() * (float)var4 + var1.m10() * (float)var3 + var1.m20();
         float var19 = var1.m01() * (float)var4 + var1.m11() * (float)var3 + var1.m21();
         int var20 = (int)Math.floor((double)Math.min(Math.min(var12, var14), Math.min(var16, var18)));
         int var21 = (int)Math.floor((double)Math.min(Math.min(var13, var15), Math.min(var17, var19)));
         int var22 = (int)Math.ceil((double)Math.max(Math.max(var12, var14), Math.max(var16, var18)));
         int var23 = (int)Math.ceil((double)Math.max(Math.max(var13, var15), Math.max(var17, var19)));
         if (this.clip == null
            || var22 > this.clip.getLeft() && var20 < this.clip.getRight() && var23 > this.clip.getTop() && var21 < this.clip.getBottom()) {
            if (this.vertices + 4 > this.colors.length) {
               this.colors = Arrays.copyOf(this.colors, this.colors.length * 2);
               this.xyuv = Arrays.copyOf(this.xyuv, this.xyuv.length * 2);
            }

            this.vertex(var12, var13, var6, var7, var10);
            this.vertex(var14, var15, var6, var9, var11);
            this.vertex(var16, var17, var8, var9, var11);
            this.vertex(var18, var19, var8, var7, var10);
            this.left = Math.min(this.left, var20);
            this.top = Math.min(this.top, var21);
            this.right = Math.max(this.right, var22);
            this.bottom = Math.max(this.bottom, var23);
            return true;
         } else {
            return false;
         }
      }

      private void vertex(float var1, float var2, float var3, float var4, int var5) {
         int var6 = this.vertices * 4;
         this.xyuv[var6] = var1;
         this.xyuv[var6 + 1] = var2;
         this.xyuv[var6 + 2] = var3;
         this.xyuv[var6 + 3] = var4;
         this.colors[this.vertices++] = var5;
      }

      public void setupVertices(VertexConsumer var1) {
         for (int var2 = 0; var2 < this.vertices; var2++) {
            int var3 = var2 * 4;
            VertexConsumer var4 = var1.vertex(this.xyuv[var3], this.xyuv[var3 + 1], 0.0F);
            if (this.pipeline != RenderPipelines.GUI) {
               var4.texture(this.xyuv[var3 + 2], this.xyuv[var3 + 3]);
            }

            var4.color(this.colors[var2]);
         }
      }

      public RenderPipeline pipeline() {
         return this.pipeline;
      }

      public TextureSetup textureSetup() {
         return this.texture;
      }

      public ScreenRect scissorArea() {
         return this.clip;
      }

      public ScreenRect bounds() {
         ScreenRect var1 = new ScreenRect(this.left, this.top, this.right - this.left, this.bottom - this.top);
         return this.clip == null ? var1 : var1.intersection(this.clip);
      }
   }
}
