package kaze.feature;

import it.unimi.dsi.fastutil.longs.Long2IntMaps;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.awt.Color;
import java.lang.ref.WeakReference;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BooleanSupplier;
import kaze.event.EventListener;
import kaze.event.events.ChunkDataEvent;
import kaze.event.events.Render3DEvent;
import kaze.event.events.TickEvent;
import kaze.module.NewFeature;
import kaze.module.ext.ClientModule;
import kaze.module.ext.EventHandler;
import kaze.module.ext.ModuleCategory;
import kaze.module.ext.event.BlockUpdateEvent;
import kaze.module.ext.setting.BooleanSetting;
import kaze.module.ext.setting.ColorSetting;
import kaze.module.ext.setting.ModeSetting;
import kaze.module.ext.setting.NumberSetting;
import kaze.utils.chunks.ChunkPlateRenderer;
import kaze.utils.ext.LevelUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

@Environment(EnvType.CLIENT)
public final class ChunkFinderBetterModule extends ClientModule implements NewFeature {
   private static final int PROBE_CHUNKS = 48;
   private static final byte OTHER = 0;
   private static final byte STONE = 1;
   private static final byte BLOB = 2;
   private static final byte AIR = 3;
   private static final byte MISSING = 4;
   private static final int[] SIDE_X;
   private static final int[] SIDE_Z;
   private static final int[] CORNER_X;
   private static final int[] CORNER_Z;
   private static final int MIN_Y = 0;
   private static final int MAX_Y = 32;
   private static final int CHUNK_COLOR = 1627389951;
   private static final int OLD_CHUNK_COLOR = 1614011733;
   private final ModeSetting detection;
   private final NumberSetting spreadRadius;
   private final NumberSetting alpha;
   private final ColorSetting chunkColor;
   private final BooleanSetting sound;
   private final ChunkPlateRenderer plates;
   private static final ChunkFinderBetterModule.ChunkCandidate UNDECIDED;
   private final Long2ObjectOpenHashMap<ChunkFinderBetterModule.ChunkCandidate> flagged;
   private final LongArrayFIFOQueue queue;
   private final LongOpenHashSet queued;
   private final List<ChunkFinderBetterModule.ChunkCandidate> fresh;
   private final Long2IntOpenHashMap heat;
   private int appliedRadius;
   private LongOpenHashSet shown;
   private boolean shownDirty;
   private int shownAge;
   private ClientWorld lastLevel;
   private boolean scanning;
   private ChunkFinderBetterModule.HeightBand appliedConfig;
   private WeakReference<ClientPlayNetworkHandler> probeServer;
   private boolean probing;
   private final LongOpenHashSet probed;
   private final WorldChunk[] around;
   private final int[] groupX;
   private final int[] groupZ;
   private int groupSize;
   private boolean guessed;
   private Block wall;
   private Block lastBlock;
   private final int[] stackTop;
   private final int[] stackShape;
   private final int[] stackAreas;
   private final boolean[] stackGuessed;
   private final Block[] stackWall;
   private boolean sawBlob;
   private int scanX;
   private int scanZ;
   private int keepHeight;
   private long[] keptStacks;
   private int keptStackCount;
   private int tallest;
   private long bottom;
   private boolean unsure;

   public ChunkFinderBetterModule() {
      super("chunk-finder-better", "Chunk Finder Better", "Scans suspicious underground shafts with Calm or Aggressive detection.", ModuleCategory.DONUT);
      int var10000 = 93709009 % 741102601;
      String var86 = "detection";
      String var6 = "Detection";
      String var7 = "Calm";
      String[] var110 = new String[2];
      String var10 = "Calm";
      var110[0] = var10;
      String var116 = "Aggressive";
      var110[1] = var116;
      ModeSetting var92 = new ModeSetting(var6, var7, var110);
      ModeSetting var43 = (ModeSetting)this.addSetting(var86, var92);
      this.detection = var43;
      String var87 = "spread-radius";
      String var102 = "Spread Radius";
      NumberSetting var94 = new NumberSetting(var102, 1.0F, 0.0F, 16.0F).step(1.0F);
      NumberSetting var46 = (NumberSetting)this.addSetting(var87, var94);
      this.spreadRadius = var46;
      String var88 = "alpha";
      String var103 = "Alpha";
      NumberSetting var96 = new NumberSetting(var103, 96.0F, 0.0F, 255.0F).step(1.0F);
      NumberSetting var49 = (NumberSetting)this.addSetting(var88, var96);
      this.alpha = var49;
      String var89 = "chunk-color";
      String var104 = "Chunk Color";
      ColorSetting var97 = new ColorSetting(var104, 1627389951);
      ColorSetting var52 = (ColorSetting)this.addSetting(var89, var97);
      this.chunkColor = var52;
      String var90 = "sound";
      String var105 = "Sound";
      BooleanSetting var98 = new BooleanSetting(var105, true);
      BooleanSetting var55 = (BooleanSetting)this.addSetting(var90, var98);
      this.sound = var55;
      ChunkPlateRenderer var56 = new ChunkPlateRenderer();
      this.plates = var56;
      Long2ObjectOpenHashMap var57 = new Long2ObjectOpenHashMap();
      this.flagged = var57;
      LongArrayFIFOQueue var58 = new LongArrayFIFOQueue();
      this.queue = var58;
      LongOpenHashSet var59 = new LongOpenHashSet();
      this.queued = var59;
      ArrayList var60 = new ArrayList();
      this.fresh = var60;
      Long2IntOpenHashMap var61 = new Long2IntOpenHashMap();
      this.heat = var61;
      LongOpenHashSet var62 = new LongOpenHashSet();
      this.shown = var62;
      this.shownDirty = true;
      WeakReference var64 = new WeakReference(null);
      this.probeServer = var64;
      LongOpenHashSet var65 = new LongOpenHashSet();
      this.probed = var65;
      WorldChunk[] var67 = new WorldChunk[9];
      this.around = var67;
      int[] var69 = new int[4];
      this.groupX = var69;
      int[] var71 = new int[4];
      this.groupZ = var71;
      int[] var73 = new int[256];
      this.stackTop = var73;
      int[] var75 = new int[256];
      this.stackShape = var75;
      int[] var77 = new int[256];
      this.stackAreas = var77;
      boolean[] var79 = new boolean[256];
      this.stackGuessed = var79;
      Block[] var81 = new Block[256];
      this.stackWall = var81;
      long[] var83 = new long[16];
      this.keptStacks = var83;
      BooleanSetting var37 = this.usesNotifications();
      BooleanSetting var39 = this.sound;
      BooleanSupplier var85 = var37::get;
      var39.visibleWhen(var85);
   }

   public void onEnable() {
      this.startLevel(MinecraftClient.getInstance().world);
   }

   public void onDisable() {
      this.startLevel(null);
   }

   private void startLevel(ClientWorld var1) {
      this.flagged.clear();
      this.heat.clear();
      this.appliedRadius = this.spreadRadius.getInt();
      this.queue.clear();
      this.queued.clear();
      this.fresh.clear();
      this.shown = new LongOpenHashSet();
      this.shownDirty = true;
      this.shownAge = 0;
      this.lastLevel = var1;
      this.scanning = var1 != null && var1.getRegistryKey() != World.NETHER && var1.getRegistryKey() != World.END;
      if (this.scanning) {
         ClientPlayNetworkHandler var2;
         if ((var2 = MinecraftClient.getInstance().getNetworkHandler()) != this.probeServer.get()) {
            this.probeServer = new WeakReference<>(var2);
            this.probing = true;
            this.probed.clear();
         }

         this.appliedConfig = this.currentConfig(var1);
         this.queueLoadedChunks(var1);
      }
   }

   private ChunkFinderBetterModule.HeightBand currentConfig(ClientWorld var1) {
      return new ChunkFinderBetterModule.HeightBand(
         Math.max(0, var1.getBottomY()), Math.min(32, var1.getTopYInclusive()), this.detection.is("Aggressive") ? 3 : 2
      );
   }

   private void queueLoadedChunks(ClientWorld var1) {
      MinecraftClient var2;
      if ((var2 = MinecraftClient.getInstance()).player != null) {
         int var3 = (Integer)var2.options.getViewDistance().getValue() + 1;

         ChunkPos var4;
         for (int var5 = (var4 = var2.player.getChunkPos()).x - var3; var5 <= var4.x + var3; var5++) {
            for (int var6 = var4.z - var3; var6 <= var4.z + var3; var6++) {
               if (LevelUtil.isLoaded(var1, var5, var6)) {
                  this.enqueue(ChunkPos.toLong(var5, var6));
               }
            }
         }
      }
   }

   private void enqueue(long var1) {
      if (this.scanning && this.queued.add(var1)) {
         this.queue.enqueue(var1);
      }
   }

   @EventListener
   public void onChunkData(ChunkDataEvent var1) {
      this.shownDirty = true;
      int var2 = var1.packet.getChunkX();
      int var3 = var1.packet.getChunkZ();

      for (int var4 = -1; var4 <= 1; var4++) {
         for (int var5 = -1; var5 <= 1; var5++) {
            this.enqueue(ChunkPos.toLong(var2 + var4, var3 + var5));
         }
      }
   }

   @EventHandler
   public void onBlockUpdate(BlockUpdateEvent var1) {
      int var2;
      if (this.scanning
         && var1.pos != null
         && (var2 = var1.pos.getY()) >= this.appliedConfig.minY() - 1
         && var2 <= this.appliedConfig.maxY() + 1
         && (matters(var1.oldState) || matters(var1.newState))) {
         int var3 = var1.pos.getX();
         int var4 = var1.pos.getZ();

         for (int var5 = var3 - 2 >> 4; var5 <= var3 + 1 >> 4; var5++) {
            for (int var6 = var4 - 2 >> 4; var6 <= var4 + 2 >> 4; var6++) {
               this.enqueue(ChunkPos.toLong(var5, var6));
            }
         }
      }
   }

   @EventListener
   public void onTick(TickEvent var1) {
      ClientWorld var2;
      if ((var2 = MinecraftClient.getInstance().world) != this.lastLevel) {
         this.startLevel(var2);
      }

      if (this.scanning) {
         ChunkFinderBetterModule.HeightBand var3;
         if (!(var3 = this.currentConfig(var2)).equals(this.appliedConfig)) {
            this.appliedConfig = var3;
            this.queueLoadedChunks(var2);
         }

         int var4;
         if ((var4 = this.spreadRadius.getInt()) != this.appliedRadius) {
            this.appliedRadius = var4;
            this.shownDirty = true;
            this.heat.clear();
            ObjectIterator var5 = this.flagged.long2ObjectEntrySet().fastIterator();

            while (var5.hasNext()) {
               Entry var6 = (Entry)var5.next();
               this.spread(var6.getLongKey(), (ChunkFinderBetterModule.ChunkCandidate)var6.getValue(), 1);
            }
         }

         long var13 = System.nanoTime() + 3000000L;

         while (!this.queue.isEmpty() && System.nanoTime() < var13) {
            long var7 = this.queue.dequeueLong();
            this.queued.remove(var7);
            int var9 = ChunkPos.getPackedX(var7);
            int var10 = ChunkPos.getPackedZ(var7);
            if (LevelUtil.isLoaded(var2, var9, var10)) {
               ChunkFinderBetterModule.ChunkCandidate var11 = this.scan(var2, var9, var10, var3);
               if (this.sawBlob) {
                  this.probe(var7);
               }

               if (var11 != UNDECIDED) {
                  ChunkFinderBetterModule.ChunkCandidate var12 = (ChunkFinderBetterModule.ChunkCandidate)this.flagged.get(var7);
                  if (var11 == null ? var12 != null : var12 == null || !var12.sameAs(var11)) {
                     this.refile(var7, var12, var11);
                     if (var12 == null) {
                        this.fresh.add(var11);
                     }
                  }
               }
            }
         }

         this.announce(this.fresh);
         this.fresh.clear();
         if (this.shownDirty || ++this.shownAge >= 20) {
            this.shown = this.computeShown(var2);
            this.shownDirty = false;
            this.shownAge = 0;
         }
      }
   }

   private void refile(long var1, ChunkFinderBetterModule.ChunkCandidate var3, ChunkFinderBetterModule.ChunkCandidate var4) {
      this.shownDirty = true;
      if (var3 != null) {
         this.spread(var1, var3, -1);
      }

      if (var4 == null) {
         this.flagged.remove(var1);
      } else {
         this.flagged.put(var1, var4);
         this.spread(var1, var4, 1);
      }
   }

   private void spread(long var1, ChunkFinderBetterModule.ChunkCandidate var3, int var4) {
      int var5 = var4 * var3.stacks().length;
      int var6 = this.appliedRadius;
      int var7 = ChunkPos.getPackedX(var1);
      int var8 = ChunkPos.getPackedZ(var1);

      for (int var9 = var7 - var6; var9 <= var7 + var6; var9++) {
         for (int var10 = var8 - var6; var10 <= var8 + var6; var10++) {
            long var11 = ChunkPos.toLong(var9, var10);
            if (this.heat.addTo(var11, var5) + var5 == 0) {
               this.heat.remove(var11);
            }
         }
      }
   }

   private LongOpenHashSet computeShown(ClientWorld var1) {
      Long2IntOpenHashMap var2 = new Long2IntOpenHashMap();
      ObjectIterator var3 = Long2IntMaps.fastIterable(this.heat).iterator();

      while (var3.hasNext()) {
         it.unimi.dsi.fastutil.longs.Long2IntMap.Entry var4;
         long var5 = (var4 = (it.unimi.dsi.fastutil.longs.Long2IntMap.Entry)var3.next()).getLongKey();
         if (LevelUtil.isLoaded(var1, ChunkPos.getPackedX(var5), ChunkPos.getPackedZ(var5))) {
            var2.put(var5, var4.getIntValue());
         }
      }

      return this.appliedRadius == 0 ? new LongOpenHashSet(var2.keySet()) : hottestPerPatch(var2);
   }

   private static LongOpenHashSet hottestPerPatch(Long2IntOpenHashMap var0) {
      LongOpenHashSet var1 = new LongOpenHashSet();
      LongOpenHashSet var2 = new LongOpenHashSet();
      LongArrayList var3 = new LongArrayList();
      LongArrayFIFOQueue var4 = new LongArrayFIFOQueue();
      LongIterator var5 = var0.keySet().iterator();

      while (var5.hasNext()) {
         long var6 = var5.next();
         if (var2.add(var6)) {
            var3.clear();
            var4.enqueue(var6);
            int var8 = 0;

            while (!var4.isEmpty()) {
               long var9 = var4.dequeueLong();
               var3.add(var9);
               var8 = Math.max(var8, var0.get(var9));
               int var11 = ChunkPos.getPackedX(var9);
               int var12 = ChunkPos.getPackedZ(var9);

               for (int var13 = 0; var13 < 4; var13++) {
                  long var14 = ChunkPos.toLong(var11 + SIDE_X[var13], var12 + SIDE_Z[var13]);
                  if (var0.containsKey(var14) && var2.add(var14)) {
                     var4.enqueue(var14);
                  }
               }
            }

            for (int var16 = 0; var16 < var3.size(); var16++) {
               if (var0.get(var3.getLong(var16)) == var8) {
                  var1.add(var3.getLong(var16));
               }
            }
         }
      }

      return var1;
   }

   private ChunkFinderBetterModule.ChunkCandidate scan(ClientWorld var1, int var2, int var3, ChunkFinderBetterModule.HeightBand var4) {
      for (int var5 = -1; var5 <= 1; var5++) {
         for (int var6 = -1; var6 <= 1; var6++) {
            this.around[(var5 + 1) * 3 + var6 + 1] = var1.getChunkManager().getWorldChunk(var2 + var5, var3 + var6);
         }
      }

      this.sawBlob = false;
      this.scanX = var2 << 4;
      this.scanZ = var3 << 4;
      this.keepHeight = var4.stackHeight();
      this.keptStackCount = 0;
      this.tallest = 0;
      this.bottom = 0L;
      this.unsure = false;

      ChunkFinderBetterModule.ChunkCandidate var27;
      try {
         WorldChunk var251;
         ChunkSection[] var24 = (var251 = this.around[4]).getSectionArray();
         int var7 = var251.getBottomSectionCoord();
         Arrays.fill(this.stackTop, Integer.MIN_VALUE);
         boolean var8 = true;

         for (int var9 = 0; var9 < var24.length; var9++) {
            ChunkSection var10;
            int var11;
            if ((var10 = var24[var9]) != null && !var10.isEmpty() && (var11 = var7 + var9 << 4) + 15 >= var4.minY() && var11 <= var4.maxY()) {
               int var12x = Math.max(var4.minY() - var11, 0);
               int var13 = Math.min(var4.maxY() - var11, 15);
               if (var8) {
                  var8 = !hasBlocks(var10, var12x, var13);
               }

               if (var10.hasAny(var0 -> var0.isOf(Blocks.STONE)) && var10.hasAny(var0 -> isBlob(var0.getBlock()))) {
                  for (int var14 = var12x; var14 <= var13; var14++) {
                     for (int var15 = 0; var15 < 16; var15++) {
                        boolean var16 = false;

                        for (int var17 = 0; var17 < 16; var17++) {
                           Block var18;
                           boolean var19;
                           if (var19 = (var18 = var10.getBlockState(var17, var14, var15).getBlock()) == Blocks.STONE) {
                              if (!var16 && this.isArea(var17, var11 + var14, var15)) {
                                 this.stack(var17, var11 + var14, var15);
                              }
                           } else if (this.probing && isBlob(var18)) {
                              this.sawBlob = true;
                              if (this.enclosed(var17, var11 + var14, var15)) {
                                 this.probing = false;
                                 this.probed.clear();
                              }
                           }

                           var16 = var19;
                        }
                     }
                  }
               }
            }
         }

         for (int var25x = 0; var25x < 256; var25x++) {
            this.keep(var25x);
         }

         if (this.tallest >= var4.stackHeight()) {
            return new ChunkFinderBetterModule.ChunkCandidate(this.bottom, this.tallest, Arrays.copyOf(this.keptStacks, this.keptStackCount));
         }

         var27 = !this.unsure && !var8 ? null : UNDECIDED;
      } finally {
         Arrays.fill(this.around, null);
      }

      return var27;
   }

   private void stack(int var1, int var2, int var3) {
      int var4 = var3 << 4 | var1;
      int var5 = this.shape(var1, var3);
      boolean var6;
      if (!(var6 = this.stackTop[var4] == var2 - 1 && this.stackShape[var4] == var5 && this.stackWall[var4] == this.wall)) {
         this.keep(var4);
      }

      this.stackTop[var4] = var2;
      this.stackShape[var4] = var5;
      this.stackWall[var4] = this.wall;
      this.stackAreas[var4] = var6 ? this.stackAreas[var4] + 1 : 1;
      this.stackGuessed[var4] = this.guessed || var6 && this.stackGuessed[var4];
   }

   private void keep(int var1) {
      int var2 = this.stackAreas[var1];
      int var3;
      if ((var3 = this.stackTop[var1]) != Integer.MIN_VALUE && var2 >= this.keepHeight) {
         int var4 = this.stackShape[var1];
         if (this.goesOn(var1 & 15, var3 + 1, var1 >> 4, var4) && this.goesOn(var1 & 15, var3 - var2, var1 >> 4, var4)) {
            if (this.stackGuessed[var1]) {
               this.unsure = true;
               return;
            }

            int var5 = this.scanX + (var1 & 15);
            int var6 = this.scanZ + (var1 >> 4);
            long var7 = BlockPos.asLong(var5, var3 - var2 + 1, var6);
            if (var2 > this.tallest || var2 == this.tallest && before(var7, this.bottom)) {
               this.tallest = var2;
               this.bottom = var7;
            }

            if (this.keptStackCount == this.keptStacks.length) {
               this.keptStacks = Arrays.copyOf(this.keptStacks, this.keptStacks.length << 1);
            }

            this.keptStacks[this.keptStackCount++] = var7;
         }
      }
   }

   private boolean goesOn(int var1, int var2, int var3, int var4) {
      for (int var5 = 0; var5 < 6; var5++) {
         if ((var4 >> var5 & 1) != 0) {
            this.kind(var1 + var5 / 3, var2, var3 + var5 % 3 - 1);
            if (!carriesStone(this.lastBlock)) {
               return false;
            }
         }
      }

      return true;
   }

   private static boolean before(long var0, long var2) {
      if (BlockPos.unpackLongY(var0) != BlockPos.unpackLongY(var2)) {
         return BlockPos.unpackLongY(var0) < BlockPos.unpackLongY(var2);
      } else {
         return BlockPos.unpackLongZ(var0) != BlockPos.unpackLongZ(var2)
            ? BlockPos.unpackLongZ(var0) < BlockPos.unpackLongZ(var2)
            : BlockPos.unpackLongX(var0) < BlockPos.unpackLongX(var2);
      }
   }

   private int shape(int var1, int var2) {
      int var3 = 0;

      for (int var4 = 0; var4 < this.groupSize; var4++) {
         var3 |= 1 << (this.groupX[var4] - var1) * 3 + this.groupZ[var4] - var2 + 1;
      }

      return var3;
   }

   private boolean isArea(int var1, int var2, int var3) {
      this.guessed = false;
      this.wall = null;
      if (this.seen(var1 - 1, var2, var3) == 2 && this.sameWall() && this.seen(var1, var2, var3 - 1) == 2 && this.sameWall()) {
         this.groupX[0] = var1;
         this.groupZ[0] = var3;
         int var4 = 1;
         int var5 = var1;
         int var6 = var3;
         int var7 = var3;

         for (int var8 = 0; var8 < var4; var8++) {
            for (int var9 = 0; var9 < 4; var9++) {
               int var10 = this.groupX[var8] + SIDE_X[var9];
               int var11 = this.groupZ[var8] + SIDE_Z[var9];
               if (!this.inGroup(var10, var11, var4)) {
                  byte var12;
                  if ((var12 = this.seen(var10, var2, var11)) == 2) {
                     if (!this.sameWall()) {
                        return false;
                     }
                  } else {
                     if (var12 != 1) {
                        return false;
                     }

                     if (var10 < var1 || var10 == var1 && var11 < var3) {
                        return false;
                     }

                     var5 = Math.max(var5, var10);
                     var6 = Math.min(var6, var11);
                     var7 = Math.max(var7, var11);
                     if (var5 - var1 > 1 || var7 - var6 > 1) {
                        return false;
                     }

                     this.groupX[var4] = var10;
                     this.groupZ[var4] = var11;
                     var4++;
                  }
               }
            }
         }

         for (int var13 = 0; var13 < var4; var13++) {
            for (int var15 = 0; var15 < 4; var15++) {
               int var16 = this.groupX[var13] + CORNER_X[var15];
               int var17 = this.groupZ[var13] + CORNER_Z[var15];
               if (!this.inGroup(var16, var17, var4) && (this.seen(var16, var2, var17) != 2 || !this.sameWall())) {
                  return false;
               }
            }
         }

         for (int var14 = 0; var14 < var4; var14++) {
            if (this.kind(this.groupX[var14], var2 + 1, this.groupZ[var14]) == 3 || this.kind(this.groupX[var14], var2 - 1, this.groupZ[var14]) == 3) {
               return false;
            }
         }

         this.groupSize = var4;
         return true;
      } else {
         return false;
      }
   }

   private boolean inGroup(int var1, int var2, int var3) {
      for (int var4 = 0; var4 < var3; var4++) {
         if (this.groupX[var4] == var1 && this.groupZ[var4] == var2) {
            return true;
         }
      }

      return false;
   }

   private byte seen(int var1, int var2, int var3) {
      byte var4;
      if ((var4 = this.kind(var1, var2, var3)) != 4) {
         return var4;
      } else {
         this.guessed = true;
         return 2;
      }
   }

   private boolean sameWall() {
      if (this.lastBlock == null) {
         return true;
      } else {
         if (this.wall == null) {
            this.wall = this.lastBlock;
         }

         return this.lastBlock == this.wall;
      }
   }

   private byte kind(int var1, int var2, int var3) {
      WorldChunk var4 = this.around[((var1 >> 4) + 1) * 3 + (var3 >> 4) + 1];
      this.lastBlock = null;
      if (var4 == null) {
         return 4;
      } else {
         int var5;
         if ((var5 = var4.getSectionIndex(var2)) >= 0 && var5 < var4.countVerticalSections()) {
            BlockState var6 = var4.getSection(var5).getBlockState(var1 & 15, var2 & 15, var3 & 15);
            this.lastBlock = var6.getBlock();
            return kindOf(var6);
         } else {
            return 0;
         }
      }
   }

   private boolean enclosed(int var1, int var2, int var3) {
      return this.full(var1 + 1, var2, var3)
         && this.full(var1 - 1, var2, var3)
         && this.full(var1, var2, var3 + 1)
         && this.full(var1, var2, var3 - 1)
         && this.full(var1, var2 + 1, var3)
         && this.full(var1, var2 - 1, var3);
   }

   private boolean full(int var1, int var2, int var3) {
      WorldChunk var4;
      int var5;
      return (var4 = this.around[((var1 >> 4) + 1) * 3 + (var3 >> 4) + 1]) == null
         ? false
         : (var5 = var4.getSectionIndex(var2)) >= 0
            && var5 < var4.countVerticalSections()
            && var4.getSection(var5).getBlockState(var1 & 15, var2 & 15, var3 & 15).isOpaqueFullCube();
   }

   private static boolean hasBlocks(ChunkSection var0, int var1, int var2) {
      if (!var0.hasAny(var0x -> !var0x.isAir())) {
         return false;
      } else {
         for (int var3 = var1; var3 <= var2; var3++) {
            for (int var4 = 0; var4 < 16; var4++) {
               for (int var5 = 0; var5 < 16; var5++) {
                  if (!var0.getBlockState(var5, var3, var4).isAir()) {
                     return true;
                  }
               }
            }
         }

         return false;
      }
   }

   private static byte kindOf(BlockState var0) {
      Block var1;
      if ((var1 = var0.getBlock()) == Blocks.STONE) {
         return 1;
      } else {
         return isBlob(var1) ? 2 : (byte)(var0.isAir() ? 3 : 0);
      }
   }

   private static boolean isBlob(Block var0) {
      return var0 == Blocks.DIORITE || var0 == Blocks.ANDESITE || var0 == Blocks.GRANITE || var0 == Blocks.GRAVEL;
   }

   private static boolean carriesStone(Block var0) {
      return var0 == Blocks.STONE || var0 == Blocks.DEEPSLATE;
   }

   private static boolean matters(BlockState var0) {
      return var0 != null && (kindOf(var0) != 0 || carriesStone(var0.getBlock()));
   }

   private void probe(long var1) {
      if (this.probing && this.probed.add(var1) && this.probed.size() >= 48) {
         this.probing = false;
         this.probed.clear();
         if (MinecraftClient.getInstance().world != null && MinecraftClient.getInstance().player != null) {
            MinecraftClient.getInstance()
               .player
               .sendMessage(Text.literal("Kaze: This server hides ores with anti-xray; patched shafts may not be visible."), false);
         }
      }
   }

   private void announce(List<ChunkFinderBetterModule.ChunkCandidate> var1) {
      if (this.notificationsOn() && !var1.isEmpty()) {
         ChunkFinderBetterModule.ChunkCandidate var2;
         ChunkFlagToast.show(BlockPos.unpackLongX((var2 = var1.get(0)).pos()), BlockPos.unpackLongZ(var2.pos()), this.sound.get());
      }
   }

   @EventListener
   public void onRender3D(Render3DEvent var1) {
      if (MinecraftClient.getInstance().world != null) {
         int var2 = this.alpha.getInt();
         int var3 = this.chunkColor.argb() & 16777215;
         this.plates.draw(var1, this.shown, new Color(var2 << 24 | var3, true), new Color(Math.min(220, var2 + 45) << 24 | var3, true), 1.5F);
      }
   }











   static {
      int[] var5;
      (var5 = new int[4])[0] = 1;
      var5[1] = -1;
      var5[2] = 0;
      var5[3] = 0;
      SIDE_X = var5;
      int[] var7;
      (var7 = new int[4])[0] = 0;
      var7[1] = 0;
      var7[2] = 1;
      var7[3] = -1;
      SIDE_Z = var7;
      int[] var9;
      (var9 = new int[4])[0] = 1;
      var9[1] = 1;
      var9[2] = -1;
      var9[3] = -1;
      CORNER_X = var9;
      int[] var11;
      (var11 = new int[4])[0] = 1;
      var11[1] = -1;
      var11[2] = 1;
      var11[3] = -1;
      CORNER_Z = var11;
      long[] var45 = new long[0];
      UNDECIDED = new ChunkFinderBetterModule.ChunkCandidate(0L, 0, var45);
   }

   @Environment(EnvType.CLIENT)
   private record ChunkCandidate(long pos, int height, long[] stacks) {
      boolean sameAs(ChunkFinderBetterModule.ChunkCandidate var1) {
         return this.pos == var1.pos && this.height == var1.height && Arrays.equals(this.stacks, var1.stacks);
      }
   }

   @Environment(EnvType.CLIENT)
   private record HeightBand(int minY, int maxY, int stackHeight) {
   }
}
