package kaze.feature;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import kaze.Kaze;
import kaze.event.EventListener;
import kaze.event.events.SetScreenEvent;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.StringSetting;
import kaze.utils.EncryptedString;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.text.Text;

public final class AutoRtpModule extends Module {
   private static final List<String> REGIONS = List.of(
      "rtp asia", "rtp eu central", "rtp eu west", "rtp eu oceania", "rtp east", "rtp west"
   );

   private final StringSetting command;
   private final NumberSetting delay;
   private final BooleanSetting randomRegion;
   private final BooleanSetting disableOnBypassFlag;
   private final List<String> queue = new ArrayList<>();
   private long lastSent;

   public AutoRtpModule() {
      super(
         EncryptedString.of("Auto RTP"),
         EncryptedString.of("Runs /rtp on a timer and cooperates with Player Bypass"),
         -1,
         Category.DONUT
      );
      this.command = new StringSetting(EncryptedString.of("Command"), "/rtp")
         .setDescription(EncryptedString.of("Command sent on each interval when Random Region is off"));
      this.delay = new NumberSetting(EncryptedString.of("Delay"), 0.05, 10.0, 1.0, 0.05)
         .getValue(EncryptedString.of("Seconds between RTP commands"));
      this.randomRegion = new BooleanSetting(EncryptedString.of("Random Region"), false)
         .setDescription(EncryptedString.of("Cycles through every Donut RTP region in a shuffled order"));
      this.disableOnBypassFlag = new BooleanSetting(EncryptedString.of("Disable On Bypass Flag"), true)
         .setDescription(EncryptedString.of("Turns Auto RTP off on Player Bypass flags; any kick also disables Auto RTP"));
      this.addSettings(this.command, this.delay, this.randomRegion, this.disableOnBypassFlag);
   }

   @Override
   public void onEnable() {
      this.lastSent = 0L;
      this.queue.clear();
      super.onEnable();
   }

   @Override
   public void onDisable() {
      this.queue.clear();
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.player == null || this.mc.getNetworkHandler() == null) {
         return;
      }
      long now = System.currentTimeMillis();
      long delayMillis = (long)(this.delay.getValue() * 1000.0);
      if (now - this.lastSent - delayMillis < 0L) {
         return;
      }

      String nextCommand;
      if (this.randomRegion.getValue()) {
         if (this.queue.isEmpty()) {
            this.queue.addAll(REGIONS);
            Collections.shuffle(this.queue);
         }
         nextCommand = this.queue.removeFirst();
      } else {
         nextCommand = normalize(this.command.getValue());
      }
      if (!nextCommand.isBlank()) {
         this.lastSent = now;
         this.mc.getNetworkHandler().sendChatCommand(nextCommand);
      }
   }

   public void onBypassFlag() {
      if (this.isEnabled() && this.disableOnBypassFlag.getValue()) {
         this.toggle(false);
         if (this.mc.player != null) {
            this.mc.player.sendMessage(Text.literal("\u00A7e[Auto RTP] \u00A7fDisabled because Player Bypass detected a flag."), false);
         }
         Kaze.INSTANCE.getSettingsManager().saveNow();
      }
   }

   @EventListener
   public void onDisconnectedScreen(SetScreenEvent event) {
      if (event.screen instanceof DisconnectedScreen) {
         this.toggle(false);
         Kaze.INSTANCE.getSettingsManager().saveNow();
      }
   }

   private static String normalize(String command) {
      if (command == null) {
         return "";
      }
      command = command.trim();
      while (command.startsWith("/")) {
         command = command.substring(1).trim();
      }
      return command;
   }
}
