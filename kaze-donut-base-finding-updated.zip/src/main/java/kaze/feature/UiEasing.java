package kaze.feature;

final class UiEasing {
   private UiEasing() {
   }

   static float clamp(float var0, float var1, float var2) {
      return var0 < var1 ? var1 : Math.min(var0, var2);
   }

   static float out(float var0) {
      float var1 = 1.0F - clamp(var0, 0.0F, 1.0F);
      return 1.0F - var1 * var1 * var1;
   }

   static float inOut(float var0) {
      var0 = clamp(var0, 0.0F, 1.0F);
      return var0 < 0.5F ? 4.0F * var0 * var0 * var0 : 1.0F - (float)Math.pow((double)(-2.0F * var0 + 2.0F), 3.0) / 2.0F;
   }

   static float lerp(float var0, float var1, float var2) {
      return var0 + (var1 - var0) * var2;
   }

   static int mix(int var0, int var1, float var2) {
      var2 = clamp(var2, 0.0F, 1.0F);
      int var3 = Math.round(lerp((float)(var0 >>> 24), (float)(var1 >>> 24), var2));
      int var4 = Math.round(lerp((float)(var0 >> 16 & 0xFF), (float)(var1 >> 16 & 0xFF), var2));
      int var5 = Math.round(lerp((float)(var0 >> 8 & 0xFF), (float)(var1 >> 8 & 0xFF), var2));
      int var6 = Math.round(lerp((float)(var0 & 0xFF), (float)(var1 & 0xFF), var2));
      return var3 << 24 | var4 << 16 | var5 << 8 | var6;
   }
}
