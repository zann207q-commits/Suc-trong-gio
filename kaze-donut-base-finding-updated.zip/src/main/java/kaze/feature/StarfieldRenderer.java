package kaze.feature;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import org.joml.Vector3f;

@Environment(EnvType.CLIENT)
final class StarfieldRenderer {
   private static final float RADIUS = 100.0F;
   private static final int STARS = 2600;
   private static final float GLOW_ABOVE = 0.8F;
   private static final long TWINKLE_NANOS = 50000000L;
   private static final int BAND_COLUMNS = 180;
   private static final int BAND_ROWS = 12;
   private static final float BAND_HALF_WIDTH = 17.0F;
   private static final int NEBULA_COLUMNS = 72;
   private static final int NEBULA_ROWS = 36;
   private static final Vector3f BAND_NORMAL = new Vector3f(0.42F, 0.5F, 0.76F).normalize();
   private final GpuQuadMesh starMesh;
   private final GpuQuadMesh bandMesh;
   private final GpuQuadMesh nebulaMesh;
   private final float[] dir;
   private final float[] size;
   private final float[] light;
   private final float[] roll;
   private final float[] phase;
   private final float[] speed;
   private final int[] rgb;
   private boolean placed;
   private long lastTwinkle;
   private float builtBrightness;
   private int bandTint;

   StarfieldRenderer() {
      String var3 = "Kaze stars";
      RenderPipeline var4 = GpuQuadMesh.GLOW;
      GpuQuadMesh var2 = new GpuQuadMesh(var3, var4, 5200);
      this.starMesh = var2;
      String var34 = "Kaze milky way";
      RenderPipeline var36 = GpuQuadMesh.GLOW;
      GpuQuadMesh var17 = new GpuQuadMesh(var34, var36, 2160);
      this.bandMesh = var17;
      String var35 = "Kaze end nebulae";
      RenderPipeline var37 = GpuQuadMesh.GLOW;
      GpuQuadMesh var18 = new GpuQuadMesh(var35, var37, 2592);
      this.nebulaMesh = var18;
      float[] var20 = new float[7800];
      this.dir = var20;
      float[] var22 = new float[2600];
      this.size = var22;
      float[] var24 = new float[2600];
      this.light = var24;
      float[] var26 = new float[2600];
      this.roll = var26;
      float[] var28 = new float[2600];
      this.phase = var28;
      float[] var30 = new float[2600];
      this.speed = var30;
      int[] var32 = new int[2600];
      this.rgb = var32;
      this.builtBrightness = -1.0F;
   }

   void renderStars(MatrixStack var1, float var2, float var3) {
      long var4 = System.nanoTime();
      if (var4 - this.lastTwinkle > (50000000L) || var3 != this.builtBrightness) {
         this.lastTwinkle = var4;
         this.builtBrightness = var3;
         this.buildStars((float)(var4 % (3600000000000L)) / 1000000000.0F, var3);
      }

      this.starMesh.draw(var1, var2);
   }

   void renderBand(MatrixStack var1, float var2, int var3) {
      if (!this.bandMesh.isBuilt() || var3 != this.bandTint) {
         this.bandTint = var3;
         this.buildBand(var3);
      }

      this.bandMesh.draw(var1, var2);
   }

   void renderNebulae(MatrixStack var1, float var2) {
      if (!this.nebulaMesh.isBuilt()) {
         this.buildNebulae();
      }

      this.nebulaMesh.draw(var1, var2);
   }

   private void place() {
      Random var1 = Random.create(10842L);
      Vector3f var2 = new Vector3f();
      Vector3f var3 = new Vector3f();
      bandAxes(var2, var3);

      for (int var4 = 0; var4 < (2600); var4++) {
         float var5;
         float var6;
         float var7;
         if (var1.nextFloat() < 0.30000001192092896F) {
            float var8 = var1.nextFloat() * 6.2831854820251465F;
            float var9 = (float)var1.nextGaussian() * 9.0F * 0.01745329238474369F;
            float var10 = MathHelper.cos((double)var9);
            float var11 = MathHelper.sin((double)var9);
            var5 = var10 * (MathHelper.cos((double)var8) * var2.x + MathHelper.sin((double)var8) * var3.x)
               + var11 * BAND_NORMAL.x;
            var6 = var10 * (MathHelper.cos((double)var8) * var2.y + MathHelper.sin((double)var8) * var3.y)
               + var11 * BAND_NORMAL.y;
            var7 = var10 * (MathHelper.cos((double)var8) * var2.z + MathHelper.sin((double)var8) * var3.z)
               + var11 * BAND_NORMAL.z;
         } else {
            var6 = var1.nextFloat() * 2.0F - 1.0F;
            float var12 = var1.nextFloat() * 6.2831854820251465F;
            float var14 = MathHelper.sqrt(1.0F - var6 * var6);
            var5 = var14 * MathHelper.cos((double)var12);
            var7 = var14 * MathHelper.sin((double)var12);
         }

         this.dir[var4 * (3)] = var5;
         this.dir[var4 * (3) + (1)] = var6;
         this.dir[var4 * (3) + (2)] = var7;
         float var13 = (float)Math.pow((double)var1.nextFloat(), 6.0);
         this.size[var4] = 0.10000000149011612F + 0.5F * var13;
         this.light[var4] = MathHelper.clamp(
            0.30000001192092896F
               + 0.699999988079071F * var13
               + 0.25F * var1.nextFloat(),
            0.0F,
            1.0F
         );
         this.roll[var4] = var1.nextFloat() * 6.2831854820251465F;
         this.phase[var4] = var1.nextFloat() * 6.2831854820251465F;
         this.speed[var4] = 1.5F
            + 3.5F * var1.nextFloat();
         this.rgb[var4] = starColour(var1.nextFloat());
      }

      this.placed = true;
   }

   private static int starColour(float var0) {
      if (var0 < 0.18000000715255737F) {
         return ColorHelper.lerp(var0 / 0.18000000715255737F, 16757870, 16774116);
      } else {
         return var0 < 0.75F
            ? 16775408
            : ColorHelper.lerp(
               (var0 - 0.75F) / 0.25F,
               16774134,
               11125503
            );
      }
   }

   private void buildStars(float var1, float var2) {
      if (!this.placed) {
         this.place();
      }

      BufferBuilder var3 = this.starMesh.begin();

      for (int var4 = 0; var4 < (2600); var4++) {
         float var5 = 0.6200000047683716F
            + 0.3799999952316284F
               * MathHelper.sin((double)(var1 * this.speed[var4] + this.phase[var4]));
         float var6 = MathHelper.clamp(
            this.light[var4] * var5 * var2, 0.0F, 1.0F
         );
         this.star(var3, var4, this.size[var4], var6);
         if (this.light[var4] > 0.800000011920929F) {
            this.star(
               var3,
               var4,
               this.size[var4] * 4.0F,
               var6 * 0.11999999731779099F
            );
         }
      }

      this.starMesh.upload(var3);
   }

   private void star(BufferBuilder var1, int var2, float var3, float var4) {
      float var5 = this.dir[var2 * (3)];
      float var6 = this.dir[var2 * (3) + (1)];
      float var7 = this.dir[var2 * (3) + (2)];
      float var8;
      float var9;
      float var10;
      if (Math.abs(var6) < 0.8999999761581421F) {
         var8 = var7;
         var9 = 0.0F;
         var10 = -var5;
      } else {
         var8 = 0.0F;
         var9 = -var7;
         var10 = var6;
      }

      float var11 = MathHelper.sqrt(var8 * var8 + var9 * var9 + var10 * var10);
      var8 /= var11;
      var9 /= var11;
      var10 /= var11;
      float var12 = var6 * var10 - var7 * var9;
      float var13 = var7 * var8 - var5 * var10;
      float var14 = var5 * var9 - var6 * var8;
      float var15 = MathHelper.cos((double)this.roll[var2]) * var3;
      float var16 = MathHelper.sin((double)this.roll[var2]) * var3;
      float var17 = var8 * var15 + var12 * var16;
      float var18 = var9 * var15 + var13 * var16;
      float var19 = var10 * var15 + var14 * var16;
      float var20 = var12 * var15 - var8 * var16;
      float var21 = var13 * var15 - var9 * var16;
      float var22 = var14 * var15 - var10 * var16;
      float var23 = var5 * 100.0F;
      float var24 = var6 * 100.0F;
      float var25 = var7 * 100.0F;
      int var26 = Math.round(var4 * 255.0F) << (24) | this.rgb[var2];
      GpuQuadMesh.vertex(var1, var23 - var17 - var20, var24 - var18 - var21, var25 - var19 - var22, var26);
      GpuQuadMesh.vertex(var1, var23 + var17 - var20, var24 + var18 - var21, var25 + var19 - var22, var26);
      GpuQuadMesh.vertex(var1, var23 + var17 + var20, var24 + var18 + var21, var25 + var19 + var22, var26);
      GpuQuadMesh.vertex(var1, var23 - var17 + var20, var24 - var18 + var21, var25 - var19 + var22, var26);
   }

   private static void bandAxes(Vector3f var0, Vector3f var1) {
      new Vector3f(0.0F, 1.0F, 0.0F)
         .cross(BAND_NORMAL, var0)
         .normalize();
      new Vector3f(BAND_NORMAL).cross(var0, var1).normalize();
   }

   private void buildBand(int var1) {
      Vector3f var2 = new Vector3f();
      Vector3f var3 = new Vector3f();
      bandAxes(var2, var3);
      float[][] var4 = new float[181][13];
      float[][] var5 = new float[181][13];
      float[][] var6 = new float[181][13];
      int[][] var7 = new int[181][13];

      for (int var8 = 0; var8 <= (180); var8++) {
         float var9 = (float)var8 / 180.0F * 6.2831854820251465F;
         float var10 = MathHelper.cos((double)var9) * var2.x + MathHelper.sin((double)var9) * var3.x;
         float var11 = MathHelper.cos((double)var9) * var2.y + MathHelper.sin((double)var9) * var3.y;
         float var12 = MathHelper.cos((double)var9) * var2.z + MathHelper.sin((double)var9) * var3.z;
         float var13 = 0.550000011920929F
            + 0.44999998807907104F
               * fbm(
                  var10 * 1.7000000476837158F,
                  var11 * 1.7000000476837158F,
                  var12 * 1.7000000476837158F
               );
         float var14 = 3.0F
            * (
               fbm(
                     var10 * 2.299999952316284F + 5.0F,
                     var11 * 2.299999952316284F,
                     var12 * 2.299999952316284F
                  )
                  - 0.5F
            );
         float var15 = MathHelper.clamp(
            fbm(
                     var10 * 1.399999976158142F,
                     var11 * 1.399999976158142F + 9.0F,
                     var12 * 1.399999976158142F
                  )
                  * 1.600000023841858F
               - 0.3499999940395355F,
            0.0F,
            1.0F
         );

         for (int var16 = 0; var16 <= (12); var16++) {
            float var17 = (
                  (float)var16 / 12.0F * 2.0F
                     - 1.0F
               )
               * 17.0F;
            float var18 = var17 * 0.01745329238474369F;
            float var19 = MathHelper.cos((double)var18);
            float var20 = MathHelper.sin((double)var18);
            float var21 = var19 * var10 + var20 * BAND_NORMAL.x;
            float var22 = var19 * var11 + var20 * BAND_NORMAL.y;
            float var23 = var19 * var12 + var20 * BAND_NORMAL.z;
            var4[var8][var16] = var21 * 100.0F;
            var5[var8][var16] = var22 * 100.0F;
            var6[var8][var16] = var23 * 100.0F;
            float var24 = var17 / (17.0F * var13);
            float var25 = (float)Math.exp((double)(-var24 * var24 * 2.200000047683716F));
            float var26 = 0.3499999940395355F
               + 0.6499999761581421F
                  * fbm(
                     var21 * 6.0F,
                     var22 * 6.0F,
                     var23 * 6.0F
                  );
            float var27 = 1.0F
               - 0.75F
                  * var15
                  * (float)Math.exp((double)(-sq((var17 - var14) / 2.5999999046325684F)));
            float var28 = MathHelper.clamp(
               var25 * var26 * var27, 0.0F, 1.0F
            );
            int var29 = ColorHelper.lerp(var25, 7306440, var1) & (16777215);
            var7[var8][var16] = Math.round(var28 * 0.41999998688697815F * 255.0F)
                  << (24)
               | var29;
         }
      }

      BufferBuilder var30 = this.bandMesh.begin();

      for (int var31 = 0; var31 < (180); var31++) {
         for (int var32 = 0; var32 < (12); var32++) {
            GpuQuadMesh.vertex(var30, var4[var31][var32], var5[var31][var32], var6[var31][var32], var7[var31][var32]);
            GpuQuadMesh.vertex(
               var30,
               var4[var31 + (1)][var32],
               var5[var31 + (1)][var32],
               var6[var31 + (1)][var32],
               var7[var31 + (1)][var32]
            );
            GpuQuadMesh.vertex(
               var30,
               var4[var31 + (1)][var32 + (1)],
               var5[var31 + (1)][var32 + (1)],
               var6[var31 + (1)][var32 + (1)],
               var7[var31 + (1)][var32 + (1)]
            );
            GpuQuadMesh.vertex(
               var30,
               var4[var31][var32 + (1)],
               var5[var31][var32 + (1)],
               var6[var31][var32 + (1)],
               var7[var31][var32 + (1)]
            );
         }
      }

      this.bandMesh.upload(var30);
   }

   private void buildNebulae() {
      float[][] var1 = new float[73][37];
      float[][] var2 = new float[73][37];
      float[][] var3 = new float[73][37];
      int[][] var4 = new int[73][37];

      for (int var5 = 0; var5 <= (72); var5++) {
         float var6 = (float)var5 / 72.0F * 6.2831854820251465F;

         for (int var7 = 0; var7 <= (36); var7++) {
            float var8 = ((float)var7 / 36.0F - 0.5F)
               * 3.1415927410125732F;
            float var9 = MathHelper.cos((double)var8) * MathHelper.cos((double)var6);
            float var10 = MathHelper.sin((double)var8);
            float var11 = MathHelper.cos((double)var8) * MathHelper.sin((double)var6);
            var1[var5][var7] = var9 * 100.0F;
            var2[var5][var7] = var10 * 100.0F;
            var3[var5][var7] = var11 * 100.0F;
            float var12 = AuroraMeshRenderer.smoothstep(
               (
                     fbm(
                           var9 * 2.200000047683716F,
                           var10 * 2.200000047683716F,
                           var11 * 2.200000047683716F
                        )
                        - 0.41999998688697815F
                  )
                  / 0.3499999940395355F
            );
            float var13 = fbm(
               var9 * 1.2999999523162842F + 11.0F,
               var10 * 1.2999999523162842F,
               var11 * 1.2999999523162842F
            );
            int var14 = var13 < 0.5F
               ? ColorHelper.lerp(var13 * 2.0F, 8011007, 16732104)
               : ColorHelper.lerp(
                  (var13 - 0.5F) * 2.0F,
                  16732104,
                  3989712
               );
            var4[var5][var7] = Math.round(var12 * 0.550000011920929F * 255.0F)
                  << (24)
               | var14 & (16777215);
         }
      }

      BufferBuilder var15 = this.nebulaMesh.begin();

      for (int var16 = 0; var16 < (72); var16++) {
         for (int var17 = 0; var17 < (36); var17++) {
            GpuQuadMesh.vertex(var15, var1[var16][var17], var2[var16][var17], var3[var16][var17], var4[var16][var17]);
            GpuQuadMesh.vertex(
               var15,
               var1[var16 + (1)][var17],
               var2[var16 + (1)][var17],
               var3[var16 + (1)][var17],
               var4[var16 + (1)][var17]
            );
            GpuQuadMesh.vertex(
               var15,
               var1[var16 + (1)][var17 + (1)],
               var2[var16 + (1)][var17 + (1)],
               var3[var16 + (1)][var17 + (1)],
               var4[var16 + (1)][var17 + (1)]
            );
            GpuQuadMesh.vertex(
               var15,
               var1[var16][var17 + (1)],
               var2[var16][var17 + (1)],
               var3[var16][var17 + (1)],
               var4[var16][var17 + (1)]
            );
         }
      }

      this.nebulaMesh.upload(var15);
   }

   static float fbm(float var0, float var1, float var2) {
      float var3 = 0.0F;
      float var4 = 0.5F;
      float var5 = 0.0F;

      for (int var6 = 0; var6 < (4); var6++) {
         var3 += var4 * noise(var0, var1, var2);
         var5 += var4;
         var0 *= 2.0299999713897705F;
         var1 *= 2.0299999713897705F;
         var2 *= 2.0299999713897705F;
         var4 *= 0.5F;
      }

      return var3 / var5;
   }

   private static float noise(float var0, float var1, float var2) {
      int var3 = MathHelper.floor(var0);
      int var4 = MathHelper.floor(var1);
      int var5 = MathHelper.floor(var2);
      float var6 = var0 - (float)var3;
      float var7 = var1 - (float)var4;
      float var8 = var2 - (float)var5;
      var6 = var6 * var6 * (3.0F - 2.0F * var6);
      var7 = var7 * var7 * (3.0F - 2.0F * var7);
      var8 = var8 * var8 * (3.0F - 2.0F * var8);
      float var9 = MathHelper.lerp(
         var6, hash(var3, var4, var5), hash(var3 + (1), var4, var5)
      );
      float var10 = MathHelper.lerp(
         var6,
         hash(var3, var4 + (1), var5),
         hash(var3 + (1), var4 + (1), var5)
      );
      float var11 = MathHelper.lerp(
         var6,
         hash(var3, var4, var5 + (1)),
         hash(var3 + (1), var4, var5 + (1))
      );
      float var12 = MathHelper.lerp(
         var6,
         hash(var3, var4 + (1), var5 + (1)),
         hash(var3 + (1), var4 + (1), var5 + (1))
      );
      return MathHelper.lerp(var8, MathHelper.lerp(var7, var9, var10), MathHelper.lerp(var7, var11, var12));
   }

   private static float hash(int var0, int var1, int var2) {
      int var3 = var0 * (374761393) + var1 * (668265263) + var2 * (1274126177);
      var3 = (var3 ^ var3 >>> (13)) * (1274126177);
      return (float)((var3 ^ var3 >>> (16)) & (16777215)) / 16777215.0F;
   }

   private static float sq(float var0) {
      return var0 * var0;
   }

   void close() {
      this.starMesh.close();
      this.bandMesh.close();
      this.nebulaMesh.close();
      this.builtBrightness = -1.0F;
   }
}
