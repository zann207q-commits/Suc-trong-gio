package kaze.feature;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;

final class UiImageCache {
   private static final Map<String, BufferedImage> SOURCES = new HashMap<>();
   private static final Map<String, UiTextureData> CACHE = new HashMap<>();

   private UiImageCache() {
   }

   static UiTextureData get(String var0, int var1) {
      int var2 = Math.max(4, Math.min(512, var1));
      return CACHE.computeIfAbsent(var0 + "@" + var2, var2x -> {
         BufferedImage var3 = source(var0);
         if (var3 == null) {
            return null;
         } else {
            BufferedImage var4 = var3;

            while (var4.getWidth() / 2 >= var2) {
               var4 = resize(var4, var4.getWidth() / 2, var4.getHeight() / 2);
            }

            BufferedImage var5 = resize(var4, var2, var2);
            int[] var6 = new int[var2 * var2];
            var5.getRGB(0, 0, var2, var2, var6, 0, var2);

            for (int var7 = 0; var7 < var6.length; var7++) {
               var6[var7] = var6[var7] & 0xFF000000 | 16777215;
            }

            return new UiTextureData("img_" + var2x, var2, var2, var6);
         }
      });
   }

   private static BufferedImage source(String var0) {
      return SOURCES.computeIfAbsent(var0, var0x -> {
         byte var3 = -1;
         switch (var0x.hashCode()) {
            case 3327403:
               if (var0x.equals("logo")) {
                  var3 = 0;
               }
            default:
               String var1 = switch (var3) {
                  case 0 -> "/assets/kaze/textures/gui/kaze_mark.png";
                  default -> null;
               };
               if (var1 == null) {
                  return null;
               } else {
                   try {
                      BufferedImage var8;
                      try (InputStream var2 = UiImageCache.class.getResourceAsStream(var1)) {
                        var8 = var2 == null ? null : ImageIO.read(var2);
                     }

                     return var8;
                  } catch (Throwable var7) {
                     return null;
                  }
               }
         }
      });
   }

   private static BufferedImage resize(BufferedImage var0, int var1, int var2) {
      BufferedImage var3 = new BufferedImage(var1, var2, 2);
      Graphics2D var4 = var3.createGraphics();
      var4.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
      var4.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
      var4.drawImage(var0, 0, 0, var1, var2, null);
      var4.dispose();
      return var3;
   }
}
