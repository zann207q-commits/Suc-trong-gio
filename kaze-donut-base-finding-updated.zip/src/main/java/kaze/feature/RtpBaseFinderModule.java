package kaze.feature;

import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Optional;
import java.util.Random;
import kaze.Kaze;
import kaze.event.EventListener;
import kaze.event.events.TickEvent;
import kaze.mixin.MobSpawnerLogicAccessor;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.ModuleManager;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.ModeSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.Setting;
import kaze.module.setting.StringSetting;
import kaze.utils.BlockUtil;
import kaze.utils.EnchantmentUtil;
import kaze.utils.EncryptedString;
import kaze.utils.InventoryUtil;
import kaze.utils.embed.DiscordWebhook;
import kaze.utils.embed.DiscordWebhook.EmbedObject;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

public final class RtpBaseFinderModule extends Module {
   public final ModeSetting<RtpBaseFinderModule.Region> mode;
   private final BooleanSetting spawn;
   private final NumberSetting minStorage;
   private final BooleanSetting autoTotemBuy;
   private final NumberSetting totemSlot;
   private final BooleanSetting autoMend;
   private final NumberSetting xpBottleSlot;
   private final BooleanSetting discordNotification;
   private final StringSetting webhook;
   private final BooleanSetting totemCheck;
   private final NumberSetting totemCheckTime;
   private final NumberSetting digToY;
   private Vec3d currentPosition;
   private Vec3d previousPosition;
   private double idleTime;
   private double totemCheckCounter;
   private boolean isDigging;
   private boolean shouldDig;
   private boolean isRepairing;
   private boolean isBuyingTotem;
   private int selectedSlot;
   private int rtpCooldown;
   private int actionDelay;
   private int totemBuyCounter;
   private int spawnerCounter;

   public RtpBaseFinderModule() {
      super(EncryptedString.of("Rtp Base Finder"),
            EncryptedString.of("Automatically searches for bases on DonutSMP"), -1, Category.DONUT);
      mode = new ModeSetting<>(EncryptedString.of("Mode"), Region.RANDOM, Region.class);
      spawn = new BooleanSetting(EncryptedString.of("Spawners"), true);
      minStorage = new NumberSetting(EncryptedString.of("Minimum Storage"), 1.0, 500.0, 100.0, 1.0);
      autoTotemBuy = new BooleanSetting(EncryptedString.of("Auto Totem Buy"), true);
      totemSlot = new NumberSetting(EncryptedString.of("Totem Slot"), 1.0, 9.0, 8.0, 1.0);
      autoMend = new BooleanSetting(EncryptedString.of("Auto Mend"), true)
            .setDescription(EncryptedString.of("Automatically repairs pickaxe."));
      xpBottleSlot = new NumberSetting(EncryptedString.of("XP Bottle Slot"), 1.0, 9.0, 9.0, 1.0);
      discordNotification = new BooleanSetting(EncryptedString.of("Discord Notification"), false);
      webhook = new StringSetting(EncryptedString.of("Webhook"), "");
      totemCheck = new BooleanSetting(EncryptedString.of("Totem Check"), true);
      totemCheckTime = new NumberSetting(EncryptedString.of("Totem Check Time"), 1.0, 120.0, 20.0, 1.0);
      digToY = new NumberSetting(EncryptedString.of("Dig To Y"), -59.0, 30.0, -20.0, 1.0);
      addSettings(new Setting[]{mode, spawn, minStorage, autoTotemBuy, totemSlot, autoMend,
            xpBottleSlot, discordNotification, webhook, totemCheck, totemCheckTime, digToY});
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent event) {
      if (this.mc.player != null) {
         if (this.actionDelay > 0) {
            this.actionDelay--;
         } else {
            this.scanForEntities();
            if (this.autoTotemBuy.getValue()) {
               int slot = this.totemSlot.getIntValue() - 1;
               if (!this.mc.player.getInventory().getStack(slot).isOf(Items.TOTEM_OF_UNDYING)) {
                  if (this.totemBuyCounter < 30 && !this.isBuyingTotem) {
                     this.totemBuyCounter++;
                     return;
                  }

                  this.totemBuyCounter = 0;
                  this.isBuyingTotem = true;
                  if (this.mc.player.getInventory().getSelectedSlot() != slot) {
                     InventoryUtil.swap(slot);
                  }

                  ScreenHandler var9 = this.mc.player.currentScreenHandler;
                  if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler && ((GenericContainerScreenHandler)var9).getRows() == 3) {
                     if (var9.getSlot(11).getStack().isOf(Items.END_STONE)) {
                        this.mc.interactionManager.clickSlot(var9.syncId, 13, 0, SlotActionType.PICKUP, this.mc.player);
                        this.actionDelay = 10;
                        return;
                     }

                     if (var9.getSlot(16).getStack().isOf(Items.EXPERIENCE_BOTTLE)) {
                        this.mc.interactionManager.clickSlot(var9.syncId, 13, 0, SlotActionType.PICKUP, this.mc.player);
                        this.actionDelay = 10;
                        return;
                     }

                     this.dropHeldStack();
                     if (var9.getSlot(23).getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
                        this.mc.interactionManager.clickSlot(var9.syncId, 23, 0, SlotActionType.PICKUP, this.mc.player);
                        this.actionDelay = 10;
                        return;
                     }
                  }

                  this.openShop();
                  return;
               }

               if (this.isBuyingTotem) {
                  if (this.mc.currentScreen != null) {
                     this.mc.player.closeHandledScreen();
                     this.actionDelay = 20;
                  }

                  this.isBuyingTotem = false;
                  this.totemBuyCounter = 0;
               }
            }

            if (this.isRepairing) {
               int slotx = this.xpBottleSlot.getIntValue() - 1;
               ItemStack stack = this.mc.player.getInventory().getStack(slotx);
               if (this.mc.player.getInventory().getSelectedSlot() != slotx) {
                  InventoryUtil.swap(slotx);
               }

               if (!stack.isOf(Items.EXPERIENCE_BOTTLE)) {
                  ScreenHandler handler = this.mc.player.currentScreenHandler;
                  if (!(this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler)
                     || ((GenericContainerScreenHandler)handler).getRows() != 3) {
                     this.openShop();
                  } else if (handler.getSlot(11).getStack().isOf(Items.END_STONE)) {
                     this.mc.interactionManager.clickSlot(handler.syncId, 13, 0, SlotActionType.PICKUP, this.mc.player);
                     this.actionDelay = 10;
                  } else if (handler.getSlot(16).getStack().isOf(Items.EXPERIENCE_BOTTLE)) {
                     this.mc.interactionManager.clickSlot(handler.syncId, 16, 0, SlotActionType.PICKUP, this.mc.player);
                     this.actionDelay = 10;
                  } else if (handler.getSlot(17).getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
                     this.mc.interactionManager.clickSlot(handler.syncId, 17, 0, SlotActionType.PICKUP, this.mc.player);
                     this.actionDelay = 10;
                  } else {
                     this.dropHeldStack();
                     if (handler.getSlot(23).getStack().isOf(Items.LIME_STAINED_GLASS_PANE)) {
                        this.mc.interactionManager.clickSlot(handler.syncId, 23, 0, SlotActionType.PICKUP, this.mc.player);
                        this.actionDelay = 10;
                     } else {
                        this.openShop();
                     }
                  }
               } else if (this.mc.currentScreen != null) {
                  this.mc.player.closeHandledScreen();
                  this.actionDelay = 20;
               } else if (!EnchantmentUtil.hasEnchantment(this.mc.player.getOffHandStack(), Enchantments.MENDING)) {
                  this.mc
                     .interactionManager
                     .clickSlot(this.mc.player.currentScreenHandler.syncId, 36 + this.selectedSlot, 40, SlotActionType.SWAP, this.mc.player);
                  this.actionDelay = 20;
               } else if (this.mc.player.getOffHandStack().getDamage() > 0) {
                  if (this.mc.interactionManager.interactItem(this.mc.player, Hand.MAIN_HAND).isAccepted()) {
                     this.mc.player.swingHand(Hand.MAIN_HAND);
                  }

                  this.actionDelay = 1;
               } else {
                  this.mc
                     .interactionManager
                     .clickSlot(this.mc.player.currentScreenHandler.syncId, 36 + this.selectedSlot, 40, SlotActionType.SWAP, this.mc.player);
                  this.isRepairing = false;
               }
            } else {
               if (this.shouldDig) {
                  this.handleAutoEat();
               }

               if (this.totemCheck.getValue()) {
                  boolean hasTotem = this.mc.player.getOffHandStack().getItem().equals(Items.TOTEM_OF_UNDYING);
                  Module autoTotem = Kaze.INSTANCE.MODULE_MANAGER.getModuleByClass(AutoTotemModule.class);
                  if (!hasTotem && (!autoTotem.isEnabled() || ((AutoTotemModule)autoTotem).findItemSlot(Items.TOTEM_OF_UNDYING) == -1)) {
                     this.totemCheckCounter++;
                  } else {
                     this.totemCheckCounter = 0.0;
                  }

                  if (this.totemCheckCounter > this.totemCheckTime.getValue()) {
                     this.notifyTotemExplosion("Your totem exploded", (int)this.mc.player.getX(), (int)this.mc.player.getY(), (int)this.mc.player.getZ());
                     return;
                  }
               }

               if (this.rtpCooldown > 0) {
                  this.rtpCooldown--;
                  if (this.rtpCooldown <= 0) {
                     if (this.previousPosition != null && this.previousPosition.distanceTo(this.mc.player.getEntityPos()) < 100.0) {
                        this.sendRtpCommand();
                        return;
                     }

                     this.mc.player.setPitch(89.9F);
                     ItemStack var6;
                     if (this.autoMend.getValue()
                        && EnchantmentUtil.hasEnchantment(var6 = this.mc.player.getMainHandStack(), Enchantments.MENDING)
                        && var6.getMaxDamage() - var6.getDamage() < 100) {
                        this.isRepairing = true;
                        this.selectedSlot = this.mc.player.getInventory().getSelectedSlot();
                     }

                     this.shouldDig = true;
                  }
               } else {
                  if (this.currentPosition != null && this.currentPosition.distanceTo(this.mc.player.getEntityPos()) < 2.0) {
                     this.idleTime++;
                  } else {
                     this.currentPosition = this.mc.player.getEntityPos();
                     this.idleTime = 0.0;
                  }

                  if (this.idleTime > 20.0 && this.isDigging) {
                     this.sendRtpCommand();
                     this.isDigging = false;
                  } else if (this.idleTime > 200.0) {
                     this.sendRtpCommand();
                     this.idleTime = 0.0;
                  } else {
                     if (this.mc.player.getY() < this.digToY.getIntValue() && !this.isDigging) {
                        this.isDigging = true;
                        this.shouldDig = false;
                     }
                  }
               }
            }
         }
      }
   }

   private void openShop() {
      this.mc.getNetworkHandler().sendChatCommand("shop");
      this.actionDelay = 10;
   }

   private void dropHeldStack() {
      this.mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(Action.DROP_ALL_ITEMS, BlockPos.ORIGIN, Direction.DOWN));
   }

   private void sendRtpCommand() {
      this.shouldDig = false;
      ClientPlayNetworkHandler var1 = this.mc.getNetworkHandler();
      RtpBaseFinderModule.Region var2;
      if (this.mode.getValue() == RtpBaseFinderModule.Region.RANDOM) {
         var2 = this.getRandomMode();
      } else {
         var2 = (RtpBaseFinderModule.Region)this.mode.getValue();
      }

      var1.sendChatCommand("rtp " + this.getModeName(var2));
      this.rtpCooldown = 150;
      this.idleTime = 0.0;
      this.previousPosition = this.mc.player.getEntityPos();
   }

   private void disconnectWithMessage(Text var1) {
      MutableText var2 = Text.literal("[RTPBaseFinder] ");
      var2.append(var1);
      this.toggle();
      this.mc.player.networkHandler.onDisconnect(new DisconnectS2CPacket(var2));
   }

   private RtpBaseFinderModule.Region getRandomMode() {
      RtpBaseFinderModule.Region[] var10000 = new RtpBaseFinderModule.Region[6];
      var10000[0] = RtpBaseFinderModule.Region.EUCENTRAL;
      var10000[1] = RtpBaseFinderModule.Region.EUWEST;
      var10000[2] = RtpBaseFinderModule.Region.EAST;
      var10000[3] = RtpBaseFinderModule.Region.WEST;
      var10000[4] = RtpBaseFinderModule.Region.ASIA;
      var10000[5] = RtpBaseFinderModule.Region.OCEANIA;
      RtpBaseFinderModule.Region[] var1 = var10000;
      return var1[new Random().nextInt(var1.length)];
   }

   private String getModeName(RtpBaseFinderModule.Region mode) {
      return switch (mode) {
         case EUCENTRAL -> "eu central";
         case EUWEST -> "eu west";
         default -> mode.name();
      };
   }

   private void handleAutoEat() {
      Module var1 = Kaze.INSTANCE.MODULE_MANAGER.getModuleByClass(AutoEatModule.class);
      if (!var1.isEnabled()) {
         this.handleBlockBreaking(true);
      } else if (!((AutoEatModule)var1).shouldEat()) {
         this.handleBlockBreaking(true);
      }
   }

   private void handleBlockBreaking(boolean var1) {
      if (this.mc.player.getPitch() != 89.9000015258789F) {
         this.mc.player.setPitch(89.9000015258789F);
      }

      if (!this.mc.player.isUsingItem()) {
         if (var1 && this.mc.crosshairTarget != null && this.mc.crosshairTarget.getType() == Type.BLOCK) {
            BlockHitResult var2 = (BlockHitResult)this.mc.crosshairTarget;
            BlockPos var3 = ((BlockHitResult)this.mc.crosshairTarget).getBlockPos();
            if (!this.mc.world.getBlockState(var3).isAir()) {
               Direction var4 = var2.getSide();
               if (this.mc.interactionManager.updateBlockBreakingProgress(var3, var4)) {
                  this.mc.player.swingHand(Hand.MAIN_HAND);
               }
            }
         } else {
            this.mc.interactionManager.cancelBlockBreaking();
         }
      }
   }

   private void scanForEntities() {
      int var1 = 0;
      int var2 = 0;
      BlockPos var3 = null;
      Iterator var4 = BlockUtil.getLoadedChunks().iterator();

      while (var4.hasNext()) {
         for (Object var6 : ((WorldChunk)var4.next()).getBlockEntityPositions()) {
            BlockEntity var7 = this.mc.world.getBlockEntity((BlockPos)var6);
            if (this.spawn.getValue() && var7 instanceof MobSpawnerBlockEntity) {
               String var8 = ((MobSpawnerLogicAccessor)((MobSpawnerBlockEntity)var7).getLogic())
                  .getSpawnEntry()
                  .getNbt()
                  .getString("id")
                  .orElse("");
               if (!var8.equals("minecraft:cave_spider")
                  && !var8.equals("minecraft:spider")) {
                  var2++;
                  var3 = (BlockPos)var6;
               }
            }

            if (var7 instanceof ChestBlockEntity
               || var7 instanceof EnderChestBlockEntity
               || var7 instanceof ShulkerBoxBlockEntity
               || var7 instanceof FurnaceBlockEntity
               || var7 instanceof BarrelBlockEntity
               || var7 instanceof EnchantingTableBlockEntity) {
               var1++;
            }
         }
      }

      if (var2 > 0) {
         this.spawnerCounter += 1;
      } else {
         this.spawnerCounter = 0;
      }

      if (this.spawnerCounter > (10)) {
         this.notifyBaseOrSpawner(
            "YOU FOUND SPAWNER",
            var3.getX(),
            var3.getY(),
            var3.getZ(),
            false
         );
         this.spawnerCounter = 0;
      }

      if (var1 > this.minStorage.getIntValue()) {
         this.notifyBaseOrSpawner(
            "YOU FOUND BASE",
            (int)this.mc.player.getX(),
            (int)this.mc.player.getY(),
            (int)this.mc.player.getZ(),
            true
         );
      }
   }

   private void notifyBaseOrSpawner(String var1, int var2, int var3, int var4, boolean var5) {
      String var6;
      if (var5) {
         var6 = "Base";
      } else {
         var6 = "Spawner";
      }

      if (this.discordNotification.getValue()) {
         DiscordWebhook var7 = new DiscordWebhook(this.webhook.value);
         EmbedObject var8 = new EmbedObject();
         var8.setTitle(var6);
         var8.setThumbnail("https://render.crafty.gg/3d/bust/" + MinecraftClient.getInstance().getSession().getUuidOrNull() + "?format=webp");
         var8.setDescription(var6 + " Found - " + MinecraftClient.getInstance().getSession().getUsername());
         var8.setColor(Color.GRAY);
         var8.setFooter(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")), null);
         var8.addField(var6 + "Found at", "x: " + var2 + " y: " + var3 + " z: " + var4, true);
         var7.addEmbed(var8);

         try {
            var7.execute();
         } catch (Throwable var10) {
         }
      }

      this.toggle();
      this.disconnectWithMessage(Text.of(var1));
   }

   private void notifyTotemExplosion(String var1, int var2, int var3, int var4) {
      if (this.discordNotification.getValue()) {
         DiscordWebhook var5 = new DiscordWebhook(this.webhook.value);
         EmbedObject var6 = new EmbedObject();
         var6.setTitle("Totem Exploded");
         var6.setThumbnail("https://render.crafty.gg/3d/bust/" + MinecraftClient.getInstance().getSession().getUuidOrNull() + "?format=webp");
         var6.setDescription("Your Totem Exploded - " + MinecraftClient.getInstance().getSession().getUsername());
         var6.setColor(Color.RED);
         var6.setFooter(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")), null);
         var6.addField(
            "Location",
            "x: " + var2 + " y: " + var3 + " z: " + var4,
            true
         );
         var5.addEmbed(var6);

         try {
            var5.execute();
         } catch (Throwable var8) {
         }
      }

      this.disconnectWithMessage(Text.of(var1));
   }

   public boolean isRepairingActive() {
      return this.isRepairing;
   }

   static enum Region {
      EUCENTRAL("eucentral", 0),
      EUWEST("euwest", 1),
      EAST("east", 2),
      WEST("west", 3),
      ASIA("asia", 4),
      OCEANIA("oceania", 5),
      RANDOM("random", 6);

      private Region(final String name, final int ordinal) {
      }
   }
}
