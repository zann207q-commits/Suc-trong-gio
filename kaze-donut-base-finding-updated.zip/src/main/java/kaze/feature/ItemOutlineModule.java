package kaze.feature;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import java.awt.Color;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import kaze.Kaze;
import kaze.mixin.RenderLayerAccessor;
import kaze.mixin.RenderPipelinesAccessor;
import kaze.mixin.RenderSetupAccessor;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.ModuleManager;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.Setting;
import kaze.module.setting.StorageBlocksSetting;
import kaze.module.setting.StorageBlocksSetting.Entry;
import kaze.utils.ColorUtil;
import kaze.utils.EncryptedString;
import net.minecraft.client.render.OutlineVertexConsumerProvider;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.RenderSetup.Builder;
import net.minecraft.client.render.RenderSetup.OutlineMode;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.item.ItemRenderState.Glint;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;

public final class ItemOutlineModule extends Module {
   private final StorageBlocksSetting color;
   private final BooleanSetting rainbow;
   private final NumberSetting rainbowSpeed;
   private final BooleanSetting pulse;
   private final NumberSetting thickness;
   private final NumberSetting fade;
   private static final Map<RenderLayer, RenderLayer> OUTLINE_LAYERS = new WeakHashMap<>();
   private static volatile boolean renderingOutline;
   private static volatile boolean failed;
   private static RenderPipeline outlinePipeline;
   private static boolean pipelineAttempted;

   public ItemOutlineModule() {
      super(EncryptedString.of("Item Outline"),
            EncryptedString.of("Adds an animated neon outline to items in your first-person hands"),
            -1, Category.RENDER);
      color = new StorageBlocksSetting(EncryptedString.of("Color"))
            .add("outline", "Outline", Items.GLOWSTONE_DUST, true, new Color(255, 75, 255))
            .colorOnly();
      rainbow = new BooleanSetting(EncryptedString.of("Rainbow"), false)
            .setDescription(EncryptedString.of("Cycles the outline through the rainbow"));
      rainbowSpeed = new NumberSetting(EncryptedString.of("Rainbow Speed"), 0.1, 10.0, 2.0, 0.1);
      pulse = new BooleanSetting(EncryptedString.of("Pulse"), true)
            .setDescription(EncryptedString.of("Makes the glow breathe in and out"));
      thickness = new NumberSetting(EncryptedString.of("Thickness"), 1.0, 15.0, 5.0, 0.5);
      fade = new NumberSetting(EncryptedString.of("Fade"), 0.0, 100.0, 75.0, 1.0)
            .getValue(EncryptedString.of("Softens the outer glow; 0 keeps only the crisp rim"));
      addSettings(new Setting[]{color, rainbow, rainbowSpeed, pulse, thickness, fade});
   }

   private int currentRgb() {
      Color selected = rainbow.getValue()
            ? ColorUtil.rainbow(rainbowSpeed.getValue(), 0, 255)
            : color.entries().get(0).color();
      return (selected.getRed() & 255) << 16
            | (selected.getGreen() & 255) << 8
            | selected.getBlue() & 255;
   }

   public static void renderHeldItem(
      ItemDisplayContext display,
      MatrixStack matrices,
      VertexConsumerProvider vertices,
      int light,
      int overlay,
      int[] colors,
      List<BakedQuad> quads,
      RenderLayer originalLayer
   ) {
      if (!failed && !renderingOutline && isFirstPersonHand(display)) {
         ItemOutlineModule module;
         if ((module = getModule()) != null && module.isEnabled()) {
            RenderLayer outlineLayer;
            if ((outlineLayer = getOutlineLayer(originalLayer)) != null) {
               renderingOutline = true;

               try {
                  OutlineVertexConsumerProvider outlines = new OutlineVertexConsumerProvider();
                  float thickness = module.thickness.getFloatValue() * 0.01F;
                  float fade = (float)module.fade.getValue() / 100.0F;
                  int rgb = module.currentRgb();
                  float pulse = 1.0F;
                  if (module.pulse.getValue()) {
                     pulse = 0.72F + 0.28F * (float)(0.5 + 0.5 * Math.sin(System.nanoTime() / 4.2E8));
                  }

                  for (int layer = 3; layer > 0; layer--) {
                     float layerPulse = layer == 1 ? 1.0F : pulse;
                     float expansion = thickness * layer / 3.0F * (layer == 1 ? 1.0F : 0.85F + 0.3F * pulse);
                     int alpha = layer == 1 ? 255 : Math.round(255.0F * fade * (layer == 2 ? 0.52F : 0.24F) * layerPulse);
                     outlines.setColor(alpha << 24 | rgb);
                     matrices.push();

                     try {
                        matrices.translate(0.5, 0.5, 0.5);
                        matrices.scale(expansion + 1.0F, expansion + 1.0F, expansion + 1.0F);
                        matrices.translate(-0.5, -0.5, -0.5);
                        ItemRenderer.renderItem(display, matrices, outlines, light, overlay, colors, quads, outlineLayer, Glint.NONE);
                        outlines.draw();
                     } finally {
                        matrices.pop();
                     }
                  }

                  return;
               } catch (Throwable var28) {
                  failed = true;
                  System.err.println("Kaze: held-item outline disabled after render error: " + var28);
               } finally {
                  renderingOutline = false;
               }
            }
         }
      }
   }

   private static ItemOutlineModule getModule() {
      try {
         if (Kaze.INSTANCE == null || Kaze.INSTANCE.getModuleManager() == null) {
            return null;
         }
         Module module = Kaze.INSTANCE.getModuleManager().getModuleByClass(ItemOutlineModule.class);
         return module instanceof ItemOutlineModule outline ? outline : null;
      } catch (Throwable ignored) {
         return null;
      }
   }

   private static boolean isFirstPersonHand(ItemDisplayContext display) {
      return display == ItemDisplayContext.FIRST_PERSON_LEFT_HAND
            || display == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
   }

   private static RenderLayer getOutlineLayer(RenderLayer original) {
      if (original == null) {
         return null;
      }
      RenderLayer cached = OUTLINE_LAYERS.get(original);
      if (cached != null) {
         return cached;
      }

      try {
         RenderSetup setup = ((RenderLayerAccessor) original).kaze$getRenderSetup();
         Map<?, ?> textures = ((RenderSetupAccessor) (Object) setup).kaze$getTextures();
         Object sampler = textures == null ? null : textures.get("Sampler0");
         if (sampler == null) {
            return null;
         }
         Method location = sampler.getClass().getDeclaredMethod("location");
         location.setAccessible(true);
         Identifier texture = (Identifier) location.invoke(sampler);
         if (texture == null) {
            return null;
         }
         Builder builder = RenderSetup.builder(getOutlinePipeline());
         builder.texture("Sampler0", texture);
         builder.outlineMode(OutlineMode.IS_OUTLINE);
         RenderLayer outline = RenderLayerAccessor.kaze$create("kaze_held_item_outline", builder.build());
         OUTLINE_LAYERS.put(original, outline);
         return outline;
      } catch (Throwable failure) {
         failed = true;
         System.err.println("Kaze: could not create held-item outline layer: " + failure);
         return null;
      }
   }

   private static RenderPipeline getOutlinePipeline() {
      if (pipelineAttempted) {
         return outlinePipeline;
      } else {
         synchronized (ItemOutlineModule.class) {
            if (pipelineAttempted) {
               return outlinePipeline;
            } else {
               try {
                  Snippet outlineSnippet = RenderPipelinesAccessor.kaze$getOutlineSnippet();
                  outlinePipeline = RenderPipelinesAccessor.kaze$register(
                     RenderPipeline.builder(new Snippet[]{outlineSnippet})
                        .withLocation("pipeline/kaze_held_item_outline")
                        .withFragmentShader("core/kaze_held_item_outline")
                        .withBlend(BlendFunction.TRANSLUCENT)
                        .build()
                  );
               } catch (Throwable var7) {
                  failed = true;
                  System.err.println("Kaze: could not register held-item outline pipeline: " + var7);
               } finally {
                  pipelineAttempted = true;
               }

               return outlinePipeline;
            }
         }
      }
   }

}
