package kaze.feature;

import java.util.UUID;
import kaze.utils.ext.NameFilter;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.util.Formatting;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.math.ColorHelper;

public final class PlayerWatchHud {
   private static final float LIFE_SECONDS = 1.5F;
   private static final float TITLE_SECONDS = 1.25F;
   private static final int TITLE_IN = 10;
   private static final int TITLE_STAY = 40;
   private static final int TITLE_OUT = 15;
   private static final float NOTE_SECONDS = 4.5F;
   private static final Text NOTE = Text.literal("Goodluck Kaze User, Be Careful");
   private static final int NOTE_COLOR = 16777045;
   private static UUID watcher;
   private static boolean hidden;
   private static String title;
   private static int stage;
   private static long startNanos;
   private static long noteNanos;
   private static boolean active;

   private PlayerWatchHud() {
   }

   public static void watching(UUID var0, String var1, int var2) {
      MinecraftClient var3 = MinecraftClient.getInstance();
      if (var3.world != null && var1 != null) {
         String var4 = NameFilter.apply(var1);
         watcher = var0;
         hidden = !var4.equals(var1);
         title = var2 > 0 ? var4 + " +" + var2 : var4;
         stage = 0;
         startNanos = System.nanoTime();
         noteNanos = 0L;
         active = true;
      }
   }

   public static boolean hasWork() {
      if (active && MinecraftClient.getInstance().world == null) {
         active = false;
      }

      return active || noteNanos != 0L;
   }

   public static void render(DrawContext var0) {
      if (hasWork()) {
         if (active) {
            MinecraftClient var1 = MinecraftClient.getInstance();
            float var2 = (float)(System.nanoTime() - startNanos) / 1.0E9F;
            if (stage == 0 && var2 >= 1.25F) {
               stage = 1;
               var1.inGameHud.setTitleTicks(10, 40, 15);
               var1.inGameHud.setSubtitle(Text.literal("WATCHING YOU").formatted(new Formatting[]{Formatting.RED, Formatting.BOLD}));
               var1.inGameHud.setTitle(Text.literal(title).formatted(new Formatting[]{Formatting.RED, Formatting.BOLD}));
            } else if (stage == 1 && var2 >= 4.5F) {
               stage = 2;
               var1.inGameHud.setDefaultTitleFade();
               noteNanos = System.nanoTime();
               active = false;
            }

            if (active && var2 < 1.5F && watcher != null) {
               drawFace(var0, var1, var2 / 1.5F);
            }
         }

         renderNote(var0);
      }
   }

   private static void drawFace(DrawContext var0, MinecraftClient var1, float var2) {
      SkinTextures var3 = null;
      if (!hidden && var1.getNetworkHandler() != null) {
         PlayerListEntry var4 = var1.getNetworkHandler().getPlayerListEntry(watcher);
         if (var4 != null) {
            var3 = var4.getSkinTextures();
         }
      }

      if (var3 == null) {
         var3 = DefaultSkinHelper.getSkinTextures(watcher);
      }

      float var11 = 0.05F + 0.6F * (float)Math.sin((double)var2 * Math.PI);
      double var5 = Math.toRadians(60.0 - 150.0 * (double)var2);
      float var7 = (float)Math.cos(var5);
      float var8 = (float)var0.getScaledWindowHeight() * 0.42F;
      var0.getMatrices().pushMatrix();
      var0.getMatrices().translate((float)var0.getScaledWindowWidth() / 2.0F, (float)var0.getScaledWindowHeight() / 2.0F - var8 * 0.08F);
      var0.getMatrices().scale(Math.max(0.04F, Math.abs(var7)), 1.0F);
      int var9 = Math.round(var8);
      int var10 = ColorHelper.withAlpha(Math.round(Math.max(0.0F, Math.min(1.0F, var11)) * 255.0F), 16777215);
      PlayerSkinDrawer.draw(var0, var3, -var9 / 2, -var9 / 2, var9, var10);
      var0.getMatrices().popMatrix();
   }

   private static void renderNote(DrawContext var0) {
      if (noteNanos != 0L) {
         float var1 = (float)(System.nanoTime() - noteNanos) / 1.0E9F;
         if (var1 >= 4.0F) {
            noteNanos = 0L;
         } else {
            float var2 = var1 < 0.5F ? var1 / 0.5F : Math.min(1.0F, (4.0F - var1) / 1.0F);
            int var3 = Math.round(var2 * 255.0F);
            if (var3 > 8) {
               TextRenderer var4 = MinecraftClient.getInstance().textRenderer;
               var0.getMatrices().pushMatrix();
               var0.getMatrices().translate((float)var0.getScaledWindowWidth() / 2.0F, (float)var0.getScaledWindowHeight() / 2.0F);
               var0.getMatrices().scale(2.0F, 2.0F);
               var0.drawText(var4, NOTE, -var4.getWidth(NOTE) / 2, -4, ColorHelper.withAlpha(var3, 16777045), true);
               var0.getMatrices().popMatrix();
            }
         }
      }
   }
}
