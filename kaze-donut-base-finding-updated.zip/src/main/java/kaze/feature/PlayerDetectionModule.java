package kaze.feature;

import java.awt.Color;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;
import kaze.event.EventListener;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.Setting;
import kaze.module.setting.StringSetting;
import kaze.utils.EncryptedString;
import kaze.utils.embed.DiscordWebhook;
import kaze.utils.embed.DiscordWebhook.EmbedObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.ClientConnection;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;

public final class PlayerDetectionModule extends Module {
   private final BooleanSetting notifications;
   private final StringSetting whitelist;
   private final BooleanSetting disconnect;
   private final BooleanSetting disableOnDetect;
   private final BooleanSetting stopBaritone;
   private final BooleanSetting webhook;
   private final StringSetting webhookUrl;
   private final BooleanSetting panicPay;
   private final StringSetting panicPayTarget;
   private final StringSetting panicPayAmount;
   private final Set<String> detectedPlayers;
   private int scanDelay;

   public PlayerDetectionModule() {
      super(EncryptedString.of("Player Detection"),
            EncryptedString.of("Alerts and optionally disconnects when another player enters view"),
            -1, Category.MISC);
      notifications = new BooleanSetting(EncryptedString.of("Chat Alerts"), true);
      whitelist = new StringSetting(EncryptedString.of("Whitelist"), "FreeCamera")
            .setDescription(EncryptedString.of("Comma-separated player names to ignore"));
      disconnect = new BooleanSetting(EncryptedString.of("Disconnect"), true);
      disableOnDetect = new BooleanSetting(EncryptedString.of("Disable On Detect"), true);
      stopBaritone = new BooleanSetting(EncryptedString.of("Stop Baritone"), true);
      webhook = new BooleanSetting(EncryptedString.of("Webhook"), false);
      webhookUrl = new StringSetting(EncryptedString.of("Discord Webhook"), "");
      panicPay = new BooleanSetting(EncryptedString.of("Panic Pay"), false);
      panicPayTarget = new StringSetting(EncryptedString.of("Panic Pay Target"), "");
      panicPayAmount = new StringSetting(EncryptedString.of("Panic Pay Amount"), "");
      detectedPlayers = new HashSet<>();
      addSettings(new Setting[]{notifications, whitelist, disconnect, disableOnDetect, stopBaritone,
            webhook, webhookUrl, panicPay, panicPayTarget, panicPayAmount});
   }

   public void onEnable() {
      this.detectedPlayers.clear();
      this.scanDelay = 0;
      super.onEnable();
   }

   public void onDisable() {
      this.detectedPlayers.clear();
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         int var10000 = this.scanDelay;
         this.scanDelay += 1;
         if (var10000 <= 0 || this.scanDelay >= (10)) {
            this.scanDelay = 0;
            Set var2 = this.parseWhitelist();
            HashSet var3 = new HashSet();

            for (PlayerEntity var5 : this.mc.world.getPlayers()) {
               if (var5 != this.mc.player && !var5.isRemoved()) {
                  String var6 = var5.getName().getString();
                  if (!var2.contains(var6.toLowerCase(Locale.ROOT))) {
                     var3.add(var6);
                  }
               }
            }

            HashSet var7 = new HashSet(var3);
            var7.removeAll(this.detectedPlayers);
            this.detectedPlayers.clear();
            this.detectedPlayers.addAll(var3);
            if (!var7.isEmpty()) {
               this.handleDetection(var7);
            }
         }
      } else {
         this.detectedPlayers.clear();
      }
   }

   private Set<String> parseWhitelist() {
      HashSet var1 = new HashSet();
      var1.add("freecamera");
      Arrays.stream(this.whitelist.getValue().split("[,;\\s]+"))
         .map(var0 -> var0.trim().toLowerCase(Locale.ROOT))
         .filter(var0 -> ((!var0.isBlank())))
         .forEach(var1::add);
      return var1;
   }

   private void handleDetection(Set<String> var1) {
      String var2 = String.join(", ", var1);
      if (this.notifications.getValue()) {
         this.mc.player.sendMessage(Text.literal("§c[Player Detection] §fPlayer(s) detected: §e" + var2), false);
      }

      if (this.stopBaritone.getValue() && this.mc.getNetworkHandler() != null) {
         this.mc.getNetworkHandler().sendChatMessage("#stop");
      }

      if (this.panicPay.getValue()
         && this.mc.getNetworkHandler() != null
         && !this.panicPayTarget.getValue().isBlank()
         && !this.panicPayAmount.getValue().isBlank()) {
         this.mc.getNetworkHandler().sendChatCommand("pay " + this.panicPayTarget.getValue().trim() + " " + this.panicPayAmount.getValue().trim());
      }

      if (this.webhook.getValue()) {
         this.sendWebhook(var2);
      }

      if (this.disableOnDetect.getValue()) {
         this.toggle(false);
      }

      if (this.disconnect.getValue()) {
         CompletableFuture.delayedExecutor(500L, TimeUnit.MILLISECONDS).execute(() -> this.mc.execute(() -> {
               if (this.mc.getNetworkHandler() != null) {
                  this.mc.getNetworkHandler().getConnection().disconnect(Text.literal("Player(s) detected: " + var2));
               }
            }));
      }
   }

   private void sendWebhook(String names) {
      String url = webhookUrl.getValue();
      if (url.isBlank()) {
         if (notifications.getValue()) {
            mc.player.sendMessage(Text.literal("§c[Player Detection] Webhook URL is empty."), false);
         }
         return;
      }

      String server = mc.getCurrentServerEntry() == null
            ? "Single Player" : mc.getCurrentServerEntry().address;
      CompletableFuture.runAsync(() -> {
         try {
            DiscordWebhook message = new DiscordWebhook(url);
            message.addEmbed(new EmbedObject()
                  .setTitle("Player Detection Alert")
                  .setDescription("Player(s) detected: " + names)
                  .setColor(new Color(231, 76, 60))
                  .addField("Server", server, true));
            message.execute();
         } catch (Throwable failure) {
            System.err.println("Kaze Player Detection webhook failed: " + failure.getMessage());
         }
      });
   }

}
