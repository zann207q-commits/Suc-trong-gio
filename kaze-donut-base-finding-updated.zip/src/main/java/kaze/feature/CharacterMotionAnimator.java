package kaze.feature;

import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import kaze.feature.BoneMotionProfile.MotionFrame;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.model.ModelPart;

@Environment(EnvType.CLIENT)
final class CharacterMotionAnimator {
   private static final long CONSTANT_0055 = 20000000000L;
   private static final Int2ObjectOpenHashMap<MotionState> STATES = new Int2ObjectOpenHashMap();
   private static final MotionFrame INPUT = new MotionFrame();
   private static final float[] CONSTANT_0101 = new float[3];
   private static long numericState0002;

   private CharacterMotionAnimator() {
   }

   static float[] update(PlayerEntityRenderState var0, BakedCharacterData var1, PlayerEntityModel var2, float[] var3) {
      if (var1.motionSlots == 0) {
         return null;
      } else {
         long var4 = System.nanoTime();
         prune(var4);
         MotionState var6 = (MotionState)STATES.get(var0.id);
         if (var6 == null || var6.model != var1) {
            var6 = new MotionState(var1);
            var6.bodyRot = var0.bodyYaw;
            STATES.put(var0.id, var6);
         }

         float var7 = var6.nanos == (0L)
            ? 0.0F
            : (float)(var4 - var6.nanos) / 1000000000.0F;
         if (var6.nanos != (0L) && var7 < 0.0005000000237487257F) {
            return var6.angles;
         } else {
            var6.nanos = var4;
            float var8 = MathHelper.wrapDegrees(var0.bodyYaw - var6.bodyRot);
            var6.bodyRot = var0.bodyYaw;
            if (var7 > 0.0F && var7 < 0.25F) {
               var6.turnRate = var6.turnRate
                  + (var8 / var7 - var6.turnRate)
                     * Math.min(1.0F, var7 * 12.0F);
            } else {
               var6.turnRate = 0.0F;
            }

            MotionFrame var9 = INPUT;
            var9.time = var0.age / 20.0F;
            var9.walkPos = var0.limbSwingAnimationProgress;
            var9.walkSpeed = var0.limbSwingAmplitude;
            var9.turnRate = var6.turnRate;
            bone(var9, CharacterBone.HEAD, var2.head, var3);
            bone(var9, CharacterBone.BODY, var2.body, var3);
            bone(var9, CharacterBone.RIGHT_ARM, var2.rightArm, var3);
            bone(var9, CharacterBone.LEFT_ARM, var2.leftArm, var3);
            bone(var9, CharacterBone.RIGHT_LEG, var2.rightLeg, var3);
            bone(var9, CharacterBone.LEFT_LEG, var2.leftLeg, var3);
            BakedCharacterPart[] var10 = var1.parts;
            int var11 = var10.length;

            for (int var12 = 0; var12 < var11; var12++) {
               BakedCharacterPart var13 = var10[var12];
               if (var13.motionSlot >= 0 && var13.motion != null) {
                  var13.motion.target(var9, var13.bone, CONSTANT_0101);
                  var13.motion.step(var6.spring, var13.motionSlot * (6), CONSTANT_0101, var7);
                  System.arraycopy(
                     var6.spring,
                     var13.motionSlot * (6),
                     var6.angles,
                     var13.motionSlot * (3),
                     3
                  );
               }
            }

            return var6.angles;
         }
      }
   }

   private static void bone(MotionFrame var0, CharacterBone var1, ModelPart var2, float[] var3) {
      int var4 = var1.ordinal();
      var0.pitch[var4] = var3[var4];
      var0.yaw[var4] = -var2.yaw;
      var0.roll[var4] = -var2.roll;
   }

   private static void prune(long var0) {
      if (var0 - numericState0002 >= (5000000000L)) {
         numericState0002 = var0;
         STATES.values()
            .removeIf(var2 -> ((var0 - var2.nanos > (20000000000L))));
      }
   }

   static void clear() {
      STATES.clear();
   }

   private static final class MotionState {
      final BakedCharacterData model;
      final float[] spring;
      final float[] angles;
      float bodyRot;
      float turnRate;
      long nanos;

      MotionState(BakedCharacterData var1) {
         this.model = var1;
         this.spring = new float[var1.motionSlots * (6)];
         this.angles = new float[var1.motionSlots * (3)];

         for (int var2 = 0; var2 < var1.motionSlots; var2++) {
            this.spring[var2 * (6)] = Float.intBitsToFloat(2143289344);
         }
      }
   }
}
