package kaze.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class PerlinNoise {
   private static final int[] PERM = new int[512];

   private PerlinNoise() {
   }

   public static float noise(float var0, float var1, float var2) {
      int var3 = floor(var0);
      int var4 = floor(var1);
      int var5 = floor(var2);
      float var6 = var0 - (float)var3;
      float var7 = var1 - (float)var4;
      float var8 = var2 - (float)var5;
      int var9 = var3 & (255);
      int var10 = var4 & (255);
      int var11 = var5 & (255);
      float var12 = fade(var6);
      float var13 = fade(var7);
      float var14 = fade(var8);
      int var15 = PERM[var9] + var10;
      int var16 = PERM[var15] + var11;
      int var17 = PERM[var15 + (1)] + var11;
      int var18 = PERM[var9 + (1)] + var10;
      int var19 = PERM[var18] + var11;
      int var20 = PERM[var18 + (1)] + var11;
      float var21 = lerp(
         grad(PERM[var16], var6, var7, var8),
         grad(PERM[var19], var6 - 1.0F, var7, var8),
         var12
      );
      float var22 = lerp(
         grad(PERM[var17], var6, var7 - 1.0F, var8),
         grad(
            PERM[var20], var6 - 1.0F, var7 - 1.0F, var8
         ),
         var12
      );
      float var23 = lerp(var21, var22, var13);
      float var24 = lerp(
         grad(
            PERM[var16 + (1)], var6, var7, var8 - 1.0F
         ),
         grad(
            PERM[var19 + (1)],
            var6 - 1.0F,
            var7,
            var8 - 1.0F
         ),
         var12
      );
      float var25 = lerp(
         grad(
            PERM[var17 + (1)],
            var6,
            var7 - 1.0F,
            var8 - 1.0F
         ),
         grad(
            PERM[var20 + (1)],
            var6 - 1.0F,
            var7 - 1.0F,
            var8 - 1.0F
         ),
         var12
      );
      return lerp(var23, lerp(var24, var25, var13), var14);
   }

   public static float noise(float var0, float var1) {
      return noise(var0, var1, 0.3700000047683716F);
   }

   public static float fbm(float var0, float var1, float var2, int var3) {
      float var4 = 0.0F;
      float var5 = 0.5F;
      float var6 = 0.0F;

      for (int var7 = 0; var7 < var3; var7++) {
         var4 += var5 * noise(var0, var1, var2);
         var6 += var5;
         var0 = var0 * 2.0299999713897705F + 17.100000381469727F;
         var1 = var1 * 2.0299999713897705F - 4.699999809265137F;
         var2 = var2 * 2.0299999713897705F + 9.300000190734863F;
         var5 *= 0.5F;
      }

      return var4 / var6;
   }

   public static float fbm(float var0, float var1, int var2) {
      return fbm(var0, var1, 0.3700000047683716F, var2);
   }

   public static float hash(int var0, int var1, int var2) {
      int var3 = var0 * (522133279) ^ var1 * (1540483477) ^ var2 * (668265263);
      var3 ^= var3 >>> (13);
      var3 *= -2048144789;
      var3 ^= var3 >>> (16);
      return (float)(var3 & (65535)) / 65535.0F;
   }

   private static int floor(float var0) {
      int var1 = (int)var0;
      return var0 < (float)var1 ? var1 - (1) : var1;
   }

   private static float fade(float var0) {
      return var0
         * var0
         * var0
         * (
            var0 * (var0 * 6.0F - 15.0F)
               + 10.0F
         );
   }

   private static float lerp(float var0, float var1, float var2) {
      return var0 + (var1 - var0) * var2;
   }

   private static float grad(int var0, float var1, float var2, float var3) {
      int var4 = var0 & (15);
      float var5 = var4 < (8) ? var1 : var2;
      float var6 = var4 < (4) ? var2 : (var4 != (12) && var4 != (14) ? var3 : var1);
      return ((var4 & (1)) == 0 ? var5 : -var5) + ((var4 & (2)) == 0 ? var6 : -var6);
   }

   static {
      int[] var0 = new int[256];
      int var1 = 0;

      while (var1 < (256)) {
         var0[var1] = var1++;
      }

      long var2 = 25214903917L;

      for (int var4 = 255; var4 > 0; var4--) {
         var2 = var2 * (6364136223846793005L) + (1442695040888963407L);
         int var5 = (int)((var2 >>> (33)) % (long)(var4 + (1)));
         int var6 = var0[var4];
         var0[var4] = var0[var5];
         var0[var5] = var6;
      }

      for (int var7 = 0; var7 < (512); var7++) {
         PERM[var7] = var0[var7 & (255)];
      }
   }
}
