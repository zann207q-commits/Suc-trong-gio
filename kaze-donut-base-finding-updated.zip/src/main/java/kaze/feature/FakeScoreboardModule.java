package kaze.feature;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kaze.event.EventListener;
import kaze.event.events.TickEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.Setting;
import kaze.module.setting.StringSetting;
import kaze.utils.EncryptedString;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.scoreboard.ScoreAccess;
import net.minecraft.scoreboard.ScoreHolder;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.ScoreboardCriterion.RenderType;
import net.minecraft.scoreboard.number.BlankNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class FakeScoreboardModule extends Module {
   private static final String OBJECTIVE = "kaze_fake_scoreboard";
   private static final String TEAM_PREFIX = "kaze_sb_";
   private final StringSetting title;
   private final BooleanSetting showMoney;
   private final StringSetting money;
   private final BooleanSetting showShards;
   private final StringSetting shards;
   private final BooleanSetting showKills;
   private final StringSetting kills;
   private final BooleanSetting showDeaths;
   private final StringSetting deaths;
   private final BooleanSetting showPlaytime;
   private final StringSetting playtime;
   private final List<String> teamNames;
   private ScoreboardObjective ours;
   private ScoreboardObjective serverObjective;
   private Object trackedWorld;
   private long lastRefresh;

   public FakeScoreboardModule() {
      super(EncryptedString.of("Fake Scoreboard"),
            EncryptedString.of("Replaces the sidebar with your own configurable scoreboard"), -1, Category.DONUT);
      title = new StringSetting(EncryptedString.of("Title"), "Kaze");
      showMoney = new BooleanSetting(EncryptedString.of("Money"), true);
      money = new StringSetting(EncryptedString.of("Money Amount"), "1M");
      showShards = new BooleanSetting(EncryptedString.of("Shards"), true);
      shards = new StringSetting(EncryptedString.of("Shards Amount"), "0");
      showKills = new BooleanSetting(EncryptedString.of("Kills"), true);
      kills = new StringSetting(EncryptedString.of("Kills Amount"), "0");
      showDeaths = new BooleanSetting(EncryptedString.of("Deaths"), true);
      deaths = new StringSetting(EncryptedString.of("Deaths Amount"), "0");
      showPlaytime = new BooleanSetting(EncryptedString.of("Playtime"), true);
      playtime = new StringSetting(EncryptedString.of("Playtime Amount"), "0h");
      teamNames = new ArrayList<>();
      addSettings(new Setting[]{title, showMoney, money, showShards, shards, showKills, kills,
            showDeaths, deaths, showPlaytime, playtime});
   }

   public void onEnable() {
      this.lastRefresh = 0L;
      this.trackedWorld = this.mc.world;
      this.rebuild();
      super.onEnable();
   }

   public void onDisable() {
      this.teardown();
      this.trackedWorld = null;
      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (this.mc.world != null && this.mc.player != null) {
         if (this.trackedWorld != this.mc.world) {
            this.ours = null;
            this.serverObjective = null;
            this.teamNames.clear();
            this.trackedWorld = this.mc.world;
            this.lastRefresh = 0L;
         }

         long var2 = System.currentTimeMillis();
         if (var2 - this.lastRefresh >= (1000L)) {
            this.lastRefresh = var2;
            this.rebuild();
         }
      }
   }

   private void rebuild() {
      if (this.mc.world != null && this.mc.player != null) {
         Scoreboard var1 = this.mc.world.getScoreboard();
         ScoreboardObjective var2 = var1.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
         if (var2 != null && !"kaze_fake_scoreboard".equals(var2.getName())) {
            this.serverObjective = var2;
         }

         this.dropTeams(var1);
         ScoreboardObjective var3 = var1.getNullableObjective("kaze_fake_scoreboard");
         if (var3 != null) {
            var1.removeObjective(var3);
         }

         this.ours = var1.addObjective(
            "kaze_fake_scoreboard",
            ScoreboardCriterion.DUMMY,
            Text.literal(this.title.getValue()),
            RenderType.INTEGER,
            false,
            BlankNumberFormat.INSTANCE
         );
         var1.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.ours);
         List var4 = this.buildLines();

         for (int var5 = 0; var5 < var4.size(); var5++) {
            String var6 = "kaze_sb_" + var5;
            this.teamNames.add(var6);
            Team var7 = var1.getTeam(var6);
            if (var7 != null) {
               var1.removeTeam(var7);
            }

            Team var8 = var1.addTeam(var6);
            var8.setPrefix((Text)var4.get(var5));
            String var9 = "§" + Integer.toHexString(var5);
            ScoreHolder var10 = ScoreHolder.fromName(var9);
            var1.removeScore(var10, this.ours);
            ScoreAccess var11 = var1.getOrCreateScore(var10, this.ours);
            var11.setScore(var4.size() - var5);
            var1.addScoreHolderToTeam(var9, var8);
         }
      }
   }

   private List<MutableText> buildLines() {
      ArrayList var1 = new ArrayList();
      if (this.showMoney.getValue()) {
         var1.add(
            this.line("$ ", Formatting.GREEN, this.money.getValue())
         );
      }

      if (this.showShards.getValue()) {
         var1.add(
            this.line(
               "✦ ", Formatting.LIGHT_PURPLE, this.shards.getValue()
            )
         );
      }

      if (this.showKills.getValue()) {
         var1.add(
            this.line(
               "⚔ ", Formatting.RED, this.kills.getValue()
            )
         );
      }

      if (this.showDeaths.getValue()) {
         var1.add(
            this.line(
               "☠ ", Formatting.GOLD, this.deaths.getValue()
            )
         );
      }

      if (this.showPlaytime.getValue()) {
         var1.add(
            this.line(
               "◷ ", Formatting.YELLOW, this.playtime.getValue()
            )
         );
      }

      if (var1.isEmpty()) {
         var1.add(Text.literal(" "));
      }

      return var1;
   }

   private MutableText line(String var1, Formatting var2, String var3) {
      return Text.literal(var1).formatted(var2).append(Text.literal(var3).formatted(Formatting.WHITE));
   }

   public void deductMoney(double var1) {
      String var3 = this.money
         .getValue()
         .trim()
         .replace(
            ",", ""
         )
         .replace(
            "$", ""
         )
         .toUpperCase(Locale.ROOT);
      double var4 = 1.0;
      if (var3.endsWith("K")) {
         var4 = 1000.0;
         var3 = var3.substring(0, var3.length() - (1));
      } else if (var3.endsWith("M")) {
         var4 = 1000000.0;
         var3 = var3.substring(0, var3.length() - (1));
      } else if (var3.endsWith("B")) {
         var4 = 1000000000.0;
         var3 = var3.substring(0, var3.length() - (1));
      } else if (var3.endsWith("T")) {
         var4 = 1000000000000.0;
         var3 = var3.substring(0, var3.length() - (1));
      }

      try {
         double var6 = Math.max(0.0, Double.parseDouble(var3) * var4 - var1);
         if (var6 >= 1000000000000.0) {
            this.money.setValue(compact(var6 / 1000000000000.0) + "T");
         } else if (var6 >= 1000000000.0) {
            this.money.setValue(compact(var6 / 1000000000.0) + "B");
         } else if (var6 >= 1000000.0) {
            this.money.setValue(compact(var6 / 1000000.0) + "M");
         } else if (var6 >= 1000.0) {
            this.money.setValue(compact(var6 / 1000.0) + "K");
         } else {
            this.money.setValue(compact(var6));
         }

         this.lastRefresh = 0L;
         if (this.isEnabled()) {
            this.rebuild();
         }
      } catch (NumberFormatException var8) {
      }
   }

   private static String compact(double var0) {
      if (Math.rint(var0) == var0) {
         return Long.toString((long)var0);
      } else {
         Locale var10000 = Locale.ROOT;
         String var10001 = "%.2f";
         Object[] var10002 = new Object[1];
         var10002[0] = var0;
         return String.format(var10000, var10001, var10002)
            .replaceAll(
               "0+$",
               ""
            )
            .replaceAll(
               "\\.$",
               ""
            );
      }
   }

   private void teardown() {
      if (this.mc.world == null) {
         this.ours = null;
         this.teamNames.clear();
      } else {
         Scoreboard var1 = this.mc.world.getScoreboard();
         this.dropTeams(var1);
         ScoreboardObjective var2 = var1.getNullableObjective("kaze_fake_scoreboard");
         if (var2 != null) {
            var1.removeObjective(var2);
         }

         ScoreboardObjective var3 = null;
         if (this.serverObjective != null && var1.getNullableObjective(this.serverObjective.getName()) != null) {
            var3 = this.serverObjective;
         }

         var1.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, var3);
         this.ours = null;
         this.serverObjective = null;
      }
   }

   private void dropTeams(Scoreboard var1) {
      for (String var3 : this.teamNames) {
         Team var4 = var1.getTeam(var3);
         if (var4 != null) {
            var1.removeTeam(var4);
         }
      }

      this.teamNames.clear();
   }

}
