package kaze.feature;

import java.util.ArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class MikaDesign extends CharacterDefinition {
   private static final int SKIN = -9532;
   private static final int SKIN_SHADE = -1331558;
   private static final int SKIN_LINE = -5740966;
   private static final int HAIR = -681403;
   private static final int HAIR_DARK = -3647457;
   private static final int HAIR_TIP = -15750;
   private static final int HAIR_LINE = -6142180;
   private static final int EAR_TIP = -4697060;
   private static final int EAR_PINK = -22088;
   private static final int TUFT = -5162;
   private static final int HOODIE = -4200487;
   private static final int HOODIE_SHADE = -7092297;
   private static final int RIB = -5710645;
   private static final int CUFF_IN = -9461870;
   private static final int HOODIE_LINE = -10774650;
   private static final int LINING = -744532;
   private static final int SKIRT = -12892555;
   private static final int SKIRT_DARK = -14275250;
   private static final int SKIRT_LINE = -14999232;
   private static final int TIGHTS = -12965330;
   private static final int TIGHTS_SHEEN = -9808288;
   private static final int TIGHTS_LINE = -15068908;
   private static final int SHOE = -542005;
   private static final int SOLE = -264207;
   private static final int MINT = -5839921;
   private static final int FISH = -8398652;
   private static final int FISH_LINE = -12811148;
   private static final int SHOE_LINE = -6659470;
   private static final int GOLD = -867761;
   private static final int TAIL_TIP = -3618;
   private static final int LASH = -13887470;
   private static final int BROW = -4691398;
   private static final float HX = 0.0F;
   private static final float HY = 27.95F;
   private static final float HZ = -0.15F;
   private static final float RX = 2.3F;
   private static final float RY = 2.3F;
   private static final float RZ = 2.35F;
   private static final float DROP = 0.4F;
   private static final float HS = 1.12F;
   private static final float NY = 24.9F;
   private static final float NZ = -0.3F;
   private static final float PPU = 55.652176F;
   private static final float TOP = 29.0F;
   private static final int PLEATS = 16;
   private static final float[][] FRINGE;
   private static final float[][] CROWN;

   public MikaDesign() {
      super(
         "mika", "Mika"
      );
   }

   protected void define(CharacterRig var1) {
      var1.scale(1.0F)
         .outline(-12967400, 0.11999999731779099F)
         .occlusion(0.30000001192092896F);
      body(var1);
      head(var1);
      hair(var1);
      ears(var1);
      arms(var1);
      legs(var1);
      tail(var1);
   }

   public static Sdf3D toHead(Sdf3D var0) {
      return var0.move(
            0.0F, -0.4000000059604645F, 0.0F
         )
         .scale(
            1.1200000047683716F,
            0.0F,
            24.899999618530273F,
            -0.30000001192092896F
         );
   }

   public static float wx(float var0) {
      return var0 * 1.1200000047683716F;
   }

   public static float wy(float var0) {
      return 24.899999618530273F
         + (var0 - 0.4000000059604645F - 24.899999618530273F) * 1.1200000047683716F;
   }

   public static float wz(float var0) {
      return -0.30000001192092896F
         + (var0 - -0.30000001192092896F) * 1.1200000047683716F;
   }

   public static float u(float var0) {
      return 128.0F + var0 * 55.65217590332031F;
   }

   public static float v(float var0) {
      return (29.0F - var0) * 55.65217590332031F;
   }

   public static float capZ(float var0, float var1, float var2) {
      float var3 = var0 / (2.7200000286102295F + var2);
      float var4 = (var1 - 28.25F) / (2.799999952316284F + var2);
      return -0.2800000011920929F
         + (2.8499999046325684F + var2)
            * (float)Math.sqrt(
               (double)Math.max(0.019999999552965164F, 1.0F - var3 * var3 - var4 * var4)
            );
   }

   public static float[] onCap(float var0, float var1, float var2, float var3) {
      float var4 = (float)Math.sqrt((double)(var0 * var0 + var1 * var1 + var2 * var2));
      var0 /= var4;
      var1 /= var4;
      var2 /= var4;
      float var5 = var0 / (2.7200000286102295F + var3);
      float var6 = var1 / (2.799999952316284F + var3);
      float var7 = var2 / (2.8499999046325684F + var3);
      float var8 = 1.0F / (float)Math.sqrt((double)(var5 * var5 + var6 * var6 + var7 * var7));
      float[] var10000 = new float[3];
      var10000[0] = var0 * var8;
      var10000[1] = 28.25F + var1 * var8;
      var10000[2] = -0.2800000011920929F + var2 * var8;
      return var10000;
   }

   public static Sdf3D crownClump(float[] var0, float var1) {
      float var2 = 0.15000000596046448F;
      float var3 = 0.9300000071525574F;
      float var4 = -0.3499999940395355F;
      float[] var5 = new float[16];
      float[] var10000 = new float[4];
      var10000[0] = 0.0F;
      var10000[1] = 0.3799999952316284F;
      var10000[2] = 0.7200000286102295F;
      var10000[3] = 1.0F;
      float[] var6 = var10000;
      var10000 = new float[4];
      var10000[0] = 0.20000000298023224F;
      var10000[1] = 0.8500000238418579F * var1;
      var10000[2] = 0.800000011920929F * var1;
      var10000[3] = 0.30000001192092896F;
      float[] var7 = var10000;
      var10000 = new float[4];
      var10000[0] = -0.11999999731779099F;
      var10000[1] = -0.07000000029802322F;
      var10000[2] = -0.07000000029802322F;
      var10000[3] = -0.14000000059604645F;
      float[] var8 = var10000;

      for (int var9 = 0; var9 < (4); var9++) {
         float[] var10 = onCap(
            var2 + (var0[0] - var2) * var6[var9],
            var3 + (var0[1] - var3) * var6[var9],
            var4 + (var0[2] - var4) * var6[var9],
            var8[var9]
         );
         var5[var9 * (4)] = var10[0];
         var5[var9 * (4) + (1)] = var10[1];
         var5[var9 * (4) + (2)] = var10[2];
         var5[var9 * (4) + (3)] = var7[var9];
      }

      return SdfShapes.tube(var5)
         .flattenFrom(
            3.200000047683716F,
            0.0F,
            28.25F,
            -0.2800000011920929F
         );
   }

   public static float surf(float var0, float var1, float var2) {
      float var3 = var0 / (2.299999952316284F + var2);
      float var4 = (var1 - 27.950000762939453F) / (2.299999952316284F + var2);
      return -0.15000000596046448F
         + (2.3499999046325684F + var2)
            * (float)Math.sqrt(
               (double)Math.max(0.019999999552965164F, 1.0F - var3 * var3 - var4 * var4)
            );
   }

   public static void head(CharacterRig var0) {
      Sdf3D var1 = SdfShapes.ellipsoid(
         0.0F,
         27.950000762939453F,
         -0.15000000596046448F,
         2.299999952316284F,
         2.299999952316284F,
         2.3499999046325684F
      );
      Sdf3D var2 = SdfShapes.ellipsoid(
         0.0F,
         26.719999313354492F,
         0.3499999940395355F,
         1.9299999475479126F,
         1.2999999523162842F,
         1.7000000476837158F
      );
      Sdf3D var3 = SdfShapes.cone(
         0.0F,
         26.200000762939453F,
         0.44999998807907104F,
         1.2000000476837158F,
         0.0F,
         25.25F,
         0.9800000190734863F,
         0.30000001192092896F
      );
      Sdf3D[] var10000 = new Sdf3D[2];
      var10000[0] = SdfShapes.box(
         0.0F,
         29.0F,
         -1.7999999523162842F,
         3.0F,
         2.299999952316284F,
         1.5F
      );
      var10000[1] = SdfShapes.box(
         0.0F,
         30.299999237060547F,
         0.5F,
         3.0F,
         1.2999999523162842F,
         3.0F
      );
      Sdf3D var4 = SdfShapes.union(var10000);
      float var7 = 0.699999988079071F;
      Sdf3D[] var10001 = new Sdf3D[3];
      var10001[0] = var1;
      var10001[1] = var2;
      var10001[2] = var3;
      Sdf3D var5 = SdfShapes.subtract(SdfShapes.blend(var7, var10001), var4).color(-9532);
      var0.part(CharacterBone.HEAD)
         .pivot(0.0F, 24.899999618530273F, -0.30000001192092896F)
         .shape(toHead(var5))
         .detail(1.5F)
         .flatLight(1.0F)
         .occlusion(0.20000000298023224F)
         .outline(-5740966, 0.10000000149011612F)
         .decal(face());
      SurfacePaint var6 = SurfacePaint.vertical(
            -9532, 23.700000762939453F, -1331558, 24.299999237060547F
         )
         .flatLight(1.0F)
         .occlusion(0.25F);
      var0.extra("neck", CharacterBone.BODY)
         .shape(
            SdfShapes.capsule(
                  0.0F,
                  23.100000381469727F,
                  -0.2800000011920929F,
                  0.0F,
                  25.200000762939453F,
                  -0.20000000298023224F,
                  0.6200000047683716F
               )
               .paint(var6)
         )
         .outline(-5740966, 0.07999999821186066F);
   }

   public static void hair(CharacterRig var0) {
      SurfacePaint var1 = SurfacePaint.field(MikaDesign::hairColor);
      Sdf3D var2 = SdfShapes.ellipsoid(
            0.0F,
            28.25F,
            -0.2800000011920929F,
            2.7200000286102295F,
            2.799999952316284F,
            2.8499999046325684F
         )
         .intersect(
            SdfShapes.plane(
               0.0F,
               27.399999618530273F,
               1.2000000476837158F,
               0.0F,
               -0.6000000238418579F,
               1.0F
            )
         )
         .intersect(SdfShapes.above(26.399999618530273F));
      Sdf3D[] var3 = new Sdf3D[CROWN.length];

      for (int var4 = 0; var4 < CROWN.length; var4++) {
         var3[var4] = crownClump(
            CROWN[var4],
            var4 % (2) == 0 ? 1.0F : 0.8999999761581421F
         );
      }

      float var10000 = 0.30000001192092896F;
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = var2;
      var10001[1] = SdfShapes.union(var3);
      Sdf3D var16 = SdfShapes.blend(var10000, var10001);
      CharacterPartBuilder var22 = var0.extra("hair", CharacterBone.HEAD);
      var10001 = new Sdf3D[2];
      var10001[0] = var16;
      var10001[1] = backLock(
         180.0F,
         24.950000762939453F,
         1.0499999523162842F,
         0.25F
      );
      CharacterPartBuilder var5 = var22.shape(toHead(SdfShapes.union(var10001).paint(var1)))
         .detail(0.8999999761581421F)
         .resolution(0.949999988079071F)
         .flatLight(0.5F)
         .occlusion(0.30000001192092896F)
         .outline(-6142180, 0.09000000357627869F);
      float[][] var23 = new float[6][];
      int var10002 = 0;
      float[] var10003 = new float[4];
      var10003[0] = -54.0F;
      var10003[1] = 25.950000762939453F;
      var10003[2] = 0.8999999761581421F;
      var10003[3] = 0.30000001192092896F;
      var23[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[4];
      var10003[0] = -75.0F;
      var10003[1] = 25.450000762939453F;
      var10003[2] = 1.0F;
      var10003[3] = -0.30000001192092896F;
      var23[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[4];
      var10003[0] = -97.0F;
      var10003[1] = 25.799999237060547F;
      var10003[2] = 1.0499999523162842F;
      var10003[3] = 0.25F;
      var23[var10002] = var10003;
      var10002 = 3;
      var10003 = new float[4];
      var10003[0] = -119.0F;
      var10003[1] = 25.299999237060547F;
      var10003[2] = 1.0499999523162842F;
      var10003[3] = -0.20000000298023224F;
      var23[var10002] = var10003;
      var10002 = 4;
      var10003 = new float[4];
      var10003[0] = -140.0F;
      var10003[1] = 25.5F;
      var10003[2] = 1.0499999523162842F;
      var10003[3] = 0.30000001192092896F;
      var23[var10002] = var10003;
      var10002 = 5;
      var10003 = new float[4];
      var10003[0] = -161.0F;
      var10003[1] = 25.100000381469727F;
      var10003[2] = 1.0F;
      var10003[3] = -0.30000001192092896F;
      var23[var10002] = var10003;
      float[][] var6 = var23;
      ArrayList var7 = new ArrayList();
      float[][] var8 = var6;
      int var9 = var6.length;

      for (int var10 = 0; var10 < var9; var10++) {
         float[] var11 = var8[var10];
         var7.add(
            backLock(
               var11[0], var11[1], var11[2], var11[3]
            )
         );
      }

      var7.add(topLock(-84.0F, 26.25F));
      var7.add(topLock(-128.0F, 26.5F));
      CharacterPartBuilder var17 = var0.extra("hair_r", CharacterBone.HEAD)
         .pivot(
            0.0F,
            wy(29.799999237060547F),
            wz(-0.4000000059604645F)
         )
         .shape(toHead(SdfShapes.union(((Sdf3D[]) var7.toArray(new Sdf3D[0]))).paint(var1)))
         .detail(1.0F)
         .resolution(0.8500000238418579F)
         .flatLight(0.5F)
         .occlusion(0.3499999940395355F)
         .outline(-6142180, 0.09000000357627869F)
         .motion(
            BoneMotionProfile.hair()
               .idle(
                  1.2000000476837158F,
                  0.0F,
                  1.0F,
                  0.3499999940395355F
               )
               .walk(
                  2.5F,
                  0.0F,
                  2.0F,
                  2.0F
               )
               .drag(6.0F)
               .hang(0.20000000298023224F)
               .turn(5.0F, 0.0F)
               .spring(60.0F, 8.0F)
               .bend(1.600000023841858F)
         );
      var0.extra("hair_l", CharacterBone.HEAD).mirrorOf(var17);
      Sdf3D[] var18 = new Sdf3D[FRINGE.length];

      for (int var19 = 0; var19 < FRINGE.length; var19++) {
         var18[var19] = fringeLock(FRINGE[var19]);
      }

      Sdf3D var20 = SdfShapes.ellipsoid(
            0.0F,
            28.25F,
            -0.2800000011920929F,
            2.559999942779541F,
            2.640000104904175F,
            2.690000057220459F
         )
         .intersect(SdfShapes.above(29.299999237060547F));
      Sdf3D var21 = SdfShapes.subtract(SdfShapes.union(var18), var20);
      CharacterPartBuilder var12 = var0.extra("fringe", CharacterBone.HEAD)
         .shape(
            toHead(
               var21.paint(
                  SurfacePaint.vertical(
                     -15750,
                     26.899999618530273F,
                     -681403,
                     29.200000762939453F
                  )
               )
            )
         )
         .detail(1.2999999523162842F)
         .resolution(0.5F)
         .flatLight(0.5F)
         .occlusion(0.25F)
         .outline(-6142180, 0.07999999821186066F);
      shine(var5, var12);
      clip(var0);
      float[] var24 = new float[24];
      var24[0] = -1.9500000476837158F;
      var24[1] = 29.5F;
      var24[2] = 0.8500000238418579F;
      var24[3] = 0.41999998688697815F;
      var24[4] = -2.359999895095825F;
      var24[5] = 28.399999618530273F;
      var24[6] = 1.0499999523162842F;
      var24[7] = 0.5600000023841858F;
      var24[8] = -2.4200000762939453F;
      var24[9] = 27.100000381469727F;
      var24[10] = 1.0800000429153442F;
      var24[11] = 0.6000000238418579F;
      var24[12] = -2.299999952316284F;
      var24[13] = 25.899999618530273F;
      var24[14] = 1.0199999809265137F;
      var24[15] = 0.5F;
      var24[16] = -2.259999990463257F;
      var24[17] = 25.0F;
      var24[18] = 0.9800000190734863F;
      var24[19] = 0.3400000035762787F;
      var24[20] = -2.5F;
      var24[21] = 24.450000762939453F;
      var24[22] = 0.949999988079071F;
      var24[23] = 0.05000000074505806F;
      TaperedTubeSdf3D var13 = SdfShapes.tube(var24)
         .flatten(
            2.299999952316284F,
            -0.550000011920929F,
            0.0F,
            0.8299999833106995F
         );
      CharacterPartBuilder var14 = var0.extra("lock_r", CharacterBone.HEAD)
         .pivot(
            wx(-1.9500000476837158F),
            wy(29.399999618530273F),
            wz(0.8500000238418579F)
         )
         .shape(
            toHead(
               pointed(
                     var13,
                     -2.5F,
                     24.450000762939453F,
                     0.949999988079071F,
                     0.4000000059604645F,
                     1.0F,
                     0.30000001192092896F
                  )
                  .paint(var1)
            )
         )
         .detail(0.800000011920929F)
         .resolution(0.550000011920929F)
         .flatLight(0.5F)
         .occlusion(0.3499999940395355F)
         .outline(-6142180, 0.09000000357627869F)
         .motion(BoneMotionProfile.hair().drag(10.0F).hang(0.3499999940395355F));
      var0.extra("lock_l", CharacterBone.HEAD).mirrorOf(var14);
      float[] var25 = new float[24];
      var25[0] = 0.05000000074505806F;
      var25[1] = 30.799999237060547F;
      var25[2] = 0.10000000149011612F;
      var25[3] = 0.23999999463558197F;
      var25[4] = 0.029999999329447746F;
      var25[5] = 31.450000762939453F;
      var25[6] = 0.20000000298023224F;
      var25[7] = 0.25999999046325684F;
      var25[8] = 0.30000001192092896F;
      var25[9] = 32.04999923706055F;
      var25[10] = 0.3199999928474426F;
      var25[11] = 0.2199999988079071F;
      var25[12] = 0.800000011920929F;
      var25[13] = 32.380001068115234F;
      var25[14] = 0.41999998688697815F;
      var25[15] = 0.17000000178813934F;
      var25[16] = 1.340000033378601F;
      var25[17] = 32.349998474121094F;
      var25[18] = 0.5F;
      var25[19] = 0.10999999940395355F;
      var25[20] = 1.7200000286102295F;
      var25[21] = 32.02000045776367F;
      var25[22] = 0.550000011920929F;
      var25[23] = 0.05000000074505806F;
      TaperedTubeSdf3D var15 = SdfShapes.tube(var25)
         .flatten(
            1.600000023841858F,
            0.0F,
            0.0F,
            1.0F
         );
      var0.extra("ahoge", CharacterBone.HEAD)
         .pivot(
            wx(0.05000000074505806F),
            wy(30.850000381469727F),
            wz(0.10000000149011612F)
         )
         .shape(
            toHead(
               var15.paint(
                  SurfacePaint.vertical(
                     -681403,
                     31.200000762939453F,
                     -15750,
                     32.099998474121094F
                  )
               )
            )
         )
         .resolution(0.5F)
         .detail(0.8999999761581421F)
         .flatLight(0.5F)
         .occlusion(0.30000001192092896F)
         .outline(-6142180, 0.07999999821186066F)
         .motion(
            BoneMotionProfile.hair()
               .idle(
                  4.0F,
                  0.0F,
                  6.0F,
                  0.5F
               )
               .walk(
                  8.0F,
                  0.0F,
                  8.0F,
                  2.0F
               )
               .drag(6.0F)
               .hang(0.30000001192092896F)
               .spring(70.0F, 5.0F)
               .bend(1.2000000476837158F)
         );
   }

   public static int hairColor(float var0, float var1, float var2) {
      int var3 = ArgbColors.mix(
         -15750,
         -681403,
         smooth(25.0F, 27.600000381469727F, var1)
      );
      float var4 = (float)Math.sqrt(
         (double)(var0 * var0 + (var2 + 0.25F) * (var2 + 0.25F))
      );
      float var5 = (
            1.0F
               - smooth(1.899999976158142F, 2.549999952316284F, var4)
         )
         * (
            1.0F
               - smooth(26.399999618530273F, 27.600000381469727F, var1)
         );
      return ArgbColors.mix(var3, -3647457, var5 * 0.75F);
   }

   public static Sdf3D fringeLock(float[] var0) {
      float var1 = var0[0] < 0.699999988079071F
         ? 0.5199999809265137F
         : (
            var0[9] > 0.0F
               ? 0.4000000059604645F
               : 0.2800000011920929F
         );
      float var10000 = var0[0];
      float var10001 = 0.05000000074505806F;
      float[] var10002 = new float[12];
      var10002[0] = var0[1];
      var10002[1] = var0[2];
      var10002[2] = capZ(
         var0[1], var0[2], -0.30000001192092896F
      );
      var10002[3] = var0[3];
      var10002[4] = var0[4];
      var10002[5] = capZ(
         var0[3], var0[4], 0.10000000149011612F
      );
      var10002[6] = var0[5];
      var10002[7] = var0[6];
      var10002[8] = surf(var0[5], var0[6], var1);
      var10002[9] = var0[7];
      var10002[10] = var0[8];
      var10002[11] = surf(
         var0[7], var0[8], 0.11999999731779099F
      );
      TaperedTubeSdf3D var2 = SdfShapes.strand(var10000, var10001, var10002)
         .flattenFrom(
            2.799999952316284F,
            0.0F,
            27.950000762939453F,
            -0.15000000596046448F
         );
      float var3 = var0[5] - var0[7];
      float var4 = var0[6] - var0[8];
      float var5 = (float)Math.sqrt((double)(var3 * var3 + var4 * var4));
      var3 /= var5;
      var4 /= var5;
      float var6 = 0.8999999761581421F * (1.0F + var0[9]);
      float var7 = 0.8999999761581421F * (1.0F - var0[9]);
      float var8 = 0.3400000035762787F;
      float[] var12 = new float[10];
      var12[0] = var0[7];
      var12[1] = var0[8];
      var12[2] = var0[7] + var3 * var6 - var4 * var8;
      var12[3] = var0[8] + var4 * var6 + var3 * var8;
      var12[4] = var0[7]
         + var3 * 8.0F
         - var4 * 5.0F;
      var12[5] = var0[8]
         + var4 * 8.0F
         + var3 * 5.0F;
      var12[6] = var0[7]
         + var3 * 8.0F
         + var4 * 5.0F;
      var12[7] = var0[8]
         + var4 * 8.0F
         - var3 * 5.0F;
      var12[8] = var0[7] + var3 * var7 + var4 * var8;
      var12[9] = var0[8] + var4 * var7 - var3 * var8;
      Sdf2D var9 = Sdf2D.polygon(var12);
      return var2.intersect(SdfShapes.extrude(var9, 6.0F, 0.0F));
   }

   public static void clip(CharacterRig var0) {
      float var10000 = 0.07999999821186066F;
      Sdf2D[] var10001 = new Sdf2D[2];
      var10001[0] = Sdf2D.ellipse(
         -0.10000000149011612F,
         0.0F,
         0.5F,
         0.3199999928474426F
      );
      int var10003 = 1;
      float[] var10004 = new float[8];
      var10004[0] = 0.30000001192092896F;
      var10004[1] = 0.0F;
      var10004[2] = 0.8600000143051147F;
      var10004[3] = 0.36000001430511475F;
      var10004[4] = 0.6600000262260437F;
      var10004[5] = 0.0F;
      var10004[6] = 0.8600000143051147F;
      var10004[7] = -0.36000001430511475F;
      var10001[var10003] = Sdf2D.polygon(var10004);
      Sdf2D var1 = Sdf2D.blend(var10000, var10001);
      Sdf3D var2 = SdfShapes.extrude(
            var1, 0.15000000596046448F, 0.10999999940395355F
         )
         .scale(1.2999999523162842F)
         .paint(
            SurfacePaint.gradient(
               -3869978,
               0.0F,
               0.3499999940395355F,
               0.0F,
               -8398652,
               0.0F,
               -0.3499999940395355F,
               0.0F
            )
         );
      float var3 = 1.6200000047683716F;
      float var4 = 28.700000762939453F;
      float var5 = 0.75F;
      float var6 = surf(var3, var4, var5);
      float var7 = 2.299999952316284F + var5;
      float var8 = 2.299999952316284F + var5;
      float var9 = 2.3499999046325684F + var5;
      float var10 = var3 / (var7 * var7);
      float var11 = (var4 - 27.950000762939453F) / (var8 * var8);
      float var12 = (var6 - -0.15000000596046448F) / (var9 * var9);
      float var13 = (float)Math.sqrt((double)(var10 * var10 + var11 * var11 + var12 * var12));
      float var14 = (float)Math.toDegrees(Math.atan2((double)var10, (double)var12));
      float var15 = (float)(-Math.toDegrees(Math.asin((double)(var11 / var13))));
      Sdf3D var16 = var2.rotate(
            0.0F, 0.0F, 35.0F
         )
         .rotate(var15, var14, 0.0F)
         .move(var3, var4, var6);
      Vec3 var17 = new Vec3(
            -0.5F, 0.07999999821186066F, 0.20000000298023224F
         )
         .rotate(0.0F, 0.0F, 35.0F)
         .rotate(var15, var14, 0.0F)
         .add(var3, var4, var6);
      Vec3 var18 = new Vec3(
            0.0F, 0.0F, 1.0F
         )
         .rotate(0.0F, 0.0F, 35.0F)
         .rotate(var15, var14, 0.0F);
      PixelCanvas var19 = new PixelCanvas(32, 32);
      var19.fill(
         Sdf2D.circle(
            16.0F, 16.0F, 7.0F
         ),
         -14796236
      );
      var19.fill(
         Sdf2D.circle(
            13.5F, 13.5F, 2.200000047683716F
         ),
         -855638017
      );
      SurfaceDecal var20 = SurfaceDecal.project(
            var19,
            wx(var17.x()),
            wy(var17.y()),
            wz(var17.z()),
            var18.x(),
            var18.y(),
            var18.z(),
            0.0F,
            1.0F,
            0.0F,
            0.3360000252723694F,
            0.3360000252723694F
         )
         .depth(0.25F, 0.25F);
      var0.extra("clip", CharacterBone.HEAD)
         .shape(toHead(var16))
         .resolution(0.4000000059604645F)
         .detail(0.5F)
         .flatLight(0.4000000059604645F)
         .outline(-12811148, 0.10000000149011612F)
         .decal(var20);
   }

   public static void shine(CharacterPartBuilder var0, CharacterPartBuilder var1) {
      PixelCanvas var2 = new PixelCanvas(96, 24);
      Sdf2D[] var10001 = new Sdf2D[2];
      var10001[0] = Sdf2D.taper(
         3.0F,
         12.0F,
         1.0F,
         48.0F,
         12.0F,
         17.0F
      );
      var10001[1] = Sdf2D.taper(
         48.0F,
         12.0F,
         17.0F,
         93.0F,
         12.0F,
         1.0F
      );
      var2.fill(Sdf2D.union(var10001), -419442022, 1.5F);
      float[][] var10000 = new float[5][];
      int var10002 = 0;
      float[] var10003 = new float[4];
      var10003[0] = -52.0F;
      var10003[1] = 0.7200000286102295F;
      var10003[2] = 0.11999999731779099F;
      var10003[3] = 6.0F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[4];
      var10003[0] = -24.0F;
      var10003[1] = 0.8999999761581421F;
      var10003[2] = -0.05999999865889549F;
      var10003[3] = -4.0F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[4];
      var10003[0] = 4.0F;
      var10003[1] = 0.6600000262260437F;
      var10003[2] = 0.07999999821186066F;
      var10003[3] = 5.0F;
      var10000[var10002] = var10003;
      var10002 = 3;
      var10003 = new float[4];
      var10003[0] = 27.0F;
      var10003[1] = 0.8199999928474426F;
      var10003[2] = -0.07999999821186066F;
      var10003[3] = -6.0F;
      var10000[var10002] = var10003;
      var10002 = 4;
      var10003 = new float[4];
      var10003[0] = 57.0F;
      var10003[1] = 0.699999988079071F;
      var10003[2] = 0.10000000149011612F;
      var10003[3] = 3.0F;
      var10000[var10002] = var10003;
      float[][] var3 = var10000;
      float[][] var4 = var3;
      int var5 = var3.length;

      for (int var6 = 0; var6 < var5; var6++) {
         float[] var7 = var4[var6];
         double var8 = Math.toRadians((double)var7[0]);
         float var10 = (float)Math.sin(var8);
         float var11 = (float)Math.cos(var8);
         float[] var12 = onCap(
            var10,
            0.36000001430511475F
               + 0.30000001192092896F * (1.0F - var11)
               + var7[2],
            var11,
            0.2800000011920929F
         );
         float var13 = var12[0];
         float var14 = var12[1] - 28.25F;
         float var15 = var12[2] + 0.2800000011920929F;
         Vec3 var16 = new Vec3(
               0.0F, 1.0F, 0.0F
            )
            .rotate(0.0F, 0.0F, var7[3]);
         SurfaceDecal var17 = SurfaceDecal.project(
               var2,
               wx(var12[0]),
               wy(var12[1]),
               wz(var12[2]),
               var13,
               var14 * 0.6000000238418579F,
               var15,
               var16.x(),
               var16.y(),
               var16.z(),
               var7[1] * 1.1200000047683716F,
               0.24639999866485596F
            )
            .depth(0.8960000276565552F, 0.8960000276565552F)
            .maxAngle(80.0F)
            .flatLight(0.800000011920929F)
            .occlusion(0.0F);
         var0.decal(var17);
         var1.decal(var17);
      }
   }

   public static Sdf3D pointed(
      TaperedTubeSdf3D var0, float var1, float var2, float var3, float var4, float var5, float var6
   ) {
      float var7 = -0.25F;
      float var8 = (float)Math.toDegrees(Math.atan2((double)var1, (double)(var3 - var7)));
      float var9 = var5 * (1.0F + var6);
      float var10 = var5 * (1.0F - var6);
      float[] var10000 = new float[10];
      var10000[0] = -5.0F;
      var10000[1] = var2 + 8.0F;
      var10000[2] = 5.0F;
      var10000[3] = var2 + 8.0F;
      var10000[4] = var4;
      var10000[5] = var2 + var9;
      var10000[6] = 0.0F;
      var10000[7] = var2;
      var10000[8] = -var4;
      var10000[9] = var2 + var10;
      Sdf2D var11 = Sdf2D.polygon(var10000);
      return var0.intersect(
         SdfShapes.extrude(var11, 5.0F, 0.0F)
            .rotate(
               0.0F,
               var8,
               0.0F,
               0.0F,
               0.0F,
               var7
            )
      );
   }

   public static Sdf3D backLock(float var0, float var1, float var2, float var3) {
      double var4 = Math.toRadians((double)var0);
      float var6 = (float)Math.sin(var4);
      float var7 = (float)Math.cos(var4);
      float var8 = Math.max(
         0.0F,
         Math.min(
            1.0F,
            (Math.abs(var0) - 100.0F) / 70.0F
         )
      );
      float[] var10000 = new float[6];
      var10000[0] = 30.100000381469727F;
      var10000[1] = 29.100000381469727F;
      var10000[2] = 27.899999618530273F;
      var10000[3] = 26.899999618530273F;
      var10000[4] = (26.899999618530273F + var1) * 0.5F
         - 0.10000000149011612F;
      var10000[5] = var1;
      float[] var9 = var10000;
      var10000 = new float[6];
      var10000[0] = 2.0399999618530273F;
      var10000[1] = 2.5899999141693115F;
      var10000[2] = 2.700000047683716F;
      var10000[3] = 2.5199999809265137F;
      var10000[4] = 2.4200000762939453F;
      var10000[5] = 2.319999933242798F;
      float[] var10 = var10000;
      var10000 = new float[6];
      var10000[0] = 2.140000104904175F;
      var10000[1] = 2.7200000286102295F;
      var10000[2] = 2.8299999237060547F;
      var10000[3] = 2.619999885559082F;
      var10000[4] = 2.4800000190734863F;
      var10000[5] = 2.3499999046325684F;
      float[] var11 = var10000;
      var10000 = new float[6];
      var10000[0] = -0.3400000035762787F;
      var10000[1] = -0.05999999865889549F;
      var10000[2] = 0.03999999910593033F;
      var10000[3] = 0.03999999910593033F;
      var10000[4] = 0.019999999552965164F;
      var10000[5] = -0.05999999865889549F - 0.23999999463558197F * var8;
      float[] var12 = var10000;
      var10000 = new float[6];
      var10000[0] = 0.699999988079071F;
      var10000[1] = 1.0499999523162842F;
      var10000[2] = 1.0499999523162842F;
      var10000[3] = 0.949999988079071F;
      var10000[4] = 0.6399999856948853F;
      var10000[5] = 0.05999999865889549F;
      float[] var13 = var10000;
      float[] var14 = new float[24];

      for (int var15 = 0; var15 < (6); var15++) {
         var14[var15 * (4)] = var6 * (var10[var15] + var12[var15]);
         var14[var15 * (4) + (1)] = var9[var15];
         var14[var15 * (4) + (2)] = -0.2800000011920929F
            + var7 * (var11[var15] + var12[var15]);
         var14[var15 * (4) + (3)] = var13[var15]
            * (var15 == (5) ? 1.0F : var2);
      }

      return pointed(
         SdfShapes.tube(var14)
            .flattenFrom(
               2.0999999046325684F,
               0.0F,
               27.950000762939453F,
               -0.15000000596046448F
            ),
         var14[20],
         var1,
         var14[22],
         0.6200000047683716F,
         1.25F,
         var3
      );
   }

   public static Sdf3D topLock(float var0, float var1) {
      double var2 = Math.toRadians((double)var0);
      float var4 = (float)Math.sin(var2);
      float var5 = (float)Math.cos(var2);
      float[] var10000 = new float[4];
      var10000[0] = 2.200000047683716F;
      var10000[1] = 2.799999952316284F;
      var10000[2] = 2.9800000190734863F;
      var10000[3] = 3.0F;
      float[] var6 = var10000;
      var10000 = new float[4];
      var10000[0] = 29.399999618530273F;
      var10000[1] = 28.200000762939453F;
      var10000[2] = 27.200000762939453F;
      var10000[3] = var1;
      float[] var7 = var10000;
      var10000 = new float[4];
      var10000[0] = 0.550000011920929F;
      var10000[1] = 0.75F;
      var10000[2] = 0.550000011920929F;
      var10000[3] = 0.07999999821186066F;
      float[] var8 = var10000;
      float[] var9 = new float[16];

      for (int var10 = 0; var10 < (4); var10++) {
         var9[var10 * (4)] = var4 * var6[var10];
         var9[var10 * (4) + (1)] = var7[var10];
         var9[var10 * (4) + (2)] = -0.25F
            + var5 * var6[var10] * 1.0499999523162842F;
         var9[var10 * (4) + (3)] = var8[var10];
      }

      return pointed(
         SdfShapes.tube(var9)
            .flattenFrom(
               2.200000047683716F,
               0.0F,
               27.950000762939453F,
               -0.15000000596046448F
            ),
         var9[12],
         var1,
         var9[14],
         0.6000000238418579F,
         1.149999976158142F,
         0.20000000298023224F
      );
   }

   public static void ears(CharacterRig var0) {
      float[] var10000 = new float[6];
      var10000[0] = -1.100000023841858F;
      var10000[1] = 0.0F;
      var10000[2] = 1.100000023841858F;
      var10000[3] = 0.0F;
      var10000[4] = 0.07999999821186066F;
      var10000[5] = 2.549999952316284F;
      Sdf3D var1 = SdfShapes.extrude(
         Sdf2D.polygon(var10000), 0.6399999856948853F, 0.3199999928474426F
      );
      var10000 = new float[8];
      var10000[0] = 0.6000000238418579F;
      var10000[1] = -0.30000001192092896F;
      var10000[2] = -0.6200000047683716F;
      var10000[3] = -0.30000001192092896F;
      var10000[4] = -0.15000000596046448F;
      var10000[5] = 2.700000047683716F;
      var10000[6] = 0.20000000298023224F;
      var10000[7] = 2.700000047683716F;
      Sdf3D var2 = SdfShapes.extrude(
            Sdf2D.polygon(var10000), 1.2999999523162842F, 0.20000000298023224F
         )
         .rotate(0.0F, 90.0F, 0.0F);
      Sdf3D var3 = SdfShapes.intersect(var1, var2)
         .paint(
            SurfacePaint.vertical(
               -681403, 1.4500000476837158F, -4697060, 2.25F
            )
         );
      var10000 = new float[6];
      var10000[0] = -0.6600000262260437F;
      var10000[1] = 0.30000001192092896F;
      var10000[2] = 0.6800000071525574F;
      var10000[3] = 0.30000001192092896F;
      var10000[4] = 0.07000000029802322F;
      var10000[5] = 1.9500000476837158F;
      Sdf3D var4 = SdfShapes.extrude(
            Sdf2D.polygon(var10000), 0.5F, 0.14000000059604645F
         )
         .move(0.0F, 0.0F, 0.6200000047683716F)
         .paint(SurfacePaint.of(-22088).flatLight(0.699999988079071F));
      Sdf3D[] var10 = new Sdf3D[2];
      int var10002 = 0;
      float var10003 = 0.14000000059604645F;
      float var10004 = 0.05000000074505806F;
      float[] var10005 = new float[9];
      var10005[0] = -0.3400000035762787F;
      var10005[1] = 0.2800000011920929F;
      var10005[2] = 0.25F;
      var10005[3] = -0.46000000834465027F;
      var10005[4] = 0.6000000238418579F;
      var10005[5] = 0.4399999976158142F;
      var10005[6] = -0.3799999952316284F;
      var10005[7] = 0.8999999761581421F;
      var10005[8] = 0.5F;
      var10[var10002] = SdfShapes.strand(var10003, var10004, var10005);
      var10002 = 1;
      var10003 = 0.14000000059604645F;
      var10004 = 0.05000000074505806F;
      var10005 = new float[9];
      var10005[0] = 0.30000001192092896F;
      var10005[1] = 0.2800000011920929F;
      var10005[2] = 0.25F;
      var10005[3] = 0.46000000834465027F;
      var10005[4] = 0.5799999833106995F;
      var10005[5] = 0.4399999976158142F;
      var10005[6] = 0.5600000023841858F;
      var10005[7] = 0.8600000143051147F;
      var10005[8] = 0.47999998927116394F;
      var10[var10002] = SdfShapes.strand(var10003, var10004, var10005);
      Sdf3D var5 = SdfShapes.union(var10)
         .paint(SurfacePaint.of(-5162).flatLight(0.699999988079071F));
      Sdf3D[] var11 = new Sdf3D[2];
      var11[0] = SdfShapes.subtract(0.10000000149011612F, var3, var4);
      var11[1] = var5;
      Sdf3D var6 = SdfShapes.union(var11)
         .scale(1.1799999475479126F)
         .rotate(-6.0F, -18.0F, 24.0F)
         .move(-1.600000023841858F, 29.75F, -0.15000000596046448F);
      CharacterPartBuilder var7 = var0.extra("ear_r", CharacterBone.HEAD)
         .pivot(
            wx(-1.600000023841858F),
            wy(29.899999618530273F),
            wz(-0.15000000596046448F)
         )
         .shape(toHead(var6))
         .resolution(0.5799999833106995F)
         .detail(0.8999999761581421F)
         .flatLight(0.4000000059604645F)
         .outline(-6142180, 0.09000000357627869F)
         .motion(earMotion(0.0F, -1.0F));
      var0.extra("ear_l", CharacterBone.HEAD)
         .mirrorOf(var7)
         .motion(earMotion(140.0F, 1.0F));
   }

   public static BoneMotionProfile earMotion(float var0, float var1) {
      return BoneMotionProfile.none()
         .idle(
            2.5F,
            0.0F,
            5.0F * var1,
            0.550000011920929F
         )
         .idlePhase(var0)
         .walk(
            3.0F,
            0.0F,
            3.0F * var1,
            2.0F
         )
         .spring(90.0F, 7.0F);
   }

   public static void body(CharacterRig var0) {
      Sdf3D[] var10000 = new Sdf3D[2];
      var10000[0] = SdfShapes.cone(
         0.0F,
         22.600000381469727F,
         -0.20000000298023224F,
         1.0199999809265137F,
         -1.9500000476837158F,
         22.200000762939453F,
         -0.20000000298023224F,
         0.8999999761581421F
      );
      var10000[1] = SdfShapes.cone(
         0.0F,
         22.600000381469727F,
         -0.20000000298023224F,
         1.0199999809265137F,
         1.9500000476837158F,
         22.200000762939453F,
         -0.20000000298023224F,
         0.8999999761581421F
      );
      Sdf3D var1 = SdfShapes.union(var10000);
      Sdf3D var2 = SdfShapes.ellipsoid(
         0.0F,
         20.5F,
         -0.10000000149011612F,
         2.299999952316284F,
         2.4000000953674316F,
         1.7200000286102295F
      );
      Sdf3D var3 = SdfShapes.ellipsoid(
         0.0F,
         17.799999237060547F,
         -0.019999999552965164F,
         2.25F,
         2.9000000953674316F,
         1.7000000476837158F
      );
      Sdf3D var4 = SdfShapes.ellipsoid(
         0.0F,
         15.25F,
         -0.05000000074505806F,
         2.450000047683716F,
         1.25F,
         1.8600000143051147F
      );
      float var14 = 1.0F;
      Sdf3D[] var10001 = new Sdf3D[4];
      var10001[0] = var1;
      var10001[1] = var2;
      var10001[2] = var3;
      var10001[3] = var4;
      Sdf3D var5 = SdfShapes.blend(var14, var10001)
         .paint(SurfacePaint.field(MikaDesign::hoodie));
      Sdf3D var15 = SdfShapes.ellipsoid(
         0.0F,
         16.299999237060547F,
         -0.019999999552965164F,
         2.5999999046325684F,
         2.9000000953674316F,
         2.0199999809265137F
      );
      float[] var20 = new float[8];
      var20[0] = -1.600000023841858F;
      var20[1] = 17.299999237060547F;
      var20[2] = 1.600000023841858F;
      var20[3] = 17.299999237060547F;
      var20[4] = 2.1500000953674316F;
      var20[5] = 14.75F;
      var20[6] = -2.1500000953674316F;
      var20[7] = 14.75F;
      Sdf3D var6 = SdfShapes.intersect(
            var15,
            SdfShapes.extrude(
                  Sdf2D.polygon(var20), 2.0F, 0.0F
               )
               .move(
                  0.0F,
                  0.0F,
                  2.0F
               )
         )
         .color(-4200487);
      Sdf3D var7 = SdfShapes.extrude(
            Sdf2D.ellipse(
               0.0F,
               0.0F,
               2.4200000762939453F,
               1.7999999523162842F
            ),
            0.4000000059604645F,
            0.30000001192092896F
         )
         .rotate(90.0F, 0.0F, 0.0F)
         .move(0.0F, 14.199999809265137F, -0.05000000074505806F)
         .color(-5710645);
      CharacterPartBuilder var16 = var0.part(CharacterBone.BODY)
         .pivot(0.0F, 23.399999618530273F, -0.10000000149011612F);
      var10001 = new Sdf3D[2];
      int var10003 = 0;
      float var10004 = 0.25F;
      Sdf3D[] var10005 = new Sdf3D[2];
      var10005[0] = var5;
      var10005[1] = var6;
      var10001[var10003] = SdfShapes.blend(var10004, var10005);
      var10001[1] = var7;
      var16.shape(SdfShapes.union(var10001))
         .resolution(1.149999976158142F)
         .detail(1.0F)
         .outline(-10774650, 0.11999999731779099F)
         .occlusion(0.30000001192092896F)
         .flatLight(0.20000000298023224F)
         .decal(pocketDecal())
         .decal(pawDecal())
         .decal(hemRib());
      var0.extra("collar", CharacterBone.BODY)
         .shape(rim().paint(SurfacePaint.field(MikaDesign::rimColor)))
         .resolution(0.699999988079071F)
         .detail(0.800000011920929F)
         .occlusion(0.30000001192092896F)
         .flatLight(0.20000000298023224F)
         .outline(-10774650, 0.10000000149011612F);
      float var17 = 0.800000011920929F;
      var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.ellipsoid(
         0.0F,
         21.700000762939453F,
         -1.850000023841858F,
         2.200000047683716F,
         2.200000047683716F,
         0.8500000238418579F
      );
      var10001[1] = SdfShapes.cone(
         0.0F,
         20.600000381469727F,
         -2.299999952316284F,
         0.800000011920929F,
         0.0F,
         19.100000381469727F,
         -2.200000047683716F,
         0.2800000011920929F
      );
      Sdf3D var8 = SdfShapes.blend(var17, var10001);
      Sdf3D var9 = SdfShapes.ellipsoid(
            0.0F,
            0.0F,
            0.0F,
            1.5499999523162842F,
            0.3499999940395355F,
            0.8500000238418579F
         )
         .rotate(-26.600000381469727F, 0.0F, 0.0F)
         .move(0.0F, 22.950000762939453F, -1.9500000476837158F);
      Sdf3D var10 = SdfShapes.subtract(
            0.15000000596046448F,
            var8.intersect(
               SdfShapes.plane(
                  0.0F,
                  22.700000762939453F,
                  -2.200000047683716F,
                  0.0F,
                  1.0F,
                  -0.5F
               )
            ),
            var9
         )
         .paint(SurfacePaint.field(MikaDesign::hoodColor));
      var0.extra("hood", CharacterBone.BODY)
         .shape(var10)
         .resolution(0.8500000238418579F)
         .detail(0.6000000238418579F)
         .occlusion(0.30000001192092896F)
         .flatLight(0.20000000298023224F)
         .outline(-10774650, 0.11999999731779099F);
      var0.extra("skirt", CharacterBone.BODY)
         .pivot(0.0F, 14.600000381469727F, 0.0F)
         .shape(skirt())
         .resolution(0.8999999761581421F)
         .detail(0.800000011920929F)
         .occlusion(0.3499999940395355F)
         .outline(-14999232, 0.11999999731779099F)
         .decal(skirtStripe())
         .motion(
            BoneMotionProfile.none()
               .walk(
                  0.0F,
                  8.0F,
                  0.0F,
                  1.0F
               )
               .walkPhase(-90.0F)
               .drag(2.0F)
               .spring(80.0F, 10.0F)
         );
      float[] var18 = new float[16];
      var18[0] = -0.3199999928474426F;
      var18[1] = 23.5F;
      var18[2] = 1.4500000476837158F;
      var18[3] = 0.12999999523162842F;
      var18[4] = -0.3799999952316284F;
      var18[5] = 22.600000381469727F;
      var18[6] = 1.75F;
      var18[7] = 0.12999999523162842F;
      var18[8] = -0.4399999976158142F;
      var18[9] = 21.299999237060547F;
      var18[10] = 1.9500000476837158F;
      var18[11] = 0.12999999523162842F;
      var18[12] = -0.47999998927116394F;
      var18[13] = 20.100000381469727F;
      var18[14] = 2.0F;
      var18[15] = 0.11999999731779099F;
      Sdf3D var11 = SdfShapes.tube(var18).color(-264984);
      Sdf3D var12 = SdfShapes.sphere(
            -0.47999998927116394F,
            19.600000381469727F,
            2.049999952316284F,
            0.44999998807907104F
         )
         .paint(
            SurfacePaint.radial(
               -3920,
               -0.6200000047683716F,
               19.799999237060547F,
               2.3499999046325684F,
               0.6000000238418579F,
               -867761
            )
         );
      CharacterPartBuilder var19 = var0.extra("cord_r", CharacterBone.BODY)
         .pivot(-0.3199999928474426F, 23.5F, 1.4500000476837158F);
      var10001 = new Sdf3D[2];
      var10001[0] = var11;
      var10001[1] = var12;
      CharacterPartBuilder var13 = var19.shape(SdfShapes.union(var10001))
         .resolution(0.5F)
         .detail(0.5F)
         .outline(-10774650, 0.07999999821186066F)
         .decal(bellDecal(-0.47999998927116394F))
         .motion(
            BoneMotionProfile.none()
               .rest(
                  -3.0F, 0.0F, 0.0F
               )
               .idle(
                  1.5F,
                  0.0F,
                  2.0F,
                  0.5F
               )
               .walk(
                  5.0F,
                  0.0F,
                  6.0F,
                  2.0F
               )
               .drag(-4.0F)
               .hang(0.8999999761581421F)
               .spring(60.0F, 6.0F)
               .bend(0.800000011920929F)
         );
      var0.extra("cord_l", CharacterBone.BODY).mirrorOf(var13);
   }

   public static Sdf3D rim() {
      float[] var10000 = new float[24];
      var10000[0] = 0.019999999552965164F;
      var10000[1] = 23.639999389648438F;
      var10000[2] = 1.440000057220459F;
      var10000[3] = 0.36000001430511475F;
      var10000[4] = -0.5F;
      var10000[5] = 23.84000015258789F;
      var10000[6] = 1.2999999523162842F;
      var10000[7] = 0.4099999964237213F;
      var10000[8] = -1.1200000047683716F;
      var10000[9] = 24.079999923706055F;
      var10000[10] = 0.800000011920929F;
      var10000[11] = 0.4300000071525574F;
      var10000[12] = -1.4199999570846558F;
      var10000[13] = 24.200000762939453F;
      var10000[14] = -0.18000000715255737F;
      var10000[15] = 0.4300000071525574F;
      var10000[16] = -1.100000023841858F;
      var10000[17] = 24.299999237060547F;
      var10000[18] = -1.1399999856948853F;
      var10000[19] = 0.4300000071525574F;
      var10000[20] = 0.10000000149011612F;
      var10000[21] = 24.34000015258789F;
      var10000[22] = -1.6799999475479126F;
      var10000[23] = 0.4300000071525574F;
      return SdfShapes.tube(var10000)
         .flattenFrom(
            1.25F,
            0.0F,
            24.100000381469727F,
            -0.25F
         )
         .mirrorX();
   }

   public static int hoodie(float var0, float var1, float var2) {
      float var3 = (float)Math.sqrt(
         (double)(var0 * var0 + (var2 + 0.20000000298023224F) * (var2 + 0.20000000298023224F))
      );
      float var4 = smooth(22.399999618530273F, 23.299999237060547F, var1)
         * (
            1.0F
               - smooth(1.7000000476837158F, 2.299999952316284F, var3)
         )
         * 0.6000000238418579F;
      float var5 = (
            1.0F
               - smooth(14.600000381469727F, 15.300000190734863F, var1)
         )
         * 0.550000011920929F;
      return ArgbColors.mix(-4200487, -7092297, Math.max(var4, var5));
   }

   public static int rimColor(float var0, float var1, float var2) {
      float var3 = (float)Math.sqrt(
         (double)(var0 * var0 + (var2 + 0.20000000298023224F) * (var2 + 0.20000000298023224F))
      );
      float var4 = smooth(
         0.2800000011920929F,
         0.36000001430511475F,
         var1 - 24.0F + 0.2199999988079071F * var2
      );
      return ArgbColors.mix(
         -4200487,
         -744532,
         Math.max(
            var4,
            1.0F
               - smooth(1.1200000047683716F, 1.3799999952316284F, var3)
         )
      );
   }

   public static int hoodColor(float var0, float var1, float var2) {
      float var3 = var0 / 2.200000047683716F;
      float var4 = (var1 - 21.700000762939453F) / 2.200000047683716F;
      float var5 = (var2 + 1.850000023841858F) / 0.8500000238418579F;
      float var6 = (
            var1
               - 22.700000762939453F
               - 0.5F * (var2 + 2.200000047683716F)
         )
         * 0.8939999938011169F;
      return var6 > -0.5F && var3 * var3 + var4 * var4 + var5 * var5 < 0.800000011920929F
         ? -744532
         : -4200487;
   }

   public static Sdf3D skirt() {
      return SdfShapes.field(
            MikaDesign::skirtDistance,
            -3.299999952316284F,
            11.800000190734863F,
            -2.799999952316284F,
            3.299999952316284F,
            14.399999618530273F,
            2.799999952316284F
         )
         .paint(SurfacePaint.field(MikaDesign::skirtColor));
   }

   public static float flare(float var0) {
      float var1 = Math.max(
         0.0F,
         Math.min(
            1.0F,
            (14.0F - var0) / 2.0999999046325684F
         )
      );
      return var1 * (2.0F - var1);
   }

   public static float pleat(float var0, float var1, float var2) {
      float var3 = 2.200000047683716F + 0.75F * var2;
      float var4 = 1.659999966621399F + 0.8399999737739563F * var2;
      double var5 = Math.atan2((double)(var0 / var3), (double)(var1 / var4))
         * 16.0
         / 6.283185307179586;
      var5 -= Math.floor(var5);
      return (float)Math.abs(
         2.0 * var5 - 1.0
      );
   }

   public static float skirtDistance(float var0, float var1, float var2) {
      float var3 = flare(var1);
      float var4 = 2.200000047683716F + 0.75F * var3;
      float var5 = 1.659999966621399F + 0.8399999737739563F * var3;
      float var6 = var0 / var4;
      float var7 = var2 / var5;
      float var8 = (float)Math.sqrt((double)(var6 * var6 + var7 * var7));
      float var9 = (var8 - 1.0F) * Math.min(var4, var5) * 0.7200000286102295F
         - 0.20000000298023224F
            * var3
            * (pleat(var0, var2, var3) - 0.5F);
      return Math.max(var9, Math.max(var1 - 14.300000190734863F, 11.899999618530273F - var1));
   }

   public static int skirtColor(float var0, float var1, float var2) {
      float var3 = flare(var1);
      return ArgbColors.mix(
         -14275250,
         -12892555,
         0.44999998807907104F
            + 0.550000011920929F
               * (1.0F - var3 + var3 * pleat(var0, var2, var3))
      );
   }

   public static SurfaceDecal skirtStripe() {
      PixelCanvas var0 = new PixelCanvas(512, 24);
      var0.fill(
         Sdf2D.box(
            256.0F,
            12.0F,
            256.0F,
            7.0F,
            0.0F
         ),
         -5839921
      );
      return SurfaceDecal.wrap(
            var0,
            0.0F,
            12.350000381469727F,
            0.0F,
            0.0F,
            1.0F,
            0.0F,
            0.0F,
            0.0F,
            1.0F,
            360.0F,
            0.1599999964237213F
         )
         .radius(2.200000047683716F, 3.200000047683716F);
   }

   public static void arms(CharacterRig var0) {
      Sdf3D var1 = SdfShapes.sphere(
         -2.7200000286102295F,
         21.950000762939453F,
         -0.15000000596046448F,
         0.949999988079071F
      );
      Sdf3D var2 = SdfShapes.cone(
         -2.8499999046325684F,
         21.600000381469727F,
         -0.15000000596046448F,
         0.8999999761581421F,
         -3.3499999046325684F,
         18.399999618530273F,
         -0.20000000298023224F,
         0.8799999952316284F
      );
      Sdf3D var3 = SdfShapes.sphere(
         -3.380000114440918F,
         18.299999237060547F,
         -0.18000000715255737F,
         0.8999999761581421F
      );
      Sdf3D var4 = SdfShapes.cone(
         -3.380000114440918F,
         18.200000762939453F,
         -0.18000000715255737F,
         0.8999999761581421F,
         -3.7200000286102295F,
         15.0F,
         0.44999998807907104F,
         1.1200000047683716F
      );
      float var10000 = 0.4000000059604645F;
      Sdf3D[] var10001 = new Sdf3D[4];
      var10001[0] = var1;
      var10001[1] = var2;
      var10001[2] = var3;
      var10001[3] = var4;
      Sdf3D var5 = SdfShapes.blend(var10000, var10001)
         .paint(SurfacePaint.field(MikaDesign::sleeve));
      Sdf3D var6 = SdfShapes.cylinder(
            -3.740000009536743F,
            15.050000190734863F,
            0.4699999988079071F,
            -3.799999952316284F,
            13.399999618530273F,
            0.6899999976158142F,
            0.8999999761581421F,
            0.2800000011920929F
         )
         .paint(SurfacePaint.field(MikaDesign::cuff));
      var10000 = 0.15000000596046448F;
      var10001 = new Sdf3D[2];
      var10001[0] = var5;
      var10001[1] = var6;
      Sdf3D var7 = SdfShapes.blend(var10000, var10001);
      CharacterPartBuilder var8 = var0.part(CharacterBone.RIGHT_ARM)
         .pivot(-2.7200000286102295F, 21.950000762939453F, -0.15000000596046448F)
         .grip(-3.799999952316284F, 12.899999618530273F, 0.8999999761581421F)
         .shape(var7)
         .detail(0.8999999761581421F)
         .resolution(1.0499999523162842F)
         .outline(-10774650, 0.11999999731779099F)
         .occlusion(0.30000001192092896F)
         .flatLight(0.20000000298023224F)
         .swing(0.6499999761581421F, 40.0F)
         .joint(
            -3.380000114440918F,
            18.299999237060547F,
            -0.18000000715255737F,
            0.699999988079071F
         )
         .decal(cuffRib());
      var0.part(CharacterBone.LEFT_ARM).mirrorOf(var8);
      CharacterPartBuilder var9 = var0.extra(
            "hand_r", CharacterBone.RIGHT_ARM
         )
         .shape(hand())
         .resolution(0.4000000059604645F)
         .detail(2.5999999046325684F)
         .flatLight(1.0F)
         .occlusion(0.25F)
         .outline(-5740966, 0.07999999821186066F);
      var0.extra("hand_l", CharacterBone.LEFT_ARM).mirrorOf(var9);
   }

   public static int sleeve(float var0, float var1, float var2) {
      float var3 = Math.max(
         0.0F,
         Math.min(
            1.0F, (21.899999618530273F - var1) / 6.900000095367432F
         )
      );
      float var4 = smooth(
            0.25F,
            0.8500000238418579F,
            var0 + 2.799999952316284F + 0.9399999976158142F * var3
         )
         * 0.5F;
      float var5 = (
            1.0F
               - smooth(
                  0.20000000298023224F,
                  0.550000011920929F,
                  Math.abs(var1 - 18.25F)
               )
         )
         * smooth(0.20000000298023224F, 0.699999988079071F, var2)
         * 0.44999998807907104F;
      return ArgbColors.mix(-4200487, -7092297, Math.max(var4, var5));
   }

   public static int cuff(float var0, float var1, float var2) {
      float var3 = -0.05999999865889549F;
      float var4 = -1.649999976158142F;
      float var5 = 0.2199999988079071F;
      float var6 = (float)Math.sqrt((double)(var3 * var3 + var4 * var4 + var5 * var5));
      float var7 = var0 + 3.799999952316284F;
      float var8 = var1 - 13.399999618530273F;
      float var9 = var2 - 0.6899999976158142F;
      float var10 = -(var7 * var3 + var8 * var4 + var9 * var5) / var6;
      float var11 = var7 + var10 * var3 / var6;
      float var12 = var8 + var10 * var4 / var6;
      float var13 = var9 + var10 * var5 / var6;
      float var14 = (float)Math.sqrt((double)(var11 * var11 + var12 * var12 + var13 * var13));
      return ArgbColors.mix(
         -5710645,
         -9461870,
         (
               1.0F
                  - smooth(0.03999999910593033F, 0.11999999731779099F, var10)
            )
            * (
               1.0F
                  - smooth(0.550000011920929F, 0.6800000071525574F, var14)
            )
      );
   }

   public static Sdf3D hand() {
      float[][] var10000 = new float[3][];
      int var10002 = 0;
      float[] var10003 = new float[3];
      var10003[0] = -3.4700000286102295F;
      var10003[1] = 0.8600000143051147F;
      var10003[2] = 13.0600004196167F;
      var10000[var10002] = var10003;
      var10002 = 1;
      var10003 = new float[3];
      var10003[0] = -3.7899999618530273F;
      var10003[1] = 0.949999988079071F;
      var10003[2] = 12.970000267028809F;
      var10000[var10002] = var10003;
      var10002 = 2;
      var10003 = new float[3];
      var10003[0] = -4.099999904632568F;
      var10003[1] = 0.8600000143051147F;
      var10003[2] = 13.039999961853027F;
      var10000[var10002] = var10003;
      float[][] var0 = var10000;
      Sdf3D[] var1 = new Sdf3D[var0.length];

      for (int var2 = 0; var2 < var0.length; var2++) {
         var1[var2] = SdfShapes.capsule(
            var0[var2][0],
            13.5F,
            var0[var2][1] - 0.11999999731779099F,
            var0[var2][0],
            var0[var2][2],
            var0[var2][1],
            0.1599999964237213F
         );
      }

      Sdf3D var3 = SdfShapes.capsule(
         -3.359999895095825F,
         13.479999542236328F,
         0.6399999856948853F,
         -3.299999952316284F,
         13.199999809265137F,
         0.7599999904632568F,
         0.15000000596046448F
      );
      Sdf3D[] var4 = new Sdf3D[2];
      var4[0] = SdfShapes.union(var1);
      var4[1] = var3;
      return SdfShapes.union(var4).paint(SurfacePaint.of(-9532));
   }

   public static void legs(CharacterRig var0) {
      Sdf3D var1 = SdfShapes.sphere(
         -1.1200000047683716F,
         13.199999809265137F,
         -0.05000000074505806F,
         1.0F
      );
      Sdf3D var2 = SdfShapes.cone(
         -1.1799999475479126F,
         12.800000190734863F,
         0.0F,
         1.1299999952316284F,
         -1.100000023841858F,
         7.900000095367432F,
         0.10000000149011612F,
         0.8799999952316284F
      );
      Sdf3D var3 = SdfShapes.sphere(
         -1.0800000429153442F,
         7.449999809265137F,
         0.11999999731779099F,
         0.8199999928474426F
      );
      Sdf3D var4 = SdfShapes.sphere(
         -1.0700000524520874F,
         7.5F,
         0.47999998927116394F,
         0.5F
      );
      float[] var10000 = new float[16];
      var10000[0] = -1.0800000429153442F;
      var10000[1] = 7.199999809265137F;
      var10000[2] = 0.10000000149011612F;
      var10000[3] = 0.8399999737739563F;
      var10000[4] = -1.100000023841858F;
      var10000[5] = 5.599999904632568F;
      var10000[6] = -0.15000000596046448F;
      var10000[7] = 0.9300000071525574F;
      var10000[8] = -1.1299999952316284F;
      var10000[9] = 3.5999999046325684F;
      var10000[10] = -0.019999999552965164F;
      var10000[11] = 0.6399999856948853F;
      var10000[12] = -1.149999976158142F;
      var10000[13] = 2.200000047683716F;
      var10000[14] = 0.0F;
      var10000[15] = 0.5199999809265137F;
      TaperedTubeSdf3D var5 = SdfShapes.tube(var10000);
      float var9 = 0.44999998807907104F;
      Sdf3D[] var10001 = new Sdf3D[5];
      var10001[0] = var1;
      var10001[1] = var2;
      var10001[2] = var3;
      var10001[3] = var4;
      var10001[4] = var5;
      Sdf3D var6 = SdfShapes.blend(var9, var10001)
         .paint(SurfacePaint.field(MikaDesign::tights));
      CharacterPartBuilder var7 = var0.part(CharacterBone.RIGHT_LEG)
         .pivot(-1.2000000476837158F, 13.699999809265137F, 0.0F)
         .shape(var6)
         .detail(0.8500000238418579F)
         .resolution(1.100000023841858F)
         .outline(-15068908, 0.11999999731779099F)
         .occlusion(0.3499999940395355F)
         .swing(0.550000011920929F, 30.0F)
         .joint(
            -1.0800000429153442F,
            7.449999809265137F,
            0.11999999731779099F,
            0.800000011920929F
         );
      var0.part(CharacterBone.LEFT_LEG).mirrorOf(var7);
      CharacterPartBuilder var8 = var0.extra(
            "shoe_r", CharacterBone.RIGHT_LEG
         )
         .shape(
            sneaker()
               .rotate(
                  0.0F,
                  -7.0F,
                  0.0F,
                  -1.2000000476837158F,
                  0.0F,
                  0.20000000298023224F
               )
         )
         .resolution(0.75F)
         .detail(1.0F)
         .outline(-6659470, 0.11999999731779099F)
         .decal(laces());
      var0.extra("shoe_l", CharacterBone.LEFT_LEG).mirrorOf(var8);
   }

   public static int tights(float var0, float var1, float var2) {
      double var3 = Math.atan2((double)(-(var0 + 1.100000023841858F)), (double)(var2 - 0.019999999552965164F))
         - 0.35;
      float var5 = smooth(0.6000000238418579F, 0.949999988079071F, (float)Math.cos(var3))
         * smooth(2.4000000953674316F, 4.5F, var1)
         * 0.5F;
      float var6 = (float)Math.sqrt(
         (double)(
            (var1 - 7.5F) * (var1 - 7.5F)
               + (var0 + 1.0700000524520874F)
                  * (var0 + 1.0700000524520874F)
                  * 1.399999976158142F
         )
      );
      float var7 = (
            1.0F
               - smooth(0.30000001192092896F, 0.800000011920929F, var6)
         )
         * smooth(0.20000000298023224F, 0.699999988079071F, var2)
         * 0.550000011920929F;
      return ArgbColors.mix(-12965330, -9808288, Math.max(var5, var7));
   }

   public static Sdf3D sneaker() {
      float var10000 = 0.25F;
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.box(
         -1.2000000476837158F,
         0.30000001192092896F,
         0.5F,
         0.8999999761581421F,
         0.30000001192092896F,
         1.840000033378601F,
         0.25999999046325684F
      );
      var10001[1] = SdfShapes.ellipsoid(
         -1.2000000476837158F,
         0.36000001430511475F,
         2.049999952316284F,
         0.8199999928474426F,
         0.3400000035762787F,
         0.5F
      );
      Sdf3D var0 = SdfShapes.blend(var10000, var10001)
         .intersect(SdfShapes.above(0.0F))
         .paint(
            SurfacePaint.of(-264207)
               .band(
                  -1011800,
                  0.0F,
                  0.46000000834465027F,
                  0.0F,
                  0.0F,
                  1.0F,
                  0.0F,
                  0.07000000029802322F,
                  0.05000000074505806F
               )
         );
      Sdf3D var1 = SdfShapes.ellipsoid(
         -1.2000000476837158F,
         0.8999999761581421F,
         1.149999976158142F,
         0.7400000095367432F,
         0.550000011920929F,
         1.1200000047683716F
      );
      Sdf3D var2 = SdfShapes.ellipsoid(
         -1.2000000476837158F,
         1.2799999713897705F,
         -0.47999998927116394F,
         0.75F,
         0.949999988079071F,
         0.8399999737739563F
      );
      var10000 = 0.44999998807907104F;
      var10001 = new Sdf3D[2];
      var10001[0] = var1;
      var10001[1] = var2;
      Sdf3D var3 = SdfShapes.blend(var10000, var10001).color(-542005);
      Sdf3D var4 = SdfShapes.ellipsoid(
            -1.2000000476837158F,
            0.7200000286102295F,
            1.8600000143051147F,
            0.6800000071525574F,
            0.36000001430511475F,
            0.5F
         )
         .color(-264207);
      Sdf3D var5 = SdfShapes.torus(
            -1.2000000476837158F,
            2.0999999046325684F,
            -0.4000000059604645F,
            0.6000000238418579F,
            0.25999999046325684F
         )
         .color(-5839921);
      Sdf3D var6 = SdfShapes.box(
            -1.2000000476837158F,
            1.75F,
            0.3499999940395355F,
            0.41999998688697815F,
            0.41999998688697815F,
            0.30000001192092896F,
            0.18000000715255737F
         )
         .rotate(
            -25.0F,
            0.0F,
            0.0F,
            -1.2000000476837158F,
            1.75F,
            0.3499999940395355F
         )
         .color(-207907);
      Sdf3D var7 = SdfShapes.capsule(
            -1.2000000476837158F,
            1.7999999523162842F,
            -1.2000000476837158F,
            -1.2000000476837158F,
            2.450000047683716F,
            -1.0199999809265137F,
            0.17000000178813934F
         )
         .color(-5839921);
      Sdf3D[] var9 = new Sdf3D[5];
      var9[0] = var0;
      int var10002 = 1;
      float var10003 = 0.11999999731779099F;
      Sdf3D[] var10004 = new Sdf3D[2];
      var10004[0] = var3;
      var10004[1] = var4;
      var9[var10002] = SdfShapes.blend(var10003, var10004);
      var9[2] = var5;
      var9[3] = var6;
      var9[4] = var7;
      return SdfShapes.union(var9);
   }

   public static void tail(CharacterRig var0) {
      float[] var10000 = new float[36];
      var10000[0] = 0.0F;
      var10000[1] = 13.949999809265137F;
      var10000[2] = -1.4500000476837158F;
      var10000[3] = 0.5799999833106995F;
      var10000[4] = 0.15000000596046448F;
      var10000[5] = 13.350000381469727F;
      var10000[6] = -2.700000047683716F;
      var10000[7] = 0.7599999904632568F;
      var10000[8] = 0.6000000238418579F;
      var10000[9] = 13.199999809265137F;
      var10000[10] = -4.099999904632568F;
      var10000[11] = 0.9200000166893005F;
      var10000[12] = 1.600000023841858F;
      var10000[13] = 14.0F;
      var10000[14] = -5.150000095367432F;
      var10000[15] = 1.059999942779541F;
      var10000[16] = 2.5999999046325684F;
      var10000[17] = 15.899999618530273F;
      var10000[18] = -5.5F;
      var10000[19] = 1.149999976158142F;
      var10000[20] = 3.200000047683716F;
      var10000[21] = 18.100000381469727F;
      var10000[22] = -5.150000095367432F;
      var10000[23] = 1.149999976158142F;
      var10000[24] = 3.3499999046325684F;
      var10000[25] = 19.899999618530273F;
      var10000[26] = -4.349999904632568F;
      var10000[27] = 1.0399999618530273F;
      var10000[28] = 3.0F;
      var10000[29] = 21.0F;
      var10000[30] = -3.450000047683716F;
      var10000[31] = 0.7200000286102295F;
      var10000[32] = 2.549999952316284F;
      var10000[33] = 21.450000762939453F;
      var10000[34] = -2.8499999046325684F;
      var10000[35] = 0.25999999046325684F;
      float[] var1 = var10000;
      MikaDesign.CurvePath var2 = new MikaDesign.CurvePath(var1);
      Sdf3D[] var10 = new Sdf3D[3];
      int var10002 = 0;
      float var10003 = 0.23999999463558197F;
      float var10004 = 0.03999999910593033F;
      float[] var10005 = new float[9];
      var10005[0] = 2.680000066757202F;
      var10005[1] = 21.31999969482422F;
      var10005[2] = -3.0199999809265137F;
      var10005[3] = 2.359999895095825F;
      var10005[4] = 21.6200008392334F;
      var10005[5] = -2.680000066757202F;
      var10005[6] = 1.9600000381469727F;
      var10005[7] = 21.6200008392334F;
      var10005[8] = -2.619999885559082F;
      var10[var10002] = SdfShapes.strand(var10003, var10004, var10005);
      var10002 = 1;
      var10003 = 0.23999999463558197F;
      var10004 = 0.03999999910593033F;
      var10005 = new float[9];
      var10005[0] = 2.680000066757202F;
      var10005[1] = 21.31999969482422F;
      var10005[2] = -3.0199999809265137F;
      var10005[3] = 2.4600000381469727F;
      var10005[4] = 21.600000381469727F;
      var10005[5] = -2.619999885559082F;
      var10005[6] = 2.4200000762939453F;
      var10005[7] = 21.6200008392334F;
      var10005[8] = -2.200000047683716F;
      var10[var10002] = SdfShapes.strand(var10003, var10004, var10005);
      var10002 = 2;
      var10003 = 0.23999999463558197F;
      var10004 = 0.03999999910593033F;
      var10005 = new float[9];
      var10005[0] = 2.680000066757202F;
      var10005[1] = 21.31999969482422F;
      var10005[2] = -3.0199999809265137F;
      var10005[3] = 2.440000057220459F;
      var10005[4] = 21.700000762939453F;
      var10005[5] = -2.7200000286102295F;
      var10005[6] = 2.4000000953674316F;
      var10005[7] = 22.1200008392334F;
      var10005[8] = -2.619999885559082F;
      var10[var10002] = SdfShapes.strand(var10003, var10004, var10005);
      Sdf3D var3 = SdfShapes.union(var10);
      CharacterPartBuilder var11 = var0.extra("tail", CharacterBone.BODY)
         .pivot(0.0F, 13.949999809265137F, -1.4500000476837158F);
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.tube(var1);
      var10001[1] = var3;
      CharacterPartBuilder var4 = var11.shape(SdfShapes.union(var10001).paint(SurfacePaint.field(var2::tailColor)))
         .detail(1.0F)
         .resolution(1.100000023841858F)
         .flatLight(0.30000001192092896F)
         .outline(-6142180, 0.10000000149011612F)
         .motion(
            BoneMotionProfile.tail()
               .idle(
                  3.0F,
                  14.0F,
                  4.0F,
                  0.4000000059604645F
               )
               .walk(
                  4.0F,
                  12.0F,
                  3.0F,
                  1.0F
               )
               .spring(30.0F, 4.0F)
               .bend(1.399999976158142F)
         );
      PixelCanvas var5 = new PixelCanvas(128, 96);
      Sdf2D[] var13 = new Sdf2D[2];
      var13[0] = Sdf2D.line(
         10.0F,
         80.0F,
         64.0F,
         26.0F,
         24.0F
      );
      var13[1] = Sdf2D.line(
         64.0F,
         26.0F,
         118.0F,
         80.0F,
         24.0F
      );
      var5.fill(Sdf2D.union(var13), -1999082968, 6.0F);
      var10000 = new float[3];
      var10000[0] = 0.30000001192092896F;
      var10000[1] = 0.4300000071525574F;
      var10000[2] = 0.5600000023841858F;
      float[] var6 = var10000;
      int var7 = var6.length;

      for (int var8 = 0; var8 < var7; var8++) {
         float var9 = var6[var8];
         var4.decal(var2.chevron(var5, var9));
      }
   }

   public static float smooth(float var0, float var1, float var2) {
      float var3 = Math.max(0.0F, Math.min(1.0F, (var2 - var0) / (var1 - var0)));
      return var3 * var3 * (3.0F - 2.0F * var3);
   }

   public static SurfaceDecal face() {
      PixelCanvas var0 = new PixelCanvas(256, 200);
      float var1 = 13.356521606445312F;
      Sdf2D[] var2 = new Sdf2D[FRINGE.length];

      for (int var3 = 0; var3 < FRINGE.length; var3++) {
         float[] var4 = FRINGE[var3];
         float var5 = var4[7]
            + (var4[5] - var4[7]) * 0.11999999731779099F;
         float var6 = var4[8]
            + (var4[6] - var4[8]) * 0.11999999731779099F;
         float var10002 = var4[0] * 1.7000000476837158F * 55.65217590332031F;
         float var10003 = 9.0F;
         float[] var10004 = new float[6];
         var10004[0] = u(var4[3]);
         var10004[1] = v(var4[4]) + var1;
         var10004[2] = u(var4[5]);
         var10004[3] = v(var4[6]) + var1;
         var10004[4] = u(var5);
         var10004[5] = v(var6) + var1;
         var2[var3] = Sdf2D.path(var10002, var10003, var10004);
      }

      var0.fill(Sdf2D.union(var2), -1713793398, 3.0F);

      for (int var7 = -1; var7 <= (1); var7 += 2) {
         eye(
            var0,
            128.0F + (float)var7 * 53.0F,
            114.0F,
            var7
         );
      }

      var0.fill(
         Sdf2D.curve(
            125.5F,
            146.5F,
            128.5F,
            150.5F,
            131.5F,
            149.0F,
            2.200000047683716F,
            1.399999976158142F
         ),
         -1713795968
      );
      float var10001 = 3.0F;
      float var8 = 3.0F;
      float[] var9 = new float[10];
      var9[0] = 117.0F;
      var9[1] = 177.0F;
      var9[2] = 122.5F;
      var9[3] = 182.5F;
      var9[4] = 128.0F;
      var9[5] = 178.5F;
      var9[6] = 133.5F;
      var9[7] = 182.5F;
      var9[8] = 139.0F;
      var9[9] = 177.0F;
      var0.fill(Sdf2D.path(var10001, var8, var9), -7455954);
      return SurfaceDecal.front(
            var0,
            0.0F,
            wy(27.203125F),
            wz(2.0999999046325684F),
            5.1519999504089355F,
            4.024999618530273F
         )
         .depth(1.399999976158142F, 1.399999976158142F)
         .maxAngle(72.0F)
         .flatLight(1.0F)
         .occlusion(0.30000001192092896F);
   }

   public static void eye(PixelCanvas var0, float var1, float var2, int var3) {
      Sdf2D var4 = Sdf2D.ellipse(
            var1,
            var2 + 10.0F,
            31.0F,
            40.0F
         )
         .rotate((float)var3 * 12.0F, var1, var2 + 10.0F);
      Sdf2D var5 = Sdf2D.ellipse(
            var1,
            var2 + 2.0F,
            26.0F,
            31.0F
         )
         .intersect(var4);
      float var10003 = var2 - 28.0F;
      float var10005 = var2 + 4.0F;
      int[] var10006 = new int[2];
      var10006[0] = -2571046;
      var10006[1] = -776;
      var0.fill(var5, ColorField2D.linear(var1, var10003, var1, var10005, var10006));
      Sdf2D var6 = Sdf2D.ellipse(
         var1 + (float)var3,
         var2 + 5.0F,
         21.0F,
         27.0F
      );
      Sdf2D var10001 = var6.intersect(var5);
      var10003 = var2 - 22.0F;
      var10005 = var2 + 32.0F;
      var10006 = new int[4];
      var10006[0] = -11920890;
      var10006[1] = -5748206;
      var10006[2] = -1535446;
      var10006[3] = -11414;
      var0.fill(var10001, ColorField2D.linear(var1, var10003, var1, var10005, var10006));
      var0.fill(
         Sdf2D.ellipse(
               var1 + (float)var3,
               var2 + 6.0F,
               9.0F,
               21.0F
            )
            .intersect(var5),
         -1711287446,
         4.0F
      );
      var0.fill(var6.outline(2.5F).intersect(var5), -1338371580);
      float var7 = var1 + (float)var3;
      float var8 = var2 + 6.0F;
      var0.fill(
         Sdf2D.circle(var7 - 42.20000076293945F, var8, 46.70000076293945F)
            .intersect(Sdf2D.circle(var7 + 42.20000076293945F, var8, 46.70000076293945F)),
         -14414846
      );
      var0.fill(
         Sdf2D.ellipse(
               var1 - 8.0F,
               var2 - 8.0F,
               7.5F,
               9.0F
            )
            .rotate(
               -20.0F,
               var1 - 8.0F,
               var2 - 8.0F
            ),
         -1
      );
      var0.fill(
         Sdf2D.circle(
            var1 + 9.0F,
            var2 + 17.0F,
            3.5F
         ),
         -419430401
      );
      var0.fill(
         Sdf2D.curve(
            var1 - (float)var3 * 28.0F,
            var2 - 8.0F,
            var1 - (float)var3 * 2.0F,
            var2 - 42.0F,
            var1 + (float)var3 * 30.0F,
            var2 - 24.0F,
            4.0F,
            9.5F
         ),
         -13887470
      );
      var0.fill(
         Sdf2D.taper(
            var1 + (float)var3 * 24.0F,
            var2 - 24.0F,
            7.0F,
            var1 + (float)var3 * 40.0F,
            var2 - 36.0F,
            1.5F
         ),
         -13887470
      );
      var0.fill(
         Sdf2D.curve(
            var1 + (float)var3 * 8.0F,
            var2 + 34.0F,
            var1 + (float)var3 * 21.0F,
            var2 + 31.0F,
            var1 + (float)var3 * 26.0F,
            var2 + 17.0F,
            1.2000000476837158F,
            3.0F
         ),
         -866506210
      );
      var0.fill(
         Sdf2D.curve(
            var1 - (float)var3 * 17.0F,
            var2 - 38.0F,
            var1 + (float)var3 * 2.0F,
            var2 - 48.0F,
            var1 + (float)var3 * 24.0F,
            var2 - 38.0F,
            1.5F,
            2.200000047683716F
         ),
         1721786442
      );
      var0.fill(
         Sdf2D.curve(
            var1 - (float)var3 * 16.0F,
            var2 - 50.0F,
            var1 + (float)var3 * 2.0F,
            var2 - 58.0F,
            var1 + (float)var3 * 22.0F,
            var2 - 53.0F,
            3.0F,
            2.0F
         ),
         -4691398
      );
      float var9 = var1 + (float)var3 * 10.0F;
      float var10 = var2 + 42.0F;
      var0.fill(
         Sdf2D.ellipse(var9, var10, 20.0F, 9.0F),
         1627357068,
         9.0F
      );

      for (int var11 = 0; var11 < (3); var11++) {
         var0.fill(
            Sdf2D.line(
               var9 - 8.0F + (float)var11 * 7.0F,
               var10 - 4.0F,
               var9 - 12.0F + (float)var11 * 7.0F,
               var10 + 4.0F,
               1.600000023841858F
            ),
            1894277230
         );
      }
   }

   public static SurfaceDecal pocketDecal() {
      PixelCanvas var0 = new PixelCanvas(240, 144);
      int var1 = -1722777742;

      for (int var2 = 0; var2 < (18); var2++) {
         var0.fill(
            Sdf2D.box(
               43.5F + (float)var2 * 9.0F,
               16.5F,
               2.5999999046325684F,
               0.75F,
               0.699999988079071F
            ),
            var1
         );
      }

      for (int var5 = 0; var5 < (23); var5++) {
         var0.fill(
            Sdf2D.box(
               21.0F + (float)var5 * 9.0F,
               129.0F,
               2.5999999046325684F,
               0.75F,
               0.699999988079071F
            ),
            var1
         );
      }

      for (int var6 = -1; var6 <= (1); var6 += 2) {
         float var3 = 120.0F + (float)var6 * 78.0F;
         float var4 = 120.0F + (float)var6 * 102.75F;
         var0.fill(
            Sdf2D.taper(
               var3,
               13.5F,
               6.0F,
               var4,
               132.0F,
               3.75F
            ),
            -1872719998
         );
         var0.fill(
            Sdf2D.taper(
               var3 + (float)var6 * 2.25F,
               13.5F,
               2.25F,
               var4 + (float)var6 * 2.25F,
               132.0F,
               1.5F
            ),
            -1605733274
         );
         var0.fill(
            Sdf2D.taper(
               var3 - (float)var6 * 4.5F,
               16.5F,
               1.899999976158142F,
               var4 - (float)var6 * 4.5F,
               129.0F,
               1.5F
            ),
            1627389951
         );
      }

      return SurfaceDecal.front(
            var0,
            0.0F,
            16.030000686645508F,
            2.299999952316284F,
            5.0F,
            3.0F
         )
         .depth(1.2000000476837158F, 1.2000000476837158F)
         .maxAngle(75.0F);
   }

   public static SurfaceDecal pawDecal() {
      PixelCanvas var0 = new PixelCanvas(128, 128);
      int var1 = -877910;
      float var10000 = 8.0F;
      Sdf2D[] var10001 = new Sdf2D[3];
      var10001[0] = Sdf2D.ellipse(
         64.0F,
         90.0F,
         27.0F,
         19.0F
      );
      var10001[1] = Sdf2D.circle(
         48.0F, 78.0F, 15.0F
      );
      var10001[2] = Sdf2D.circle(
         80.0F, 78.0F, 15.0F
      );
      Sdf2D var2 = Sdf2D.blend(var10000, var10001);
      var0.fill(var2, var1);
      var0.fill(
         Sdf2D.ellipse(
               28.0F,
               52.0F,
               11.0F,
               14.0F
            )
            .rotate(-25.0F, 28.0F, 52.0F),
         var1
      );
      var0.fill(
         Sdf2D.ellipse(
               51.0F,
               33.0F,
               11.0F,
               14.5F
            )
            .rotate(-8.0F, 51.0F, 33.0F),
         var1
      );
      var0.fill(
         Sdf2D.ellipse(
               77.0F,
               33.0F,
               11.0F,
               14.5F
            )
            .rotate(8.0F, 77.0F, 33.0F),
         var1
      );
      var0.fill(
         Sdf2D.ellipse(
               100.0F,
               52.0F,
               11.0F,
               14.0F
            )
            .rotate(25.0F, 100.0F, 52.0F),
         var1
      );
      return SurfaceDecal.front(
            var0,
            1.2000000476837158F,
            20.600000381469727F,
            1.600000023841858F,
            1.5F,
            1.5F
         )
         .depth(1.5F, 1.5F)
         .maxAngle(70.0F);
   }

   public static PixelCanvas ribs(int var0, int var1) {
      PixelCanvas var2 = new PixelCanvas(var1, 16);
      float var3 = (float)var1 / (float)var0;

      for (int var4 = 0; var4 < var0; var4++) {
         float var5 = (float)var4 * var3 + var3 * 0.5F;
         var2.fill(
            Sdf2D.box(
               var5,
               8.0F,
               var3 * 0.18000000715255737F,
               8.0F,
               0.0F
            ),
            1078491756
         );
      }

      return var2;
   }

   public static SurfaceDecal hemRib() {
      return SurfaceDecal.wrap(
            ribs(64, 506),
            0.0F,
            14.199999809265137F,
            -0.05000000074505806F,
            0.0F,
            1.0F,
            0.0F,
            0.0F,
            0.0F,
            1.0F,
            360.0F,
            0.6200000047683716F
         )
         .radius(1.2000000476837158F, 3.299999952316284F);
   }

   public static SurfaceDecal cuffRib() {
      return SurfaceDecal.wrap(
            ribs(24, 256),
            -3.7699999809265137F,
            14.300000190734863F,
            0.5699999928474426F,
            0.05999999865889549F,
            1.649999976158142F,
            -0.2199999988079071F,
            0.0F,
            0.0F,
            1.0F,
            360.0F,
            1.2000000476837158F
         )
         .radius(0.6000000238418579F, 1.399999976158142F);
   }

   public static SurfaceDecal bellDecal(float var0) {
      PixelCanvas var1 = new PixelCanvas(64, 64);
      var1.fill(
         Sdf2D.box(
            32.0F,
            30.0F,
            30.0F,
            2.0F,
            1.0F
         ),
         -5737444
      );
      var1.fill(
         Sdf2D.circle(
            32.0F, 40.0F, 4.5F
         ),
         -11915254
      );
      var1.fill(
         Sdf2D.line(
            32.0F,
            40.0F,
            32.0F,
            60.0F,
            3.5F
         ),
         -11915254
      );
      var1.fill(
         Sdf2D.ellipse(
            24.0F,
            20.0F,
            5.0F,
            3.5F
         ),
         -1426063361
      );
      return SurfaceDecal.front(
            var1,
            var0,
            19.600000381469727F,
            2.5F,
            1.0F,
            1.0F
         )
         .depth(0.6000000238418579F, 0.6000000238418579F)
         .maxAngle(70.0F);
   }

   public static SurfaceDecal laces() {
      PixelCanvas var0 = new PixelCanvas(96, 128);
      int var1 = -7710102;

      for (int var2 = 0; var2 < (4); var2++) {
         float var3 = 30.0F + (float)var2 * 22.0F;
         var0.fill(
            Sdf2D.line(
               24.0F,
               var3,
               72.0F,
               var3 + 14.0F,
               6.0F
            ),
            -1
         );
         var0.fill(
            Sdf2D.line(
               72.0F,
               var3,
               24.0F,
               var3 + 14.0F,
               6.0F
            ),
            -1
         );
         var0.fill(Sdf2D.circle(20.0F, var3, 3.5F), var1);
         var0.fill(Sdf2D.circle(76.0F, var3, 3.5F), var1);
      }

      var0.fill(
         Sdf2D.ellipse(
               36.0F,
               14.0F,
               11.0F,
               6.0F
            )
            .outline(4.0F),
         -1
      );
      var0.fill(
         Sdf2D.ellipse(
               60.0F,
               14.0F,
               11.0F,
               6.0F
            )
            .outline(4.0F),
         -1
      );
      var0.fill(
         Sdf2D.circle(
            48.0F, 16.0F, 4.0F
         ),
         -1
      );
      Vec3 var6 = new Vec3(
         -1.2000000476837158F, 0.0F, 0.20000000298023224F
      );
      Vec3 var7 = new Vec3(
            -1.2000000476837158F, 1.6200000047683716F, 0.7200000286102295F
         )
         .rotate(0.0F, -7.0F, 0.0F, var6);
      Vec3 var4 = new Vec3(
            0.0F, 0.800000011920929F, 0.6000000238418579F
         )
         .rotate(0.0F, -7.0F, 0.0F);
      Vec3 var5 = new Vec3(
            0.0F, 0.6000000238418579F, -0.800000011920929F
         )
         .rotate(0.0F, -7.0F, 0.0F);
      return SurfaceDecal.project(
            var0,
            var7.x(),
            var7.y(),
            var7.z(),
            var4.x(),
            var4.y(),
            var4.z(),
            var5.x(),
            var5.y(),
            var5.z(),
            0.949999988079071F,
            1.25F
         )
         .depth(0.6000000238418579F, 0.6000000238418579F)
         .maxAngle(65.0F);
   }

















































   static {
      float[][] var5 = new float[8][];
      float[] var21;
      (var21 = new float[10])[0] = 1.0F;
      var21[1] = -1.0F;
      var21[2] = 30.15F;
      var21[3] = -1.5F;
      var21[4] = 29.6F;
      var21[5] = -2.0F;
      var21[6] = 28.3F;
      var21[7] = -1.8F;
      var21[8] = 27.0F;
      var21[9] = 0.3F;
      var5[0] = var21;
      float[] var23;
      (var23 = new float[10])[0] = 0.95F;
      var23[1] = -0.42F;
      var23[2] = 30.25F;
      var23[3] = -0.75F;
      var23[4] = 29.75F;
      var23[5] = -1.05F;
      var23[6] = 28.6F;
      var23[7] = -0.85F;
      var23[8] = 27.9F;
      var23[9] = -0.35F;
      var5[1] = var23;
      float[] var25;
      (var25 = new float[10])[0] = 1.05F;
      var25[1] = -0.28F;
      var25[2] = 30.3F;
      var25[3] = 0.0F;
      var25[4] = 29.8F;
      var25[5] = 0.5F;
      var25[6] = 28.4F;
      var25[7] = 0.42F;
      var25[8] = 27.2F;
      var25[9] = 0.4F;
      var5[2] = var25;
      float[] var5x;
      (var5x = new float[10])[0] = 0.95F;
      var5x[1] = 0.55F;
      var5x[2] = 30.25F;
      var5x[3] = 0.9F;
      var5x[4] = 29.75F;
      var5x[5] = 1.25F;
      var5x[6] = 28.6F;
      var5x[7] = 1.02F;
      var5x[8] = 27.65F;
      var5x[9] = -0.3F;
      var5[3] = var5x;
      float[] var29;
      (var29 = new float[10])[0] = 1.0F;
      var29[1] = 1.1F;
      var29[2] = 30.15F;
      var29[3] = 1.6F;
      var29[4] = 29.6F;
      var29[5] = 2.05F;
      var29[6] = 28.3F;
      var29[7] = 1.85F;
      var29[8] = 26.75F;
      var29[9] = 0.35F;
      var5[4] = var29;
      float[] var31;
      (var31 = new float[10])[0] = 0.65F;
      var31[1] = -0.75F;
      var31[2] = 30.2F;
      var31[3] = -1.2F;
      var31[4] = 29.6F;
      var31[5] = -1.5F;
      var31[6] = 28.3F;
      var31[7] = -1.3F;
      var31[8] = 27.45F;
      var31[9] = 0.3F;
      var5[5] = var31;
      float[] var33;
      (var33 = new float[10])[0] = 0.5F;
      var33[1] = 0.28F;
      var33[2] = 30.25F;
      var33[3] = 0.6F;
      var33[4] = 29.7F;
      var33[5] = 0.88F;
      var33[6] = 28.5F;
      var33[7] = 0.75F;
      var33[8] = 27.5F;
      var33[9] = -0.3F;
      var5[6] = var33;
      float[] var35;
      (var35 = new float[10])[0] = 0.5F;
      var35[1] = -0.45F;
      var35[2] = 30.25F;
      var35[3] = -0.4F;
      var35[4] = 29.7F;
      var35[5] = -0.3F;
      var35[6] = 28.3F;
      var35[7] = -0.18F;
      var35[8] = 27.6F;
      var35[9] = 0.3F;
      var5[7] = var35;
      FRINGE = var5;
      float[][] var7x = new float[6][];
      float[] var37;
      (var37 = new float[3])[0] = -0.413F;
      var37[1] = 0.766F;
      var37[2] = 0.492F;
      var7x[0] = var37;
      float[] var39;
      (var39 = new float[3])[0] = -0.992F;
      var39[1] = 0.087F;
      var39[2] = -0.087F;
      var7x[1] = var39;
      float[] var41;
      (var41 = new float[3])[0] = -0.539F;
      var41[1] = -0.342F;
      var41[2] = -0.77F;
      var7x[2] = var41;
      float[] var43;
      (var43 = new float[3])[0] = 0.464F;
      var43[1] = -0.375F;
      var43[2] = -0.803F;
      var7x[3] = var43;
      float[] var45;
      (var45 = new float[3])[0] = 0.975F;
      var45[1] = 0.139F;
      var45[2] = -0.172F;
      var7x[4] = var45;
      float[] var47;
      (var47 = new float[3])[0] = 0.353F;
      var47[1] = 0.788F;
      var47[2] = 0.504F;
      var7x[5] = var47;
      CROWN = var7x;
   }

   @Environment(EnvType.CLIENT)
   private static final class CurvePath {
   private final float[] xs;
   private final float[] ys;
   private final float[] zs;
   private final float[] len;
   private final int n;

   CurvePath(float[] var1) {
      int var2 = var1.length / (4) - (2);
      int var3 = 12;
      this.n = var2 * var3 + (1);
      this.xs = new float[this.n];
      this.ys = new float[this.n];
      this.zs = new float[this.n];
      this.len = new float[this.n];
      int var4 = 0;

      for (int var5 = 1; var5 <= var2; var5++) {
         int var6 = (var5 - (1)) * (4);
         int var7 = var5 * (4);
         int var8 = (var5 + (1)) * (4);
         float var9 = var5 == (1)
            ? var1[0]
            : (var1[var6] + var1[var7]) * 0.5F;
         float var10 = var5 == (1)
            ? var1[1]
            : (var1[var6 + (1)] + var1[var7 + (1)]) * 0.5F;
         float var11 = var5 == (1)
            ? var1[2]
            : (var1[var6 + (2)] + var1[var7 + (2)]) * 0.5F;
         float var12 = var5 == var2 ? var1[var8] : (var1[var7] + var1[var8]) * 0.5F;
         float var13 = var5 == var2
            ? var1[var8 + (1)]
            : (var1[var7 + (1)] + var1[var8 + (1)]) * 0.5F;
         float var14 = var5 == var2
            ? var1[var8 + (2)]
            : (var1[var7 + (2)] + var1[var8 + (2)]) * 0.5F;

         for (int var15 = 0; var15 < var3 || var5 == var2 && var15 == var3; var15++) {
            float var16 = (float)var15 / (float)var3;
            float var17 = 1.0F - var16;
            this.xs[var4] = var17 * var17 * var9
               + 2.0F * var17 * var16 * var1[var7]
               + var16 * var16 * var12;
            this.ys[var4] = var17 * var17 * var10
               + 2.0F * var17 * var16 * var1[var7 + (1)]
               + var16 * var16 * var13;
            this.zs[var4] = var17 * var17 * var11
               + 2.0F * var17 * var16 * var1[var7 + (2)]
               + var16 * var16 * var14;
            if (var4 > 0) {
               float var18 = this.xs[var4] - this.xs[var4 - (1)];
               float var19 = this.ys[var4] - this.ys[var4 - (1)];
               float var20 = this.zs[var4] - this.zs[var4 - (1)];
               this.len[var4] = this.len[var4 - (1)]
                  + (float)Math.sqrt((double)(var18 * var18 + var19 * var19 + var20 * var20));
            }

            var4++;
         }
      }
   }

   float param(float var1, float var2, float var3) {
      int var4 = 0;
      float var5 = 3.4028234663852886e+38F;

      for (int var6 = 0; var6 < this.n; var6++) {
         float var7 = var1 - this.xs[var6];
         float var8 = var2 - this.ys[var6];
         float var9 = var3 - this.zs[var6];
         float var10 = var7 * var7 + var8 * var8 + var9 * var9;
         if (var10 < var5) {
            var5 = var10;
            var4 = var6;
         }
      }

      return this.len[var4] / this.len[this.n - (1)];
   }

   int tailColor(float var1, float var2, float var3) {
      float var4 = this.param(var1, var2, var3);
      return ArgbColors.mix(
         ArgbColors.mix(
            -3647457,
            -681403,
            MikaDesign.smooth(0.03999999910593033F, 0.2199999988079071F, var4)
         ),
         -3618,
         MikaDesign.smooth(0.7200000286102295F, 0.800000011920929F, var4)
      );
   }

   SurfaceDecal chevron(PixelCanvas var1, float var2) {
      float var3 = var2 * this.len[this.n - (1)];
      int var4 = 1;

      while (var4 < this.n - (2) && this.len[var4] < var3) {
         var4++;
      }

      float var5 = this.xs[var4 + (1)] - this.xs[var4 - (1)];
      float var6 = this.ys[var4 + (1)] - this.ys[var4 - (1)];
      float var7 = this.zs[var4 + (1)] - this.zs[var4 - (1)];
      return SurfaceDecal.wrap(
            var1,
            this.xs[var4],
            this.ys[var4],
            this.zs[var4],
            var5,
            var6,
            var7,
            this.xs[var4] - 1.7999999523162842F,
            this.ys[var4] - 17.600000381469727F,
            this.zs[var4] + 3.299999952316284F,
            140.0F,
            0.8999999761581421F
         )
         .radius(0.30000001192092896F, 1.600000023841858F);
   }
}
}
