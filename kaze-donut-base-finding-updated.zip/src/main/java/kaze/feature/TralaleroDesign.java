package kaze.feature;

import kaze.feature.Sdf2D.DistanceField2D;
import kaze.feature.SdfShapes.DistanceField3D;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class TralaleroDesign extends CharacterDefinition {
   private static final float YJ = 17.9F;
   private static final float PIVOT_Z = -1.5F;
   private static final float SHIFT = 0.8F;
   private static final float LEG_X = 2.9F;
   private static final float HIP = 12.0F;
   private static final float LEG_Z = 3.4F;
   private static final float KNEE = 6.4F;
   private static final float MID_HIP = 14.2F;
   private static final float MID_Z = -7.0F;
   private static final float SHOE_SCALE = 1.15F;
   private static final float[] BODY_Z;
   private static final float[] BODY_Y;
   private static final float[] BODY_RY;
   private static final float[] BODY_RX;
   private static final float[] LINE_Z;
   private static final float[] LINE_Y;
   private static final float MOUTH_DEG = 152.0F;
   private static final int MOUTH_W = 284;
   private static final int MOUTH_H = 120;
   private static final float MOUTH_PX = 25.0F;
   private static final float MOUTH_Z = 9.45F;
   private static final float CORNER = 74.0F;
   private static final float LIP_FRONT = 11.0F;
   private static final float LIP_BACK = 7.4F;
   private static final int BACK_TOP = -12621165;
   private static final int BACK = -10515274;
   private static final int BELLY = -920330;
   private static final int FIN_TIP = -13346176;
   private static final int SKIN = -10055494;
   private static final int SKIN_LIGHT = -8674358;
   private static final int SKIN_DARK = -11634525;
   private static final int SHOE = -13933608;
   private static final int SHOE_DARK = -14989656;
   private static final int SHOE_LIGHT = -9593609;
   private static final int SOLE = -657935;
   private static final int SOLE_GREY = -4604218;
   private static final int LINE = -15194566;
   private static final int MOUTH = -12972264;
   private static final int GUM = -10872282;
   private static final int TEETH = -263436;

   public TralaleroDesign() {
      super("tralalero", "Tralalero Tralala");
   }

   protected void define(CharacterRig var1) {
      var1.scale(1.0F)
         .outline(-15194566, 0.1599999964237213F)
         .occlusion(0.5F)
         .firstPersonArms(false);
      var1.part(CharacterBone.BODY)
         .pivot(0.0F, 15.899999618530273F, 0.0F);
      Sdf3D var2 = SdfShapes.field(
         TralaleroDesign::loft,
         -5.800000190734863F,
         11.699999809265137F,
         -14.600000381469727F,
         5.800000190734863F,
         24.099998474121094F,
         14.199999809265137F
      );
      Sdf3D var3 = SdfShapes.field(
         (var0, var1x, var2x) -> bellyLine(var2x) - var1x,
         -6.0F,
         10.899999618530273F,
         -14.0F,
         6.0F,
         24.899999618530273F,
         15.0F
      );
      float var10000 = 1.100000023841858F;
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.intersect(0.5F, var2, var3)
         .paint(SurfacePaint.field(TralaleroDesign::skin));
      var10001[1] = dorsal();
      Sdf3D var4 = SdfShapes.blend(var10000, var10001)
         .move(0.0F, 0.0F, 0.800000011920929F);
      PixelCanvas var5 = eyeCanvas();
      PixelCanvas var6 = gillCanvas();
      PixelCanvas var7 = laceCanvas();
      PixelCanvas var8 = stripeCanvas();
      CharacterPartBuilder var9 = var1.extra("shark", CharacterBone.BODY)
         .pivot(0.0F, 17.899999618530273F, -1.5F)
         .shape(var4)
         .resolution(1.2000000476837158F)
         .detail(0.7799999713897705F)
         .outline(0.10000000149011612F)
         .neck(
            0.0F,
            17.899999618530273F,
            6.800000190734863F,
            0.0F,
            0.0F,
            1.0F,
            3.0F
         )
         .look(0.44999998807907104F, 0.44999998807907104F, 28.0F)
         .motion(
            BoneMotionProfile.none()
               .idle(
                  0.699999988079071F,
                  0.800000011920929F,
                  0.0F,
                  0.2800000011920929F
               )
               .walk(
                  2.0F,
                  0.0F,
                  4.0F,
                  1.0F
               )
               .follow(CharacterBone.HEAD, 0.25F)
               .spring(70.0F, 10.0F)
               .limit(12.0F)
         )
         .decal(eye(var5, 1.0F))
         .decal(eye(var5.mirrored(), -1.0F))
         .decal(gills(var6, 1.0F))
         .decal(gills(var6.mirrored(), -1.0F));
      Sdf3D var10 = SdfShapes.field(
         (var0, var1x, var2x) -> var1x - bellyLine(var2x) - 0.4000000059604645F,
         -6.0F,
         10.899999618530273F,
         -14.0F,
         6.0F,
         24.899999618530273F,
         15.0F
      );
      Sdf3D var11 = SdfShapes.intersect(var2.inflate(-0.15000000596046448F), var10)
         .paint(
            SurfacePaint.of(-920330)
               .flatLight(0.4000000059604645F)
               .occlusion(0.3499999940395355F)
         )
         .move(0.0F, 0.0F, 0.800000011920929F);
      var1.extra("belly", var9)
         .shape(var11)
         .resolution(1.0F)
         .detail(1.0F)
         .decal(mouth());
      var1.extra("tail", var9)
         .pivot(0.0F, 19.19999885559082F, -9.899999618530273F)
         .shape(caudal())
         .resolution(1.0F)
         .motion(
            BoneMotionProfile.tail()
               .idle(
                  1.0F,
                  9.0F,
                  0.0F,
                  0.44999998807907104F
               )
               .walk(
                  2.0F,
                  14.0F,
                  0.0F,
                  1.0F
               )
               .drag(5.0F)
               .hang(0.30000001192092896F)
               .turn(0.0F, 16.0F)
               .spring(40.0F, 5.5F)
               .bend(1.2000000476837158F)
         );
      CharacterPartBuilder var12 = var1.part(CharacterBone.RIGHT_ARM)
         .pivot(-4.300000190734863F, 15.399999618530273F, 4.0F)
         .grip(-6.800000190734863F, 13.399999618530273F, 2.700000047683716F)
         .shape(pectoral())
         .resolution(0.8999999761581421F)
         .detail(0.800000011920929F)
         .swing(0.3499999940395355F);
      var1.part(CharacterBone.LEFT_ARM).mirrorOf(var12);
      CharacterPartBuilder var13 = var1.part(CharacterBone.RIGHT_LEG)
         .pivot(-2.9000000953674316F, 12.0F, 3.4000000953674316F)
         .shape(
            leg(
               -2.9000000953674316F,
               12.0F,
               3.4000000953674316F,
               -1.0F
            )
         )
         .resolution(1.0F)
         .detail(1.399999976158142F)
         .swing(0.5F, 35.0F)
         .joint(
            -2.8000001907348633F,
            6.5F,
            3.5500001907348633F,
            0.800000011920929F
         );
      var1.part(CharacterBone.LEFT_LEG).mirrorOf(var13);
      CharacterPartBuilder var14 = var1.extra(
            "shoe_r", CharacterBone.RIGHT_LEG
         )
         .shape(shoe(-2.9000000953674316F, 3.4000000953674316F))
         .resolution(1.0F)
         .detail(1.600000023841858F)
         .decal(laces(var7, -2.9000000953674316F, 3.4000000953674316F))
         .decal(
            stripe(
               var8, -2.9000000953674316F, 3.4000000953674316F, -1.0F
            )
         );
      var1.extra("shoe_l", CharacterBone.LEFT_LEG).mirrorOf(var14);
      CharacterPartBuilder var15 = var1.extra("leg_mid", CharacterBone.BODY)
         .pivot(0.0F, 14.199999809265137F, -7.0F)
         .shape(
            leg(
               0.0F,
               14.199999809265137F,
               -7.0F,
               1.0F
            )
         )
         .resolution(1.0F)
         .detail(1.399999976158142F)
         .motion(
            BoneMotionProfile.none()
               .follow(CharacterBone.LEFT_LEG, 0.5F)
               .walk(
                  22.0F,
                  0.0F,
                  0.0F,
                  1.0F
               )
               .hang(0.5F)
               .limit(45.0F)
         );
      var1.extra("shoe_mid", var15)
         .shape(shoe(0.0F, -7.0F))
         .resolution(1.0F)
         .detail(1.600000023841858F)
         .decal(laces(var7, 0.0F, -7.0F))
         .decal(
            stripe(
               var8,
               0.0F,
               -7.0F,
               -1.0F
            )
         )
         .decal(
            stripe(
               var8.mirrored(),
               0.0F,
               -7.0F,
               1.0F
            )
         );
   }

   private static float smooth(float var0, float var1, float var2) {
      float var3 = (var2 - var0) / (var1 - var0);
      var3 = var3 < 0.0F
         ? 0.0F
         : Math.min(var3, 1.0F);
      return var3 * var3 * (3.0F - 2.0F * var3);
   }

   private static int segment(float[] var0, float var1) {
      int var2 = 0;

      while (var2 < var0.length - (2) && var1 > var0[var2 + (1)]) {
         var2++;
      }

      return var2;
   }

   private static float spline(float[] var0, float[] var1, int var2, float var3, boolean var4) {
      int var5 = var0.length;
      float var6 = var0[var2 + (1)] - var0[var2];
      float var7 = Math.max(0.0F, Math.min(1.0F, (var3 - var0[var2]) / var6));
      float var8 = var1[Math.max(0, var2 - (1))];
      float var9 = var1[var2];
      float var10 = var1[var2 + (1)];
      float var11 = var1[Math.min(var5 - (1), var2 + (2))];
      float var12 = 2.0F * var8
         - 5.0F * var9
         + 4.0F * var10
         - var11;
      float var13 = 3.0F * var9 - var8 - 3.0F * var10 + var11;
      return var4
         ? 0.5F
            * (var10 - var8 + 2.0F * var12 * var7 + 3.0F * var13 * var7 * var7)
            / var6
         : 0.5F
            * (2.0F * var9 + (var10 - var8) * var7 + var12 * var7 * var7 + var13 * var7 * var7 * var7);
   }

   private static float bellyLine(float var0) {
      return spline(
         LINE_Z,
         LINE_Y,
         segment(LINE_Z, var0),
         var0,
         false
      );
   }

   private static float loft(float var0, float var1, float var2) {
      int var3 = BODY_Z.length;
      if (var2 > BODY_Z[var3 - (1)]) {
         float var18 = var1 - 17.899999618530273F - BODY_Y[var3 - (1)];
         float var20 = var2 - BODY_Z[var3 - (1)];
         return (float)Math.sqrt((double)(var0 * var0 + var18 * var18 + var20 * var20)) - BODY_RY[var3 - (1)];
      } else if (var2 < BODY_Z[0]) {
         float var17 = var1 - 17.899999618530273F - BODY_Y[0];
         float var19 = var2 - BODY_Z[0];
         return (float)Math.sqrt((double)(var0 * var0 + var17 * var17 + var19 * var19)) - BODY_RX[0];
      } else {
         int var4 = segment(BODY_Z, var2);
         float var5 = 17.899999618530273F
            + spline(BODY_Z, BODY_Y, var4, var2, false);
         float var6 = spline(BODY_Z, BODY_RY, var4, var2, false);
         float var7 = spline(BODY_Z, BODY_RX, var4, var2, false);
         float var8 = spline(BODY_Z, BODY_RY, var4, var2, true);
         float var9 = spline(BODY_Z, BODY_RX, var4, var2, true);
         float var10 = spline(BODY_Z, BODY_Y, var4, var2, true);
         float var11 = Math.max(Math.abs(var9), Math.abs(var8)) + Math.abs(var10);
         float var12 = var0 / var7;
         float var13 = (var1 - var5) / var6;
         float var14 = (float)Math.sqrt((double)(var12 * var12 + var13 * var13));
         float var15 = (float)Math.sqrt((double)(var12 * var12 / (var7 * var7) + var13 * var13 / (var6 * var6)));
         float var16 = var15 < 9.999999974752427e-07F
            ? -Math.min(var7, var6)
            : var14 * (var14 - 1.0F) / var15;
         return var16 / (float)Math.sqrt((double)(1.0F + var11 * var11));
      }
   }

   private static int skin(float var0, float var1, float var2) {
      return ArgbColors.mix(
         -10515274,
         -12621165,
         smooth(bellyLine(var2) + 0.5F, 23.399999618530273F, var1)
      );
   }

   private static Sdf2D outline(float var0, float... var1) {
      float[] var2 = (float[])var1.clone();

      for (int var3 = 1; var3 < var2.length; var3 += 2) {
         var2[var3] += var0;
      }

      return Sdf2D.polygon(var2);
   }

   private static Sdf3D blade(Sdf2D var0, float var1, float var2, float var3, float var4) {
      Sdf3D var5 = SdfShapes.extrude(var0, var3, var3);
      float var6 = (float)Math.sqrt((double)(1.0F + var4 * var4));
      return SdfShapes.field((var6x, var7, var8) -> {
         float var9 = (float)Math.sqrt((double)((var6x - var1) * (var6x - var1) + (var7 - var2) * (var7 - var2)));
         return Math.max(var5.distance(var6x, var7, var8), (Math.abs(var8) - var3 + var4 * var9) / var6);
      }, var0.minX(), var0.minY(), -var3, var0.maxX(), var0.maxY(), var3);
   }

   private static Sdf3D side(Sdf3D var0) {
      return orient(
         var0,
         0.0F,
         0.0F,
         0.0F,
         new Vec3(
            0.0F, 0.0F, -1.0F
         ),
         Vec3.UP
      );
   }

   private static Sdf3D dorsal() {
      float var10000 = 17.899999618530273F;
      float[] var10001 = new float[28];
      var10001[0] = -2.5999999046325684F;
      var10001[1] = 4.199999809265137F;
      var10001[2] = -1.899999976158142F;
      var10001[3] = 6.199999809265137F;
      var10001[4] = -1.0F;
      var10001[5] = 7.900000095367432F;
      var10001[6] = 0.10000000149011612F;
      var10001[7] = 9.399999618530273F;
      var10001[8] = 1.399999976158142F;
      var10001[9] = 10.600000381469727F;
      var10001[10] = 2.5999999046325684F;
      var10001[11] = 11.5F;
      var10001[12] = 3.700000047683716F;
      var10001[13] = 12.100000381469727F;
      var10001[14] = 3.200000047683716F;
      var10001[15] = 11.199999809265137F;
      var10001[16] = 2.75F;
      var10001[17] = 10.0F;
      var10001[18] = 2.450000047683716F;
      var10001[19] = 8.699999809265137F;
      var10001[20] = 2.4000000953674316F;
      var10001[21] = 7.400000095367432F;
      var10001[22] = 2.5999999046325684F;
      var10001[23] = 6.199999809265137F;
      var10001[24] = 3.0999999046325684F;
      var10001[25] = 5.0F;
      var10001[26] = 3.5999999046325684F;
      var10001[27] = 4.199999809265137F;
      Sdf2D var0 = outline(var10000, var10001);
      var10000 = 17.899999618530273F;
      var10001 = new float[14];
      var10001[0] = 8.300000190734863F;
      var10001[1] = 2.200000047683716F;
      var10001[2] = 8.899999618530273F;
      var10001[3] = 3.5999999046325684F;
      var10001[4] = 9.699999809265137F;
      var10001[5] = 4.699999809265137F;
      var10001[6] = 10.600000381469727F;
      var10001[7] = 5.5F;
      var10001[8] = 10.199999809265137F;
      var10001[9] = 4.5F;
      var10001[10] = 10.100000381469727F;
      var10001[11] = 3.4000000953674316F;
      var10001[12] = 10.399999618530273F;
      var10001[13] = 2.200000047683716F;
      Sdf2D var1 = outline(var10000, var10001);
      Sdf3D[] var4 = new Sdf3D[2];
      var4[0] = side(
         blade(
            var0.inflate(0.10000000149011612F),
            0.4000000059604645F,
            22.5F,
            1.5F,
            0.125F
         )
      );
      var4[1] = side(
         blade(
            var1,
            9.399999618530273F,
            20.69999885559082F,
            0.7200000286102295F,
            0.14000000059604645F
         )
      );
      Sdf3D var2 = SdfShapes.union(var4);
      return var2.paint(
         SurfacePaint.vertical(
            -12621165, 22.899999618530273F, -13346176, 29.399999618530273F
         )
      );
   }

   private static Sdf3D caudal() {
      float var10000 = 17.899999618530273F;
      float[] var10001 = new float[40];
      var10001[0] = 12.0F;
      var10001[1] = 1.399999976158142F;
      var10001[2] = 11.699999809265137F;
      var10001[3] = 2.200000047683716F;
      var10001[4] = 12.399999618530273F;
      var10001[5] = 3.799999952316284F;
      var10001[6] = 13.199999809265137F;
      var10001[7] = 5.400000095367432F;
      var10001[8] = 14.0F;
      var10001[9] = 7.0F;
      var10001[10] = 14.800000190734863F;
      var10001[11] = 8.300000190734863F;
      var10001[12] = 15.399999618530273F;
      var10001[13] = 9.100000381469727F;
      var10001[14] = 15.0F;
      var10001[15] = 7.900000095367432F;
      var10001[16] = 14.600000381469727F;
      var10001[17] = 6.300000190734863F;
      var10001[18] = 14.300000190734863F;
      var10001[19] = 4.599999904632568F;
      var10001[20] = 14.100000381469727F;
      var10001[21] = 3.0F;
      var10001[22] = 14.199999809265137F;
      var10001[23] = 1.600000023841858F;
      var10001[24] = 14.399999618530273F;
      var10001[25] = 0.20000000298023224F;
      var10001[26] = 14.699999809265137F;
      var10001[27] = -1.2999999523162842F;
      var10001[28] = 14.949999809265137F;
      var10001[29] = -2.700000047683716F;
      var10001[30] = 15.199999809265137F;
      var10001[31] = -3.9000000953674316F;
      var10001[32] = 14.5F;
      var10001[33] = -3.200000047683716F;
      var10001[34] = 13.600000381469727F;
      var10001[35] = -2.200000047683716F;
      var10001[36] = 12.800000190734863F;
      var10001[37] = -1.0F;
      var10001[38] = 11.899999618530273F;
      var10001[39] = 0.4000000059604645F;
      Sdf2D var0 = outline(var10000, var10001);
      Sdf3D var1 = side(
         blade(
            var0.inflate(0.07999999821186066F),
            12.0F,
            19.299999237060547F,
            0.8199999928474426F,
            0.06199999898672104F
         )
      );
      Sdf3D var2 = SdfShapes.cone(
         0.0F,
         19.100000381469727F,
         -10.300000190734863F,
         1.5F,
         0.0F,
         19.299999237060547F,
         -12.5F,
         1.0F
      );
      Sdf3D var3 = SdfShapes.ellipsoid(
         0.0F,
         19.299999237060547F,
         -12.199999809265137F,
         1.2999999523162842F,
         0.550000011920929F,
         1.399999976158142F
      );
      var10000 = 0.699999988079071F;
      Sdf3D[] var5 = new Sdf3D[3];
      var5[0] = var2;
      var5[1] = var3;
      var5[2] = var1;
      return SdfShapes.blend(var10000, var5)
         .paint(
            SurfacePaint.radial(
               -10515274,
               0.0F,
               19.299999237060547F,
               -12.199999809265137F,
               5.5F,
               -13346176
            )
         )
         .move(0.0F, 0.0F, 0.800000011920929F);
   }

   private static Sdf3D pectoral() {
      float[] var10000 = new float[26];
      var10000[0] = -1.2000000476837158F;
      var10000[1] = 2.0F;
      var10000[2] = 0.5F;
      var10000[3] = 2.0999999046325684F;
      var10000[4] = 2.0F;
      var10000[5] = 1.7000000476837158F;
      var10000[6] = 3.5F;
      var10000[7] = 1.0F;
      var10000[8] = 5.0F;
      var10000[9] = 0.10000000149011612F;
      var10000[10] = 6.300000190734863F;
      var10000[11] = -0.8999999761581421F;
      var10000[12] = 7.0F;
      var10000[13] = -1.600000023841858F;
      var10000[14] = 6.0F;
      var10000[15] = -1.5F;
      var10000[16] = 4.599999904632568F;
      var10000[17] = -1.350000023841858F;
      var10000[18] = 3.200000047683716F;
      var10000[19] = -1.2999999523162842F;
      var10000[20] = 1.7999999523162842F;
      var10000[21] = -1.5F;
      var10000[22] = 0.4000000059604645F;
      var10000[23] = -1.899999976158142F;
      var10000[24] = -1.2000000476837158F;
      var10000[25] = -2.200000047683716F;
      Sdf2D var0 = Sdf2D.polygon(var10000);
      Sdf3D var1 = orient(
         blade(
            var0,
            0.0F,
            0.0F,
            0.6200000047683716F,
            0.05000000074505806F
         ),
         -4.300000190734863F,
         15.399999618530273F,
         3.200000047683716F,
         new Vec3(
            -0.800000011920929F, -0.5F, -0.33000001311302185F
         ),
         new Vec3(
            0.25F, 0.05000000074505806F, 1.0F
         )
      );
      return var1.paint(
            SurfacePaint.radial(
               -10515274,
               -4.300000190734863F,
               15.399999618530273F,
               3.200000047683716F,
               6.0F,
               -13346176
            )
         )
         .move(0.0F, 0.0F, 0.800000011920929F);
   }

   private static SurfacePaint legPaint(float var0) {
      return SurfacePaint.field(
         (var1, var2, var3) -> {
            float var4 = smooth(var0 + 0.30000001192092896F, var0 + 1.2000000476837158F, var3);
            float var5 = smooth(
                  1.2999999523162842F,
                  0.30000001192092896F,
                  Math.abs(var2 - 6.400000095367432F)
               )
               * smooth(var0 - 0.20000000298023224F, var0 - 0.800000011920929F, var3);
            return ArgbColors.mix(
               ArgbColors.mix(-10055494, -8674358, var4), -11634525, var5
            );
         }
      );
   }

   private static Sdf3D leg(float var0, float var1, float var2, float var3) {
      float var4 = 6.400000095367432F;
      float var5 = var1 - 6.400000095367432F;
      Sdf3D var6 = SdfShapes.capsule(
         var0, var1, var2, var0, var1 + 2.799999952316284F, var2, 1.850000023841858F
      );
      Sdf3D var7 = SdfShapes.cone(
         var0,
         var1 + 0.30000001192092896F,
         var2,
         2.0F,
         var0 - var3 * 0.15000000596046448F,
         var4 + 0.8999999761581421F,
         var2 + 0.15000000596046448F,
         1.1200000047683716F
      );
      Sdf3D var8 = SdfShapes.ellipsoid(
         var0 + var3 * 0.05000000074505806F,
         var4 + 0.5600000023841858F * var5,
         var2 + 0.8500000238418579F,
         1.1799999475479126F,
         0.41999998688697815F * var5,
         1.0800000429153442F
      );
      Sdf3D var9 = SdfShapes.ellipsoid(
         var0 + var3 * 0.699999988079071F,
         var4 + 0.550000011920929F * var5,
         var2,
         0.8500000238418579F,
         0.44999998807907104F * var5,
         1.0499999523162842F
      );
      Sdf3D var10 = SdfShapes.ellipsoid(
         var0 - var3 * 0.6000000238418579F,
         var4 + 1.350000023841858F,
         var2 + 0.550000011920929F,
         0.800000011920929F,
         1.0F,
         0.7799999713897705F
      );
      Sdf3D var11 = SdfShapes.ellipsoid(
         var0,
         var4 + 0.550000011920929F * var5,
         var2 - 0.699999988079071F,
         1.2000000476837158F,
         0.44999998807907104F * var5,
         0.949999988079071F
      );
      Sdf3D var12 = SdfShapes.sphere(
         var0 - var3 * 0.10000000149011612F,
         var4 + 0.10000000149011612F,
         var2 + 0.15000000596046448F,
         0.8999999761581421F
      );
      Sdf3D var13 = SdfShapes.ellipsoid(
         var0 - var3 * 0.05000000074505806F,
         var4 + 0.25F,
         var2 + 0.949999988079071F,
         0.550000011920929F,
         0.6200000047683716F,
         0.4000000059604645F
      );
      Sdf3D var14 = SdfShapes.cone(
         var0 - var3 * 0.10000000149011612F,
         var4 - 0.30000001192092896F,
         var2 + 0.25F,
         0.8600000143051147F,
         var0,
         2.4000000953674316F,
         var2 + 0.05000000074505806F,
         0.5600000023841858F
      );
      Sdf3D var15 = SdfShapes.ellipsoid(
         var0 - var3 * 0.36000001430511475F,
         var4 - 1.5499999523162842F,
         var2 - 0.6200000047683716F,
         0.8399999737739563F,
         1.5499999523162842F,
         0.9800000190734863F
      );
      Sdf3D var16 = SdfShapes.ellipsoid(
         var0 + var3 * 0.36000001430511475F,
         var4 - 1.25F,
         var2 - 0.550000011920929F,
         0.7599999904632568F,
         1.350000023841858F,
         0.8799999952316284F
      );
      Sdf3D var17 = SdfShapes.cone(
         var0,
         var4 - 2.700000047683716F,
         var2 - 0.550000011920929F,
         0.5F,
         var0,
         2.200000047683716F,
         var2 - 0.5F,
         0.41999998688697815F
      );
      Sdf3D var18 = SdfShapes.sphere(
         var0, 2.299999952316284F, var2, 0.5799999833106995F
      );
      Sdf3D[] var10000 = new Sdf3D[2];
      var10000[0] = var6;
      int var10002 = 1;
      float var10003 = 0.30000001192092896F;
      Sdf3D[] var10004 = new Sdf3D[12];
      var10004[0] = var7;
      var10004[1] = var8;
      var10004[2] = var9;
      var10004[3] = var10;
      var10004[4] = var11;
      var10004[5] = var12;
      var10004[6] = var13;
      var10004[7] = var14;
      var10004[8] = var15;
      var10004[9] = var16;
      var10004[10] = var17;
      var10004[11] = var18;
      var10000[var10002] = SdfShapes.blend(var10003, var10004);
      Sdf3D var19 = SdfShapes.union(var10000).paint(legPaint(var2));
      Sdf3D var20 = flat(
            foot(0.0F),
            var0,
            0.6000000238418579F,
            var2,
            0.6000000238418579F,
            0.5199999809265137F
         )
         .paint(
            SurfacePaint.vertical(
               -4604218, 0.20000000298023224F, -657935, 0.30000001192092896F
            )
         );
      var10000 = new Sdf3D[2];
      var10000[0] = var19;
      var10000[1] = var20.scale(
         1.149999976158142F, var0, 0.0F, var2
      );
      return SdfShapes.union(var10000);
   }

   private static Sdf3D orient(
      Sdf3D var0, float var1, float var2, float var3, Vec3 var4, Vec3 var5
   ) {
      Vec3 var6 = var4.normalize();
      Vec3 var7 = var6.cross(var5).normalize();
      Vec3 var8 = var7.cross(var6);
      float var9 = (float)Math.acos(
         (double)Math.max(
            -1.0F,
            Math.min(
               1.0F,
               (var6.x() + var8.y() + var7.z() - 1.0F) * 0.5F
            )
         )
      );
      Sdf3D var10 = var9 < 9.999999747378752e-05F
         ? var0
         : var0.rotateAxis(
            var8.z() - var7.y(),
            var7.x() - var6.z(),
            var6.y() - var8.x(),
            (float)Math.toDegrees((double)var9),
            0.0F,
            0.0F,
            0.0F
         );
      return var10.move(var1, var2, var3);
   }

   private static Sdf3D flat(Sdf2D var0, float var1, float var2, float var3, float var4, float var5) {
      return orient(
         SdfShapes.extrude(var0, var4, var5), var1, var2, var3, Vec3.LEFT, Vec3.FORWARD
      );
   }

   private static Sdf2D foot(float var0) {
      Sdf2D var1 = Sdf2D.circle(
         0.0F, -1.0499999523162842F, 1.0F
      );
      Sdf2D var2 = Sdf2D.circle(
         0.0F, 1.399999976158142F, 1.2200000286102295F
      );
      Sdf2D var3 = Sdf2D.circle(
         0.0F, 2.3499999046325684F, 1.0499999523162842F
      );
      float var10000 = 2.200000047683716F;
      Sdf2D[] var10001 = new Sdf2D[3];
      var10001[0] = var1;
      var10001[1] = var2;
      var10001[2] = var3;
      Sdf2D var4 = Sdf2D.blend(var10000, var10001);
      return var0 > 0.0F ? var4.inflate(-var0) : var4;
   }

   private static Sdf3D shoe(float var0, float var1) {
      float var10000 = 0.800000011920929F;
      Sdf3D[] var10001 = new Sdf3D[2];
      var10001[0] = SdfShapes.cone(
         var0,
         1.5499999523162842F,
         var1 - 0.8500000238418579F,
         1.2999999523162842F,
         var0,
         1.25F,
         var1 + 1.100000023841858F,
         1.2999999523162842F
      );
      var10001[1] = SdfShapes.ellipsoid(
         var0,
         0.949999988079071F,
         var1 + 1.9500000476837158F,
         1.2200000286102295F,
         0.9200000166893005F,
         1.5F
      );
      Sdf3D var2 = SdfShapes.blend(var10000, var10001);
      SurfacePaint var3 = SurfacePaint.field(
         (var1x, var2x, var3x) -> ArgbColors.mix(
               -13933608,
               -14989656,
               smooth(var1 - 0.6000000238418579F, var1 - 1.2999999523162842F, var3x)
            )
      );
      Sdf3D var4 = SdfShapes.intersect(
            0.15000000596046448F,
            var2,
            flat(
               foot(0.10000000149011612F),
               var0,
               2.0F,
               var1,
               1.2999999523162842F,
               0.25F
            )
         )
         .paint(var3);
      Sdf3D var5 = SdfShapes.torus(
            var0,
            2.950000047683716F,
            var1 - 0.5F,
            0.7799999713897705F,
            0.3400000035762787F
         )
         .rotate(
            -14.0F,
            0.0F,
            0.0F,
            var0,
            2.950000047683716F,
            var1 - 0.5F
         )
         .color(-14989656);
      Sdf3D var6 = SdfShapes.ellipsoid(
            var0,
            2.9000000953674316F,
            var1 + 0.3499999940395355F,
            0.5199999809265137F,
            0.4000000059604645F,
            0.699999988079071F
         )
         .rotate(
            20.0F,
            0.0F,
            0.0F,
            var0,
            2.9000000953674316F,
            var1 + 0.3499999940395355F
         )
         .color(-9593609);
      Sdf3D var7 = SdfShapes.ellipsoid(
            var0,
            3.1500000953674316F,
            var1 - 1.25F,
            0.25999999046325684F,
            0.44999998807907104F,
            0.20000000298023224F
         )
         .color(-14989656);
      var10000 = 0.20000000298023224F;
      var10001 = new Sdf3D[4];
      var10001[0] = var4;
      var10001[1] = var5;
      var10001[2] = var6;
      var10001[3] = var7;
      return SdfShapes.blend(var10000, var10001)
         .scale(1.149999976158142F, var0, 0.0F, var1);
   }

   private static PixelCanvas laceCanvas() {
      PixelCanvas var0 = new PixelCanvas(60, 76);

      for (int var1 = 0; var1 < (4); var1++) {
         float var2 = 6.5F + (float)var1 * 20.25F;
         float var3 = 22.5F - (float)var1 * 1.899999976158142F;
         var0.fill(
            Sdf2D.box(
               30.0F,
               var2,
               var3,
               4.099999904632568F,
               4.099999904632568F
            ),
            -1
         );
         var0.fill(
            Sdf2D.circle(
               30.0F - var3 - 2.299999952316284F,
               var2,
               2.4000000953674316F
            ),
            -14274500
         );
         var0.fill(
            Sdf2D.circle(
               30.0F + var3 + 2.299999952316284F,
               var2,
               2.4000000953674316F
            ),
            -14274500
         );
      }

      return var0;
   }

   private static PixelCanvas stripeCanvas() {
      PixelCanvas var0 = new PixelCanvas(160, 30);
      var0.fill(
         Sdf2D.line(
            20.0F,
            9.0F,
            140.0F,
            21.0F,
            13.0F
         ),
         -1
      );
      return var0;
   }

   private static SurfaceDecal stripe(PixelCanvas var0, float var1, float var2, float var3) {
      float var4 = 1.149999976158142F;
      return SurfaceDecal.project(
            var0,
            var1 + var3 * 1.2999999523162842F * var4,
            1.5499999523162842F * var4,
            var2 + 0.3499999940395355F * var4,
            var3,
            0.0F,
            0.0F,
            0.0F,
            1.0F,
            0.0F,
            3.5999999046325684F * var4,
            0.6800000071525574F * var4
         )
         .depth(0.8999999761581421F, 0.8999999761581421F)
         .maxAngle(70.0F)
         .flatLight(0.6000000238418579F)
         .occlusion(0.4000000059604645F);
   }

   private static SurfaceDecal laces(PixelCanvas var0, float var1, float var2) {
      float var3 = 1.149999976158142F;
      return SurfaceDecal.project(
            var0,
            var1,
            2.700000047683716F * var3,
            var2 + 1.2999999523162842F * var3,
            0.0F,
            0.7900000214576721F,
            0.6100000143051147F,
            0.0F,
            1.0F,
            0.0F,
            1.25F * var3,
            1.5800000429153442F * var3
         )
         .depth(0.8999999761581421F, 0.8999999761581421F)
         .flatLight(0.6000000238418579F)
         .occlusion(0.4000000059604645F);
   }

   private static PixelCanvas eyeCanvas() {
      PixelCanvas var0 = new PixelCanvas(96, 96);
      float var1 = 48.0F;
      float var2 = 50.0F;
      Sdf2D var3 = Sdf2D.ellipse(
         var1, var2, 21.0F, 20.0F
      );
      var0.fill(var3.inflate(4.0F), 1428832344, 3.0F);
      float var10002 = var1 - 4.5F;
      float var10003 = var2 - 6.0F;
      float var10004 = 26.0F;
      int[] var10005 = new int[2];
      var10005[0] = -14011322;
      var10005[1] = -16316147;
      var0.fill(var3, ColorField2D.radial(var10002, var10003, var10004, var10005));
      var0.fill(
         Sdf2D.circle(
            var1 - 7.5F,
            var2 - 7.0F,
            5.599999904632568F
         ),
         -1
      );
      var0.fill(
         Sdf2D.circle(
            var1 + 7.5F,
            var2 + 8.0F,
            2.4000000953674316F
         ),
         -1325400065
      );
      var0.fill(
         Sdf2D.arc(
            var1,
            var2 + 2.0F,
            22.0F,
            200.0F,
            340.0F,
            4.0F
         ),
         -2144713630,
         2.0F
      );
      return var0;
   }

   private static SurfaceDecal eye(PixelCanvas var0, float var1) {
      return SurfaceDecal.project(
            var0,
            var1 * 3.299999952316284F,
            20.100000381469727F,
            10.199999809265137F,
            var1 * 0.8399999737739563F,
            0.36000001430511475F,
            0.4000000059604645F,
            0.0F,
            1.0F,
            0.0F,
            2.200000047683716F,
            2.200000047683716F
         )
         .depth(1.2000000476837158F, 1.2000000476837158F)
         .maxAngle(75.0F)
         .flatLight(0.699999988079071F);
   }

   private static PixelCanvas gillCanvas() {
      PixelCanvas var0 = new PixelCanvas(120, 120);

      for (int var1 = 0; var1 < (5); var1++) {
         float var2 = 16.0F + (float)var1 * 22.0F;
         float var3 = 42.0F - (float)var1 * 3.0F;
         var0.fill(
            Sdf2D.curve(
               var2,
               58.0F - var3,
               var2 + 7.0F,
               58.0F,
               var2,
               58.0F + var3,
               3.4000000953674316F,
               3.4000000953674316F
            ),
            -802799780
         );
      }

      return var0;
   }

   private static SurfaceDecal gills(PixelCanvas var0, float var1) {
      return SurfaceDecal.project(
            var0,
            var1 * 5.099999904632568F,
            18.5F,
            6.0F,
            var1,
            0.05000000074505806F,
            0.20000000298023224F,
            0.0F,
            1.0F,
            0.0F,
            2.799999952316284F,
            2.799999952316284F
         )
         .depth(1.5F, 1.5F);
   }

   private static float mouthX(float var0) {
      return 142.0F + var0 * 284.0F / 152.0F;
   }

   private static float arch(float var0) {
      float var1 = Math.min(1.0F, Math.abs(var0) / 74.0F);
      float var2 = 11.0F
         - 3.5999999046325684F * (float)Math.pow((double)var1, 1.8);
      return 60.0F
         - (var2 - 9.449999809265137F) * 25.0F;
   }

   private static float gape(float var0) {
      float var1 = Math.min(1.0F, Math.abs(var0) / 74.0F);
      return 15.000000953674316F * (1.0F - var1 * var1);
   }

   private static SurfaceDecal mouth() {
      PixelCanvas var0 = new PixelCanvas(284, 120);
      float var1 = 0.5352112650871277F;
      float[] var2 = new float[284];
      float[] var3 = new float[284];
      float[] var4 = new float[284];

      for (int var5 = 0; var5 < (284); var5++) {
         float var6 = ((float)var5 + 0.5F - 142.0F) * var1;
         float var7 = (
               arch(var6 + 0.5F)
                  - arch(var6 - 0.5F)
            )
            * var1;
         var2[var5] = arch(var6);
         var3[var5] = Math.abs(var6) > 75.0F
            ? -1.0F
            : gape(var6);
         var4[var5] = 1.0F / (float)Math.sqrt((double)(1.0F + var7 * var7));
      }

      Sdf2D var15 = Sdf2D.field(
         (var3x, var4x) -> {
            int var5x = Math.max(0, Math.min(283, (int)var3x));
            return var3[var5x] < 0.0F
               ? 4.0F
               : (Math.abs(var4x - var2[var5x]) - var3[var5x]) * var4[var5x];
         },
         mouthX(-76.0F),
         3.0F,
         mouthX(76.0F),
         117.0F
      );
      float var10002 = 0.0F;
      float var10003 = 0.0F;
      float var10004 = 0.0F;
      float var10005 = 120.0F;
      int[] var10006 = new int[2];
      var10006[0] = -10872282;
      var10006[1] = -12972264;
      var0.fill(var15, ColorField2D.linear(var10002, var10003, var10004, var10005, var10006));
      float var16 = 0.75F;
      float var17 = 2.5F;

      for (int var8 = -4; var8 <= (4); var8++) {
         float var9 = (float)var8 * 15.0F;
         float var10 = gape(var9);
         if (!(var10 < var17)) {
            float[] var10000 = new float[6];
            var10000[0] = mouthX(var9 - 6.0F);
            var10000[1] = arch(var9 - 6.0F)
               - gape(var9 - 6.0F)
               - var16;
            var10000[2] = mouthX(var9 + 6.0F);
            var10000[3] = arch(var9 + 6.0F)
               - gape(var9 + 6.0F)
               - var16;
            var10000[4] = mouthX(var9);
            var10000[5] = arch(var9) + var10 * 0.5F;
            Sdf2D var11 = Sdf2D.polygon(var10000);
            var0.fill(var11.intersect(var15), -263436);
            float var12 = var9 + 7.5F;
            float var13 = gape(var12);
            if (!(var13 < var17) && var8 != (4)) {
               var10000 = new float[6];
               var10000[0] = mouthX(var12 - 5.0F);
               var10000[1] = arch(var12 - 5.0F)
                  + gape(var12 - 5.0F)
                  + var16;
               var10000[2] = mouthX(var12 + 5.0F);
               var10000[3] = arch(var12 + 5.0F)
                  + gape(var12 + 5.0F)
                  + var16;
               var10000[4] = mouthX(var12);
               var10000[5] = arch(var12) - var13 * 0.3499999940395355F;
               Sdf2D var14 = Sdf2D.polygon(var10000);
               var0.fill(var14.intersect(var15), -1185056);
            }
         }
      }

      var0.fill(var15.outline(2.5F), -15194566);
      return SurfaceDecal.wrap(
            var0,
            0.0F,
            18.350000381469727F,
            10.25F,
            0.0F,
            0.0F,
            1.0F,
            0.0F,
            -1.0F,
            0.0F,
            152.0F,
            4.800000190734863F
         )
         .maxAngle(80.0F)
         .flatLight(1.0F)
         .occlusion(0.30000001192092896F);
   }





















   static {
      float[] var3;
      (var3 = new float[13])[0] = -12.4F;
      var3[1] = -10.7F;
      var3[2] = -8.4F;
      var3[3] = -5.7F;
      var3[4] = -2.9F;
      var3[5] = 0.0F;
      var3[6] = 2.9F;
      var3[7] = 5.8F;
      var3[8] = 8.3F;
      var3[9] = 10.3F;
      var3[10] = 11.8F;
      var3[11] = 12.8F;
      var3[12] = 13.4F;
      BODY_Z = var3;
      float[] var5;
      (var5 = new float[13])[0] = 1.4F;
      var5[1] = 1.15F;
      var5[2] = 0.8F;
      var5[3] = 0.4F;
      var5[4] = 0.1F;
      var5[5] = 0.0F;
      var5[6] = 0.05F;
      var5[7] = 0.25F;
      var5[8] = 0.5F;
      var5[9] = 0.75F;
      var5[10] = 0.95F;
      var5[11] = 1.05F;
      var5[12] = 1.1F;
      BODY_Y = var5;
      float[] var7;
      (var7 = new float[13])[0] = 1.0F;
      var7[1] = 2.1F;
      var7[2] = 3.3F;
      var7[3] = 4.6F;
      var7[4] = 5.5F;
      var7[5] = 5.85F;
      var7[6] = 5.75F;
      var7[7] = 5.2F;
      var7[8] = 4.35F;
      var7[9] = 3.35F;
      var7[10] = 2.3F;
      var7[11] = 1.35F;
      var7[12] = 0.45F;
      BODY_RY = var7;
      float[] var9;
      (var9 = new float[13])[0] = 0.9F;
      var9[1] = 1.8F;
      var9[2] = 2.9F;
      var9[3] = 4.2F;
      var9[4] = 5.1F;
      var9[5] = 5.45F;
      var9[6] = 5.35F;
      var9[7] = 4.8F;
      var9[8] = 3.95F;
      var9[9] = 3.0F;
      var9[10] = 2.1F;
      var9[11] = 1.25F;
      var9[12] = 0.45F;
      BODY_RX = var9;
      float[] var11;
      (var11 = new float[12])[0] = -14.5F;
      var11[1] = -11.0F;
      var11[2] = -8.0F;
      var11[3] = -5.0F;
      var11[4] = -2.0F;
      var11[5] = 1.0F;
      var11[6] = 3.5F;
      var11[7] = 5.5F;
      var11[8] = 7.0F;
      var11[9] = 9.0F;
      var11[10] = 11.0F;
      var11[11] = 14.5F;
      LINE_Z = var11;
      float[] var13;
      (var13 = new float[12])[0] = 19.699999F;
      var13[1] = 19.1F;
      var13[2] = 18.1F;
      var13[3] = 17.1F;
      var13[4] = 16.4F;
      var13[5] = 16.3F;
      var13[6] = 16.9F;
      var13[7] = 17.65F;
      var13[8] = 17.4F;
      var13[9] = 17.6F;
      var13[10] = 18.1F;
      var13[11] = 18.4F;
      LINE_Y = var13;
   }
}
