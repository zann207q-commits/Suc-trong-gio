package kaze.feature;

import java.util.random.RandomGenerator;

public final class RetryDeadline {
   public static final long MIN_DELAY_NANOS = 30_000_000_000L;
   public static final long MAX_DELAY_NANOS = 120_000_000_000L;

   private long deadline;
   private boolean armed;

   public void arm(long now, RandomGenerator random) {
      this.deadline = now + random.nextLong(MIN_DELAY_NANOS, MAX_DELAY_NANOS + 1);
      this.armed = true;
   }

   public void retry(long now) {
      this.deadline = now + 1_000_000_000L;
      this.armed = true;
   }

   public boolean isArmed() {
      return this.armed;
   }

   public boolean due(long now) {
      return this.armed && now - this.deadline >= 0;
   }

   public void clear() {
      this.armed = false;
   }
}
