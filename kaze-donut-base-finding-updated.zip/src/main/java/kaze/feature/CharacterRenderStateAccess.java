package kaze.feature;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface CharacterRenderStateAccess {
   WornCharacterModel kaze$character();

   void kaze$setCharacter(WornCharacterModel var1);

   float kaze$seat();

   void kaze$setSeat(float var1);
}
