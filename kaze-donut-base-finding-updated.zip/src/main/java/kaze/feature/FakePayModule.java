package kaze.feature;

import java.util.Locale;
import kaze.Kaze;
import kaze.event.EventListener;
import kaze.event.events.PacketSendEvent;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.Setting;
import kaze.module.setting.BooleanSetting;
import kaze.utils.EncryptedString;
import net.minecraft.util.Formatting;
import net.minecraft.text.Text;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.network.packet.c2s.play.ChatCommandSignedC2SPacket;

public final class FakePayModule extends Module {
   private final BooleanSetting sound = new BooleanSetting(
      EncryptedString.of("Sound"), true
   );
   private final BooleanSetting actionBar = new BooleanSetting(
      EncryptedString.of("Action Bar"), true
   );
   private final BooleanSetting removeFromScoreboard = new BooleanSetting(
         EncryptedString.of("Remove From Fake Scoreboard"),
         false
      )
      .setDescription(
         EncryptedString.of(
            "Subtracts every fake payment from Fake Scoreboard's money amount"
         )
      );

   public FakePayModule() {
      super(
         EncryptedString.of("Fake Pay"),
         EncryptedString.of("Fakes /pay instead of sending it"),
         -1,
         Category.MISC
      );
      Setting[] var10001 = new Setting[3];
      var10001[0] = this.sound;
      var10001[1] = this.actionBar;
      var10001[2] = this.removeFromScoreboard;
      this.addSettings(var10001);
   }

   @EventListener
   public void onPacketSend(PacketSendEvent var1) {
      String var2 = null;
      if (var1.packet instanceof CommandExecutionC2SPacket var3) {
         var2 = var3.command();
      } else if (var1.packet instanceof ChatCommandSignedC2SPacket var4) {
         var2 = var4.command();
      }

      if (var2 != null && this.handlePay(var2)) {
         var1.cancel();
      }
   }

   private boolean handlePay(String var1) {
      if (this.mc.player == null) {
         return false;
      } else {
         String[] var2 = var1.trim().split("\\s+");
         if (var2.length >= (3)
            && "pay".equals(var2[0].toLowerCase(Locale.ROOT))) {
            Double var3 = parseMoney(var2[2]);
            if (var3 != null && Double.isFinite(var3) && !(var3 <= 0.0)) {
               MutableText var4 = Text.literal("You paid ")
                  .formatted(Formatting.GRAY)
                  .append(Text.literal(var2[1]).formatted(Formatting.AQUA))
                  .append(Text.literal(" $" + formatMoney(var3)).formatted(Formatting.GREEN))
                  .append(
                     Text.literal(".").formatted(Formatting.GRAY)
                  );
               this.mc.player.sendMessage(var4, false);
               if (this.actionBar.getValue()) {
                  this.mc.player.sendMessage(var4.copy(), true);
               }

               if (this.sound.getValue()) {
                  this.mc
                     .player
                     .playSound(SoundEvents.ENTITY_ARROW_HIT_PLAYER, 1.0F, 1.0F);
               }

               if (this.removeFromScoreboard.getValue()) {
                  FakeScoreboardModule var5 = (FakeScoreboardModule)Kaze.INSTANCE
                     .getModuleManager()
                     .getModuleByClass(FakeScoreboardModule.class);
                  if (var5 != null) {
                     var5.deductMoney(var3);
                  }
               }

               return true;
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   private static Double parseMoney(String var0) {
      if (var0 == null) {
         return null;
      } else {
         String var1 = var0.trim()
            .replace(
               ",", ""
            )
            .replace(
               "$", ""
            )
            .toUpperCase(Locale.ROOT);
         double var2 = 1.0;
         if (var1.endsWith("K")) {
            var2 = 1000.0;
            var1 = var1.substring(0, var1.length() - (1));
         } else if (var1.endsWith("M")) {
            var2 = 1000000.0;
            var1 = var1.substring(0, var1.length() - (1));
         } else if (var1.endsWith("B")) {
            var2 = 1000000000.0;
            var1 = var1.substring(0, var1.length() - (1));
         } else if (var1.endsWith("T")) {
            var2 = 1000000000000.0;
            var1 = var1.substring(0, var1.length() - (1));
         }

         try {
            return Double.parseDouble(var1) * var2;
         } catch (NumberFormatException var5) {
            return null;
         }
      }
   }

   private static String formatMoney(double var0) {
      if (var0 >= 1000000000000.0) {
         return trim(var0 / 1000000000000.0) + "T";
      } else if (var0 >= 1000000000.0) {
         return trim(var0 / 1000000000.0) + "B";
      } else if (var0 >= 1000000.0) {
         return trim(var0 / 1000000.0) + "M";
      } else {
         return var0 >= 1000.0
            ? trim(var0 / 1000.0) + "K"
            : trim(var0);
      }
   }

   private static String trim(double var0) {
      if (Math.rint(var0) == var0) {
         return Long.toString((long)var0);
      } else {
         Locale var10000 = Locale.ROOT;
         String var10001 = "%.2f";
         Object[] var10002 = new Object[1];
         var10002[0] = var0;
         return String.format(var10000, var10001, var10002)
            .replaceAll(
               "0+$",
               ""
            )
            .replaceAll(
               "\\.$",
               ""
            );
      }
   }
}
