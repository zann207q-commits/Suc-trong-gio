package kaze.feature;

import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;

class BlockOverlayModule$1 {
   static final int[] $SwitchMap$net$minecraft$util$math$Direction = new int[Direction.values().length];
   static final int[] $SwitchMap$net$minecraft$util$math$Direction$Axis = new int[Axis.values().length];

   static {
      try {
         $SwitchMap$net$minecraft$util$math$Direction$Axis[Axis.X.ordinal()] = 1;
      } catch (NoSuchFieldError ignored) {
      }
      try {
         $SwitchMap$net$minecraft$util$math$Direction$Axis[Axis.Y.ordinal()] = 2;
      } catch (NoSuchFieldError ignored) {
      }
      try {
         $SwitchMap$net$minecraft$util$math$Direction$Axis[Axis.Z.ordinal()] = 3;
      } catch (NoSuchFieldError ignored) {
      }
      try {
         $SwitchMap$net$minecraft$util$math$Direction[Direction.EAST.ordinal()] = 1;
      } catch (NoSuchFieldError ignored) {
      }
      try {
         $SwitchMap$net$minecraft$util$math$Direction[Direction.WEST.ordinal()] = 2;
      } catch (NoSuchFieldError ignored) {
      }
      try {
         $SwitchMap$net$minecraft$util$math$Direction[Direction.UP.ordinal()] = 3;
      } catch (NoSuchFieldError ignored) {
      }
      try {
         $SwitchMap$net$minecraft$util$math$Direction[Direction.DOWN.ordinal()] = 4;
      } catch (NoSuchFieldError ignored) {
      }
      try {
         $SwitchMap$net$minecraft$util$math$Direction[Direction.SOUTH.ordinal()] = 5;
      } catch (NoSuchFieldError ignored) {
      }
      try {
         $SwitchMap$net$minecraft$util$math$Direction[Direction.NORTH.ordinal()] = 6;
      } catch (NoSuchFieldError ignored) {
      }
   }
}
