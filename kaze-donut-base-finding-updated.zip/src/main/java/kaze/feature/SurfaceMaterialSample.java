package kaze.feature;

import java.nio.charset.StandardCharsets;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class SurfaceMaterialSample {
   public float r;
   public float g;
   public float b;
   public float glow;
   public float flat;
   public float flatWeight;
   public float occlusion;
   public float occlusionWeight;

   public void set(int rgb) {
      this.r = (float)((rgb >> 16) & 255) / 255.0F;
      this.g = (float)((rgb >> 8) & 255) / 255.0F;
      this.b = (float)(rgb & 255) / 255.0F;
      this.glow = 0.0F;
      this.flat = 0.0F;
      this.flatWeight = 0.0F;
      this.occlusion = 0.0F;
      this.occlusionWeight = 0.0F;
   }

   public void set(SurfaceMaterialSample other) {
      this.r = other.r;
      this.g = other.g;
      this.b = other.b;
      this.glow = other.glow;
      this.flat = other.flat;
      this.flatWeight = other.flatWeight;
      this.occlusion = other.occlusion;
      this.occlusionWeight = other.occlusionWeight;
   }

   public void mix(SurfaceMaterialSample other, float amount) {
      float remaining = 1.0F - amount;
      this.r = this.r * remaining + other.r * amount;
      this.g = this.g * remaining + other.g * amount;
      this.b = this.b * remaining + other.b * amount;
      this.glow = this.glow * remaining + other.glow * amount;
      this.flat = this.flat * remaining + other.flat * amount;
      this.flatWeight = this.flatWeight * remaining + other.flatWeight * amount;
      this.occlusion = this.occlusion * remaining + other.occlusion * amount;
      this.occlusionWeight = this.occlusionWeight * remaining + other.occlusionWeight * amount;
   }

   public void toward(int rgb, float amount) {
      float remaining = 1.0F - amount;
      this.r = this.r * remaining + ((float)((rgb >> 16) & 255) / 255.0F) * amount;
      this.g = this.g * remaining + ((float)((rgb >> 8) & 255) / 255.0F) * amount;
      this.b = this.b * remaining + ((float)(rgb & 255) / 255.0F) * amount;
   }

   public int argb() {
      return -16777216 | channel(this.r) << 16 | channel(this.g) << 8 | channel(this.b);
   }

   float flat(float base) {
      return blend(base, this.flat, this.flatWeight);
   }

   float occlusion(float base) {
      return blend(base, this.occlusion, this.occlusionWeight);
   }

   private static float blend(float base, float target, float weight) {
      if (weight <= 1.0E-4F) {
         return base;
      }
      float clampedWeight = Math.min(1.0F, weight);
      return Math.max(0.0F, Math.min(1.0F, base * (1.0F - clampedWeight) + target * (clampedWeight / weight)));
   }

   static int channel(float value) {
      int rounded = Math.round(value * 255.0F);
      return rounded >= 0 ? Math.min(rounded, 255) : 0;
   }

   public static String decodeString(byte[] data, byte[] key, int seed) {
      byte[] seedBytes = Integer.toString(seed).getBytes();
      for (int i = 0; i < data.length; i++) {
         data[i] = (byte)(data[i] ^ seedBytes[i % seedBytes.length]);
         data[i] = (byte)(data[i] ^ key[i % key.length]);
      }
      return new String(data, StandardCharsets.UTF_16);
   }
}
