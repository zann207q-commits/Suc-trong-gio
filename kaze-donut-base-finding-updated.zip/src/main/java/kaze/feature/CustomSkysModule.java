package kaze.feature;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.function.BooleanSupplier;
import kaze.mixin.CustomSkysClientWorldAccessor;
import kaze.module.ext.ClientModule;
import kaze.module.ext.ModuleCategory;
import kaze.module.ext.ModuleRegistry;
import kaze.module.ext.setting.BooleanSetting;
import kaze.module.ext.setting.ColorSetting;
import kaze.module.ext.setting.ModeSetting;
import kaze.module.ext.setting.NumberSetting;
import kaze.utils.BytecodeException;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.state.SkyRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import org.joml.Quaternionf;
import org.joml.Vector3fc;
import org.joml.Vector4f;


@Environment(EnvType.CLIENT)
public final class CustomSkysModule extends ClientModule {
   private static final String CUSTOM = "Custom";
   private static final String AURORA_ALWAYS = "Always";
   private static final String AURORA_COLD = "Cold Biomes";
   private static final String AURORA_OFF = "Off";
   private static final float MOON_SCALE = 1.4F;
   private static final SkyPalette[] THEMES;
   private final ModeSetting theme;
   private final ColorSetting nightColor;
   private final ColorSetting sunsetColor;
   private final ColorSetting auroraColor;
   private final ColorSetting auroraTopColor;
   private final BooleanSetting gradientSky;
   private final BooleanSetting keepInRain;
   private final BooleanSetting celestialGlow;
   private final BooleanSetting stars;
   private final NumberSetting starBrightness;
   private final BooleanSetting milkyWay;
   private final NumberSetting milkyWayBrightness;
   private final BooleanSetting shootingStars;
   private final ModeSetting aurora;
   private final NumberSetting auroraBrightness;
   private final NumberSetting auroraSpeed;
   private final BooleanSetting cloudColors;
   private final BooleanSetting endSky;
   private final BooleanSetting netherColors;
   private final SkyDomeRenderer sky;
   private final StarfieldRenderer star;
   private final AuroraMeshRenderer auroraMesh;
   private final MatrixStack world;
   private float night;
   private float rainBrightness;
   private float auroraHere;
   private long lastFrame;
   private boolean moonScaled;

   public CustomSkysModule() {
      super(
         "custom-skys",
         "Custom Skys",
         "A custom sky with stars and an aurora.",
         ModuleCategory.VISUALS
      );
      String var10002 = "theme";
      String var10005 = "Theme";
      String var10006 = "Borealis";
      String[] var10007 = new String[6];
      var10007[0] = "Borealis";
      var10007[1] = "Nebula";
      var10007[2] = "Kaze";
      var10007[3] = "Frost";
      var10007[4] = "Crimson";
      var10007[5] = "Custom";
      this.theme = this.addSetting(var10002, new ModeSetting(var10005, var10006, var10007));
      this.nightColor = this.addSetting(
         "night-color",
         new ColorSetting("Night Sky Color", -16047568)
      );
      this.sunsetColor = this.addSetting(
         "sunset-color",
         new ColorSetting("Sunset Color", -3703914)
      );
      this.auroraColor = this.addSetting(
         "aurora-color",
         new ColorSetting("Aurora Color", -13697126)
      );
      this.auroraTopColor = this.addSetting(
         "aurora-top-color",
         new ColorSetting("Aurora Top Color", -7713281)
      );
      this.gradientSky = this.addSetting(
         "gradient-sky",
         new BooleanSetting("Gradient Sky", true)
      );
      this.keepInRain = this.addSetting(
         "keep-in-rain",
         new BooleanSetting(
            "Keep In Rain", true
         )
      );
      this.celestialGlow = this.addSetting(
         "sun-moon-glow",
         new BooleanSetting(
            "Sun & Moon Glow", true
         )
      );
      this.stars = this.addSetting(
         "stars",
         new BooleanSetting("Stars", true)
      );
      this.starBrightness = this.addSetting(
         "star-brightness",
         new NumberSetting(
               "Star Brightness",
               1.2999999523162842F,
               0.5F,
               2.0F
            )
            .step(0.10000000149011612F)
      );
      this.milkyWay = this.addSetting(
         "milky-way",
         new BooleanSetting("Milky Way", true)
      );
      this.milkyWayBrightness = this.addSetting(
         "milky-way-brightness",
         new NumberSetting(
               "Milky Way Brightness",
               1.0F,
               0.20000000298023224F,
               2.0F
            )
            .step(0.10000000149011612F)
      );
      this.shootingStars = this.addSetting(
         "shooting-stars",
         new BooleanSetting(
            "Shooting Stars", true
         )
      );
      var10002 = "aurora";
      var10005 = "Aurora";
      var10006 = "Always";
      var10007 = new String[3];
      var10007[0] = "Always";
      var10007[1] = "Cold Biomes";
      var10007[2] = "Off";
      this.aurora = this.addSetting(var10002, new ModeSetting(var10005, var10006, var10007));
      this.auroraBrightness = this.addSetting(
         "aurora-brightness",
         new NumberSetting(
               "Aurora Brightness",
               1.0F,
               0.20000000298023224F,
               2.0F
            )
            .step(0.10000000149011612F)
      );
      this.auroraSpeed = this.addSetting(
         "aurora-speed",
         new NumberSetting(
               "Aurora Speed",
               1.0F,
               0.20000000298023224F,
               3.0F
            )
            .step(0.10000000149011612F)
      );
      this.cloudColors = this.addSetting(
         "cloud-colors",
         new BooleanSetting(
            "Cloud Colors", true
         )
      );
      this.endSky = this.addSetting(
         "end-sky",
         new BooleanSetting("End Sky", true)
      );
      this.netherColors = this.addSetting(
         "nether-colors",
         new BooleanSetting(
            "Nether Colors", true
         )
      );
      this.sky = new SkyDomeRenderer();
      this.star = new StarfieldRenderer();
      this.auroraMesh = new AuroraMeshRenderer();
      this.world = new MatrixStack();
      this.rainBrightness = 1.0F;
      this.nightColor.visibleWhen(() -> this.theme.is("Custom"));
      this.sunsetColor.visibleWhen(() -> this.theme.is("Custom"));
      this.auroraColor.visibleWhen(() -> this.theme.is("Custom"));
      this.auroraTopColor.visibleWhen(() -> this.theme.is("Custom"));
      this.starBrightness.visibleWhen(this.stars::get);
      this.milkyWayBrightness.visibleWhen(this.milkyWay::get);
      this.auroraBrightness
         .visibleWhen(
            () -> ((!this.aurora.is("Off")
                  ? 1
                  : 0) != 0)
         );
      this.auroraSpeed
         .visibleWhen(
            () -> ((!this.aurora.is("Off")
                  ? 1
                  : 0) != 0)
         );
   }

   public static CustomSkysModule get() {
      CustomSkysModule var0 = ModuleRegistry.get(CustomSkysModule.class);
      return var0 != null && var0.isEnabled() ? var0 : null;
   }

   @Override
   public void onDisable() {
      this.sky.close();
      this.star.close();
      this.auroraMesh.close();
   }

   public void extract(ClientWorld var1, float var2, SkyRenderState var3) {
      this.night = MathHelper.clamp(
         var3.starBrightness * 2.0F,
         0.0F,
         1.0F
      );
      float var4 = 1.0F - var3.rainGradient;
      float var5 = var1.getThunderGradient(var2);
      if (this.keepInRain.get()) {
         this.night = Math.max(this.night, clearNight(var3.sunAngle) * var4);
         var3.starBrightness = Math.max(var3.starBrightness, this.night * 0.5F);
         var3.rainGradient = 1.0F;
         var4 = 0.0F;
         var5 = 0.0F;
      }

      this.rainBrightness = 1.0F - var4;
      SkyPalette var6 = this.currentTheme();
      int var7 = ((CustomSkysClientWorldAccessor)var1).kaze$atmosphereSkyFlash();
      this.sky
         .update(
            var3.sunAngle,
            var3.moonAngle,
            var4,
            var5,
            var7 > 0
               ? Math.min(1.0F, ((float)var7 - var2) / 2.0F)
               : 0.0F,
            var6.nightZenith(),
            var6.nightHorizon(),
            var6.twilight()
         );
   }

   private static float clearNight(float var0) {
      float var1 = MathHelper.clamp(
         0.75F - 2.0F * MathHelper.cos((double)var0),
         0.0F,
         1.0F
      );
      return var1 * var1;
   }

   public boolean skyDisc() {
      if (this.gradientSky.get() && this.sky.ready()) {
         this.sky.renderDome(this.world);
         return true;
      } else {
         return false;
      }
   }

   public boolean replacesSunrise() {
      return ((this.gradientSky.get() && this.sky.ready()));
   }

   public boolean stars(MatrixStack var1) {
      float var2 = this.night * this.rainBrightness;
      if (this.milkyWay.get()) {
         this.star.renderBand(var1, var2 * this.milkyWayBrightness.get(), this.currentTheme().milkyWay());
      }

      if (!this.stars.get()) {
         return false;
      } else {
         this.star.renderStars(var1, var2, this.starBrightness.get());
         return true;
      }
   }

   public void beforeMoon(MatrixStack var1) {
      this.moonScaled = this.celestialGlow.get();
      if (this.moonScaled) {
         var1.push();
         var1.scale(
            1.399999976158142F, 1.0F, 1.399999976158142F
         );
      }
   }

   public void afterMoon(MatrixStack var1) {
      if (this.moonScaled) {
         var1.pop();
      }

      this.moonScaled = false;
   }

   public void afterCelestials() {
      long var1 = System.nanoTime();
      float var3 = this.lastFrame == (0L)
         ? 0.0F
         : Math.min((float)(var1 - this.lastFrame) / 1000000000.0F, 0.10000000149011612F);
      this.lastFrame = var1;
      if (this.sky.ready()) {
         if (this.celestialGlow.get()) {
            this.sky.renderHalos(this.world, this.rainBrightness, this.night);
         }

         if (this.shootingStars.get()) {
            this.sky.renderMeteors(this.world, this.night, this.rainBrightness);
         }

         this.auroraHere = this.auroraHere
            + (this.auroraTarget() - this.auroraHere)
               * Math.min(1.0F, var3 * 0.5F);
         if (this.auroraHere > 0.009999999776482582F
            && this.night > 0.009999999776482582F) {
            SkyPalette var4 = this.currentTheme();
            float var5 = (float)(var1 % (3600000000000L))
               / 1000000000.0F
               * this.auroraSpeed.get();
            float var6 = this.auroraHere
               * this.night
               * (0.3499999940395355F + 0.6499999761581421F * this.rainBrightness)
               * this.auroraBrightness.get();
            this.auroraMesh.render(this.world, var6, var5, var4.auroraLow(), var4.auroraHigh());
         }
      }
   }

   private float auroraTarget() {
      if (this.aurora.is("Off")) {
         return 0.0F;
      } else if (this.aurora.is("Always")) {
         return 1.0F;
      } else {
         MinecraftClient var1 = MinecraftClient.getInstance();
         if (var1.world == null) {
            return 0.0F;
         } else {
            BlockPos var2 = BlockPos.ofFloored(var1.gameRenderer.getCamera().getCameraPos());
            return ((Biome)var1.world.getBiome(var2).value()).isCold(var2, var1.world.getSeaLevel())
               ? 1.0F
               : 0.0F;
         }
      }
   }

   public void fog(Camera var1, ClientWorld var2, Vector4f var3) {
      if (var2.getRegistryKey() == World.OVERWORLD) {
         if (!this.gradientSky.get() || !this.sky.ready()) {
            return;
         }

         Vector3fc var4 = var1.getHorizontalPlane();
         int var5 = this.sky.horizonToward(var4.x(), var4.z());
         var3.x = (float)(var5 >> (16) & (255)) / 255.0F;
         var3.y = (float)(var5 >> (8) & (255)) / 255.0F;
         var3.z = (float)(var5 & (255)) / 255.0F;
      } else if (var2.getRegistryKey() == World.NETHER && this.netherColors.get()) {
         float var6 = 0.2125999927520752F * var3.x
            + 0.7152000069618225F * var3.y
            + 0.0722000002861023F * var3.z;
         var3.x = MathHelper.clamp(
            (var6 + (var3.x - var6) * 1.4500000476837158F) * 1.1200000047683716F,
            0.0F,
            1.0F
         );
         var3.y = MathHelper.clamp(
            (var6 + (var3.y - var6) * 1.4500000476837158F) * 1.1200000047683716F,
            0.0F,
            1.0F
         );
         var3.z = MathHelper.clamp(
            (var6 + (var3.z - var6) * 1.4500000476837158F) * 1.1200000047683716F,
            0.0F,
            1.0F
         );
      }
   }

   public int clouds(int var1) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (this.cloudColors.get()
         && this.sky.ready()
         && var2.world != null
         && var2.world.getRegistryKey() == World.OVERWORLD) {
         float var3 = this.sky.golden();
         float var4 = this.sky.nightness();
         int var5 = ColorHelper.lerp(
            var3,
            ColorHelper.lerp(var4, 16777215, this.currentTheme().nightHorizon()),
            this.sky.twilightGlow()
         );
         float var6 = Math.max(var3 * 0.75F, var4 * 0.550000011920929F);
         return keepBrightness(var1, var5, var6);
      } else {
         return var1;
      }
   }

   public boolean endSky() {
      if (!this.endSky.get()) {
         return false;
      } else {
         long var1 = System.nanoTime();
         this.sky.renderEndDome(this.world);
         MatrixStack var3 = new MatrixStack();
         var3.multiply(
            RotationAxis.POSITIVE_Y
               .rotationDegrees(
                  (float)(var1 % (1200000000000L))
                     / 1000000000.0F
                     * 0.30000001192092896F
               )
         );
         this.star.renderNebulae(var3, 1.0F);
         this.star.renderStars(var3, 1.0F, 1.2000000476837158F);
         return true;
      }
   }

   private SkyPalette currentTheme() {
      SkyPalette[] var1 = THEMES;
      int var2 = var1.length;

      for (int var3 = 0; var3 < var2; var3++) {
         SkyPalette var4 = var1[var3];
         if (this.theme.is(var4.name())) {
            return var4;
         }
      }

      int var5 = this.nightColor.rgb();
      return new SkyPalette(
         "Custom",
         SkyDomeRenderer.scale(var5, 0.30000001192092896F),
         var5,
         this.sunsetColor.rgb(),
         this.auroraColor.rgb(),
         this.auroraTopColor.rgb(),
         15263999
      );
   }

   private static int keepBrightness(int var0, int var1, float var2) {
      if (var2 <= 0.0F) {
         return var0;
      } else {
         float var3 = (float)(var0 >> (16) & (255)) / 255.0F;
         float var4 = (float)(var0 >> (8) & (255)) / 255.0F;
         float var5 = (float)(var0 & (255)) / 255.0F;
         float var6 = (float)(var1 >> (16) & (255)) / 255.0F;
         float var7 = (float)(var1 >> (8) & (255)) / 255.0F;
         float var8 = (float)(var1 & (255)) / 255.0F;
         float var9 = luminance(var3, var4, var5)
            / Math.max(luminance(var6, var7, var8), 0.0010000000474974513F);
         var3 = MathHelper.lerp(var2, var3, Math.min(1.0F, var6 * var9));
         var4 = MathHelper.lerp(var2, var4, Math.min(1.0F, var7 * var9));
         var5 = MathHelper.lerp(var2, var5, Math.min(1.0F, var8 * var9));
         return var0 & (-16777216)
            | channel(var3) << (16)
            | channel(var4) << (8)
            | channel(var5);
      }
   }

   private static float luminance(float var0, float var1, float var2) {
      return 0.2125999927520752F * var0
         + 0.7152000069618225F * var1
         + 0.0722000002861023F * var2;
   }

   private static int channel(float var0) {
      return MathHelper.clamp(Math.round(var0 * 255.0F), 0, 255);
   }

   static {
      SkyPalette[] var10000 = new SkyPalette[5];
      var10000[0] = new SkyPalette(
         "Borealis",
         198414,
         729648,
         13073302,
         3080090,
         9063935,
         13163263
      );
      var10000[1] = new SkyPalette(
         "Nebula",
         459791,
         2233916,
         14053304,
         16732120,
         5991679,
         15124735
      );
      var10000[2] = new SkyPalette(
         "Kaze",
         657157,
         2890512,
         15239498,
         16757306,
         16730670,
         16769200
      );
      var10000[3] = new SkyPalette(
         "Frost",
         264724,
         1454154,
         11057384,
         8382719,
         15135999,
         14544639
      );
      var10000[4] = new SkyPalette(
         "Crimson",
         721926,
         3018260,
         15227490,
         16724821,
         16751164,
         16765640
      );
      THEMES = var10000;
   }

   @Environment(EnvType.CLIENT)
   private record SkyPalette(String name, int nightZenith, int nightHorizon,
                             int twilight, int auroraLow, int auroraHigh, int milkyWay) {
   }
}
