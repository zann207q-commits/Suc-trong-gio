package kaze.event.events;

import kaze.event.CancellableEvent;

public class SendMovementPacketsEvent extends CancellableEvent {
}
