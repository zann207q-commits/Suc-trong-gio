package kaze.event.events;

import kaze.event.CancellableEvent;

public class AttackEvent extends CancellableEvent {
}
