package kaze.event.events;

import kaze.event.Event;

public final class TotemPopEvent implements Event {
}
