package kaze.event.events;

import kaze.event.CancellableEvent;

public class ChunkMarkClosedEvent extends CancellableEvent {
}
