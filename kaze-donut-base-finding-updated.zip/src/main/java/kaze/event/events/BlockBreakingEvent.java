package kaze.event.events;

import kaze.event.CancellableEvent;

public class BlockBreakingEvent extends CancellableEvent {
}
