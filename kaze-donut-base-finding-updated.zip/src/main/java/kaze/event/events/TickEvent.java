package kaze.event.events;

import kaze.event.CancellableEvent;

public class TickEvent extends CancellableEvent {
}
