package kaze.event.events;

import kaze.event.CancellableEvent;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;

public final class LightUpdateEvent extends CancellableEvent {
   public final LightUpdateS2CPacket packet;

   public LightUpdateEvent(LightUpdateS2CPacket var1) {
      this.packet = var1;
   }
}
