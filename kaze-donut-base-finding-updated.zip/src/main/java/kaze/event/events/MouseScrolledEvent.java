package kaze.event.events;

import kaze.event.CancellableEvent;

public class MouseScrolledEvent extends CancellableEvent {
   public double amount;

   public MouseScrolledEvent(double amount) {
      this.amount = amount;
   }
}
