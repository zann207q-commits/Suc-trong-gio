package kaze.module.ext;

public enum Stage {
   PRE,
   POST;
}
