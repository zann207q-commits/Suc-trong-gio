package kaze.module.setting;

public final class ButtonSetting extends Setting {
   private final Runnable action;

   public ButtonSetting(CharSequence var1, Runnable var2) {
      super(var1);
      this.action = var2;
   }

   public void run() {
      try {
         this.action.run();
      } catch (Throwable var2) {
         System.err.println("Kaze: action failed: " + var2);
      }
   }
}
