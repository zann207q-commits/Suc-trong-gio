package kaze.module;

import kaze.utils.EncryptedString;

public enum Category {
   COMBAT(EncryptedString.of("Combat")),
   MISC(EncryptedString.of("Misc")),
   MACROS(EncryptedString.of("Donut")),
   DONUT(EncryptedString.of("Base finding")),
   RENDER(EncryptedString.of("Render")),
   CLIENT(EncryptedString.of("Client"));

   public final CharSequence name;

   private Category(final CharSequence nullxx) {
      this.name = nullxx;
   }
}
