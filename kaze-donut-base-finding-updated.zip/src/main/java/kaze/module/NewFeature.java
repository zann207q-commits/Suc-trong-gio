package kaze.module;

public interface NewFeature {
}
