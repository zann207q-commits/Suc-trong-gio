package kaze.module.modules.client;

import kaze.event.EventListener;
import kaze.event.events.PacketReceiveEvent;
import kaze.event.events.TickEvent;
import kaze.halloween.Halloween;
import kaze.module.Category;
import kaze.module.Module;
import kaze.module.setting.BooleanSetting;
import kaze.module.setting.ModeSetting;
import kaze.module.setting.NumberSetting;
import kaze.module.setting.Setting;
import kaze.utils.EncryptedString;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import kaze.feature.KazeClickGuiScreen;
import kaze.feature.UiPalette;

public final class Kaze extends Module {
   public static final ModeSetting<UiPalette> theme = new ModeSetting<>(EncryptedString.of("Theme"), UiPalette.Black, UiPalette.class)
      .setDescription(EncryptedString.of("Accent, gradient and lighting colors of the client"));
   public static final BooleanSetting uiSounds = new BooleanSetting(EncryptedString.of("UI Sounds"), true)
      .setDescription(EncryptedString.of("Soft sounds for clicks, toggles and menus"));
   public static final NumberSetting uiVolume = new NumberSetting(EncryptedString.of("UI Volume"), 0.0, 100.0, 70.0, 1.0)
      .getValue(EncryptedString.of("Volume of the interface sounds in percent"));
   public static final BooleanSetting halloweenMusic = new BooleanSetting(EncryptedString.of("Halloween Music"), true)
      .setDescription(EncryptedString.of("Halloween song in the menu (Halloween theme)"));
   public static final NumberSetting halloweenVolume = new NumberSetting(EncryptedString.of("Halloween Music Volume"), 0.0, 100.0, 35.0, 1.0)
      .getValue(EncryptedString.of("How loud the Halloween menu music is"));
   public static final BooleanSetting beatShake = new BooleanSetting(EncryptedString.of("Beat Shake"), true)
      .setDescription(EncryptedString.of("The backdrop moves gently with the beat"));
   public static final NumberSetting shakeStrength = new NumberSetting(EncryptedString.of("Beat Shake Strength"), 0.0, 100.0, 50.0, 5.0)
      .getValue(EncryptedString.of("How strongly the background reacts to the beat"));
   public static final NumberSetting guiSize = new NumberSetting(EncryptedString.of("GUI Size"), 70.0, 140.0, 100.0, 5.0)
      .getValue(EncryptedString.of("Scale of the Kaze menu in percent"));
   public static final BooleanSetting renderBackground = new BooleanSetting(EncryptedString.of("Background"), true)
      .setDescription(EncryptedString.of("Dims the world behind Kaze editor screens"));
   private final BooleanSetting preventClose = new BooleanSetting(EncryptedString.of("Prevent Close"), true)
      .setDescription(EncryptedString.of("For servers with freeze plugins that don't let you open the GUI"));
   public static final ModeSetting<Kaze.AnimationMode> animationMode = new ModeSetting<>(
      EncryptedString.of("Animations"), Kaze.AnimationMode.NORMAL, Kaze.AnimationMode.class
   );
   public boolean shouldPreventClose;

   public Kaze() {
      super(EncryptedString.of("Kaze+"), EncryptedString.of("Settings for the client"), 344, Category.CLIENT);
      this.addSettings(
         new Setting[]{
            theme, uiSounds, uiVolume, halloweenMusic, halloweenVolume, beatShake, shakeStrength, guiSize, renderBackground, this.preventClose, animationMode
         }
      );
   }

   @Override
   public void onEnable() {
      if (Halloween.guiLocked()) {
         this.setEnabled(false);
         Halloween.lockedNotice();
      } else {
         if (!(this.mc.currentScreen instanceof KazeClickGuiScreen)) {
            kaze.Kaze.INSTANCE.screen = this.mc.currentScreen;
         }

         if (kaze.Kaze.INSTANCE.GUI != null) {
            kaze.Kaze.INSTANCE.GUI.prepareOpen();
            this.mc.setScreenAndRender(kaze.Kaze.INSTANCE.GUI);
         } else if (this.mc.player != null && this.mc.currentScreen instanceof InventoryScreen) {
            this.shouldPreventClose = true;
         }

         super.onEnable();
      }
   }

   @Override
   public void onDisable() {
      if (this.mc.currentScreen instanceof KazeClickGuiScreen) {
         kaze.Kaze.INSTANCE.GUI.requestClose();
      } else if (this.mc.currentScreen instanceof InventoryScreen) {
         this.shouldPreventClose = false;
      }

      super.onDisable();
   }

   @EventListener
   public void onTick(TickEvent var1) {
      if (kaze.Kaze.INSTANCE.GUI != null) {
         kaze.Kaze.INSTANCE.GUI.syncAmbience();
      }
   }

   @EventListener
   public void onPacketReceive(PacketReceiveEvent var1) {
      if (this.shouldPreventClose && var1.packet instanceof OpenScreenS2CPacket && this.preventClose.getValue()) {
         var1.cancel();
      }
   }

   public static enum AnimationMode {
      NORMAL("Normal", 0),
      POSITIVE("Positive", 1),
      OFF("Off", 2);

      private AnimationMode(final String nullxx, final int nullxxx) {
      }

      private static Kaze.AnimationMode[] $values() {
         return new Kaze.AnimationMode[]{NORMAL, POSITIVE, OFF};
      }
   }
}
