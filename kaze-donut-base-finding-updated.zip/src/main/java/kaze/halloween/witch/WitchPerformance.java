package kaze.halloween.witch;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3f;

public final class WitchPerformance {
   public static final float APPEAR_END = 2.2F;
   public static final float NOTICE = 3.7F;
   public static final float TURN_START = 4.1F;
   public static final float WAVE_START = 5.3F;
   public static final float WAVE_END = 8.0F;
   public static final float HAT_START = 8.0F;
   public static final float HAT_END = 9.8F;
   public static final float SPELL_START = 9.7F;
   public static final float SPELL_END = 11.9F;
   public static final float MOUNT_START = 11.9F;
   public static final float MOUNT_END = 13.9F;
   public static final float FLY_START = 14.7F;
   public static final float WAVE_BACK = 19.7F;
   public static final float VANISH_LEN = 2.8F;
   private final WitchRig rig;
   private final int hips;
   private final int spine1;
   private final int spine2;
   private final int chest;
   private final int neck;
   private final int head;
   private final int jaw;
   private final int eyeR;
   private final int eyeL;
   private final int[] hat;
   private final int[] hair;
   private final int[] cloak;
   private final int shoulderR;
   private final int elbowR;
   private final int wristR;
   private final int shoulderL;
   private final int elbowL;
   private final int wristL;
   private final int[][] fingersR;
   private final int[][] fingersL;
   private final int hipR;
   private final int kneeR;
   private final int ankleR;
   private final int hipL;
   private final int kneeL;
   private final int ankleL;
   private final Quaternionf[] stand;
   private final Quaternionf[] sit;
   private final Quaternionf q = new Quaternionf();
   private final Vector3f v = new Vector3f();
   public final Vector3d origin = new Vector3d();
   public final Matrix4f model = new Matrix4f();
   public final Matrix4f broom = new Matrix4f();
   public float alpha;
   public float glow;
   public float dissolveAt;
   public float dissolveMode;
   public boolean finished;
   public float vanishStart = Float.MAX_VALUE;
   public float casting;
   private WitchPerformance.Ground ground;
   private float bodyYaw;
   private float yawVel;
   private float startYaw;
   private float headYaw;
   private float headYawVel;
   private final Vector3f flyPos = new Vector3f();
   private final Vector3f flyVel = new Vector3f();
   private float flyYaw;
   private float flyYawVel;
   private float flyPitch;
   private float flyPitchVel;
   private float flyRoll;
   private float flyRollVel;
   private float pathS;
   private float lastT = -1.0F;
   private final Matrix4f heldGrip = new Matrix4f();
   private boolean gripReady;
   private Vector3f[] path;
   private float exitFade = 1.0F;
   private boolean exiting;

   public WitchPerformance(WitchRig var1) {
      this.rig = var1;
      WitchAsset var2 = var1.asset;
      this.hips = var2.joint("Root_M");
      this.spine1 = var2.joint("Spine1_M");
      this.spine2 = var2.joint("Spine2_M");
      this.chest = var2.joint("Chest_M");
      this.neck = var2.joint("Neck_M");
      this.head = var2.joint("Head_M");
      this.jaw = var2.joint("JawJoint_M");
      this.eyeR = var2.joint("EyeJoint_R");
      this.eyeL = var2.joint("EyeJoint_L");
      this.hat = joints(var2, "hat1_M", "hat2_M", "hat3_L", "hat4_L", "hat5_L", "hat6_L");
      this.hair = joints(
         var2, "hairstrand20_L", "hairstrand21_L", "hairstrand22_L", "hairstrand23_L", "hairstrand24_L", "hairstrand25_L", "hairstrand26_L", "hairstrand27_L"
      );
      this.cloak = joints(var2, "cloak1_M", "cloak2_M", "cloak3_M", "cloak4_M", "cloak5_M", "cloak6_M", "cloak7_M");
      this.shoulderR = var2.joint("Shoulder_R");
      this.elbowR = var2.joint("Elbow_R");
      this.wristR = var2.joint("Wrist_R");
      this.shoulderL = var2.joint("Shoulder_L");
      this.elbowL = var2.joint("Elbow_L");
      this.wristL = var2.joint("Wrist_L");
      this.fingersR = fingers(var2, "_R");
      this.fingersL = fingers(var2, "_L");
      this.hipR = var2.joint("Hip_R");
      this.kneeR = var2.joint("Knee_R");
      this.ankleR = var2.joint("Ankle_R");
      this.hipL = var2.joint("Hip_L");
      this.kneeL = var2.joint("Knee_L");
      this.ankleL = var2.joint("Ankle_L");
      this.stand = new Quaternionf[var1.count];
      this.sit = new Quaternionf[var1.count];

      for (int var3 = 0; var3 < var1.count; var3++) {
         this.stand[var3] = new Quaternionf();
         this.sit[var3] = new Quaternionf();
      }
   }

   private static int[] joints(WitchAsset var0, String... var1) {
      int[] var2 = new int[var1.length];

      for (int var3 = 0; var3 < var1.length; var3++) {
         var2[var3] = var0.joint(var1[var3]);
      }

      return var2;
   }

   private static int[][] fingers(WitchAsset var0, String var1) {
      String[] var2 = new String[]{"ThumbFinger", "IndexFinger", "MiddleFinger", "RingFinger", "PinkyFinger"};
      int[][] var3 = new int[5][3];

      for (int var4 = 0; var4 < 5; var4++) {
         for (int var5 = 0; var5 < 3; var5++) {
            var3[var4][var5] = var0.joint(var2[var4] + (var5 + 1) + var1);
         }
      }

      return var3;
   }

   public void start(Vector3d var1, Vector3d var2, WitchPerformance.Ground var3) {
      this.origin.set(var1);
      this.ground = var3;
      float var4 = (float)Math.atan2(var2.x - var1.x, var2.z - var1.z);
      this.startYaw = var4 + 0.95F;
      this.bodyYaw = this.startYaw;
      this.yawVel = 0.0F;
      this.headYaw = 0.0F;
      this.headYawVel = 0.0F;
      this.finished = false;
      this.alpha = 0.0F;
      this.lastT = -1.0F;
      this.gripReady = false;
      this.pathS = 0.0F;
      this.path = null;
      this.vanishStart = Float.MAX_VALUE;
      this.exitFade = 1.0F;
      this.exiting = false;
   }

   public void exit() {
      this.exiting = true;
   }

   static float clamp01(float var0) {
      return var0 < 0.0F ? 0.0F : Math.min(var0, 1.0F);
   }

   static float span(float var0, float var1, float var2) {
      return clamp01((var0 - var1) / (var2 - var1));
   }

   static float smooth(float var0) {
      var0 = clamp01(var0);
      return var0 * var0 * var0 * (var0 * (var0 * 6.0F - 15.0F) + 10.0F);
   }

   static float window(float var0, float var1, float var2, float var3, float var4) {
      return smooth(span(var0, var1, var1 + var2)) * (1.0F - smooth(span(var0, var3 - var4, var3)));
   }

   private static float wrap(float var0) {
      while ((double)var0 > Math.PI) {
         var0 -= (float) (Math.PI * 2);
      }

      while ((double)var0 < -Math.PI) {
         var0 += (float) (Math.PI * 2);
      }

      return var0;
   }

   private static Quaternionf axis(Quaternionf var0, float var1, float var2, float var3, float var4) {
      float var5 = (float)Math.sqrt((double)(var1 * var1 + var2 * var2 + var3 * var3));
      return var0.rotationAxis((float)Math.toRadians((double)var4), var1 / var5, var2 / var5, var3 / var5);
   }

   private void turn(Quaternionf[] var1, int var2, float var3, float var4, float var5, float var6) {
      if (var2 >= 0 && var6 != 0.0F) {
         var1[var2].premul(axis(this.q, var3, var4, var5, var6));
      }
   }

   private static void clear(Quaternionf[] var0) {
      for (Quaternionf var4 : var0) {
         var4.identity();
      }
   }

   private void curl(Quaternionf[] var1, int[][] var2, float var3, float var4, float var5) {
      for (int var6 = 1; var6 < 5; var6++) {
         float var7 = ((float)var6 - 2.5F) * 3.0F * (1.0F - var4);

         for (int var8 = 0; var8 < 3; var8++) {
            float var9 = var4 * (var8 == 0 ? 55.0F : (var8 == 1 ? 80.0F : 55.0F));
            this.turn(var1, var2[var6][var8], 0.0F, 0.0F, 1.0F, var3 * var9);
            if (var8 == 0) {
               this.turn(var1, var2[var6][var8], 1.0F, 0.0F, 0.0F, var7);
            }
         }
      }

      for (int var10 = 0; var10 < 3; var10++) {
         this.turn(var1, var2[0][var10], 0.0F, 1.0F, 0.0F, -var3 * var5 * (var10 == 0 ? 25.0F : 35.0F));
      }
   }

   public void update(float var1, Vector3d var2) {
      float var3 = this.lastT < 0.0F ? 0.0F : Math.max(0.0F, Math.min(0.1F, var1 - this.lastT));
      this.lastT = var1;
      WitchRig var4 = this.rig;
      clear(this.stand);
      clear(this.sit);
      float var5 = (float)(var2.x - this.origin.x);
      float var6 = (float)(var2.z - this.origin.z);
      float var7 = (float)Math.atan2((double)var5, (double)var6);
      float var8 = (float)Math.sqrt((double)(var5 * var5 + var6 * var6));
      float var9 = (float)(var2.y - (this.origin.y + 1.5));
      float var10 = (float)Math.toDegrees(Math.atan2((double)var9, (double)Math.max(0.5F, var8)));
      if (var1 < 14.7F) {
         float var11 = var1 < 4.1F ? this.startYaw : this.startYaw + wrap(var7 - this.startYaw);
         float var12 = 15.0F;
         float var13 = wrap(var11 - this.bodyYaw);
         this.yawVel = this.yawVel + (var13 * var12 - this.yawVel * 2.0F * (float)Math.sqrt((double)var12)) * var3;
         this.bodyYaw = wrap(this.bodyYaw + this.yawVel * var3);
         if (var3 == 0.0F) {
            this.bodyYaw = var11;
         }
      }

      float var47 = (float)Math.toDegrees((double)Math.max(-1.15F, Math.min(1.15F, wrap(var7 - this.bodyYaw))));
      float var48 = 40.0F * window(var1, 2.15F, 0.5F, 3.05F, 0.45F) - 36.0F * window(var1, 3.0F, 0.5F, 3.9F, 0.3F);
      float var49 = smooth(span(var1, 3.7F, 4.15F));
      float var14 = var48 * (1.0F - var49) + var47 * var49;
      float var15 = var1 > 3.7F && var1 < 4.2F ? 90.0F : 45.0F;
      this.headYawVel = this.headYawVel + ((var14 - this.headYaw) * var15 - this.headYawVel * 2.0F * (float)Math.sqrt((double)var15)) * var3;
      this.headYaw = this.headYaw + this.headYawVel * var3;
      if (var3 == 0.0F) {
         this.headYaw = var14;
      }

      float var16 = 1.0F - smooth(span(var1, 11.9F, 12.7F));
      float var17 = (float)Math.sin((double)(var1 * 1.7F));
      float var18 = (float)Math.sin((double)(var1 * 0.83F + 0.4F));
      Quaternionf[] var19 = this.stand;
      this.turn(var19, this.spine1, 1.0F, 0.0F, 0.0F, 1.2F * var17);
      this.turn(var19, this.chest, 1.0F, 0.0F, 0.0F, -1.6F * var17);
      this.turn(var19, this.spine2, 0.0F, 0.0F, 1.0F, 1.1F * var18);
      this.turn(var19, this.hips, 0.0F, 0.0F, 1.0F, -1.2F * var18);
      this.turn(var19, this.chest, 0.0F, 1.0F, 0.0F, this.headYaw * 0.18F * var16);
      this.turn(var19, this.neck, 0.0F, 1.0F, 0.0F, this.headYaw * 0.32F * var16);
      this.turn(var19, this.head, 0.0F, 1.0F, 0.0F, this.headYaw * 0.5F * var16);
      float var20 = var49 * var16;
      this.turn(var19, this.neck, 1.0F, 0.0F, 0.0F, -var10 * 0.35F * var20);
      this.turn(var19, this.head, 1.0F, 0.0F, 0.0F, -var10 * 0.45F * var20);
      float var21 = Math.max(-26.0F, Math.min(26.0F, (var14 - this.headYaw) * 1.4F + var47 * 0.15F * var49));
      this.turn(var19, this.eyeR, 0.0F, 1.0F, 0.0F, var21 * var16);
      this.turn(var19, this.eyeL, 0.0F, 1.0F, 0.0F, var21 * var16);
      this.turn(var19, this.shoulderR, 0.0F, 0.0F, 1.0F, 26.0F);
      this.turn(var19, this.shoulderR, 1.0F, 0.0F, 0.0F, -6.0F);
      this.turn(var19, this.elbowR, 1.0F, 0.0F, 0.0F, -14.0F);
      this.curl(var19, this.fingersR, -1.0F, 0.25F, 0.2F);
      this.turn(var19, this.shoulderL, 0.0F, 0.0F, 1.0F, -14.0F);
      this.turn(var19, this.shoulderL, 1.0F, 0.0F, 0.0F, -16.0F);
      this.turn(var19, this.elbowL, 1.0F, 0.0F, 0.0F, -58.0F);
      this.turn(var19, this.wristL, 0.0F, 1.0F, 0.0F, 12.0F);
      this.curl(var19, this.fingersL, 1.0F, 1.0F, 1.0F);
      float var22 = 1.0F - smooth(span(var1, 1.2F, 2.6F));
      if (var22 > 0.0F) {
         this.turn(var19, this.neck, 1.0F, 0.0F, 0.0F, 14.0F * var22);
         this.turn(var19, this.head, 1.0F, 0.0F, 0.0F, 16.0F * var22);
         this.turn(var19, this.spine2, 1.0F, 0.0F, 0.0F, 4.0F * var22);
         this.turn(var19, this.shoulderR, 0.0F, 0.0F, 1.0F, -18.0F * var22);
      }

      float var23 = (float)Math.sin(Math.PI * (double)span(var1, 3.7F, 4.25F));
      this.turn(var19, this.chest, 1.0F, 0.0F, 0.0F, -5.0F * var23);
      this.turn(var19, this.head, 1.0F, 0.0F, 0.0F, -4.0F * var23);
      float var24 = window(var1, 5.3F, 0.7F, 8.0F, 0.6F);
      float var25 = window(var1, 5.25F, 0.47F, 8.05F, 0.55F);
      if (var24 > 0.0F || var25 > 0.0F) {
         float var26 = (float)Math.sin((double)(var1 - 5.3F - 0.5F) * Math.PI * 2.0 * 1.45);
         float var27 = window(var1, 5.75F, 0.4F, 7.55F, 0.45F);
         this.turn(var19, this.shoulderR, 0.0F, 0.0F, 1.0F, -84.0F * var24);
         this.turn(var19, this.shoulderR, 1.0F, 0.0F, 0.0F, -26.0F * var24);
         this.turn(var19, this.elbowR, 0.0F, 0.0F, 1.0F, -96.0F * var25);
         this.turn(var19, this.elbowR, 0.0F, 0.0F, 1.0F, 20.0F * var26 * var27);
         this.turn(var19, this.wristR, 0.0F, 0.0F, 1.0F, 16.0F * (float)Math.sin((double)(var1 - 5.3F - 0.62F) * Math.PI * 2.0 * 1.45) * var27);
         this.curl(var19, this.fingersR, -1.0F, -0.25F * var25, -0.4F * var25);
         this.turn(var19, this.chest, 0.0F, 0.0F, 1.0F, 3.5F * var24);
         this.turn(var19, this.spine2, 0.0F, 1.0F, 0.0F, -4.0F * var24);
         this.turn(var19, this.head, 0.0F, 0.0F, 1.0F, -4.0F * var24 + 2.0F * var26 * var27);
         this.turn(var19, this.jaw, 1.0F, 0.0F, 0.0F, 4.0F * var24);
      }

      float var50 = window(var1, 8.0F, 0.5F, 9.8F, 0.55F);
      float var51 = window(var1, 8.5F, 0.4F, 9.5F, 0.5F);
      if (var50 > 0.0F) {
         this.turn(var19, this.shoulderR, 1.0F, 0.0F, 0.0F, -95.0F * var50);
         this.turn(var19, this.shoulderR, 0.0F, 0.0F, 1.0F, -22.0F * var50);
         this.turn(var19, this.elbowR, 1.0F, 0.0F, 0.0F, -70.0F * var50);
         this.turn(var19, this.elbowR, 0.0F, 1.0F, 0.0F, 30.0F * var50);
         this.curl(var19, this.fingersR, -1.0F, 0.45F * var50, 0.6F * var50);
         this.turn(var19, this.spine1, 1.0F, 0.0F, 0.0F, 9.0F * var51);
         this.turn(var19, this.chest, 1.0F, 0.0F, 0.0F, 6.0F * var51);
         this.turn(var19, this.neck, 1.0F, 0.0F, 0.0F, 8.0F * var51);
         this.turn(var19, this.head, 1.0F, 0.0F, 0.0F, 9.0F * var51);
         this.turn(var19, this.hipR, 1.0F, 0.0F, 0.0F, -12.0F * var51);
         this.turn(var19, this.kneeR, 1.0F, 0.0F, 0.0F, 22.0F * var51);
         this.turn(var19, this.ankleR, 1.0F, 0.0F, 0.0F, -10.0F * var51);
         this.turn(var19, this.hipL, 1.0F, 0.0F, 0.0F, -16.0F * var51);
         this.turn(var19, this.kneeL, 1.0F, 0.0F, 0.0F, 30.0F * var51);
         this.turn(var19, this.ankleL, 1.0F, 0.0F, 0.0F, -14.0F * var51);
      }

      float var28 = window(var1, 9.7F, 0.7F, 11.9F, 0.55F);
      this.casting = window(var1, 10.15F, 0.3F, 11.549999F, 0.35F);
      if (var28 > 0.0F) {
         float var29 = (float)Math.sin((double)((var1 - 9.7F) * 3.3F)) * this.casting;
         this.turn(var19, this.shoulderR, 1.0F, 0.0F, 0.0F, -128.0F * var28);
         this.turn(var19, this.shoulderR, 0.0F, 0.0F, 1.0F, -18.0F * var28 + 8.0F * var29);
         this.turn(var19, this.elbowR, 1.0F, 0.0F, 0.0F, -22.0F * var28);
         this.turn(var19, this.wristR, 1.0F, 0.0F, 0.0F, -20.0F * var28);
         this.curl(var19, this.fingersR, -1.0F, -0.35F * var28, -0.5F * var28);
         this.turn(var19, this.chest, 1.0F, 0.0F, 0.0F, -7.0F * var28);
         this.turn(var19, this.neck, 1.0F, 0.0F, 0.0F, -12.0F * var28);
         this.turn(var19, this.head, 1.0F, 0.0F, 0.0F, -16.0F * var28);
         this.turn(var19, this.jaw, 1.0F, 0.0F, 0.0F, 7.0F * this.casting);
      }

      Quaternionf[] var52 = this.sit;
      this.turn(var52, this.spine1, 1.0F, 0.0F, 0.0F, 9.0F + 1.0F * var17);
      this.turn(var52, this.spine2, 1.0F, 0.0F, 0.0F, 6.0F);
      this.turn(var52, this.chest, 1.0F, 0.0F, 0.0F, 3.0F);
      this.turn(var52, this.neck, 1.0F, 0.0F, 0.0F, -9.0F);
      this.turn(var52, this.head, 1.0F, 0.0F, 0.0F, -6.0F);
      this.turn(var52, this.hipR, 1.0F, 0.0F, 0.0F, -78.0F);
      this.turn(var52, this.hipR, 0.0F, 0.0F, 1.0F, -10.0F);
      this.turn(var52, this.kneeR, 1.0F, 0.0F, 0.0F, 92.0F);
      this.turn(var52, this.ankleR, 1.0F, 0.0F, 0.0F, -18.0F);
      this.turn(var52, this.hipL, 1.0F, 0.0F, 0.0F, -74.0F);
      this.turn(var52, this.hipL, 0.0F, 0.0F, 1.0F, 10.0F);
      this.turn(var52, this.kneeL, 1.0F, 0.0F, 0.0F, 98.0F);
      this.turn(var52, this.ankleL, 1.0F, 0.0F, 0.0F, -18.0F);
      this.turn(var52, this.shoulderR, 0.0F, 0.0F, 1.0F, 30.0F);
      this.turn(var52, this.shoulderR, 1.0F, 0.0F, 0.0F, -44.0F);
      this.turn(var52, this.elbowR, 1.0F, 0.0F, 0.0F, -22.0F);
      this.turn(var52, this.shoulderL, 0.0F, 0.0F, 1.0F, -30.0F);
      this.turn(var52, this.shoulderL, 1.0F, 0.0F, 0.0F, -44.0F);
      this.turn(var52, this.elbowL, 1.0F, 0.0F, 0.0F, -22.0F);
      this.curl(var52, this.fingersR, -1.0F, 1.0F, 1.0F);
      this.curl(var52, this.fingersL, 1.0F, 1.0F, 1.0F);
      if (var1 > 14.2F) {
         float var30 = smooth(span(var1, 16.2F, 17.3F)) * (1.0F - smooth(span(var1, this.vanishStart - 1.0F, this.vanishStart)));
         float[] var31 = this.lookAngles(var2);
         float var32 = Math.max(-75.0F, Math.min(75.0F, var31[0])) * var30;
         float var33 = Math.max(-30.0F, Math.min(30.0F, var31[1])) * var30;
         this.turn(var52, this.chest, 0.0F, 1.0F, 0.0F, var32 * 0.2F);
         this.turn(var52, this.neck, 0.0F, 1.0F, 0.0F, var32 * 0.35F);
         this.turn(var52, this.head, 0.0F, 1.0F, 0.0F, var32 * 0.45F);
         this.turn(var52, this.head, 1.0F, 0.0F, 0.0F, -var33 * 0.6F);
         float var34 = window(var1, 19.7F, 0.55F, 21.6F, 0.55F);
         if (var34 > 0.0F) {
            float var35 = (float)Math.sin((double)(var1 - 19.7F) * Math.PI * 2.0 * 1.6) * window(var1, 20.1F, 0.3F, 21.2F, 0.3F);
            this.turn(var52, this.shoulderR, 1.0F, 0.0F, 0.0F, 44.0F * var34);
            this.turn(var52, this.shoulderR, 0.0F, 0.0F, 1.0F, -105.0F * var34);
            this.turn(var52, this.elbowR, 0.0F, 0.0F, 1.0F, -80.0F * var34 + 18.0F * var35);
            this.curl(var52, this.fingersR, -1.0F, -1.2F * var34, -1.3F * var34);
         }
      }

      float var53 = smooth(span(var1, 12.2F, 13.75F));
      float var54 = var1 < 12.7F ? (float)Math.sin(Math.PI * (double)span(var1, 11.9F, 12.7F)) : 0.0F;

      for (int var55 = 0; var55 < var4.count; var55++) {
         var4.rot[var55].set(this.stand[var55]).slerp(this.sit[var55], var53);
      }

      if (var54 > 0.0F) {
         this.turn(var4.rot, this.hipR, 1.0F, 0.0F, 0.0F, -22.0F * var54);
         this.turn(var4.rot, this.kneeR, 1.0F, 0.0F, 0.0F, 38.0F * var54);
         this.turn(var4.rot, this.ankleR, 1.0F, 0.0F, 0.0F, -16.0F * var54);
         this.turn(var4.rot, this.hipL, 1.0F, 0.0F, 0.0F, -22.0F * var54);
         this.turn(var4.rot, this.kneeL, 1.0F, 0.0F, 0.0F, 38.0F * var54);
         this.turn(var4.rot, this.ankleL, 1.0F, 0.0F, 0.0F, -16.0F * var54);
         this.turn(var4.rot, this.spine1, 1.0F, 0.0F, 0.0F, 8.0F * var54);
      }

      float var56 = window(var1, 14.55F, 0.35F, 17.4F, 0.6F);
      if (var56 > 0.0F) {
         float var57 = 0.5F + 0.5F * (float)Math.sin((double)(var1 - 14.7F) * Math.PI * 2.0 * 3.2);
         this.turn(var4.rot, this.jaw, 1.0F, 0.0F, 0.0F, (8.0F + 10.0F * var57) * var56);
         this.turn(var4.rot, this.head, 1.0F, 0.0F, 0.0F, -14.0F * var56);
         this.turn(var4.rot, this.chest, 1.0F, 0.0F, 0.0F, -5.0F * var56 * var57);
      }

      float var58 = this.flyVel.length();
      float var59 = Math.min(1.0F, var58 / 7.0F);
      float var60 = smooth(span(var1, 12.5F, 14.4F));
      float var36 = 0.25F + 0.75F * var59;

      for (int var37 = 0; var37 < this.cloak.length; var37++) {
         float var38 = var1 * (3.0F + 6.0F * var59) - (float)var37 * 0.85F;
         float var39 = (6.0F + 6.5F * (float)var37) * (0.35F * var60 + var59) * 0.5F;
         this.turn(var4.rot, this.cloak[var37], 1.0F, 0.0F, 0.0F, var39 + (float)Math.sin((double)var38) * (1.5F + 4.0F * var36) * (0.4F + 0.2F * (float)var37));
         this.turn(var4.rot, this.cloak[var37], 0.0F, 0.0F, 1.0F, (float)Math.sin((double)(var38 * 0.7F + 1.3F)) * 2.0F * var36);
      }

      for (int var61 = 0; var61 < this.hair.length; var61++) {
         float var64 = var1 * (2.2F + 5.0F * var59) - (float)var61 * 0.7F;
         this.turn(var4.rot, this.hair[var61], 1.0F, 0.0F, 0.0F, 2.0F + 4.5F * (float)var61 * var59 + (float)Math.sin((double)var64) * (1.2F + 3.0F * var59));
         this.turn(var4.rot, this.hair[var61], 0.0F, 0.0F, 1.0F, (float)Math.sin((double)(var64 * 0.8F + 0.5F)) * (1.0F + 2.5F * var59));
      }

      for (int var62 = 1; var62 < this.hat.length; var62++) {
         float var65 = var1 * (2.0F + 4.0F * var59) - (float)var62 * 0.6F;
         this.turn(
            var4.rot,
            this.hat[var62],
            1.0F,
            0.0F,
            0.0F,
            (float)var62 * 4.0F * var59 + (float)Math.sin((double)var65) * (1.0F + 2.0F * var59) * (float)var62 * 0.5F
         );
      }

      float var63 = (float)Math.sin(Math.PI * (double)span(var1, 12.5F, 13.299999F));
      var4.rootOffset.set(0.0F, -0.05F * var54 + 0.1F * Math.max(0.0F, var63) * (1.0F - var53 * 0.3F) - 0.045F * var51, 0.0F);
      var4.solve();
      if (!this.gripReady) {
         this.computeGrip();
      }

      Matrix4f var66 = new Matrix4f(var4.world[this.wristL]).mul(this.heldGrip);
      Matrix4f var67 = this.seatedBroom(new Matrix4f());
      Matrix4f var40 = new Matrix4f(var67).translateLocal(0.36F, 0.06F, 0.02F);
      float var41 = smooth(span(var1, 11.95F, 12.849999F));
      float var42 = smooth(span(var1, 12.75F, 13.599999F));
      Matrix4f var43 = new Matrix4f();
      blend(var66, var40, var41, var43);
      blend(var43, var67, var42, this.broom);
      float var44 = 0.0F;
      if (var1 >= 11.9F) {
         var44 = 0.62F * smooth(span(var1, 12.5F, 14.299999F));
         var44 += 0.06F * (float)Math.sin((double)((var1 - 11.9F) * 2.4F)) * smooth(span(var1, 13.599999F, 14.299999F));
      }

      this.fly(var1, var3, var44, var2);
      if (this.exiting) {
         this.exitFade = Math.max(0.0F, this.exitFade - var3 / 0.9F);
      }

      if (var1 < 2.3F) {
         float var45 = span(var1, 0.0F, 2.0F);
         this.dissolveMode = 1.0F;
         this.dissolveAt = -0.25F + 2.35F * (1.0F - (1.0F - var45) * (1.0F - var45) * (1.0F - var45));
      } else if (var1 >= this.vanishStart) {
         float var69 = span(var1, this.vanishStart, this.vanishStart + 2.8F);
         this.dissolveMode = -1.0F;
         this.dissolveAt = -0.3F + 2.45F * smooth(var69);
      } else {
         this.dissolveMode = 0.0F;
      }

      float var70 = var1 >= this.vanishStart ? 1.0F - smooth(span(var1, this.vanishStart + 1.54F, this.vanishStart + 2.8F)) : 1.0F;
      this.alpha = smooth(span(var1, 0.0F, 0.35F)) * var70 * this.exitFade;
      float var46 = Math.max(1.0F - smooth(span(var1, 2.2F, 3.7F)), this.casting * 0.7F);
      if (var1 >= this.vanishStart) {
         var46 = 1.0F;
      }

      this.glow = (0.45F + 0.55F * var46) * this.exitFade;
      this.finished = var1 >= this.vanishStart + 2.8F + 0.4F || this.exiting && this.exitFade <= 0.0F;
   }

   private float[] lookAngles(Vector3d var1) {
      Vector3f var2 = this.model.transformPosition(this.rig.position(this.chest, new Vector3f()));
      Vector3f var3 = new Vector3f((float)(var1.x - this.origin.x) - var2.x, (float)(var1.y - this.origin.y) - var2.y, (float)(var1.z - this.origin.z) - var2.z);
      new Matrix4f(this.model).invert().transformDirection(var3);
      float var4 = (float)Math.toDegrees(Math.atan2((double)var3.x, (double)var3.z));
      float var5 = (float)Math.toDegrees(Math.atan2((double)var3.y, Math.sqrt((double)(var3.x * var3.x + var3.z * var3.z))));
      return new float[]{var4, var5};
   }

   private void computeGrip() {
      WitchRig var1 = this.rig;
      Vector3f var2 = new Vector3f();

      for (int var3 = 1; var3 < 5; var3++) {
         var2.add(var1.position(this.fingersL[var3][0], this.v));
      }

      var2.div(4.0F);
      Vector3f var5 = var1.position(this.wristL, new Vector3f());
      var2.lerp(var5, 0.35F);
      Matrix4f var4 = new Matrix4f().translation(var2.x + 0.012F, 0.0F, var2.z + 0.01F).rotateY((float)Math.toRadians(-20.0));
      this.heldGrip.set(var1.world[this.wristL]).invert().mul(var4);
      this.gripReady = true;
   }

   private Matrix4f seatedBroom(Matrix4f var1) {
      WitchRig var2 = this.rig;
      Vector3f var3 = var2.position(this.wristL, new Vector3f());
      Vector3f var4 = new Vector3f(var3).add(-0.17F, 0.0F, 0.0F);
      Vector3f var5 = var2.position(this.hipR, new Vector3f()).add(var2.position(this.hipL, this.v)).mul(0.5F);
      var5.y -= 0.115F;
      var5.z -= 0.02F;
      Vector3f var6 = new Vector3f(var4).sub(var5);
      var6.y -= 0.02F;
      var6.normalize();
      Vector3f var7 = new Vector3f(1.0F, 0.0F, 0.0F);
      Vector3f var8 = new Vector3f(var7).cross(var6).normalize();
      var7.set(var6).cross(var8).normalize();
      Matrix4f var9 = new Matrix4f(var7.x, var7.y, var7.z, 0.0F, var6.x, var6.y, var6.z, 0.0F, var8.x, var8.y, var8.z, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
      Vector3f var10 = new Vector3f(var5).sub(new Vector3f(var6).mul(0.74F));
      return var1.translation(var10).mul(var9);
   }

   private static void blend(Matrix4f var0, Matrix4f var1, float var2, Matrix4f var3) {
      Vector3f var4 = var0.getTranslation(new Vector3f());
      Vector3f var5 = var1.getTranslation(new Vector3f());
      Quaternionf var6 = var0.getNormalizedRotation(new Quaternionf());
      Quaternionf var7 = var1.getNormalizedRotation(new Quaternionf());
      var3.translation(var4.lerp(var5, var2)).rotate(var6.slerp(var7, var2));
   }

   private void buildPath(Vector3f var1, Vector3d var2) {
      float var3 = (float)(var2.x - this.origin.x);
      float var4 = (float)(var2.z - this.origin.z);
      float var5 = (float)Math.atan2((double)(var1.z - var4), (double)(var1.x - var3));
      float var6 = Math.max(4.0F, (float)Math.hypot((double)(var1.x - var3), (double)(var1.z - var4)));
      float[][] var7 = new float[][]{
         {0.0F, 0.0F, 0.0F},
         {0.32F, 1.0F, 1.8F},
         {0.95F, 2.5F, 4.4F},
         {1.65F, 4.0F, 7.2F},
         {2.4F, 5.5F, 10.0F},
         {3.15F, 7.5F, 13.0F},
         {3.85F, 11.0F, 17.0F},
         {4.45F, 19.0F, 23.0F},
         {4.85F, 32.0F, 31.0F},
         {5.1F, 48.0F, 40.0F}
      };
      this.path = new Vector3f[var7.length];
      float var8 = var1.y;

      for (int var9 = 0; var9 < var7.length; var9++) {
         float var10 = var5 + var7[var9][0];
         float var11 = var6 + var7[var9][1];
         Vector3f var12 = var9 == 0
            ? new Vector3f(var1)
            : new Vector3f(var3 + (float)Math.cos((double)var10) * var11, var1.y + var7[var9][2], var4 + (float)Math.sin((double)var10) * var11);
         if (var9 > 0) {
            if (this.ground != null) {
               double var13 = this.ground.top(this.origin.x + (double)var12.x, this.origin.z + (double)var12.z);
               if (!Double.isNaN(var13)) {
                  var12.y = Math.max(var12.y, (float)(var13 - this.origin.y) + 3.6F);
               }
            }

            var12.y = Math.max(var12.y, var8 + 0.4F);
         }

         var8 = var12.y;
         this.path[var9] = var12;
      }
   }

   private Vector3f pathAt(float var1, Vector3f var2) {
      int var3 = this.path.length;
      var1 = Math.max(0.0F, Math.min((float)var3 - 1.001F, var1));
      int var4 = (int)var1;
      float var5 = var1 - (float)var4;
      Vector3f var6 = this.path[Math.max(0, var4 - 1)];
      Vector3f var7 = this.path[var4];
      Vector3f var8 = this.path[Math.min(var3 - 1, var4 + 1)];
      Vector3f var9 = this.path[Math.min(var3 - 1, var4 + 2)];
      float var10 = var5 * var5;
      float var11 = var10 * var5;

      for (int var12 = 0; var12 < 3; var12++) {
         float var13 = var6.get(var12);
         float var14 = var7.get(var12);
         float var15 = var8.get(var12);
         float var16 = var9.get(var12);
         var2.setComponent(
            var12,
            0.5F
               * (
                  2.0F * var14
                     + (-var13 + var15) * var5
                     + (2.0F * var13 - 5.0F * var14 + 4.0F * var15 - var16) * var10
                     + (-var13 + 3.0F * var14 - 3.0F * var15 + var16) * var11
               )
         );
      }

      return var2;
   }

   private void fly(float var1, float var2, float var3, Vector3d var4) {
      if (var1 < 14.7F) {
         this.flyPos.set(0.0F, var3, 0.0F);
         this.flyVel.zero();
         this.flyYaw = this.bodyYaw;
         this.flyYawVel = 0.0F;
         this.flyRoll = 0.0F;
         this.flyRollVel = 0.0F;
         this.pathS = 0.0F;
         this.flyPitch = -0.16F * smooth(span(var1, 13.7F, 14.7F));
         this.flyPitchVel = 0.0F;
         this.model.translation(this.flyPos).rotateY(this.flyYaw).rotateX(this.flyPitch);
      } else {
         if (this.path == null) {
            this.buildPath(new Vector3f(0.0F, var3, 0.0F), var4);
         }

         float var5 = var1 - 14.7F;
         float var6 = 7.0F * smooth(span(var5, 0.0F, 2.8F)) + 0.35F;
         Vector3f var7 = this.pathAt(this.pathS, new Vector3f());
         Vector3f var8 = this.pathAt(this.pathS + 0.02F, new Vector3f());
         float var9 = Math.max(0.05F, var8.distance(var7) / 0.02F);
         this.pathS += var6 * var2 / var9;
         if (this.vanishStart == Float.MAX_VALUE && (this.pathS > (float)this.path.length - 2.4F || var5 > 12.5F)) {
            this.vanishStart = var1;
         }

         Vector3f var10 = this.pathS >= (float)this.path.length - 1.01F
            ? new Vector3f(this.flyPos).fma(var2, this.flyVel)
            : this.pathAt(this.pathS, new Vector3f());
         if (var2 > 0.0F) {
            Vector3f var11 = new Vector3f(var10).sub(this.flyPos).div(var2);
            this.flyVel.lerp(var11, 1.0F - (float)Math.exp((double)(-var2 * 12.0F)));
         }

         this.flyPos.set(var10);
         Vector3f var19 = this.pathAt(this.pathS + 0.22F, new Vector3f()).sub(var10);
         if (var19.lengthSquared() < 1.0E-6F) {
            var19.set(this.flyVel);
         }

         float var12 = var19.lengthSquared() > 1.0E-6F ? (float)Math.atan2((double)var19.x, (double)var19.z) : this.flyYaw;
         float var13 = (float)Math.sqrt((double)(var19.x * var19.x + var19.z * var19.z));
         float var14 = -((float)Math.atan2((double)var19.y, (double)Math.max(0.05F, var13))) * 0.5F;
         float var15 = 7.0F;
         float var16 = 2.0F * (float)Math.sqrt((double)var15);
         this.flyYawVel = this.flyYawVel + (wrap(var12 - this.flyYaw) * var15 - this.flyYawVel * var16) * var2;
         this.flyYaw = wrap(this.flyYaw + this.flyYawVel * var2);
         this.flyPitchVel = this.flyPitchVel + ((var14 - this.flyPitch) * var15 - this.flyPitchVel * var16) * var2;
         this.flyPitch = this.flyPitch + this.flyPitchVel * var2;
         float var17 = Math.max(-0.55F, Math.min(0.55F, -this.flyYawVel * 0.5F));
         this.flyRollVel = this.flyRollVel + ((var17 - this.flyRoll) * 5.0F - this.flyRollVel * 2.0F * (float)Math.sqrt(5.0)) * var2;
         this.flyRoll = this.flyRoll + this.flyRollVel * var2;
         float var18 = 0.06F * (float)Math.sin((double)(var1 * 2.6F));
         this.model.translation(this.flyPos.x, this.flyPos.y + var18, this.flyPos.z).rotateY(this.flyYaw).rotateX(this.flyPitch).rotateZ(this.flyRoll);
      }
   }

   public Vector3f broomTail(Vector3f var1) {
      return new Matrix4f(this.model).mul(this.broom).transformPosition(var1.set(0.0F, 0.22F, 0.0F));
   }

   public Vector3f center(Vector3f var1) {
      return this.model.transformPosition(this.rig.position(this.chest, var1));
   }

   public Vector3f rightHand(Vector3f var1) {
      Vector3f var2 = new Vector3f();

      for (int var3 = 1; var3 < 5; var3++) {
         var2.add(this.rig.position(this.fingersR[var3][0], this.v));
      }

      var2.div(4.0F);
      return this.model.transformPosition(var1.set(var2));
   }

   public Vector3f bodyAt(float var1, float var2, Vector3f var3) {
      float var4 = var1 > 1.45F ? 0.22F : (var1 > 0.9F ? 0.2F : 0.16F);
      var3.set((float)Math.cos((double)var2) * var4, var1, (float)Math.sin((double)var2) * var4);
      return this.model.transformPosition(var3);
   }

   public Vector3f velocity(Vector3f var1) {
      return var1.set(this.flyVel);
   }

   public float speed() {
      return this.flyVel.length();
   }

   public interface Ground {
      double top(double var1, double var3);
   }
}
