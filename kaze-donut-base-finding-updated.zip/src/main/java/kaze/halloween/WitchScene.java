package kaze.halloween;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import kaze.halloween.witch.WitchAsset;
import kaze.halloween.witch.WitchPerformance;
import kaze.halloween.witch.WitchRenderer;
import kaze.halloween.witch.WitchRig;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.world.LightType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.random.Random;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.world.Heightmap.Type;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class WitchScene {
   private static CompletableFuture<WitchAsset> loading;
   private static WitchAsset asset;
   private static WitchRig rig;
   private static WitchPerformance perf;
   private static boolean running;
   private static float t;
   private static boolean laughed;
   private static boolean puffed;
   private static float acc;
   private static float trailAcc;
   private static final List<WitchScene.Delayed> SOUNDS = new ArrayList<>();
   private static final Random SOUND_RANDOM = Random.create();
   private static final WitchRenderer.Look LOOK = new WitchRenderer.Look();

   private WitchScene() {
   }

   public static void preload() {
      if (asset == null && loading == null) {
         loading = CompletableFuture.supplyAsync(() -> {
            try {
               WitchAsset var1;
               try (InputStream var0 = WitchScene.class.getResourceAsStream("/assets/kaze/witch/witch.kwm")) {
                  if (var0 == null) {
                     throw new IllegalStateException("missing witch model");
                  }

                  var1 = WitchAsset.load(var0);
               }

               return var1;
            } catch (Exception var5) {
               throw new RuntimeException(var5);
            }
         });
      }
   }

   private static boolean ready() {
      if (asset != null) {
         return true;
      } else {
         preload();

         try {
            asset = loading.join();
         } catch (Throwable var1) {
            System.err.println("Kaze: witch model failed to load: " + var1);
            asset = null;
         }

         loading = null;
         return asset != null;
      }
   }

   public static boolean start() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      if (var0.player != null && var0.world != null && ready()) {
         rig = new WitchRig(asset);
         perf = new WitchPerformance(rig);
         Vec3d var1 = var0.player.getCameraPosVec(1.0F);
         Vec3d var2 = place(var0, var1);
         ClientWorld var3 = var0.world;
         perf.start(
            new Vector3d(var2.x, var2.y, var2.z),
            new Vector3d(var1.x, var1.y, var1.z),
            (var1x, var3x) -> {
               int var5 = MathHelper.floor(var1x);
               int var6 = MathHelper.floor(var3x);
               return var3.isChunkLoaded(var5 >> 4, var6 >> 4) ? (double)var3.getTopY(Type.MOTION_BLOCKING, var5, var6) : Double.NaN;
            }
         );
         t = 0.0F;
         laughed = false;
         puffed = false;
         acc = 0.0F;
         trailAcc = 0.0F;
         running = true;
         SOUNDS.clear();
         return true;
      } else {
         return false;
      }
   }

   private static Vec3d place(MinecraftClient var0, Vec3d var1) {
      ClientWorld var2 = var0.world;
      float var3 = var0.player.getYaw();
      double var4 = -Math.sin(Math.toRadians((double)var3));
      double var6 = Math.cos(Math.toRadians((double)var3));

      for (double var8 = 10.0; var8 >= 5.0; var8 -= 0.5) {
         double var10 = var1.x + var4 * var8;
         double var12 = var1.z + var6 * var8;
         int var14 = MathHelper.floor(var10);
         int var15 = MathHelper.floor(var12);

         for (int var16 = MathHelper.floor(var1.y) + 4; var16 >= MathHelper.floor(var1.y) - 10; var16--) {
            BlockPos var17 = new BlockPos(var14, var16, var15);
            if (!var2.getBlockState(var17).getCollisionShape(var2, var17).isEmpty()
               && var2.getBlockState(var17.up()).getCollisionShape(var2, var17.up()).isEmpty()
               && var2.getBlockState(var17.up(2)).getCollisionShape(var2, var17.up(2)).isEmpty()) {
               double var18 = (double)var16 + var2.getBlockState(var17).getCollisionShape(var2, var17).getMax(Axis.Y);
               Vec3d var20 = new Vec3d(var10, var18, var12);
               BlockHitResult var21 = var2.raycast(
                  new RaycastContext(var1, var20.add(0.0, 1.2, 0.0), ShapeType.COLLIDER, FluidHandling.NONE, var0.player)
               );
               if (var21.getType() == net.minecraft.util.hit.HitResult.Type.MISS) {
                  return var20;
               }
               break;
            }
         }
      }

      return new Vec3d(var1.x + var4 * 7.0, var1.y - 1.62, var1.z + var6 * 7.0);
   }

   public static boolean running() {
      return running;
   }

   public static void hurry() {
      if (running && perf != null) {
         perf.exit();
      }
   }

   private static float smooth(float var0) {
      var0 = Math.max(0.0F, Math.min(1.0F, var0));
      return var0 * var0 * (3.0F - 2.0F * var0);
   }

   public static void update(float var0) {
      if (!running) {
         flushSounds(var0);
      } else {
         MinecraftClient var1 = MinecraftClient.getInstance();
         if (var1.player != null && var1.world != null) {
            t += var0;
            Vec3d var2 = var1.player.getCameraPosVec(1.0F);
            perf.update(t, new Vector3d(var2.x, var2.y, var2.z));
            Vector3d var3 = perf.origin;
            Vector3f var4 = perf.center(new Vector3f());
            Vec3d var5 = new Vec3d(var3.x + (double)var4.x, var3.y + (double)var4.y, var3.z + (double)var4.z);
            java.util.Random var6 = HalloweenParticles.random();
            if (t < 2.8000002F) {
               acc += var0 * 60.0F;

               while (acc >= 1.0F) {
                  acc--;
                  double var7 = var6.nextDouble() * Math.PI * 2.0;
                  double var9 = 0.55 + var6.nextDouble() * 0.35;
                  float var11 = 0.9F;
                  if (var6.nextFloat() < 0.35F) {
                     HalloweenParticles.spawn(
                        0,
                        var3.x + Math.cos(var7) * var9,
                        var3.y + 0.1 + var6.nextDouble() * 0.5,
                        var3.z + Math.sin(var7) * var9,
                        (float)(-Math.sin(var7) * (double)var11),
                        0.25F + var6.nextFloat() * 0.3F,
                        (float)(Math.cos(var7) * (double)var11),
                        0.45F + var6.nextFloat() * 0.3F,
                        2.4F,
                        2.4F + var6.nextFloat(),
                        0.2F,
                        0.15F,
                        0.27F,
                        0.55F
                     );
                  } else {
                     Vector3f var12 = perf.bodyAt(Math.max(0.05F, perf.dissolveAt), (float)var7, new Vector3f());
                     HalloweenParticles.spawn(
                        var6.nextFloat() < 0.5F ? 1 : 3,
                        var3.x + (double)var12.x,
                        var3.y + (double)var12.y,
                        var3.z + (double)var12.z,
                        (float)Math.cos(var7) * 0.35F,
                        0.25F + var6.nextFloat() * 0.4F,
                        (float)Math.sin(var7) * 0.35F,
                        0.05F + var6.nextFloat() * 0.04F,
                        0.4F,
                        0.9F + var6.nextFloat() * 0.8F,
                        1.0F,
                        0.55F + var6.nextFloat() * 0.25F,
                        0.2F,
                        0.9F
                     );
                  }
               }
            }

            if (t > 2.2F && t < 11.9F) {
               trailAcc += var0 * 7.0F;

               while (trailAcc >= 1.0F) {
                  trailAcc--;
                  double var18 = var6.nextDouble() * Math.PI * 2.0;
                  HalloweenParticles.spawn(
                     4,
                     var3.x + Math.cos(var18) * 0.8,
                     var3.y + 0.3 + var6.nextDouble() * 1.5,
                     var3.z + Math.sin(var18) * 0.8,
                     (float)(-Math.sin(var18)) * 0.12F,
                     0.05F,
                     (float)Math.cos(var18) * 0.12F,
                     0.025F,
                     0.6F,
                     2.2F + var6.nextFloat(),
                     0.8F,
                     0.7F,
                     1.0F,
                     0.75F
                  );
               }
            }

            if (perf.casting > 0.01F) {
               Vector3f var19 = perf.rightHand(new Vector3f());
               acc = acc + var0 * 70.0F * perf.casting;

               while (acc >= 1.0F) {
                  acc--;
                  float var8 = t * 7.0F + var6.nextFloat() * 0.6F;
                  float var28 = 0.25F + var6.nextFloat() * 0.25F;
                  float var10 = 1.4F + var6.nextFloat() * 0.8F;
                  boolean var34 = var6.nextFloat() < 0.55F;
                  HalloweenParticles.spawn(
                     var6.nextFloat() < 0.4F ? 2 : 1,
                     var3.x + (double)var19.x,
                     var3.y + (double)var19.y,
                     var3.z + (double)var19.z,
                     (float)Math.cos((double)var8) * var28 * 3.0F,
                     var10,
                     (float)Math.sin((double)var8) * var28 * 3.0F,
                     0.04F + var6.nextFloat() * 0.04F,
                     0.5F,
                     1.1F + var6.nextFloat() * 0.9F,
                     var34 ? 1.0F : 0.72F,
                     var34 ? 0.6F : 0.45F,
                     var34 ? 0.25F : 1.0F,
                     0.95F
                  );
               }
            }

            if (!puffed && t >= 12.799999F) {
               puffed = true;

               for (int var20 = 0; var20 < 26; var20++) {
                  double var24 = var6.nextDouble() * Math.PI * 2.0;
                  HalloweenParticles.spawn(
                     0,
                     var3.x + Math.cos(var24) * 0.4,
                     var3.y + 0.15,
                     var3.z + Math.sin(var24) * 0.4,
                     (float)Math.cos(var24) * 1.6F,
                     0.2F + var6.nextFloat() * 0.3F,
                     (float)Math.sin(var24) * 1.6F,
                     0.4F + var6.nextFloat() * 0.3F,
                     2.6F,
                     2.0F + var6.nextFloat(),
                     0.22F,
                     0.17F,
                     0.28F,
                     0.5F
                  );
               }
            }

            if (!laughed && t >= 14.7F) {
               laughed = true;
               sound(SoundEvents.ENTITY_WITCH_CELEBRATE, var5.add(0.0, 0.6, 0.0), 1.9F, 0.86F, 0.0F);
               sound(SoundEvents.ENTITY_WITCH_CELEBRATE, var5.add(0.0, 2.5, 0.0), 1.3F, 0.84F, 0.22F);
               sound(SoundEvents.ENTITY_WITCH_CELEBRATE, var5.add(0.0, 5.0, 0.0), 0.95F, 0.81F, 0.5F);
               sound(SoundEvents.ENTITY_PHANTOM_FLAP, var5, 0.7F, 0.6F, 0.05F);
            }

            if (t > 13.9F && perf.alpha > 0.02F) {
               Vector3f var21 = perf.broomTail(new Vector3f());
               Vector3f var25 = perf.velocity(new Vector3f());
               float var29 = var25.length();
               trailAcc = trailAcc + var0 * (8.0F + 40.0F * Math.min(1.0F, var29 / 6.0F)) * perf.alpha;

               while (trailAcc >= 1.0F) {
                  trailAcc--;
                  float var32 = var6.nextFloat();
                  double var35 = var3.x + (double)var21.x + (var6.nextDouble() - 0.5) * 0.18;
                  double var13 = var3.y + (double)var21.y + (var6.nextDouble() - 0.5) * 0.18;
                  double var15 = var3.z + (double)var21.z + (var6.nextDouble() - 0.5) * 0.18;
                  if (var32 < 0.22F) {
                     HalloweenParticles.spawn(
                        0,
                        var35,
                        var13,
                        var15,
                        -var25.x * 0.15F,
                        -var25.y * 0.15F + 0.1F,
                        -var25.z * 0.15F,
                        0.18F + var6.nextFloat() * 0.12F,
                        3.0F,
                        1.4F + var6.nextFloat() * 0.8F,
                        0.24F,
                        0.19F,
                        0.3F,
                        0.42F * perf.alpha
                     );
                  } else if (var32 < 0.62F) {
                     HalloweenParticles.spawn(
                        3,
                        var35,
                        var13,
                        var15,
                        -var25.x * 0.25F + (var6.nextFloat() - 0.5F) * 0.6F,
                        -var25.y * 0.2F,
                        -var25.z * 0.25F + (var6.nextFloat() - 0.5F) * 0.6F,
                        0.03F + var6.nextFloat() * 0.025F,
                        0.5F,
                        1.0F + var6.nextFloat() * 1.2F,
                        1.0F,
                        0.5F + var6.nextFloat() * 0.25F,
                        0.15F,
                        perf.alpha
                     );
                  } else {
                     boolean var17 = var6.nextFloat() < 0.45F;
                     HalloweenParticles.spawn(
                        2,
                        var35,
                        var13,
                        var15,
                        -var25.x * 0.4F + (var6.nextFloat() - 0.5F),
                        -var25.y * 0.4F + (var6.nextFloat() - 0.5F),
                        -var25.z * 0.4F + (var6.nextFloat() - 0.5F),
                        0.03F + var6.nextFloat() * 0.02F,
                        0.5F,
                        0.6F + var6.nextFloat() * 0.6F,
                        var17 ? 0.75F : 1.0F,
                        var17 ? 0.5F : 0.7F,
                        var17 ? 1.0F : 0.35F,
                        perf.alpha
                     );
                  }
               }
            }

            if (perf.dissolveMode < 0.0F && perf.alpha > 0.02F) {
               acc += var0 * 90.0F;

               while (acc >= 1.0F) {
                  acc--;
                  float var22 = var6.nextFloat() * 6.2832F;
                  Vector3f var26 = perf.bodyAt(perf.dissolveAt, var22, new Vector3f());
                  boolean var30 = var6.nextFloat() < 0.4F;
                  HalloweenParticles.spawn(
                     var6.nextFloat() < 0.5F ? 1 : 4,
                     var3.x + (double)var26.x,
                     var3.y + (double)var26.y,
                     var3.z + (double)var26.z,
                     (float)Math.cos((double)var22) * 0.5F,
                     0.4F + var6.nextFloat() * 0.5F,
                     (float)Math.sin((double)var22) * 0.5F,
                     0.06F + var6.nextFloat() * 0.05F,
                     0.3F,
                     1.2F + var6.nextFloat(),
                     var30 ? 0.75F : 1.0F,
                     var30 ? 0.5F : 0.62F,
                     var30 ? 1.0F : 0.28F,
                     1.0F
                  );
               }
            }

            flushSounds(var0);
            float var23 = (float)var5.distanceTo(var2);
            Vec3d var36 = var5;
            float var27;
            float var31;
            float var33;
            if (t < 11.9F) {
               var27 = 1.0F - 0.16F * smooth((t - 1.0F) / 5.0F) - 0.06F * perf.casting;
               var31 = 4.5F;
               var33 = 1.2F;
               if (perf.casting > 0.0F) {
                  var36 = var5.add(0.0, 0.5 * (double)perf.casting, 0.0);
               }
            } else if (t < 14.7F) {
               var27 = 0.86F;
               var31 = 5.0F;
               var33 = 1.6F;
            } else {
               var27 = Math.max(0.34F, Math.min(0.86F, 9.5F / Math.max(1.0F, var23)));
               var31 = 6.5F;
               var33 = 2.4F;
               Vector3f var37 = perf.velocity(new Vector3f());
               var36 = var5.add((double)var37.x * 0.2, (double)var37.y * 0.2, (double)var37.z * 0.2);
            }

            CinematicCamera.follow(var36, var31, var27, var33);
            if (perf.finished) {
               running = false;
            }
         } else {
            reset();
         }
      }
   }

   public static boolean finished() {
      return !running;
   }

   private static void sound(SoundEvent var0, Vec3d var1, float var2, float var3, float var4) {
      SOUNDS.add(new WitchScene.Delayed(var0, var1, var2, var3, var4));
   }

   private static void flushSounds(float var0) {
      MinecraftClient var1 = MinecraftClient.getInstance();

      for (int var2 = SOUNDS.size() - 1; var2 >= 0; var2--) {
         WitchScene.Delayed var3 = SOUNDS.get(var2);
         var3.delay -= var0;
         if (var3.delay <= 0.0F) {
            SOUNDS.remove(var2);

            try {
               var1.getSoundManager()
                  .play(
                     new PositionedSoundInstance(
                        var3.event, SoundCategory.MASTER, var3.volume, var3.pitch, SOUND_RANDOM, var3.at.x, var3.at.y, var3.at.z
                     )
                  );
            } catch (Throwable var5) {
            }
         }
      }
   }

   public static void render(Vec3d var0) {
      if (running && perf != null && !(perf.alpha <= 0.003F)) {
         MinecraftClient var1 = MinecraftClient.getInstance();
         if (var1.world != null && WitchRenderer.ensure(asset)) {
            Vector3d var2 = perf.origin;
            Matrix4f var3 = new Matrix4f()
               .translation((float)(var2.x - var0.x), (float)(var2.y - var0.y), (float)(var2.z - var0.z))
               .mul(perf.model);
            Vector3f var4 = perf.center(new Vector3f());
            BlockPos var5 = BlockPos.ofFloored(var2.x + (double)var4.x, var2.y + (double)var4.y, var2.z + (double)var4.z);
            WitchRenderer.Look var6 = LOOK;
            var6.alpha = perf.alpha;
            var6.block = var1.world.getLightLevel(LightType.BLOCK, var5);
            var6.sky = var1.world.getLightLevel(LightType.SKY, var5);
            var6.worldLight = 0.85F;
            var6.emissive = 1.4F * perf.glow;
            var6.rim = 0.35F + 0.45F * perf.glow;
            var6.dissolveMode = perf.dissolveMode;
            var6.dissolveAt = perf.dissolveAt;
            Vector4f var7 = HalloweenAtmosphere.moonDir();
            if (var7.w > 0.05F) {
               Vector3f var8 = new Vector3f(var7.x, Math.max(0.35F, var7.y), var7.z).normalize();
               var6.keyDir[0] = var8.x;
               var6.keyDir[1] = var8.y;
               var6.keyDir[2] = var8.z;
            } else {
               var6.keyDir[0] = 0.3F;
               var6.keyDir[1] = 0.8F;
               var6.keyDir[2] = 0.4F;
            }

            var6.keyDir[3] = 1.0F;
            var6.fillColor[3] = 0.22F + 0.35F * perf.glow;
            WitchRenderer.draw(rig, var3, perf.broom, var6);
         }
      }
   }

   public static void reset() {
      running = false;
      perf = null;
      rig = null;
      SOUNDS.clear();
      WitchRenderer.release();
      asset = null;
      if (loading != null) {
         loading.cancel(true);
         loading = null;
      }
   }

   private static final class Delayed {
      final SoundEvent event;
      final Vec3d at;
      final float volume;
      final float pitch;
      float delay;

      Delayed(SoundEvent var1, Vec3d var2, float var3, float var4, float var5) {
         this.event = var1;
         this.at = var2;
         this.volume = var3;
         this.pitch = var4;
         this.delay = var5;
      }
   }
}
