package kaze.halloween;

import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

public final class CinematicCamera {
   private static boolean active;
   private static boolean inputLocked;
   private static float blend;
   private static boolean releasing;
   private static float yaw;
   private static float pitch;
   private static float yawVel;
   private static float pitchVel;
   private static Vec3d target;
   private static float stiffness = 8.0F;
   private static float aimBias;
   private static float fov = 1.0F;
   private static float fovVel;
   private static float fovTarget = 1.0F;

   private CinematicCamera() {
   }

   public static void begin() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      ClientPlayerEntity var1 = var0.player;
      if (var1 != null) {
         if (!active) {
            yaw = var1.getYaw();
            pitch = var1.getPitch();
            yawVel = 0.0F;
            pitchVel = 0.0F;
            fov = 1.0F;
            fovVel = 0.0F;
            blend = 0.0F;
         }

         active = true;
         releasing = false;
         inputLocked = true;
         fovTarget = 1.0F;
      }
   }

   public static void follow(Vec3d var0, float var1, float var2, float var3) {
      target = var0;
      stiffness = var1;
      fovTarget = var2;
      aimBias = var3;
   }

   public static void release() {
      if (active) {
         releasing = true;
         fovTarget = 1.0F;
      }
   }

   public static void reset() {
      active = false;
      releasing = false;
      inputLocked = false;
      blend = 0.0F;
      fov = 1.0F;
      fovTarget = 1.0F;
      target = null;
   }

   public static boolean active() {
      return active;
   }

   public static boolean inputLocked() {
      return inputLocked;
   }

   private static float wrap(float var0) {
      var0 %= 360.0F;
      if (var0 >= 180.0F) {
         var0 -= 360.0F;
      }

      if (var0 < -180.0F) {
         var0 += 360.0F;
      }

      return var0;
   }

   public static void update(float var0) {
      if (active) {
         MinecraftClient var1 = MinecraftClient.getInstance();
         ClientPlayerEntity var2 = var1.player;
         if (var2 == null || var1.world == null) {
            reset();
         } else if (!(var0 <= 0.0F)) {
            float var3 = releasing ? 0.0F : 1.0F;
            float var4 = var0 / (releasing ? 1.15F : 0.55F);
            blend = blend < var3 ? Math.min(var3, blend + var4) : Math.max(var3, blend - var4);
            if (releasing && blend <= 0.0F) {
               active = false;
               releasing = false;
               inputLocked = false;
               fov = 1.0F;
               target = null;
            } else {
               if (target != null && !releasing) {
                  Vec3d var5 = var2.getCameraPosVec(1.0F);
                  Vec3d var6 = target.subtract(var5);
                  double var7 = Math.sqrt(var6.x * var6.x + var6.z * var6.z);
                  float var9 = (float)Math.toDegrees(Math.atan2(-var6.x, var6.z));
                  float var10 = (float)(-Math.toDegrees(Math.atan2(var6.y, Math.max(0.01, var7))));
                  var10 += aimBias;
                  var10 = Math.max(-88.0F, Math.min(88.0F, var10));
                  float var11 = stiffness;
                  float var12 = 2.0F * (float)Math.sqrt((double)var11);
                  int var13 = Math.max(1, (int)Math.ceil((double)(var0 / 0.008F)));
                  float var14 = var0 / (float)var13;

                  for (int var15 = 0; var15 < var13; var15++) {
                     float var16 = wrap(var9 - yaw);
                     yawVel = yawVel + (var16 * var11 - yawVel * var12) * var14;
                     yaw = yaw + yawVel * var14;
                     pitchVel = pitchVel + ((var10 - pitch) * var11 - pitchVel * var12) * var14;
                     pitch = pitch + pitchVel * var14;
                  }
               }

               float var17 = 3.2F;
               float var18 = 2.0F * (float)Math.sqrt((double)var17) * 1.05F;
               fovVel = fovVel + ((fovTarget - fov) * var17 - fovVel * var18) * var0;
               fov = fov + fovVel * var0;
            }
         }
      }
   }

   private static float weight() {
      float var0 = Math.max(0.0F, Math.min(1.0F, blend));
      return var0 * var0 * (3.0F - 2.0F * var0);
   }

   public static float yaw(float var0) {
      return active ? var0 + wrap(yaw - var0) * weight() : var0;
   }

   public static float pitch(float var0) {
      return active ? var0 + (pitch - var0) * weight() : var0;
   }

   public static float fov(float var0) {
      return active ? var0 * (1.0F + (fov - 1.0F) * weight()) : var0;
   }
}
