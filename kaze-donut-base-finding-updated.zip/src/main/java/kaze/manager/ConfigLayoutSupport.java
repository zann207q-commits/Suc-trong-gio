package kaze.manager;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import kaze.Kaze;
import kaze.feature.HudModule;

final class ConfigLayoutSupport {
   private static Object field(Object var0, String var1) throws ReflectiveOperationException {
      Field var2 = var0.getClass().getDeclaredField(var1);
      var2.setAccessible(true);
      return var2.get(var0);
   }

   private static void field(Object var0, String var1, Object var2) throws ReflectiveOperationException {
      Field var3 = var0.getClass().getDeclaredField(var1);
      var3.setAccessible(true);
      var3.set(var0, var2);
   }

   private static void save(Object var0, String var1) throws ReflectiveOperationException {
      Method var2 = var0.getClass().getDeclaredMethod(var1);
      var2.setAccessible(true);
      var2.invoke(var0);
   }

   static JsonObject capture() {
      JsonObject var0 = new JsonObject();

      try {
         Object var1 = field(Kaze.INSTANCE.GUI, "ui");
         save(var1, "loadPosition");
         var0.addProperty("x", (Float)field(var1, "offX"));
         var0.addProperty("y", (Float)field(var1, "offY"));
         HudModule var2 = (HudModule)Kaze.INSTANCE.getModuleManager().getModuleByClass(HudModule.class);
         Object var3 = field(var2, "hud");
         save(var3, "load");
         Map var4 = (Map)field(var3, "places");
         JsonObject var5 = new JsonObject();

         for (Object var7Raw : var4.entrySet()) {Entry var7 = (Entry)var7Raw;
            Object var8 = var7.getValue();
            JsonObject var9 = new JsonObject();
            var9.addProperty("moved", (Boolean)field(var8, "moved"));
            var9.addProperty("right", (Boolean)field(var8, "right"));
            var9.addProperty("bottom", (Boolean)field(var8, "bottom"));
            var9.addProperty("x", (Float)field(var8, "ox"));
            var9.addProperty("y", (Float)field(var8, "oy"));
            var5.add(((Enum)var7.getKey()).name(), var9);
         }

         var0.add("hud", var5);
         return var0;
      } catch (ReflectiveOperationException var10) {
         throw new IllegalStateException("Couldn't read the HUD layout.", var10);
      }
   }

   static JsonObject defaults() {
      JsonObject var0 = new JsonObject();
      var0.addProperty("x", 0);
      var0.addProperty("y", 0);
      var0.add("hud", new JsonObject());
      return var0;
   }

   static void validate(JsonObject var0) {
      number(var0.get("x"));
      number(var0.get("y"));
      JsonObject var1 = var0.getAsJsonObject("hud");
      if (var1 != null && var1.size() <= 32) {
         for (Entry var3 : var1.entrySet()) {
            JsonObject var4 = ((JsonElement)var3.getValue()).getAsJsonObject();
            number(var4.get("x"));
            number(var4.get("y"));

            for (String var6 : List.of("moved", "right", "bottom")) {
               JsonElement var7 = var4.get(var6);
               if (var7 == null || !var7.isJsonPrimitive() || !var7.getAsJsonPrimitive().isBoolean()) {
                  throw new IllegalArgumentException("Invalid HUD layout.");
               }
            }
         }
      } else {
         throw new IllegalArgumentException("Invalid HUD layout.");
      }
   }

   private static float number(JsonElement var0) {
      if (var0 != null && var0.isJsonPrimitive() && var0.getAsJsonPrimitive().isNumber()) {
         float var1 = var0.getAsFloat();
         if (Float.isFinite(var1) && !(Math.abs(var1) > 10000.0F)) {
            return var1;
         } else {
            throw new IllegalArgumentException("Invalid layout position.");
         }
      } else {
         throw new IllegalArgumentException("Invalid layout position.");
      }
   }

   static void apply(JsonObject var0) {
      validate(var0);

      try {
         Object var1 = field(Kaze.INSTANCE.GUI, "ui");
         field(var1, "offX", number(var0.get("x")));
         field(var1, "offY", number(var0.get("y")));
         field(var1, "posLoaded", true);
         field(var1, "dragging", false);
         save(var1, "savePosition");
         HudModule var2 = (HudModule)Kaze.INSTANCE.getModuleManager().getModuleByClass(HudModule.class);
         Object var3 = field(var2, "hud");
         Map var4 = (Map)field(var3, "places");
         var4.clear();
         field(var3, "dragging", null);
         Class var5 = Class.forName("kaze.feature.HudLayoutEditor$HudSection");
         Constructor var6 = Class.forName("kaze.feature.HudLayoutEditor$adsdzhecwnzmbs").getDeclaredConstructor();
         var6.setAccessible(true);

         for (Entry var8 : var0.getAsJsonObject("hud").entrySet()) {
            Enum var9;
            try {
               var9 = Enum.valueOf(var5, (String)var8.getKey());
            } catch (IllegalArgumentException var12) {
               continue;
            }

            JsonObject var10 = ((JsonElement)var8.getValue()).getAsJsonObject();
            Object var11 = var6.newInstance();
            field(var11, "moved", var10.get("moved").getAsBoolean());
            field(var11, "right", var10.get("right").getAsBoolean());
            field(var11, "bottom", var10.get("bottom").getAsBoolean());
            field(var11, "ox", number(var10.get("x")));
            field(var11, "oy", number(var10.get("y")));
            var4.put(var9, var11);
         }

         field(var3, "loaded", true);
         save(var3, "save");
      } catch (ReflectiveOperationException var13) {
         throw new IllegalStateException("Couldn't restore the HUD layout.", var13);
      }
   }
}
