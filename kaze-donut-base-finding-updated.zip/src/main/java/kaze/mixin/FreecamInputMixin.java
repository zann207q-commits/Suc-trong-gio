package kaze.mixin;

import kaze.Kaze;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import kaze.feature.FreecamModule;

@Mixin(
   value = {KeyboardInput.class},
   remap = false
)
public abstract class FreecamInputMixin {
   @Inject(
      method = {"method_3129"},
      at = {@At("TAIL")},
      remap = false
   )
   private void kaze$continueBodyInput(CallbackInfo var1) {
      if (Kaze.INSTANCE != null && Kaze.INSTANCE.getModuleManager() != null) {
         FreecamModule var2 = (FreecamModule)Kaze.INSTANCE.getModuleManager().getModuleByClass(FreecamModule.class);
         if (var2 != null && var2.isEnabled()) {
            var2.applyContinuedPlayerInput((Input)(Object)this);
         }
      }
   }
}
