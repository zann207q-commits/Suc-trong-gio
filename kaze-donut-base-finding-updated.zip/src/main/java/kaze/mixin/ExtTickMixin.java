package kaze.mixin;

import kaze.module.ext.ExtBridge;
import kaze.module.ext.Stage;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MinecraftClient.class})
public abstract class ExtTickMixin {
   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void kaze$extTickStart(CallbackInfo var1) {
      ExtBridge.tick(Stage.PRE);
   }

   @Inject(
      method = {"tick"},
      at = {@At("RETURN")}
   )
   private void kaze$extTickEnd(CallbackInfo var1) {
      ExtBridge.tick(Stage.POST);
   }
}
