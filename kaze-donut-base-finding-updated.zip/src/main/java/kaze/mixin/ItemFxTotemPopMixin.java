package kaze.mixin;

import kaze.itemfx.ItemFx;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({ClientPlayNetworkHandler.class})
public abstract class ItemFxTotemPopMixin {
   @Redirect(
      method = {"onEntityStatus"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/particle/ParticleManager;addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V"
      )
   )
   private void kaze$totemBurst(ParticleManager var1, Entity var2, ParticleEffect var3, int var4) {
      boolean var5 = false;

      try {
         var5 = ItemFx.totemPop(var2, var3);
      } catch (Throwable var7) {
         System.err.println("Kaze: totem burst failed: " + var7);
      }

      if (!var5) {
         var1.addEmitter(var2, var3, var4);
      }
   }
}
