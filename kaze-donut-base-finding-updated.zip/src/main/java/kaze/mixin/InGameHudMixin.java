package kaze.mixin;

import kaze.event.events.Render2DEvent;
import kaze.manager.EventManager;
import kaze.utils.RenderUtils;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import kaze.feature.OgScoreboardModule;

@Mixin({InGameHud.class})
public class InGameHudMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void onRenderHud(DrawContext ctx, RenderTickCounter rtc, CallbackInfo ci) {
      RenderUtils.setContext(ctx);
      EventManager.b(new Render2DEvent(ctx, rtc.getTickProgress(true)));
   }

   @Inject(
      method = {"renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hideVanillaSidebar(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
      if (OgScoreboardModule.shouldHideVanillaSidebar()) {
         ci.cancel();
      }
   }
}
