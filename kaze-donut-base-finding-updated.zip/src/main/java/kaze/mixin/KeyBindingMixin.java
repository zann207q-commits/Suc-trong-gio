package kaze.mixin;

import kaze.Kaze;
import kaze.imixin.IKeybinding;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.InputUtil.Key;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({KeyBinding.class})
public abstract class KeyBindingMixin implements IKeybinding {
   @Shadow
   private Key boundKey;

   @Shadow
   public abstract void setPressed(boolean var1);

   @Override
   public boolean kaze$isActuallyPressed() {
      return InputUtil.isKeyPressed(Kaze.mc.getWindow(), this.boundKey.getCode());
   }

   @Override
   public void kaze$resetPressed() {
      this.setPressed(this.kaze$isActuallyPressed());
   }
}
