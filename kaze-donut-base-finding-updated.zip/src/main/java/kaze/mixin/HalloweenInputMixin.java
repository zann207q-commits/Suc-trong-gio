package kaze.mixin;

import kaze.halloween.CinematicCamera;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.input.Input;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({KeyboardInput.class})
public abstract class HalloweenInputMixin {
   @Inject(
      method = {"tick"},
      at = {@At("TAIL")}
   )
   private void kaze$freeze(CallbackInfo var1) {
      if (CinematicCamera.inputLocked()) {
         ((Input)(Object)this).playerInput = PlayerInput.DEFAULT;
         ((InputAccessor)this).kaze$setMovementVector(Vec2f.ZERO);
      }
   }
}
