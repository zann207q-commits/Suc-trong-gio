package kaze.mixin;

import kaze.itemfx.ItemFx;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({InGameOverlayRenderer.class})
public abstract class ItemFxFloatingMixin {
   @Shadow
   private int floatingItemTimer;

   @Inject(
      method = {"renderFloatingItem"},
      at = {@At("HEAD")}
   )
   private void kaze$floatStart(MatrixStack var1, float var2, OrderedRenderCommandQueue var3, CallbackInfo var4) {
      ItemFx.floating(Math.max(0.0F, Math.min(1.0F, ((float)(40 - this.floatingItemTimer) + var2) / 40.0F)));
   }

   @Inject(
      method = {"renderFloatingItem"},
      at = {@At("RETURN")}
   )
   private void kaze$floatEnd(MatrixStack var1, float var2, OrderedRenderCommandQueue var3, CallbackInfo var4) {
      ItemFx.floating(-1.0F);
   }
}
