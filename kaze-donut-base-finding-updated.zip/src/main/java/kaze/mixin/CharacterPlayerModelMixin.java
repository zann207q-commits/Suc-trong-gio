package kaze.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.util.Arm;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import kaze.feature.CharacterFeatureRenderer;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityModel.class})
public abstract class CharacterPlayerModelMixin {
   @Inject(
      method = {"setArmAngle"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void kaze$characterHand(PlayerEntityRenderState var1, Arm var2, MatrixStack var3, CallbackInfo var4) {
      if (CharacterFeatureRenderer.translateToHand((PlayerEntityModel)(Object)this, var1, var2, var3)) {
         var4.cancel();
      }
   }
}
