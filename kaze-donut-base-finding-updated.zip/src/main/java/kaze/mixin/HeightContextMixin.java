package kaze.mixin;

import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.HeightContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(
   value = {HeightContext.class},
   priority = 900
)
public abstract class HeightContextMixin {
   @Redirect(
      method = {"<init>"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/gen/chunk/ChunkGenerator;getMinimumY()I"
      ),
      require = 0
   )
   private int onMinY(ChunkGenerator cg) {
      return cg == null ? -9999999 : cg.getMinimumY();
   }

   @Redirect(
      method = {"<init>"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/world/gen/chunk/ChunkGenerator;getWorldHeight()I"
      ),
      require = 0
   )
   private int onHeight(ChunkGenerator cg) {
      return cg == null ? 100000000 : cg.getWorldHeight();
   }
}
