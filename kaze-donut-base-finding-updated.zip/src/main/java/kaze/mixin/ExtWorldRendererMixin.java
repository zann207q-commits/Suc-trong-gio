package kaze.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import kaze.module.ext.ExtBridge;
import kaze.utils.ext.ShaderOverlay;
import kaze.utils.ext.TracerEngine;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.world.debug.gizmo.GizmoDrawing.CollectorScope;
import net.minecraft.client.render.fog.FogRenderer.FogType;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WorldRenderer.class})
public abstract class ExtWorldRendererMixin {
   @ModifyArg(
      method = {"render"},
      at = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/debug/DebugRenderer;render(Lnet/minecraft/client/render/Frustum;DDDF)V"
      ),
      index = 0
   )
   private Frustum kaze$extRender3D(Frustum var1, @Local(argsOnly = true,ordinal = 0) Matrix4f var2, @Local(argsOnly = true,ordinal = 1) Matrix4f var3) {
      float var4 = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(false);
      TracerEngine.beginFrame(var2, var3);
      CollectorScope var5 = ShaderOverlay.capture();

      try {
         ExtBridge.render3D(var4, var1);
      } catch (Throwable var9) {
         if (var5 != null) {
            try {
               var5.close();
            } catch (Throwable var8) {
               var9.addSuppressed(var8);
            }
         }

         throw var9;
      }

      if (var5 != null) {
         var5.close();
      }

      return var1;
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void kaze$extOverlayAfterShaderPack(
      CallbackInfo var1,
      @Local(argsOnly = true) GpuBufferSlice var2,
      @Local(argsOnly = true) Camera var3,
      @Local(argsOnly = true,ordinal = 0) Matrix4f var4,
      @Local(argsOnly = true,ordinal = 1) Matrix4f var5
   ) {
      if (ShaderOverlay.pending()) {
         ShaderOverlay.render(var3, var4, var5, var2, kaze$onTopFog(var2, var3));
      }
   }

   @Unique
   private static GpuBufferSlice kaze$onTopFog(GpuBufferSlice var0, Camera var1) {
      return var1.getSubmersionType() == CameraSubmersionType.NONE
         ? var0
         : ((KazeGameRendererAccessor)MinecraftClient.getInstance().gameRenderer).kaze$getFogRenderer().getFogBuffer(FogType.NONE);
   }
}
