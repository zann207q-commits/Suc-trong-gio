package kaze.mixin;

import kaze.itemfx.ItemFx;
import net.minecraft.client.item.ItemModelManager;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.util.HeldItemContext;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.item.ItemDisplayContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ItemModelManager.class})
public abstract class ItemFxModelManagerMixin {
   @Inject(
      method = {"clearAndUpdate"},
      at = {@At("TAIL")}
   )
   private void kaze$tagFx(ItemRenderState var1, ItemStack var2, ItemDisplayContext var3, World var4, HeldItemContext var5, int var6, CallbackInfo var7) {
      try {
         ItemFx.tag(var1, var2, var3);
      } catch (Throwable var9) {
         System.err.println("Kaze: custom item tagging failed: " + var9);
      }
   }
}
