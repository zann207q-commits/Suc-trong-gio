package kaze.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import kaze.feature.CharacterRenderStateAccess;
import kaze.feature.WornCharacterModel;

@Environment(EnvType.CLIENT)
@Mixin({PlayerEntityRenderState.class})
public abstract class CharacterRenderStateMixin implements CharacterRenderStateAccess {
   @Unique
   private WornCharacterModel kaze$character;
   @Unique
   private float kaze$seat;

   @Override
   public WornCharacterModel kaze$character() {
      return this.kaze$character;
   }

   @Override
   public void kaze$setCharacter(WornCharacterModel var1) {
      this.kaze$character = var1;
   }

   @Override
   public float kaze$seat() {
      return this.kaze$seat;
   }

   @Override
   public void kaze$setSeat(float var1) {
      this.kaze$seat = var1;
   }
}
