package kaze.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.fog.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({GameRenderer.class})
public interface KazeGameRendererAccessor {
   @Invoker("getFov")
   float kaze$getFov(Camera var1, float var2, boolean var3);

   @Accessor("fogRenderer")
   FogRenderer kaze$getFogRenderer();

   @Invoker("shouldRenderBlockOutline")
   boolean kaze$shouldRenderBlockOutline();
}
