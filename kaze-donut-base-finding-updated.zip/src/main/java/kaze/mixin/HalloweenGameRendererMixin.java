package kaze.mixin;

import kaze.halloween.CinematicCamera;
import kaze.halloween.CinematicOverlay;
import kaze.halloween.Halloween;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import kaze.feature.HalloweenGhostOverlay;

@Mixin({GameRenderer.class})
public abstract class HalloweenGameRendererMixin {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   private void kaze$halloweenFrame(RenderTickCounter var1, boolean var2, CallbackInfo var3) {
      try {
         Halloween.frame();
      } catch (Throwable var5) {
         System.err.println("Kaze: Halloween frame failed: " + var5);
      }
   }

   @Inject(
      method = {"getFov"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void kaze$cinematicZoom(Camera var1, float var2, boolean var3, CallbackInfoReturnable<Float> var4) {
      if (var3 && CinematicCamera.active()) {
         var4.setReturnValue(CinematicCamera.fov(var4.getReturnValueF()));
      }
   }

   @Inject(
      method = {"tiltViewWhenHurt"},
      at = {@At("HEAD")}
   )
   private void kaze$beatShake(MatrixStack var1, float var2, CallbackInfo var3) {
      float var4 = HalloweenGhostOverlay.worldRoll();
      float var5 = HalloweenGhostOverlay.worldPitch();
      if (var4 != 0.0F || var5 != 0.0F) {
         var1.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(var4));
         var1.multiply(RotationAxis.POSITIVE_X.rotationDegrees(var5));
      }
   }

   @Inject(
      method = {"renderHand"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void kaze$hideHand(float var1, boolean var2, Matrix4f var3, CallbackInfo var4) {
      if (CinematicOverlay.hideHud()) {
         var4.cancel();
      }
   }
}
