package kaze.utils.ext;

import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongSet;
import kaze.utils.RenderVisibility;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.render.DrawStyle;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.ColorHelper;

@Environment(EnvType.CLIENT)
public final class ChunkOverlay {
   public static final double MARKER_Y = 63.0;
   private static final float EDGE_SHADE = 0.77F;
   private static final float LINE_WIDTH = 1.5F;

   private ChunkOverlay() {
   }

   public static void draw(LongSet var0, int var1, float var2) {
      if (!var0.isEmpty()) {
         DrawStyle var3 = DrawStyle.filled(var1);
         int var4 = ColorHelper.withAlpha(Math.min(255, ColorHelper.getAlpha(var1) * 3 / 2), ColorHelper.scaleRgb(var1, 0.77F));
         FoglessLines var5 = FoglessLines.forFrame(var2);
         LongIterator var6 = var0.iterator();

         while (var6.hasNext()) {
            long var7 = var6.next();
            int var9 = ChunkPos.getPackedX(var7);
            int var10 = ChunkPos.getPackedZ(var7);
            double var11 = (double)(var9 << 4);
            double var13 = (double)(var10 << 4);
            double var15 = var11 + 16.0;
            double var17 = var13 + 16.0;
            if (RenderVisibility.box(var11, 63.0, var13, var15, 63.0, var17)) {
               GizmoDrawing.box(new Box(var11, 63.0, var13, var15, 63.0, var17), var3).ignoreOcclusion();
               if (!var0.contains(ChunkPos.toLong(var9, var10 - 1))) {
                  edge(var5, var11, var13, var15, var13, var4);
               }

               if (!var0.contains(ChunkPos.toLong(var9, var10 + 1))) {
                  edge(var5, var11, var17, var15, var17, var4);
               }

               if (!var0.contains(ChunkPos.toLong(var9 - 1, var10))) {
                  edge(var5, var11, var13, var11, var17, var4);
               }

               if (!var0.contains(ChunkPos.toLong(var9 + 1, var10))) {
                  edge(var5, var15, var13, var15, var17, var4);
               }
            }
         }
      }
   }

   private static void edge(FoglessLines var0, double var1, double var3, double var5, double var7, int var9) {
      var0.line(new Vec3d(var1, 63.0, var3), new Vec3d(var5, 63.0, var7), var9, 1.5F);
   }
}
