package kaze.utils.embed;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class DiscordWebhook {
   private final String webhookUrl;
   private String content;
   private String username;
   private String avatarUrl;
   private boolean tts;
   private final List<DiscordWebhook.EmbedObject> embeds = new ArrayList<>();

   public DiscordWebhook(String webhookUrl) {
      this.webhookUrl = webhookUrl;
   }

   public void a(String content) {
      this.content = content;
   }

   public void b(String username) {
      this.username = username;
   }

   public void c(String avatarUrl) {
      this.avatarUrl = avatarUrl;
   }

   public void a(boolean tts) {
      this.tts = tts;
   }

   public void addEmbed(DiscordWebhook.EmbedObject embed) {
      this.embeds.add(embed);
   }

   public void execute() throws IOException {
   }

   private static String readResponse(InputStream input) throws IOException {
      if (input == null) {
         return "";
      } else {
         InputStream var1 = input;

         String var2;
         try {
            var2 = new String(input.readAllBytes(), StandardCharsets.UTF_8);
         } catch (Throwable var5) {
            if (input != null) {
               try {
                  var1.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }
            }

            throw var5;
         }

         if (input != null) {
            input.close();
         }

         return var2;
      }
   }

   public static record Author(String name, String url, String iconUrl) {
   }

   public static class EmbedObject {
      public String title;
      public String description;
      public String url;
      public Color color;
      public DiscordWebhook.Footer footer;
      public DiscordWebhook.Thumbnail thumbnail;
      public DiscordWebhook.Image image;
      public DiscordWebhook.Author author;
      public final List<DiscordWebhook.Field> fields = new ArrayList<>();

      public DiscordWebhook.EmbedObject setDescription(String value) {
         this.description = value;
         return this;
      }

      public DiscordWebhook.EmbedObject setColor(Color value) {
         this.color = value;
         return this;
      }

      public DiscordWebhook.EmbedObject setTitle(String value) {
         this.title = value;
         return this;
      }

      public DiscordWebhook.EmbedObject setUrl(String value) {
         this.url = value;
         return this;
      }

      public DiscordWebhook.EmbedObject setFooter(String text, String iconUrl) {
         this.footer = new DiscordWebhook.Footer(text, iconUrl);
         return this;
      }

      public DiscordWebhook.EmbedObject setImage(DiscordWebhook.Image value) {
         this.image = value;
         return this;
      }

      public DiscordWebhook.EmbedObject setThumbnail(String value) {
         this.thumbnail = new DiscordWebhook.Thumbnail(value);
         return this;
      }

      public DiscordWebhook.EmbedObject setAuthor(DiscordWebhook.Author value) {
         this.author = value;
         return this;
      }

      public DiscordWebhook.EmbedObject addField(String name, String value, boolean inline) {
         this.fields.add(new DiscordWebhook.Field(name, value, inline));
         return this;
      }

      private JsonObject toJson() {
         JsonObject json = new JsonObject();
         if (this.title != null) {
            json.addProperty("title", this.title);
         }

         if (this.description != null) {
            json.addProperty("description", this.description);
         }

         if (this.url != null) {
            json.addProperty("url", this.url);
         }

         if (this.color != null) {
            json.addProperty("color", this.color.getRed() << 16 | this.color.getGreen() << 8 | this.color.getBlue());
         }

         if (this.footer != null) {
            JsonObject child = new JsonObject();
            child.addProperty("text", this.footer.text());
            if (this.footer.iconUrl() != null) {
               child.addProperty("icon_url", this.footer.iconUrl());
            }

            json.add("footer", child);
         }

         if (this.image != null) {
            JsonObject child = new JsonObject();
            child.addProperty("url", this.image.url());
            json.add("image", child);
         }

         if (this.thumbnail != null) {
            JsonObject child = new JsonObject();
            child.addProperty("url", this.thumbnail.url());
            json.add("thumbnail", child);
         }

         if (this.author != null) {
            JsonObject child = new JsonObject();
            child.addProperty("name", this.author.name());
            if (this.author.url() != null) {
               child.addProperty("url", this.author.url());
            }

            if (this.author.iconUrl() != null) {
               child.addProperty("icon_url", this.author.iconUrl());
            }

            json.add("author", child);
         }

         if (!this.fields.isEmpty()) {
            JsonArray jsonFields = new JsonArray();

            for (DiscordWebhook.Field field : this.fields) {
               JsonObject childx = new JsonObject();
               childx.addProperty("name", field.a());
               childx.addProperty("value", field.b());
               childx.addProperty("inline", field.c());
               jsonFields.add(childx);
            }

            json.add("fields", jsonFields);
         }

         return json;
      }
   }

   public static record Field(String a, String b, boolean c) {
   }

   public static record Footer(String text, String iconUrl) {
   }

   public static record Image(String url) {
   }

   public static record Thumbnail(String url) {
   }
}
