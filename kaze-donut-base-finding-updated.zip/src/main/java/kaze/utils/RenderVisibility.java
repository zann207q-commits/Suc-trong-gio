package kaze.utils;

import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

public final class RenderVisibility {
   private static final FrustumIntersection FRUSTUM = new FrustumIntersection();
   private static final Matrix4f CLIP = new Matrix4f();
   private static double originX;
   private static double originY;
   private static double originZ;
   private static boolean ready;

   private RenderVisibility() {
   }

   public static void begin(Matrix4f var0, Matrix4f var1, double var2, double var4, double var6) {
      set(var0, var1, var2, var4, var6);
   }

   public static void beginWorldFrame(Matrix4fc var0, Matrix4fc var1) {
      Camera var2 = MinecraftClient.getInstance().gameRenderer.getCamera();
      if (var2 != null && var2.isReady()) {
         Vec3d var3 = var2.getCameraPos();
         set(var1, var0, var3.x, var3.y, var3.z);
      } else {
         disable();
      }
   }

   private static void set(Matrix4fc var0, Matrix4fc var1, double var2, double var4, double var6) {
      CLIP.set(var0).mul(var1);
      ready = CLIP.isFinite() && Double.isFinite(var2) && Double.isFinite(var4) && Double.isFinite(var6);
      if (ready) {
         FRUSTUM.set(CLIP);
         originX = var2;
         originY = var4;
         originZ = var6;
      }
   }

   public static void disable() {
      ready = false;
   }

   public static boolean box(double var0, double var2, double var4, double var6, double var8, double var10) {
      return !ready
         ? true
         : FRUSTUM.testAab(
            (float)(Math.min(var0, var6) - originX - 0.5),
            (float)(Math.min(var2, var8) - originY - 0.5),
            (float)(Math.min(var4, var10) - originZ - 0.5),
            (float)(Math.max(var0, var6) - originX + 0.5),
            (float)(Math.max(var2, var8) - originY + 0.5),
            (float)(Math.max(var4, var10) - originZ + 0.5)
         );
   }
}
