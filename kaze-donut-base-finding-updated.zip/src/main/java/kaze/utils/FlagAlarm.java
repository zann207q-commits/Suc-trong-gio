package kaze.utils;

import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public final class FlagAlarm {
   private static int remainingBeats;
   private static int ticksUntilNext;

   private FlagAlarm() {
   }

   public static void trigger(MinecraftClient client) {
      play(client, 0);
      remainingBeats = 5;
      ticksUntilNext = 7;
   }

   public static void tick(MinecraftClient client) {
      if (remainingBeats > 0) {
         if (--ticksUntilNext <= 0) {
            int beat = 5 - remainingBeats + 1;
            play(client, beat);
            remainingBeats--;
            ticksUntilNext = 7;
         }
      }
   }

   private static void play(MinecraftClient client, int beat) {
      float pitch = beat % 2 == 0 ? 0.72F : 0.92F;
      client.getSoundManager().play(PositionedSoundInstance.ui((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), pitch, 1.0F));
   }
}
