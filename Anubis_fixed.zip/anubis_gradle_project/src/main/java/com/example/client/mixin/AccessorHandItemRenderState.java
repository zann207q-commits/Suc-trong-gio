/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10444;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_10444.class})
public interface AccessorHandItemRenderState {
    @Accessor(value="field_55340")
    public class_10444.class_10446[] anubis$handLayers();

    @Accessor(value="field_55339")
    public int anubis$handLayerCount();
}

