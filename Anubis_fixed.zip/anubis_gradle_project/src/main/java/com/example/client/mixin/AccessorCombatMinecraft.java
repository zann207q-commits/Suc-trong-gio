/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_310.class})
public interface AccessorCombatMinecraft {
    @Accessor(value="field_1752")
    public int anubis$rightClickDelay();

    @Accessor(value="field_1752")
    public void anubis$setRightClickDelay(int var1);
}

