/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.anubis.client.module.impl.render.AtmosphereModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_758;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_758.class})
public abstract class MixinAtmosphereFogRenderer {
    @Inject(method={"method_62185"}, at={@At(value="RETURN")})
    private void anubis$fogColour(class_4184 camera, float partialTick, class_638 level, int renderDistance, float darkness, CallbackInfoReturnable<Vector4f> cir) {
        class_1309 living;
        if (camera.method_19334() != class_5636.field_27888 || darkness > 0.0f) {
            return;
        }
        class_1297 class_12972 = camera.method_19331();
        if (class_12972 instanceof class_1309 && ((living = (class_1309)class_12972).method_6059(class_1294.field_5919) || living.method_6059(class_1294.field_38092))) {
            return;
        }
        AtmosphereModule atmosphere = AtmosphereModule.get();
        if (atmosphere != null) {
            atmosphere.fog(camera, level, (Vector4f)cir.getReturnValue());
        }
    }
}

