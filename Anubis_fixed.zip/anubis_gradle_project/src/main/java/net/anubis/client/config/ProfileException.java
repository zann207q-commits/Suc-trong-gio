/*
 * Decompiled with CFR.
 */
package net.anubis.client.config;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class ProfileException
extends Exception {
    public ProfileException(String message) {
        super(message);
    }
}

