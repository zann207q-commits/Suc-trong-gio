/*
 * Decompiled with CFR.
 */
package net.anubis.client.module;

import java.util.List;
import net.anubis.client.module.ClientModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface ModuleProvider {
    public String id();

    public List<ClientModule> createModules();
}

