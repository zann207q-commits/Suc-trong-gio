/*
 * Decompiled with CFR.
 */
package net.anubis.client.event;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.anubis.client.event.EventPriority;
import net.anubis.client.event.Stage;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.METHOD})
@Environment(value=EnvType.CLIENT)
public @interface EventHandler {
    public EventPriority priority() default EventPriority.NORMAL;

    public Stage stage() default Stage.PRE;
}

