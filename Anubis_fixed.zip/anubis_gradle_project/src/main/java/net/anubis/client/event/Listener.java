/*
 * Decompiled with CFR.
 */
package net.anubis.client.event;

import net.anubis.client.event.Event;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@FunctionalInterface
@Environment(value=EnvType.CLIENT)
public interface Listener<E extends Event> {
    public void invoke(E var1);
}

