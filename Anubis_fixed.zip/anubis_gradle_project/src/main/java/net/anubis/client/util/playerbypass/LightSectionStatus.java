/*
 * Decompiled with CFR.
 */
package net.anubis.client.util.playerbypass;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public enum LightSectionStatus {
    NORMAL,
    EMPTY_MASK,
    ZEROED_PRESENT,
    UNIFORM_MAX,
    UNKNOWN;

}

