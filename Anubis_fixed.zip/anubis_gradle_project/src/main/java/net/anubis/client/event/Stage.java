/*
 * Decompiled with CFR.
 */
package net.anubis.client.event;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public enum Stage {
    PRE,
    POST;

}

