/*
 * Decompiled with CFR.
 */
package net.anubis.client.util.pvp;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public record Rotation(float yaw, float pitch) {
}

