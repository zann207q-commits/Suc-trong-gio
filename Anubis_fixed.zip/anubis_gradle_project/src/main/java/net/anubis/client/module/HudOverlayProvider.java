/*
 * Decompiled with CFR.
 */
package net.anubis.client.module;

import imgui.ImDrawList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public interface HudOverlayProvider {
    public boolean isHudOverlayEnabled();

    public void renderHudOverlay(ImDrawList var1, float var2, float var3);
}

