/*
 * Decompiled with CFR.
 */
package net.anubis.client.util.seedscan;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
final class WgRandom {
    private long lo;
    private long hi;

    WgRandom() {
    }

    private WgRandom(long lo, long hi) {
        this.lo = lo;
        this.hi = hi;
    }

    WgRandom copy() {
        return new WgRandom(this.lo, this.hi);
    }

    boolean sameState(WgRandom other) {
        return this.lo == other.lo && this.hi == other.hi;
    }

    long stateHash() {
        return this.lo * 31L + this.hi;
    }

    private static long mix(long l) {
        l = (l ^ l >>> 30) * -4658895280553007687L;
        l = (l ^ l >>> 27) * -7723592293110705685L;
        return l ^ l >>> 31;
    }

    void setSeed(long seed) {
        long m = seed ^ 0x6A09E667F3BCC909L;
        long n = m + -7046029254386353131L;
        this.lo = WgRandom.mix(m);
        this.hi = WgRandom.mix(n);
        if ((this.lo | this.hi) == 0L) {
            this.lo = -7046029254386353131L;
            this.hi = 7640891576956012809L;
        }
    }

    private long step() {
        long l = this.lo;
        long m = this.hi;
        long n = Long.rotateLeft(l + m, 17) + l;
        this.lo = Long.rotateLeft(l, 49) ^ (m ^= l) ^ m << 21;
        this.hi = Long.rotateLeft(m, 28);
        return n;
    }

    void skip(int steps) {
        for (int i = 0; i < steps; ++i) {
            this.step();
        }
    }

    int next(int bits) {
        return (int)(this.step() >>> 64 - bits);
    }

    int nextInt(int bound) {
        int k;
        int j;
        if ((bound & bound - 1) == 0) {
            return (int)((long)bound * (long)this.next(31) >> 31);
        }
        while ((j = this.next(31)) - (k = j % bound) + (bound - 1) < 0) {
        }
        return k;
    }

    int between(int min, int max) {
        return this.nextInt(max - min + 1) + min;
    }

    long nextLong() {
        int i = this.next(32);
        int j = this.next(32);
        return ((long)i << 32) + (long)j;
    }

    float nextFloat() {
        return (float)this.next(24) * 5.9604645E-8f;
    }

    double nextDouble() {
        int i = this.next(26);
        int j = this.next(27);
        return (double)(((long)i << 27) + (long)j) * (double)1.110223E-16f;
    }

    long setDecorationSeed(long worldSeed, int blockX, int blockZ) {
        this.setSeed(worldSeed);
        long m = this.nextLong() | 1L;
        long n = this.nextLong() | 1L;
        long seed = (long)blockX * m + (long)blockZ * n ^ worldSeed;
        this.setSeed(seed);
        return seed;
    }

    void setFeatureSeed(long decorationSeed, int index, int step) {
        this.setSeed(decorationSeed + (long)index + 10000L * (long)step);
    }
}

