/*
 * Decompiled with CFR.
 */
package net.anubis.client.module.impl.client;

import imgui.ImDrawList;
import imgui.ImFont;
import java.util.Locale;
import net.anubis.client.esp.ChunkScanner;
import net.anubis.client.event.impl.Render3DEvent;
import net.anubis.client.gui.AnubisWidgets;
import net.anubis.client.imgui.ImGuiManager;
import net.anubis.client.module.ClientModule;
import net.anubis.client.module.HudOverlayProvider;
import net.anubis.client.module.ModuleCategory;
import net.anubis.client.module.ModuleRegistry;
import net.anubis.client.module.setting.BooleanSetting;
import net.anubis.client.module.setting.NumberSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(value=EnvType.CLIENT)
public final class PerformanceModule
extends ClientModule
implements HudOverlayProvider {
    private final BooleanSetting frustumCulling = this.addSetting("frustum-culling", new BooleanSetting("Frustum Culling", true));
    private final NumberSetting scanBudget = this.addSetting("scan-budget-ms", new NumberSetting("Scan Budget ms", 2.0f, 0.5f, 8.0f).step(0.5f));
    private long smoothedNanos;

    public PerformanceModule() {
        super("performance", "Performance", "Render performance settings.", ModuleCategory.CLIENT);
    }

    public static boolean frustumCulling() {
        PerformanceModule module = ModuleRegistry.get(PerformanceModule.class);
        return module == null || module.frustumCulling.get();
    }

    public static long scanBudgetNanos() {
        PerformanceModule module = ModuleRegistry.get(PerformanceModule.class);
        return module == null ? 2000000L : (long)(module.scanBudget.get() * 1000000.0f);
    }

    @Override
    public boolean isHudOverlayEnabled() {
        return this.isEnabled();
    }

    @Override
    public void renderHudOverlay(ImDrawList dl, float screenW, float screenH) {
        this.smoothedNanos += (Render3DEvent.lastDurationNanos() - this.smoothedNanos) / 8L;
        String text = String.format(Locale.ROOT, "3D listeners %.2f ms  \u00b7  scan queue %d", (double)this.smoothedNanos / 1000000.0, ChunkScanner.pending());
        ImFont font = ImGuiManager.getInstance().hudLabelFont();
        float x = screenW - AnubisWidgets.textWidth(font, text) - 8.0f;
        float y = screenH - AnubisWidgets.lineHeight(font) - 6.0f;
        AnubisWidgets.text(dl, font, x + 1.0f, y + 1.0f, -1610612736, text);
        AnubisWidgets.text(dl, font, x, y, -3618616, text);
    }
}

