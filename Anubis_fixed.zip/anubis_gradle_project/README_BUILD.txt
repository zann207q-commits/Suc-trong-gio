Anubis Beta 0.9.9 - experimental Gradle project scaffold

This ZIP adds a standard Gradle/Fabric Loom project layout around the decompiled source and the ARM64 render-hook guard.

Requirements:
- JDK 21
- Gradle 8.x (recommended: install Gradle locally; no wrapper JAR is included)
- Internet access for Gradle to resolve Minecraft/Fabric dependencies

Build attempt:
  gradle build

Important limitations:
- This was decompiled with CFR, not recovered from the original source repository.
- Some methods in summary.txt were not fully decompiled by CFR and may not compile correctly.
- The source uses intermediary Minecraft class names; mappings/dependencies may still need adjustment for the exact Minecraft 1.21.11 toolchain.
- The project has not been built or tested. A successful Gradle configuration is not guaranteed, and no working JAR is promised.
- The ARM64 patch only skips the ImGui render call on ARM64; it does not provide an Android ARM64 ImGui native library or guarantee that all modules/UI work in Zalith.
- Do not overwrite the original JAR. Test any resulting build separately.
