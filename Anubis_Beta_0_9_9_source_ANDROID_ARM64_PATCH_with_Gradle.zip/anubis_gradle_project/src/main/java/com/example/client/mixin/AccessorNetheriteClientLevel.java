/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_638;
import net.minecraft.class_7202;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_638.class})
public interface AccessorNetheriteClientLevel {
    @Accessor(value="field_37951")
    public class_7202 anubis$blockStatePredictionHandler();
}

