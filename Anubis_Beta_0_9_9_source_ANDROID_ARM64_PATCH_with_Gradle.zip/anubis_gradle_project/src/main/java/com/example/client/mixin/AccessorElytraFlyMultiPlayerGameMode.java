/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_636.class})
public interface AccessorElytraFlyMultiPlayerGameMode {
    @Invoker(value="method_2911")
    public void anubis$elytraFlySyncSelected();
}

