/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_374;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_374.class})
public interface AccessorHudToastManager {
    @Accessor(value="field_2239")
    public List<?> anubis$hudVisibleToasts();
}

