/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(targets={"net/minecraft/class_1796$class_1797"})
public interface AccessorHudCooldownInstance {
    @Accessor(value="comp_3083")
    public int anubis$hudStartTime();

    @Accessor(value="comp_3084")
    public int anubis$hudEndTime();
}

