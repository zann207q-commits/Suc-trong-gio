/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_746.class})
public interface AccessorLocalPlayer {
    @Accessor(value="field_3923")
    public void anubis$setPositionReminder(int var1);

    @Accessor(value="field_3919")
    public boolean anubis$wasSprinting();

    @Accessor(value="field_54156")
    public class_10185 anubis$lastSentInput();
}

