/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1796;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1796.class})
public interface AccessorHudItemCooldowns {
    @Accessor(value="field_8024")
    public Map<class_2960, ?> anubis$hudCooldowns();

    @Accessor(value="field_8025")
    public int anubis$hudTickCount();
}

