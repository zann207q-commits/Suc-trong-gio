/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_4970.class})
public interface AccessorElytraFlyBlockBehaviour {
    @Accessor(value="field_23159")
    public boolean anubis$elytraFlyHasCollision();
}

