/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1917;
import net.minecraft.class_1952;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1917.class})
public interface AccessorSpawnerNametagsBaseSpawner {
    @Accessor(value="field_9155")
    public class_1952 anubis$spawnerNametagsNextSpawnData();

    @Accessor(value="field_9158")
    public int anubis$spawnerNametagsRequiredPlayerRange();
}

