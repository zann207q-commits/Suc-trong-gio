/*
 * Decompiled with CFR.
 */
package com.example.client.mixin;

import net.anubis.client.imgui.ImGuiManager;
import net.anubis.client.module.impl.misc.noinvleak.StreamOverlay;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1041;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(value=EnvType.CLIENT)
@Mixin(value={class_1041.class})
public abstract class MixinGameRenderer {
    @Inject(method={"method_15998"}, at={@At(value="HEAD")})
    private void anubis$beforeSwap(CallbackInfo ci) {
        // Zalith/Android runs on ARM64. This build bundles desktop ImGui natives
        // (x86_64/Windows/macOS/Linux), so do not enter the ImGui/stream overlay
        // render path on ARM64 or the client can crash with UnsatisfiedLinkError.
        String arch = System.getProperty("os.arch", "");
        if (arch.equalsIgnoreCase("aarch64") || arch.equalsIgnoreCase("arm64")) {
            return;
        }

        StreamOverlay.endFrame();
        ImGuiManager.getInstance().renderIfActive();
    }
}

